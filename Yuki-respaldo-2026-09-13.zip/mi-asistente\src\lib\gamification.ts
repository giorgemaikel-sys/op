import type { UserStats } from './types'

export function emptyStats(): UserStats {
  return { streak: 0, bestStreak: 0, lastActive: '', days: 0, messages: 0, achievements: [] }
}

function todayStr(): string {
  return new Date().toISOString().slice(0, 10)
}

export interface Achievement {
  id: string
  name: string
  emoji: string
  desc: string
}

export const ACHIEVEMENTS: Achievement[] = [
  { id: 'first', name: 'Primer paso', emoji: '👣', desc: 'Enviaste tu primer mensaje' },
  { id: 'msg10', name: 'Conversador', emoji: '💬', desc: '10 mensajes enviados' },
  { id: 'msg50', name: 'Charlatán', emoji: '🗣️', desc: '50 mensajes enviados' },
  { id: 'msg200', name: 'Imparable', emoji: '🚀', desc: '200 mensajes enviados' },
  { id: 'streak3', name: 'Constante', emoji: '🔥', desc: '3 días seguidos' },
  { id: 'streak7', name: 'Semana completa', emoji: '📅', desc: '7 días seguidos' },
  { id: 'streak30', name: 'Maestro del hábito', emoji: '🏆', desc: '30 días seguidos' },
]

/** Registra actividad de hoy; devuelve stats actualizadas y los logros recién ganados. */
export function recordActivity(stats: UserStats): {
  stats: UserStats
  unlocked: Achievement[]
} {
  const today = todayStr()
  const s: UserStats = {
    ...emptyStats(),
    ...stats,
    achievements: [...(stats?.achievements || [])],
  }
  s.messages += 1
  if (s.lastActive !== today) {
    const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10)
    s.streak = s.lastActive === yesterday ? s.streak + 1 : 1
    s.days += 1
    s.lastActive = today
    if (s.streak > s.bestStreak) s.bestStreak = s.streak
  }
  const unlocked: Achievement[] = []
  const unlock = (id: string) => {
    if (!s.achievements.includes(id)) {
      s.achievements.push(id)
      const a = ACHIEVEMENTS.find((x) => x.id === id)
      if (a) unlocked.push(a)
    }
  }
  if (s.messages >= 1) unlock('first')
  if (s.messages >= 10) unlock('msg10')
  if (s.messages >= 50) unlock('msg50')
  if (s.messages >= 200) unlock('msg200')
  if (s.streak >= 3) unlock('streak3')
  if (s.streak >= 7) unlock('streak7')
  if (s.streak >= 30) unlock('streak30')
  return { stats: s, unlocked }
}
