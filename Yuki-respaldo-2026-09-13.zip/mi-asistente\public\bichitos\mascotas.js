/* Bichitos de escritorio - overlay para CUALQUIER pagina web (bookmarklet).
 * Se carga desde Yuki y suelta los bichitos sobre la pagina actual.
 * Nota: en sitios con seguridad estricta (Google Classroom/Docs, YouTube) el
 * navegador bloquea esto; funciona en la mayoria de los demas sitios.
 * Volver a tocar el marcador los quita (toggle). Texto en escapes ASCII. */
(function () {
  'use strict'
  if (window.__bichitos && window.__bichitos.destroy) {
    try { window.__bichitos.destroy() } catch (e) { /* noop */ }
    window.__bichitos = null
    return
  }

  var ORIGIN = (function () {
    try { return new URL(document.currentScript.src).origin } catch (e) { return '' }
  })()
  var BASE = ORIGIN + '/bichitos'

  var GRAVITY = 1.8, WALK = 1.5, FLOAT = 0.95, CLIMB = 1.6
  var JUMP_V = 16.0, JUMP_VX = 3.2, P_SEEK = 0.013, P_JUMP = 0.006, P_GRAPPLE = 0.004
  var TICK_MS = 40
  var DPR = Math.max(1, Math.min(3, Math.round(window.devicePixelRatio || 1)))

  var CHARACTERS = {
    gato: { name: 'Gato', flies: false, image: 'gato', frames: 8, base_h: 80, native: 1, special_rate: 0.012,
      specials: [ { name: 'play', dir: 'gato_play', frames: 4, loops: 3, cd: 220, speed: 6 },
        { name: 'dormir', dir: 'gato_dormir', frames: 6, kind: 'sleep', h: 60, loops: 6, speed: 10 } ] },
    perro: { name: 'Perro', flies: false, image: 'perro', frames: 6, base_h: 86, native: 1,
      jump_image: 'perro_salto', jump_frames: 10, jump_h: 116,
      specials: [ { name: 'dormir', dir: 'perro_dormir', frames: 6, kind: 'sleep', h: 56, loops: 6, speed: 10 } ] },
    conejo: { name: 'Conejo', flies: false, image: 'conejo', frames: 12, base_h: 84, native: 1,
      specials: [ { name: 'dormir', dir: 'conejo_dormir', frames: 4, kind: 'sleep', h: 80, loops: 1, hold: 150, speed: 14 } ] },
    elfa: { name: 'Elfa', flies: false, image: 'elfa', frames: 8, base_h: 104, native: 1, special_rate: 0.010,
      specials: [ { name: 'disparo', dir: 'elfa_shoot', frames: 6, h: 102, cx_frac: 0.42, loops: 1, cd: 450, speed: 8,
          shoot: { at: 4, speed: 12.0, arrow: 'flecha' } },
        { name: 'dormir', dir: 'elfa_dormir', frames: 4, kind: 'sleep', h: 76, loops: 1, hold: 150, speed: 14 } ] },
    dino: { name: 'Dinosaurio', flies: false, image: 'dino', frames: 8, base_h: 90, native: 1, special_rate: 0.007,
      specials: [ { name: 'llora', dir: 'dino_llora', frames: 6, loops: 1, cd: 800, weight: 1, speed: 7 },
        { name: 'feliz', dir: 'dino_feliz', frames: 3, loops: 2, cd: 800, weight: 2, speed: 8 },
        { name: 'dormir', dir: 'dino_dormir', frames: 4, kind: 'sleep', h: 82, loops: 1, hold: 150, speed: 14 } ] },
    robot: { name: 'Robot', flies: false, image: 'robot', frames: 3, base_h: 80, native: 1,
      grapple_image: 'robot_grapple', grapple_frames: 9, grapple_h: 80, grapple_cx_frac: 0.21,
      specials: [ { name: 'dormir', dir: 'robot_dormir', frames: 4, kind: 'sleep', h: 80, loops: 1, hold: 150, speed: 14 } ] },
    claude: { name: 'Claude', flies: false, draw: 'claude' },
    fantasma: { name: 'Fantasma', flies: true, image: 'fantasma', frames: 4, base_h: 96, native: 1, special_rate: 0.006,
      specials: [ { name: 'susto', dir: 'fantasma_susto', frames: 6, loops: 1, cd: 700, speed: 6 },
        { name: 'dormir', dir: 'fantasma_dormir', frames: 4, kind: 'sleep', h: 150, loops: 1, hold: 150, speed: 14, goto: 'top' } ] },
    colibri: { name: 'Colibrí', flies: true, image: 'colibri', frames: 6, base_h: 80, native: 1, special_rate: 0.007,
      specials: [ { name: 'canta', dir: 'colibri_canta', frames: 3, loops: 3, cd: 600, speed: 6 },
        { name: 'dormir', dir: 'colibri_dormir', frames: 3, kind: 'sleep', h: 74, loops: 1, hold: 150, speed: 14, goto: 'floor' } ] },
    pollito: { name: 'Pollito', flies: false, image: 'pollito', frames: 16, base_h: 96, native: 1,
      specials: [ { name: 'dormir', dir: 'pollito_dormir', frames: 4, kind: 'sleep', h: 86, loops: 1, hold: 150, speed: 14 } ] },
    esqueleto: { name: 'Esqueleto', flies: false, image: 'esqueleto', frames: 6, base_h: 94, native: 1, special_rate: 0.006,
      specials: [ { name: 'dormir', dir: 'esqueleto_dormir', frames: 5, h: 94, cx_frac: 0.5, kind: 'sleep', loops: 1, speed: 12, hold: 150 } ] },
  }
  var ORDER = ['pollito', 'gato', 'perro', 'conejo', 'elfa', 'dino', 'robot', 'claude', 'fantasma', 'colibri', 'esqueleto']
  var COLORS = { pollito: '#ffd23f', gato: '#f4a24c', perro: '#d2a679', conejo: '#9aa6c8', elfa: '#b39ddb',
    dino: '#6cbf6c', robot: '#b8c0cc', claude: '#d97757', fantasma: '#c9c2ea', colibri: '#b8a9e0', esqueleto: '#d9d2c5' }

  var rand = Math.random
  function randint(a, b) { return Math.floor(rand() * (b - a + 1)) + a }
  function choice(a) { return a[Math.floor(rand() * a.length)] }
  function choices(o, w) { var t = 0, i; for (i = 0; i < w.length; i++) t += w[i]; var r = rand() * t; for (i = 0; i < o.length; i++) { r -= w[i]; if (r <= 0) return o[i] } return o[o.length - 1] }

  var _cache = {}
  function loadSprite(name, frames) {
    if (_cache[name]) return _cache[name]
    var spr = { name: name, n: frames, ok: false, w: 0, h: 0, imgs: [] }
    for (var i = 0; i < frames; i++) {
      var img = new Image()
      img.decoding = 'async'
      img.src = BASE + '/' + name + '/' + i + '.png'
      if (i === 0) { (function (im) { im.onload = function () { spr.w = im.naturalWidth; spr.h = im.naturalHeight; spr.ok = true } })(img) }
      spr.imgs.push(img)
    }
    _cache[name] = spr
    return spr
  }
  function sizeFor(spr, th) { if (!spr || !spr.ok || !spr.h) return [th, th]; return [Math.max(1, Math.round(spr.w * th / spr.h)), th] }

  function makeDraw(ctx, facing, cx) {
    var fx = function (x) { return facing < 0 ? 2 * cx - x : x }
    return {
      rrect: function (x1, y1, x2, y2, r, fill) {
        var a = fx(x1), b = fx(x2), L = Math.min(a, b), R = Math.max(a, b)
        var rr = Math.min(r, (R - L) / 2, (y2 - y1) / 2)
        ctx.beginPath(); ctx.moveTo(L + rr, y1); ctx.arcTo(R, y1, R, y2, rr); ctx.arcTo(R, y2, L, y2, rr); ctx.arcTo(L, y2, L, y1, rr); ctx.arcTo(L, y1, R, y1, rr); ctx.closePath(); ctx.fillStyle = fill; ctx.fill()
      },
      line: function (x1, y1, x2, y2, fill, w) { ctx.beginPath(); ctx.moveTo(fx(x1), y1); ctx.lineTo(fx(x2), y2); ctx.strokeStyle = fill; ctx.lineWidth = w || 2; ctx.lineCap = 'round'; ctx.stroke() },
      dot: function (x, y, r, fill) { ctx.beginPath(); ctx.ellipse(fx(x), y, r, r, 0, 0, Math.PI * 2); ctx.fillStyle = fill; ctx.fill() },
    }
  }
  function drawClaude(ctx, W, H, facing, state, phase, blink) {
    var sx = W * DPR / 100, sy = H * DPR / 100
    ctx.setTransform(sx, 0, 0, sy, 0, 0); ctx.clearRect(0, 0, 100, 100)
    var oy = state === 'sit' || state === 'sleep' ? 8 : 0
    var s = state === 'walk' ? (phase % 2 === 0 ? 3 : -3) : 0
    var body = '#d97757', dark = '#c15f3f', closed = blink || state === 'sleep'
    var D = makeDraw(ctx, facing, 50)
    var eye = function (x, y) { if (closed) D.line(x - 3, y, x + 3, y, '#5a2c1c', 2); else D.dot(x, y, 2.6, '#5a2c1c') }
    D.rrect(41 - s, 70 + oy, 48 - s, 88, 3, dark); D.rrect(52 + s, 70 + oy, 59 + s, 88, 3, dark)
    D.rrect(26, 52 + oy, 33, 70 + oy, 3, body); D.rrect(67, 52 + oy, 74, 70 + oy, 3, body)
    D.rrect(30, 42 + oy, 70, 78 + oy, 17, body)
    var cx0 = 50, cy0 = 30 + oy, ang
    for (ang = 0; ang < 360; ang += 45) { var rd = ang * Math.PI / 180; D.line(cx0, cy0, cx0 + 11 * Math.cos(rd), cy0 + 11 * Math.sin(rd), dark, 2) }
    D.dot(cx0, cy0, 4, '#f0a077'); eye(43, 56 + oy); eye(57, 56 + oy)
    D.dot(38, 62 + oy, 3, '#ffb59a'); D.dot(62, 62 + oy, 3, '#ffb59a')
    if (!closed) D.line(44, 64 + oy, 56, 64 + oy, '#5a2c1c', 2)
  }

  function Pet(world, key) {
    this.world = world; this.key = key; this.spec = CHARACTERS[key]; this.flies = this.spec.flies
    this.isImage = !!this.spec.image; this.nFrames = this.spec.frames || 1; this.baseH = this.spec.base_h || 92
    this.native = this.spec.native_facing || this.spec.native || 1; this.specialRate = this.spec.special_rate != null ? this.spec.special_rate : 0.01
    this.scale = world.scale; this.facing = choice([-1, 1]); this.animEvery = this.flies ? 2 : this.isImage ? 3 : 7
    this.sprite = null; this.jumpSprite = null; this.jumpFrames = 0; this.jumpH = 0; this.hasJump = false
    this.grappleSprite = null; this.grappleFrames = 0; this.grappleH = 0; this.grappleCxFrac = 0.5; this.hasGrapple = false
    this.animSpecials = []; this.sleepSpecial = null
    this.W = 40; this.H = 40; this.cx = 20; this.ground = 40; this.anim = 0; this.animSub = 0
    this.blink = false; this.blinkLeft = 0; this.vy = 0; this.vx = 0; this.support = 0; this.state = 'walk'; this.active = 'walk'
    this.timer = 60; this.x = 0; this.y = 0; this.hoverY = 0; this.targetY = 0
    this.jumpCd = 0; this.grappleCd = 0; this.grappleIdx = 0; this.grappleSub = 0
    this.climbCd = 0; this.climbDir = 0; this.climbTop = 0; this.climbHold = 0; this.climbHoldMax = 0
    this.seekSide = 'L'; this.seekX = 0; this.curSpecial = null; this.specialIdx = 0; this.specialSub = 0
    this.specialReturn = 'walk'; this.specialShot = false; this.specialHold = 0; this.pendingSleep = null
    this.sleepTx = 0; this.sleepTy = 0; this.needResize = false; this.dragOff = [0, 0]

    if (this.isImage) {
      this.sprite = loadSprite(this.spec.image, this.nFrames)
      if (this.spec.jump_image) { this.jumpSprite = loadSprite(this.spec.jump_image, this.spec.jump_frames || 0); this.jumpFrames = this.spec.jump_frames || 0; this.jumpH = this.spec.jump_h || this.baseH; this.hasJump = true }
      if (this.spec.grapple_image) { this.grappleSprite = loadSprite(this.spec.grapple_image, this.spec.grapple_frames || 0); this.grappleFrames = this.spec.grapple_frames || 0; this.grappleH = this.spec.grapple_h || this.baseH; this.grappleCxFrac = this.spec.grapple_cx_frac != null ? this.spec.grapple_cx_frac : 0.5; this.hasGrapple = true }
      var specs = this.spec.specials || [], j
      for (j = 0; j < specs.length; j++) {
        var sp = specs[j], spr = loadSprite(sp.dir, sp.frames)
        var e = { name: sp.name, sprite: spr, frames: sp.frames, h: sp.h != null ? sp.h : this.baseH, cx_frac: sp.cx_frac != null ? sp.cx_frac : 0.5, loops: sp.loops != null ? sp.loops : 1, cd: sp.cd != null ? sp.cd : 300, weight: sp.weight != null ? sp.weight : 1, speed: sp.speed != null ? sp.speed : 6, shoot: sp.shoot, hold: sp.hold != null ? sp.hold : 0, goto: sp.goto, cd_left: 0 }
        if (sp.kind === 'sleep') this.sleepSpecial = e; else this.animSpecials.push(e)
      }
    }

    var el = document.createElement('div')
    el.className = 'yuki-pet'
    el.style.cssText = 'position:absolute;left:0;top:0;pointer-events:auto;cursor:grab;touch-action:none;user-select:none;-webkit-user-select:none;will-change:transform;'
    this.el = el
    if (this.isImage) {
      this.img = document.createElement('img'); this.img.draggable = false
      this.img.style.cssText = 'position:absolute;left:0;top:0;width:100%;height:100%;pointer-events:none;'
      el.appendChild(this.img); this.canvas = null; this.ctx = null
    } else {
      this.canvas = document.createElement('canvas')
      this.canvas.style.cssText = 'position:absolute;left:0;top:0;width:100%;height:100%;pointer-events:none;'
      this.ctx = this.canvas.getContext('2d'); el.appendChild(this.canvas); this.img = null
    }
    this.zzz = document.createElement('span'); this.zzz.textContent = '💤'
    this.zzz.style.cssText = 'position:absolute;top:-6px;right:-6px;font-size:16px;pointer-events:none;display:none;'
    el.appendChild(this.zzz)

    this.recomputeMetrics(); this.resizeEl()
    var b = world.bounds
    if (this.flies) {
      this.hoverY = Math.max(b.top0 + 10, b.floor - 150); this.x = rand() * Math.max(0, b.b2 - this.W)
      this.y = this.hoverY; this.targetY = this.hoverY; this.vx = FLOAT * this.facing; this.state = 'float'
    } else {
      var fx = b.b0 + this.cx + 4 + rand() * Math.max(1, b.b2 - b.b0 - 2 * this.cx - 8)
      this.x = fx - this.cx; this.y = b.floor - this.ground; this.vx = WALK * this.facing; this.state = 'walk'
    }
    this.timer = randint(50, 130); this.apply()
    var self = this
    this._down = function (e) { self.onDown(e) }
    el.addEventListener('pointerdown', this._down)
  }
  Pet.prototype.activeSprite = function () {
    if (this.active === 'jump' && this.hasJump) return [this.jumpSprite, this.jumpH]
    if (this.active === 'grapple' && this.hasGrapple) return [this.grappleSprite, this.grappleH]
    if (this.active === 'special' && this.curSpecial) return [this.curSpecial.sprite, this.curSpecial.h]
    return [this.sprite, this.baseH]
  }
  Pet.prototype.recomputeMetrics = function () {
    if (this.isImage) {
      var a = this.activeSprite(), spr = a[0], bh = a[1]
      var th = Math.max(26, Math.round(bh * this.scale)), sz = sizeFor(spr, th)
      this.W = sz[0]; this.H = sz[1]
      if (this.active === 'grapple' && this.hasGrapple) { var f = this.grappleCxFrac; if (this.facing !== this.native) f = 1 - f; this.cx = f * sz[0] }
      else if (this.active === 'special' && this.curSpecial) { var f2 = this.curSpecial.cx_frac; if (this.facing !== this.native) f2 = 1 - f2; this.cx = f2 * sz[0] }
      else this.cx = sz[0] / 2
      this.ground = sz[1]; this.needResize = !(spr && spr.ok)
    } else { this.W = Math.max(26, Math.round(100 * this.scale)); this.H = this.W; this.cx = 50 * this.scale; this.ground = 88 * this.scale; this.needResize = false }
  }
  Pet.prototype.resizeEl = function () {
    this.el.style.width = this.W + 'px'; this.el.style.height = this.H + 'px'
    if (this.canvas) { this.canvas.width = Math.max(1, Math.round(this.W * DPR)); this.canvas.height = Math.max(1, Math.round(this.H * DPR)) }
  }
  Pet.prototype.setScale = function (ns) { var fx = this.x + this.cx, fy = this.y + this.ground; this.scale = ns; this.recomputeMetrics(); this.resizeEl(); this.x = fx - this.cx; this.y = fy - this.ground; this.apply() }
  Pet.prototype.switchActive = function (k) { var fx = this.x + this.cx, fy = this.y + this.ground; this.active = k; this.recomputeMetrics(); this.resizeEl(); this.x = fx - this.cx; this.y = fy - this.ground; this.apply() }
  Pet.prototype.apply = function () { this.el.style.transform = 'translate(' + Math.round(this.x) + 'px,' + Math.round(this.y) + 'px)' }
  Pet.prototype.onDown = function (e) {
    e.preventDefault(); e.stopPropagation(); var self = this
    try { this.el.setPointerCapture(e.pointerId) } catch (x) { /* noop */ }
    this.state = 'drag'; this.support = null; this.dragOff = [e.clientX - this.x, e.clientY - this.y]; this.el.style.cursor = 'grabbing'
    this._move = function (ev) { if (self.state !== 'drag') return; var b = self.world.bounds; self.x = Math.min(Math.max(ev.clientX - self.dragOff[0], b.b0 - 60), b.b2 + 60 - self.W); self.y = Math.min(Math.max(ev.clientY - self.dragOff[1], b.top0 - 60), b.bottom0 + 20); self.apply() }
    this._up = function () { self.el.removeEventListener('pointermove', self._move); self.el.removeEventListener('pointerup', self._up); self.el.removeEventListener('pointercancel', self._up); self.el.style.cursor = 'grab'; if (self.flies) self.state = 'return'; else { self.vy = 0; self.state = 'fall'; self.support = null } }
    this.el.addEventListener('pointermove', this._move); this.el.addEventListener('pointerup', this._up); this.el.addEventListener('pointercancel', this._up)
  }
  Pet.prototype.update = function () {
    var spd = Math.max(0.05, this.world.speed); this.blinkTick()
    if (this.needResize) { var a = this.activeSprite(); if (a[0] && a[0].ok) this.switchActive(this.active) }
    if (this.state === 'drag') { this.advanceAnim(); this.redraw(); return }
    if (this.state === 'gosleep') { this.gosleepStep(); this.redraw(); return }
    if (this.state === 'special') { this.specialStep(); this.redraw(); return }
    if (this.flies) { this.updateFlyer(spd); this.advanceAnim() } else { this.updateWalker(spd); this.advanceAnim() }
    this.apply(); this.redraw()
  }
  Pet.prototype.blinkTick = function () { if (this.blinkLeft > 0) { this.blinkLeft--; this.blink = true } else { this.blink = false; if (this.state !== 'sleep' && rand() < 0.012) this.blinkLeft = 4 } }
  Pet.prototype.advanceAnim = function () { this.animSub++; if (this.animSub >= this.animEvery) { this.animSub = 0; this.anim++ } }
  Pet.prototype.updateWalker = function (spd) {
    var b = this.world.bounds
    if (this.state === 'fall') { this.vy += GRAVITY; this.y += this.vy; var fy = this.y + this.ground; if (fy >= b.floor) { this.support = 0; this.y = b.floor - this.ground; this.vy = 0; this.state = choice(['idle', 'walk']); this.vx = WALK * this.facing; this.timer = randint(40, 110) } return }
    if (this.state === 'climb') { this.climbStep(spd); return }
    if (this.state === 'seek') { this.seekStep(spd); return }
    if (this.state === 'jump') { this.jumpStep(spd); return }
    if (this.state === 'grapple') { this.grappleStep(); return }
    var x1 = b.b0, x2 = b.b2; this.y = b.floor - this.ground
    if (this.climbCd > 0) this.climbCd--; if (this.jumpCd > 0) this.jumpCd--; if (this.grappleCd > 0) this.grappleCd--
    this.timer--; if (this.timer <= 0) this.pickNextWalker()
    if (this.hasJump && this.support === 0 && this.jumpCd === 0 && (this.state === 'walk' || this.state === 'idle') && rand() < P_JUMP) { this.beginJump(); return }
    if (this.hasGrapple && this.support === 0 && this.grappleCd === 0 && (this.state === 'walk' || this.state === 'idle') && rand() < P_GRAPPLE) { var fxx = this.x + this.cx; this.facing = b.b2 - fxx < fxx - b.b0 ? 1 : -1; this.beginGrapple(); return }
    if ((this.state === 'walk' || this.state === 'idle') && this.maybeSpecial('walk')) return
    if (this.world.climb && this.support === 0 && this.climbCd === 0 && (this.state === 'walk' || this.state === 'idle') && rand() < P_SEEK) { var fx = this.x + this.cx; this.seekSide = fx - b.b0 < b.b2 - fx ? 'L' : 'R'; this.seekX = this.seekSide === 'L' ? b.b0 : b.b2; this.state = 'seek'; return }
    if (this.state === 'walk') { this.x += this.vx * spd; var fx2 = this.x + this.cx; if (fx2 <= x1) this.hitEdge(x1, x2, true); else if (fx2 >= x2) this.hitEdge(x1, x2, false) }
  }
  Pet.prototype.hitEdge = function (x1, x2, left) { if (left) { this.x = x1 - this.cx + 0.2; this.facing = 1; this.vx = WALK } else { this.x = x2 - this.cx - 0.2; this.facing = -1; this.vx = -WALK } }
  Pet.prototype.beginJump = function () { this.switchActive('jump'); this.state = 'jump'; this.support = null; this.vy = -JUMP_V; this.vx = JUMP_VX * this.facing; this.jumpCd = 220 }
  Pet.prototype.jumpStep = function (spd) {
    var b = this.world.bounds; this.vy += GRAVITY; this.x += this.vx * spd; this.y += this.vy
    var fx = this.x + this.cx; if (fx < b.b0) { this.x = b.b0 - this.cx; this.vx = Math.abs(this.vx); this.facing = 1 } else if (fx > b.b2) { this.x = b.b2 - this.cx; this.vx = -Math.abs(this.vx); this.facing = -1 }
    var fy = this.y + this.ground; if (this.vy > 0 && fy >= b.floor) { this.support = 0; this.switchActive('walk'); this.y = b.floor - this.ground; this.vy = 0; this.state = 'walk'; this.vx = WALK * this.facing; this.timer = randint(50, 120) }
  }
  Pet.prototype.beginGrapple = function () { this.switchActive('grapple'); this.state = 'grapple'; this.grappleIdx = 0; this.grappleSub = 0; this.grappleCd = 500 }
  Pet.prototype.grappleStep = function () { this.grappleSub++; if (this.grappleSub >= 5) { this.grappleSub = 0; this.grappleIdx++ } if (this.grappleIdx >= this.grappleFrames + 3) { this.facing = -this.facing; this.switchActive('walk'); this.state = 'walk'; this.vx = WALK * this.facing; this.grappleIdx = 0; this.timer = randint(60, 140) } }
  Pet.prototype.seekStep = function (spd) { var b = this.world.bounds; this.y = b.floor - this.ground; var fx = this.x + this.cx; if (Math.abs(fx - this.seekX) <= 6) { this.beginWallClimb(); return } this.facing = this.seekX > fx ? 1 : -1; this.vx = WALK * this.facing; this.x += this.vx * spd; var nfx = this.x + this.cx; if (nfx < b.b0) this.x = b.b0 - this.cx; else if (nfx > b.b2) this.x = b.b2 - this.cx }
  Pet.prototype.beginWallClimb = function () { var b = this.world.bounds; this.state = 'climb'; this.climbDir = 1; this.climbTop = randint(b.top0 + 10, Math.max(b.top0 + 40, Math.floor(b.floor * 0.45))); this.climbHold = 0; this.climbHoldMax = randint(20, 60); this.facing = this.seekSide === 'L' ? 1 : -1; this.support = null; if (this.seekSide === 'L') this.x = b.b0; else this.x = b.b2 - this.W }
  Pet.prototype.climbStep = function (spd) {
    var b = this.world.bounds; if (this.seekSide === 'L') this.x = b.b0; else this.x = b.b2 - this.W
    if (this.climbDir > 0) { this.y -= CLIMB * spd; if (this.y <= this.climbTop) { this.y = this.climbTop; this.climbDir = 0; this.climbHold = 0 } }
    else if (this.climbDir === 0) { this.climbHold++; if (this.climbHold >= this.climbHoldMax) this.climbDir = -1 }
    else { this.y += CLIMB * spd; if (this.y + this.ground >= b.floor) { this.y = b.floor - this.ground; this.support = 0; this.state = 'walk'; this.vx = WALK * this.facing; this.climbCd = 150; this.timer = randint(60, 140) } }
  }
  Pet.prototype.maybeSpecial = function (ret) {
    if (!this.animSpecials.length) return false
    for (var i = 0; i < this.animSpecials.length; i++) if (this.animSpecials[i].cd_left > 0) this.animSpecials[i].cd_left--
    if (rand() >= this.specialRate) return false
    var elig = this.animSpecials.filter(function (s) { return s.cd_left === 0 }); if (!elig.length) return false
    var s = choices(elig, elig.map(function (e) { return e.weight }))
    this.curSpecial = s; this.specialReturn = ret; this.specialIdx = 0; this.specialSub = 0; this.specialHold = 0; this.specialShot = false; this.switchActive('special'); this.state = 'special'; return true
  }
  Pet.prototype.specialStep = function () {
    var s = this.curSpecial; if (!s) { this.state = this.specialReturn; return }
    this.specialSub++; if (this.specialSub >= s.speed) { this.specialSub = 0; this.specialIdx++ }
    if (s.shoot && !this.specialShot && this.specialIdx >= s.shoot.at) { this.specialShot = true; this.world.spawnArrow(this, s.shoot.speed, s.shoot.arrow) }
    if (this.specialIdx >= s.loops * s.frames) { this.specialHold++; if (this.specialHold >= (s.hold || 0)) { s.cd_left = s.cd; this.curSpecial = null; this.switchActive('walk'); this.state = this.specialReturn; if (this.state === 'walk') this.vx = WALK * this.facing; this.specialIdx = 0 } }
    this.apply()
  }
  Pet.prototype.beginSleep = function () { var sp = this.sleepSpecial; this.pendingSleep = sp; var b = this.world.bounds; if (sp.goto === 'top') this.sleepTy = b.top0; else this.sleepTy = b.floor - this.ground; this.sleepTx = this.x; this.state = 'gosleep' }
  Pet.prototype.gosleepStep = function () { this.y += (this.sleepTy - this.y) * 0.16; this.x += (this.sleepTx - this.x) * 0.16; if (Math.abs(this.sleepTy - this.y) < 3 && Math.abs(this.sleepTx - this.x) < 3) this.startSleep(); this.advanceAnim(); this.apply() }
  Pet.prototype.startSleep = function () { var sp = this.pendingSleep; this.curSpecial = sp; this.specialReturn = this.flies ? 'float' : 'walk'; this.specialIdx = 0; this.specialSub = 0; this.specialHold = 0; this.specialShot = false; this.switchActive('special'); var b = this.world.bounds; if (sp.goto === 'top') this.y = b.top0; else this.y = b.floor - this.ground; this.state = 'special' }
  Pet.prototype.pickNextWalker = function () {
    this.state = choices(['walk', 'idle', 'sit', 'sleep'], [6, 3, 2, 2])
    if (this.state === 'sleep' && this.sleepSpecial) { this.beginSleep(); return }
    if (this.state === 'walk') { this.facing = choice([-1, 1]); this.vx = WALK * this.facing; this.timer = randint(60, 160) }
    else if (this.state === 'idle') this.timer = randint(25, 70)
    else if (this.state === 'sit') this.timer = randint(60, 140)
    else this.timer = randint(120, 260)
  }
  Pet.prototype.updateFlyer = function (spd) {
    var b = this.world.bounds, maxx = Math.max(b.b0, b.b2 - this.W)
    if (this.state === 'return') { this.y += (this.hoverY - this.y) * 0.12; if (Math.abs(this.y - this.hoverY) < 1.5) { this.y = this.hoverY; this.targetY = this.hoverY; this.state = 'float'; this.timer = randint(60, 140) } return }
    this.timer--
    if (this.timer <= 0) { this.state = choices(['float', 'sleep'], [6, 1]); if (this.state === 'sleep' && this.sleepSpecial) { this.beginSleep(); return } if (this.state === 'float') { this.targetY = randint(b.top0 + 10, b.floor - 40); this.facing = choice([-1, 1]); this.vx = FLOAT * this.facing; this.timer = randint(80, 180) } else this.timer = randint(120, 240) }
    if (this.state === 'float') { if (this.maybeSpecial('float')) return; this.x += this.vx * spd; if (this.x <= b.b0) { this.x = b.b0; this.facing = 1; this.vx = FLOAT } else if (this.x >= maxx) { this.x = maxx; this.facing = -1; this.vx = -FLOAT } this.y += (this.targetY - this.y) * 0.05 }
  }
  Pet.prototype.redraw = function () {
    this.zzz.style.display = this.state === 'sleep' ? '' : 'none'
    if (this.isImage && this.img) {
      var spr, nfr
      if (this.state === 'jump' && this.hasJump) { spr = this.jumpSprite; nfr = this.jumpFrames }
      else if (this.state === 'grapple' && this.hasGrapple) { spr = this.grappleSprite; nfr = this.grappleFrames }
      else if (this.state === 'special' && this.curSpecial) { spr = this.curSpecial.sprite; nfr = this.curSpecial.frames }
      else { spr = this.sprite; nfr = this.nFrames }
      var idx
      if (this.state === 'grapple') idx = Math.min(this.grappleIdx, nfr - 1)
      else if (this.state === 'special') idx = this.curSpecial && this.curSpecial.loops > 1 ? this.specialIdx % nfr : Math.min(this.specialIdx, nfr - 1)
      else { var an = this.state !== 'idle' && this.state !== 'sit' && this.state !== 'sleep'; idx = an ? this.anim % nfr : 0 }
      var flip = this.facing !== this.native
      if (spr && spr.ok) { var im = spr.imgs[((idx % nfr) + nfr) % nfr]; if (im && this.img.src !== im.src) this.img.src = im.src; this.img.style.transform = flip ? 'scaleX(-1)' : 'scaleX(1)'; this.img.style.visibility = 'visible' }
      else this.img.style.visibility = 'hidden'
    } else if (this.ctx) {
      var pose = this.state === 'drag' || this.state === 'return' || this.state === 'float' ? 'idle' : this.state === 'climb' || this.state === 'seek' ? 'walk' : this.state
      drawClaude(this.ctx, this.W, this.H, this.facing, pose, this.anim, this.blink)
    }
  }
  Pet.prototype.destroy = function () { try { this.el.removeEventListener('pointerdown', this._down) } catch (e) { /* noop */ } if (this.el.parentNode) this.el.parentNode.removeChild(this.el) }

  function Projectile(world, name, cx, cy, vx, scale, height) {
    height = height || 26; this.world = world; this.vx = vx
    var spr = loadSprite(name, 1), th = Math.max(10, Math.round(height * scale)), sz = sizeFor(spr, th)
    this.W = sz[0]; this.H = sz[1]; this.x = cx - sz[0] / 2; this.y = cy - sz[1] / 2
    this.el = document.createElement('div')
    this.el.style.cssText = 'position:absolute;left:0;top:0;width:' + sz[0] + 'px;height:' + sz[1] + 'px;pointer-events:none;will-change:transform;'
    this.img = document.createElement('img'); this.img.draggable = false; this.img.src = BASE + '/' + name + '/0.png'
    this.img.style.cssText = 'width:100%;height:100%;transform:scaleX(' + (vx < 0 ? -1 : 1) + ');'
    this.el.appendChild(this.img); world.container.appendChild(this.el); this.apply()
  }
  Projectile.prototype.apply = function () { this.el.style.transform = 'translate(' + Math.round(this.x) + 'px,' + Math.round(this.y) + 'px)' }
  Projectile.prototype.update = function () { this.x += this.vx; var b = this.world.bounds; if (this.x + this.W < b.b0 - 30 || this.x > b.b2 + 30) return false; this.apply(); return true }
  Projectile.prototype.destroy = function () { if (this.el.parentNode) this.el.parentNode.removeChild(this.el) }

  function World(container) {
    this.container = container; this.speed = 1; this.scale = 1; this.climb = true
    this.pets = []; this.projectiles = []; var self = this
    this.bounds = this.measure(); this._resize = function () { self.bounds = self.measure() }
    window.addEventListener('resize', this._resize)
    this.timer = window.setInterval(function () { self.tick() }, TICK_MS)
  }
  World.prototype.measure = function () { var w = window.innerWidth, h = window.innerHeight; return { b0: 0, top0: 0, b2: w, bottom0: h, floor: h } }
  World.prototype.setSettings = function (s) { if (s.speed != null) this.speed = s.speed; if (s.climb != null) this.climb = s.climb; if (s.scale != null && s.scale !== this.scale) { this.scale = s.scale; for (var i = 0; i < this.pets.length; i++) this.pets[i].setScale(s.scale) } }
  World.prototype.spawnArrow = function (pet, speed, name) { var cx = pet.x + pet.cx + pet.facing * pet.W * 0.3, cy = pet.y + pet.H * 0.42; this.projectiles.push(new Projectile(this, name, cx, cy, speed * pet.facing, pet.scale)) }
  World.prototype.add = function (key) { if (!CHARACTERS[key]) return; var p = new Pet(this, key); this.pets.push(p); this.container.appendChild(p.el) }
  World.prototype.removeLast = function () { var p = this.pets.pop(); if (p) p.destroy() }
  World.prototype.removeAll = function () { for (var i = 0; i < this.pets.length; i++) this.pets[i].destroy(); this.pets = []; for (var j = 0; j < this.projectiles.length; j++) this.projectiles[j].destroy(); this.projectiles = [] }
  World.prototype.count = function () { return this.pets.length }
  World.prototype.tick = function () {
    for (var i = 0; i < this.pets.length; i++) { try { this.pets[i].update() } catch (e) { /* noop */ } }
    var keep = []
    for (var j = 0; j < this.projectiles.length; j++) { var pr = this.projectiles[j]; var ok = false; try { ok = pr.update() } catch (e) { ok = false } if (ok) keep.push(pr); else pr.destroy() }
    this.projectiles = keep
  }
  World.prototype.destroy = function () { if (this.timer) window.clearInterval(this.timer); window.removeEventListener('resize', this._resize); this.removeAll() }

  // ---- capa + panel ----
  var layer = document.createElement('div')
  layer.style.cssText = 'position:fixed;inset:0;left:0;top:0;width:100%;height:100%;pointer-events:none;overflow:hidden;z-index:2147483000;'
  document.documentElement.appendChild(layer)
  var world = new World(layer)
  var STARTERS = ['pollito', 'gato', 'perro', 'fantasma', 'colibri']
  for (var si = 0; si < STARTERS.length; si++) world.add(STARTERS[si])

  var panel = document.createElement('div')
  panel.style.cssText = 'position:fixed;right:14px;bottom:14px;z-index:2147483003;width:230px;max-width:80vw;background:rgba(28,32,48,.96);color:#fff;border-radius:14px;box-shadow:0 8px 30px rgba(0,0,0,.4);padding:10px;font:13px system-ui,sans-serif;pointer-events:auto;'
  var html = '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px"><b style="font-size:13px">🐾 Bichitos</b><span><button data-a="min" style="background:none;border:0;color:#fff;cursor:pointer;font-size:15px;padding:2px 6px">–</button><button data-a="close" style="background:none;border:0;color:#fff;cursor:pointer;font-size:15px;padding:2px 6px">✕</button></span></div>'
  html += '<div data-body><div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:5px;margin-bottom:6px">'
  for (var oi = 0; oi < ORDER.length; oi++) { var k = ORDER[oi]; html += '<button data-add="' + k + '" style="background:' + COLORS[k] + ';color:#20263a;border:0;border-radius:8px;padding:5px 2px;font:600 11px system-ui;cursor:pointer">' + CHARACTERS[k].name + '</button>' }
  html += '</div><div data-count style="text-align:center;color:#aab0c6;font-size:11px;margin-bottom:6px"></div>'
  html += '<div style="font-size:11px;margin-bottom:2px">Velocidad</div><input data-speed type="range" min="0.3" max="2.5" step="0.1" value="1" style="width:100%;margin-bottom:6px">'
  html += '<div style="font-size:11px;margin-bottom:2px">Tamaño</div><input data-scale type="range" min="0.6" max="1.8" step="0.1" value="1" style="width:100%;margin-bottom:8px">'
  html += '<div style="display:flex;gap:6px"><button data-a="one" style="flex:1;background:#40465f;color:#fff;border:0;border-radius:8px;padding:6px;cursor:pointer;font-size:12px">Quitar uno</button><button data-a="all" style="flex:1;background:#40465f;color:#fff;border:0;border-radius:8px;padding:6px;cursor:pointer;font-size:12px">Quitar todos</button></div></div>'
  panel.innerHTML = html
  document.documentElement.appendChild(panel)

  function upd() { var c = panel.querySelector('[data-count]'); var n = world.count(); if (c) c.textContent = n + ' bichito' + (n !== 1 ? 's' : '') + ' · arrástralos' }
  upd()
  panel.addEventListener('click', function (e) {
    var t = e.target
    if (t.getAttribute('data-add')) { world.add(t.getAttribute('data-add')); upd() }
    var a = t.getAttribute('data-a')
    if (a === 'one') { world.removeLast(); upd() }
    else if (a === 'all') { world.removeAll(); upd() }
    else if (a === 'close') { destroy() }
    else if (a === 'min') { var body = panel.querySelector('[data-body]'); body.style.display = body.style.display === 'none' ? '' : 'none' }
  })
  panel.addEventListener('input', function (e) {
    var t = e.target
    if (t.hasAttribute('data-speed')) world.setSettings({ speed: parseFloat(t.value) })
    if (t.hasAttribute('data-scale')) world.setSettings({ scale: parseFloat(t.value) })
  })

  function destroy() { try { world.destroy() } catch (e) { /* noop */ } if (layer.parentNode) layer.parentNode.removeChild(layer); if (panel.parentNode) panel.parentNode.removeChild(panel); window.__bichitos = null }
  window.__bichitos = { destroy: destroy, world: world }
})();
