import { useMemo, useState } from 'react'
import type { Conversation } from '../lib/types'

interface Props {
  conversations: Conversation[]
  activeId: string | null
  open: boolean
  onClose: () => void
  onSelect: (id: string) => void
  onNew: () => void
  onDelete: (id: string) => void
  onRename: (id: string, title: string) => void
  onTogglePin: (id: string) => void
  onSetFolder: (id: string, folder: string) => void
  profileName: string
  profileAvatar: string
  onSwitchProfile: () => void
  collapsed?: boolean
}

export default function Sidebar({
  conversations,
  activeId,
  open,
  onClose,
  onSelect,
  onNew,
  onDelete,
  onRename,
  onTogglePin,
  onSetFolder,
  profileName,
  profileAvatar,
  onSwitchProfile,
  collapsed,
}: Props) {
  const [query, setQuery] = useState('')
  const [editingId, setEditingId] = useState<string | null>(null)
  const [draft, setDraft] = useState('')
  const [collapsedFolders, setCollapsedFolders] = useState<Record<string, boolean>>({})

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase()
    const base = !q
      ? conversations
      : conversations.filter((c) => {
          if (c.title.toLowerCase().includes(q)) return true
          return c.messages.some((m) => m.content.toLowerCase().includes(q))
        })
    // Anclados primero (orden estable: conserva el orden por reciente dentro de cada grupo)
    return [...base].sort((a, b) => Number(!!b.pinned) - Number(!!a.pinned))
  }, [conversations, query])

  function commitRename(id: string) {
    const t = draft.trim()
    setEditingId(null)
    if (t) onRename(id, t)
  }

  // Agrupar por carpeta (los sin carpeta van sueltos arriba).
  const grouped = useMemo(() => {
    const folders = new Map<string, Conversation[]>()
    const loose: Conversation[] = []
    for (const c of filtered) {
      if (c.folder) {
        if (!folders.has(c.folder)) folders.set(c.folder, [])
        folders.get(c.folder)!.push(c)
      } else loose.push(c)
    }
    return {
      folders: [...folders.entries()].sort((a, b) => a[0].localeCompare(b[0])),
      loose,
    }
  }, [filtered])
  const hasFolders = grouped.folders.length > 0

  function renderRow(c: Conversation) {
    return (
      <div
        key={c.id}
        className={`group flex items-center gap-2 rounded-lg px-3 py-2 cursor-pointer text-sm ${
          c.id === activeId
            ? 'bg-zinc-100 dark:bg-zinc-800'
            : 'hover:bg-zinc-100 dark:hover:bg-zinc-800/60'
        }`}
        onClick={() => onSelect(c.id)}
      >
        {editingId === c.id ? (
          <input
            autoFocus
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onClick={(e) => e.stopPropagation()}
            onBlur={() => commitRename(c.id)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') commitRename(c.id)
              if (e.key === 'Escape') setEditingId(null)
            }}
            className="flex-1 min-w-0 rounded border border-indigo-400 bg-white dark:bg-zinc-900 px-1 py-0.5 text-sm outline-none"
          />
        ) : (
          <span
            className="flex-1 truncate"
            onDoubleClick={(e) => {
              e.stopPropagation()
              setDraft(c.title)
              setEditingId(c.id)
            }}
            title="Doble clic para renombrar"
          >
            {c.pinned && <span className="mr-1">📌</span>}
            {c.title || 'Sin título'}
          </span>
        )}
        <button
          onClick={(e) => {
            e.stopPropagation()
            onTogglePin(c.id)
          }}
          className={`${
            c.pinned
              ? 'opacity-100 text-indigo-500'
              : 'opacity-0 group-hover:opacity-100 text-zinc-400 hover:text-indigo-500'
          } transition-opacity`}
          title={c.pinned ? 'Desanclar' : 'Anclar arriba'}
        >
          📌
        </button>
        <button
          onClick={(e) => {
            e.stopPropagation()
            const f = prompt('Carpeta (vacío = sin carpeta):', c.folder || '')
            if (f !== null) onSetFolder(c.id, f)
          }}
          className={`${
            c.folder
              ? 'opacity-100 text-indigo-500'
              : 'opacity-0 group-hover:opacity-100 text-zinc-400 hover:text-indigo-500'
          } transition-opacity`}
          title={c.folder ? `Carpeta: ${c.folder}` : 'Mover a una carpeta'}
        >
          🗂️
        </button>
        <button
          onClick={(e) => {
            e.stopPropagation()
            setDraft(c.title)
            setEditingId(c.id)
          }}
          className="opacity-0 group-hover:opacity-100 text-zinc-400 hover:text-indigo-500 transition-opacity"
          title="Renombrar"
        >
          ✎
        </button>
        <button
          onClick={(e) => {
            e.stopPropagation()
            onDelete(c.id)
          }}
          className="opacity-0 group-hover:opacity-100 text-zinc-400 hover:text-red-500 transition-opacity"
          title="Eliminar"
        >
          ✕
        </button>
      </div>
    )
  }

  return (
    <>
      {/* Fondo oscuro en móvil cuando el menú está abierto */}
      <div
        className={`fixed inset-0 z-20 bg-black/50 md:hidden transition-opacity ${
          open ? 'opacity-100' : 'pointer-events-none opacity-0'
        }`}
        onClick={onClose}
      />
      <aside
        className={`fixed z-30 md:static md:z-auto h-full w-72 shrink-0 flex flex-col border-r border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 transition-transform md:translate-x-0 ${
          open ? 'translate-x-0' : '-translate-x-full'
        } ${collapsed ? 'md:hidden' : ''}`}
      >
        <div className="flex items-center gap-2 px-4 h-14 border-b border-zinc-200 dark:border-zinc-800">
          <img src="/icon-192.png" alt="Yuki" className="h-8 w-8 rounded-lg object-cover" />
          <span className="font-semibold">Yuki</span>
        </div>

        <div className="p-3 space-y-2">
          <button
            onClick={onNew}
            className="w-full rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white py-2 text-sm font-medium transition-colors"
          >
            + Nuevo chat
          </button>
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="🔎 Buscar en el historial…"
            className="w-full rounded-lg border border-zinc-200 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-800 text-sm px-3 py-1.5 outline-none"
          />
        </div>

        <nav className="flex-1 overflow-y-auto px-2 pb-3 space-y-1">
          {filtered.length === 0 && (
            <p className="text-xs text-zinc-400 px-2 py-4 text-center">
              {query ? 'Sin resultados' : 'Aún no hay conversaciones'}
            </p>
          )}
          {!hasFolders
            ? filtered.map(renderRow)
            : (
              <>
                {grouped.loose.map(renderRow)}
                {grouped.folders.map(([name, list]) => (
                  <div key={name} className="pt-1">
                    <button
                      onClick={() =>
                        setCollapsedFolders((s) => ({ ...s, [name]: !s[name] }))
                      }
                      className="w-full flex items-center gap-1 px-2 py-1.5 rounded-lg text-xs font-medium text-zinc-500 hover:bg-zinc-100 dark:hover:bg-zinc-800/60"
                    >
                      <span className="text-[10px]">{collapsedFolders[name] ? '▸' : '▾'}</span>
                      <span>🗂️ {name}</span>
                      <span className="ml-auto text-zinc-400">{list.length}</span>
                    </button>
                    {!collapsedFolders[name] && (
                      <div className="ml-1 space-y-1">{list.map(renderRow)}</div>
                    )}
                  </div>
                ))}
              </>
            )}
        </nav>

        <div className="border-t border-zinc-200 dark:border-zinc-800 p-2">
          <div className="flex items-center gap-2 rounded-lg px-2 py-2">
            <div className="h-8 w-8 rounded-full bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center text-white text-sm shrink-0">
              {profileAvatar || profileName.slice(0, 1).toUpperCase()}
            </div>
            <span className="flex-1 truncate text-sm font-medium">{profileName}</span>
            <button
              onClick={onSwitchProfile}
              className="text-xs text-zinc-400 hover:text-indigo-500 shrink-0"
              title="Cambiar de perfil"
            >
              Cambiar
            </button>
          </div>
          <p className="text-[11px] text-zinc-400 text-center pb-1">
            100% local · privado · sincronizado
          </p>
        </div>
      </aside>
    </>
  )
}
