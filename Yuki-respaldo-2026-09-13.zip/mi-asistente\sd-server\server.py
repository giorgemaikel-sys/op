"""
Servidor local de generación de imágenes para el asistente.
Usa Stable Diffusion (sd-turbo) sobre torch-directml (GPU AMD en Windows).
Gratis, local y privado. Expone una API HTTP simple.

Endpoints:
  GET  /health   -> estado del modelo
  POST /generate -> { prompt, negative_prompt?, steps?, width?, height?, seed? }
                    devuelve { image: <base64 png>, seconds }
"""
import base64
import io
import json
import os
import sys
import time
import threading
import queue
import gc
import ctypes
import secrets
from ctypes import wintypes

try:
    import psutil
except Exception:  # noqa
    psutil = None

import torch
import torch_directml
from flask import Flask, request, jsonify, Response
from flask_cors import CORS
from diffusers import AutoPipelineForText2Image

# Modelo de imágenes. sd-turbo es rápido y fiable en GPUs modestas / DirectML (8GB).
# (Un modelo con guía tipo DreamShaper da más calidad pero en fp32 es demasiado
#  pesado para esta tarjeta; se puede activar poniendo YUKI_SD_MODEL.)
MODEL_PRIMARY = os.environ.get("YUKI_SD_MODEL", "stabilityai/sd-turbo")
MODEL_FALLBACK = "stabilityai/sd-turbo"
MODEL_ID = MODEL_PRIMARY  # el que quedó cargado (lo actualiza load_model)
is_turbo = True
PORT = 7861

# Prompt negativo por defecto: sube mucho la calidad (evita borrosos, deformes, etc.).
DEFAULT_NEGATIVE = (
    "lowres, blurry, low quality, worst quality, jpeg artifacts, deformed, distorted, "
    "disfigured, bad anatomy, bad proportions, extra limbs, extra fingers, fused fingers, "
    "mutated, ugly, grainy, watermark, text, signature, username, out of frame, cropped"
)

# Contraseña de administrador (la misma que en storage-plugin.ts). Ejecutar código
# Python es una operación potente, así que SOLO se permite con esta contraseña.
ADMIN_PASS = "11101063520"


def _runner_python() -> str:
    """Devuelve el intérprete del venv (tiene numpy/pandas/matplotlib y las libs
    que instale el usuario); si no existe, el mismo que corre este servidor."""
    here = os.path.dirname(os.path.abspath(__file__))
    venv_py = os.path.join(here, ".venv", "Scripts", "python.exe")
    return venv_py if os.path.exists(venv_py) else sys.executable


def _admin_ok() -> bool:
    return request.headers.get("x-owner-pass", "") == ADMIN_PASS

app = Flask(__name__)
CORS(app)

dml = torch_directml.device()
pipe = None
loading = False
load_error = None

# Whisper (voz -> texto), carga perezosa en el primer uso.
whisper_model = None
whisper_lock = threading.Lock()


def get_whisper():
    global whisper_model
    if whisper_model is None:
        with whisper_lock:
            if whisper_model is None:
                from faster_whisper import WhisperModel

                print("[sd-server] Cargando Whisper (base) en CPU …")
                whisper_model = WhisperModel("base", device="cpu", compute_type="int8")
                print("[sd-server] Whisper listo.")
    return whisper_model


def load_model():
    global pipe, loading, load_error, is_turbo, MODEL_ID
    loading = True
    try:
        _free_gpu_memory()  # que Ollama no retenga VRAM al cargar el modelo (GPU de 8GB)
    except Exception:  # noqa
        pass
    for mid in [MODEL_PRIMARY, MODEL_FALLBACK]:
        turbo = "turbo" in mid.lower()
        try:
            print(f"[sd-server] Cargando {mid} en {dml} …")
            p = AutoPipelineForText2Image.from_pretrained(
                mid,
                torch_dtype=torch.float32,
                safety_checker=None,
                requires_safety_checker=False,
            )
            # Ajustes de bajo consumo de VRAM (GPU de 8 GB) + liberación entre imágenes:
            p.enable_attention_slicing("max")
            p.enable_vae_slicing()
            p.enable_vae_tiling()
            try:
                # Sube a la GPU solo el componente en uso y lo baja después → poco pico
                # de VRAM y memoria liberada entre generaciones.
                p.enable_model_cpu_offload(device=dml)
                print("[sd-server] model_cpu_offload activo.")
            except Exception as e:  # noqa
                print("[sd-server] offload no disponible, uso .to(dml):", e)
                p = p.to(dml)
            pipe = p
            is_turbo = turbo
            MODEL_ID = mid
            load_error = None
            print(f"[sd-server] Modelo listo: {mid} (turbo={turbo})")
            break
        except Exception as e:  # noqa
            load_error = str(e)
            print(f"[sd-server] ERROR al cargar {mid}: {e}")
    loading = False


@app.route("/health")
def health():
    return jsonify(
        {
            "ready": pipe is not None,
            "loading": loading,
            "error": load_error,
            "device": str(dml),
            "model": MODEL_ID,
            "whisper_ready": whisper_model is not None,
        }
    )


def _free_gpu_memory():
    """Libera la VRAM que ocupa Ollama para que Stable Diffusion quepa en la
    tarjeta de 8GB. Pide descargar los modelos y mata el 'runner' de Ollama
    (Ollama lo relanza solo en el siguiente chat)."""
    import subprocess
    import urllib.request
    # 1) pedir a Ollama que descargue lo cargado (keep_alive:0)
    try:
        ps = json.load(urllib.request.urlopen("http://127.0.0.1:11434/api/ps", timeout=3))
        for m in ps.get("models", []):
            try:
                req = urllib.request.Request(
                    "http://127.0.0.1:11434/api/generate",
                    data=json.dumps({"model": m["name"], "keep_alive": 0, "prompt": ""}).encode(),
                    headers={"Content-Type": "application/json"},
                )
                urllib.request.urlopen(req, timeout=5)
            except Exception:  # noqa
                pass
    except Exception:  # noqa
        pass
    # 2) matar el runner que retiene la VRAM (varios nombres según versión)
    for name in ("llama-server.exe", "ollama_llama_server.exe", "ollama-runner.exe"):
        try:
            subprocess.run(["taskkill", "/F", "/IM", name], capture_output=True, timeout=5)
        except Exception:  # noqa
            pass
    gc.collect()
    time.sleep(1.0)


@app.route("/freegpu", methods=["POST"])
def freegpu():
    """Libera la VRAM (descarga Ollama) para que las imágenes vuelvan a caber."""
    try:
        _free_gpu_memory()
        return jsonify({"ok": True})
    except Exception as e:  # noqa
        return jsonify({"ok": False, "error": str(e)}), 500


# Cierre que se añade DESPUÉS del código del usuario para capturar TODAS las
# figuras de matplotlib (si las hay) en PNG. No ponemos nada ANTES del código para
# que los números de línea de los errores coincidan con lo que escribió el usuario;
# el backend "Agg" (sin ventanas en la PC) se fija con la variable MPLBACKEND.
_PY_POST = (
    "\n# ---- guardar TODAS las figuras (si hay) ----\n"
    "try:\n"
    "    import matplotlib.pyplot as _plt\n"
    "    for _i, _n in enumerate(_plt.get_fignums()):\n"
    "        _plt.figure(_n).savefig(r'{imgdir}' + '/__fig_%03d.png' % _i, bbox_inches='tight')\n"
    "except Exception:\n"
    "    pass\n"
)
_MAX_OUT = 20000  # tope de caracteres de salida


@app.route("/runpython", methods=["POST"])
def runpython():
    """Ejecuta código Python en un proceso aparte (aislado, con timeout) y
    devuelve stdout/stderr y una imagen si el código dibujó con matplotlib.
    Local y privado: corre en esta misma PC."""
    import os
    import sys
    import shutil
    import tempfile
    import subprocess

    # Candado de administrador: exige la contraseña maestra en la cabecera.
    if not _admin_ok():
        return (
            jsonify({"ok": False, "error": "Se requiere la contraseña de administrador."}),
            403,
        )

    data = request.get_json(force=True, silent=True) or {}
    code = data.get("code", "")
    if not isinstance(code, str) or not code.strip():
        return jsonify({"ok": False, "error": "No hay código para ejecutar."}), 400
    timeout = min(int(data.get("timeout", 25) or 25), 120)
    stdin_text = str(data.get("stdin", "") or "")

    py = _runner_python()
    workdir = tempfile.mkdtemp(prefix="yuki_py_")
    script = os.path.join(workdir, "script.py")
    source = code + _PY_POST.format(imgdir=workdir.replace("\\", "\\\\"))
    try:
        with open(script, "w", encoding="utf-8") as f:
            f.write(source)
        env = dict(os.environ, PYTHONIOENCODING="utf-8", MPLBACKEND="Agg")
        try:
            proc = subprocess.run(
                [py, script],
                cwd=workdir,
                input=stdin_text,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=timeout,
                env=env,
            )
            stdout, stderr, rc = proc.stdout, proc.stderr, proc.returncode
            # Ocultar la ruta del archivo temporal en los tracebacks.
            if stderr:
                stderr = stderr.replace(script, "<tu código>")
        except subprocess.TimeoutExpired:
            return jsonify(
                {
                    "ok": False,
                    "stdout": "",
                    "stderr": "",
                    "error": f"⏱️ Se agotó el tiempo ({timeout}s). "
                    "¿Un bucle infinito o algo muy pesado?",
                }
            )

        images = []
        try:
            for fn in sorted(os.listdir(workdir)):
                if fn.startswith("__fig_") and fn.endswith(".png"):
                    with open(os.path.join(workdir, fn), "rb") as im:
                        images.append(base64.b64encode(im.read()).decode())
        except Exception:  # noqa
            images = []

        return jsonify(
            {
                "ok": rc == 0,
                "returncode": rc,
                "stdout": (stdout or "")[:_MAX_OUT],
                "stderr": (stderr or "")[:_MAX_OUT],
                "image": images[0] if images else None,  # compatibilidad
                "images": images,
            }
        )
    except Exception as e:  # noqa
        return jsonify({"ok": False, "error": str(e)}), 500
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


# Caracteres permitidos en un nombre de paquete de pip (incluye versiones y extras).
import re as _re

_PKG_RE = _re.compile(r"^[A-Za-z0-9_.\-\[\]=<>!~,()* ]+$")


@app.route("/pipinstall", methods=["POST"])
def pipinstall():
    """Instala una o varias librerías con pip en el entorno del asistente.
    Solo administrador. Ej: 'requests', 'pandas==2.2.0', 'rich seaborn'."""
    import subprocess

    if not _admin_ok():
        return jsonify({"ok": False, "error": "Se requiere la contraseña de administrador."}), 403

    data = request.get_json(force=True, silent=True) or {}
    pkg = str(data.get("package", "")).strip()
    if not pkg:
        return jsonify({"ok": False, "error": "Escribe el nombre de la librería."}), 400
    if len(pkg) > 200 or not _PKG_RE.match(pkg):
        return jsonify({"ok": False, "error": "Nombre de librería no válido."}), 400
    # Cada palabra es un paquete (se pasan como argumentos, sin shell → sin inyección).
    args = [a for a in pkg.split() if a]

    py = _runner_python()
    try:
        env = dict(os.environ, PYTHONIOENCODING="utf-8")
        proc = subprocess.run(
            [py, "-m", "pip", "install", "--disable-pip-version-check", *args],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
            timeout=300, env=env,
        )
        out = ((proc.stdout or "") + ("\n" + proc.stderr if proc.stderr else ""))[:_MAX_OUT]
        return jsonify({"ok": proc.returncode == 0, "output": out})
    except subprocess.TimeoutExpired:
        return jsonify({"ok": False, "error": "⏱️ La instalación tardó demasiado (5 min)."})
    except Exception as e:  # noqa
        return jsonify({"ok": False, "error": str(e)}), 500


@app.route("/pylibs", methods=["GET"])
def pylibs():
    """Lista las librerías instaladas en el entorno. Solo administrador."""
    import subprocess

    if not _admin_ok():
        return jsonify({"ok": False, "error": "Se requiere la contraseña de administrador."}), 403
    py = _runner_python()
    try:
        proc = subprocess.run(
            [py, "-m", "pip", "list", "--format=freeze", "--disable-pip-version-check"],
            capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=30,
        )
        libs = [l.strip() for l in (proc.stdout or "").splitlines() if l.strip()]
        return jsonify({"ok": True, "libs": libs, "python": sys.version.split()[0]})
    except Exception as e:  # noqa
        return jsonify({"ok": False, "error": str(e)}), 500


@app.route("/runcmd", methods=["POST"])
def runcmd():
    """Terminal del Studio: ejecuta un comando de la consola de Windows en una
    carpeta y devuelve la salida + la carpeta resultante (para que 'cd' funcione).
    Solo administrador. Local y privado."""
    import subprocess

    if not _admin_ok():
        return jsonify({"ok": False, "error": "Se requiere la contraseña de administrador."}), 403

    data = request.get_json(force=True, silent=True) or {}
    cmd = str(data.get("cmd", "")).strip()
    cwd = str(data.get("cwd", "") or "")
    if not cmd:
        return jsonify({"ok": False, "error": "Comando vacío."}), 400
    if not cwd or not os.path.isdir(cwd):
        cwd = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # carpeta del proyecto

    mark = "===YUKICWD==="
    full = f"chcp 65001>nul & {cmd} & echo {mark} & cd"
    try:
        proc = subprocess.run(
            ["cmd", "/c", full],
            cwd=cwd,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=40,
        )
        out = (proc.stdout or "") + (proc.stderr or "")
        new_cwd = cwd
        if mark in out:
            before, after = out.split(mark, 1)
            out = before
            lines = [ln.strip() for ln in after.splitlines() if ln.strip()]
            if lines and os.path.isdir(lines[-1]):
                new_cwd = lines[-1]
        return jsonify({"ok": proc.returncode == 0, "output": out[:_MAX_OUT], "cwd": new_cwd})
    except subprocess.TimeoutExpired:
        return jsonify({"ok": False, "error": "⏱️ El comando tardó demasiado (40s).", "cwd": cwd})
    except Exception as e:  # noqa
        return jsonify({"ok": False, "error": str(e), "cwd": cwd}), 500


# ----------------------------------------------------------------------
#  Consola de Python (REPL): un intérprete que RECUERDA las variables entre
#  líneas. Escribes Python (print, x=5, etc.) y se ejecuta. Solo admin.
# ----------------------------------------------------------------------
_REPL_DELIM = "<<<YUKI_REPL_DONE>>>"
# Consola interactiva de verdad: soporta bloques de varias líneas (def/for/while…)
# con continuación. Devuelve por cada línea {out, more}: more=True significa
# "necesito más líneas" (el bloque sigue), como el prompt '...' de Python.
_REPL_DRIVER = r'''
import sys, io, json, code, traceback
_con = code.InteractiveConsole({'__name__': '__main__'})
_D = '<<<YUKI_REPL_DONE>>>'
for _line in sys.stdin:
    try:
        _src = json.loads(_line).get('code', '')
    except Exception:
        continue
    _buf = io.StringIO(); _o, _e = sys.stdout, sys.stderr
    sys.stdout = _buf; sys.stderr = _buf
    _more = False
    try:
        _more = _con.push(_src)
    except SystemExit:
        _con.resetbuffer(); _more = False
    except BaseException:
        traceback.print_exc()
    finally:
        sys.stdout = _o; sys.stderr = _e
    sys.stdout.write(json.dumps({'out': _buf.getvalue(), 'more': bool(_more)}) + '\n' + _D + '\n')
    sys.stdout.flush()
'''

_repl_sessions = {}  # sid -> {proc, queue, workdir}


def _start_repl():
    import subprocess
    import tempfile

    workdir = tempfile.mkdtemp(prefix="yuki_repl_")
    driver = os.path.join(workdir, "repl.py")
    with open(driver, "w", encoding="utf-8") as f:
        f.write(_REPL_DRIVER)
    env = dict(os.environ, PYTHONIOENCODING="utf-8", MPLBACKEND="Agg")
    proc = subprocess.Popen(
        [_runner_python(), "-u", driver],
        stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, encoding="utf-8", errors="replace",
        cwd=os.path.dirname(os.path.dirname(os.path.abspath(__file__))), env=env,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    q: "queue.Queue" = queue.Queue()

    def _reader():
        for ln in proc.stdout:
            q.put(ln)
        q.put(None)

    threading.Thread(target=_reader, daemon=True).start()
    sid = secrets.token_urlsafe(12)
    _repl_sessions[sid] = {"proc": proc, "queue": q, "workdir": workdir}
    return sid


def _kill_repl(sid):
    sess = _repl_sessions.pop(sid, None)
    if not sess:
        return
    try:
        sess["proc"].kill()
    except Exception:  # noqa
        pass
    try:
        import shutil
        shutil.rmtree(sess.get("workdir", ""), ignore_errors=True)
    except Exception:  # noqa
        pass


@app.route("/repl", methods=["POST"])
def repl():
    if not _admin_ok():
        return jsonify({"ok": False, "error": "Se requiere la contraseña de administrador."}), 403
    data = request.get_json(force=True, silent=True) or {}
    src = data.get("code", "")
    if not isinstance(src, str):
        src = ""
    sid = data.get("sid") or ""
    sess = _repl_sessions.get(sid)
    if not sess or sess["proc"].poll() is not None:
        sid = _start_repl()
        sess = _repl_sessions[sid]

    try:
        sess["proc"].stdin.write(json.dumps({"code": src}) + "\n")
        sess["proc"].stdin.flush()
    except Exception:  # noqa
        _kill_repl(sid)
        return jsonify({"ok": False, "output": "(la consola se reinició)", "sid": None})

    out = []
    deadline = time.time() + 20
    while True:
        remaining = deadline - time.time()
        if remaining <= 0:
            _kill_repl(sid)  # posible bucle infinito → matar y reiniciar
            return jsonify({
                "ok": False,
                "output": "".join(out) + "\n⏱️ Se agotó el tiempo. La consola se reinició (se perdieron las variables).",
                "sid": None,
            })
        try:
            ln = sess["queue"].get(timeout=min(0.2, remaining))
        except queue.Empty:
            continue
        if ln is None:  # el proceso terminó
            _kill_repl(sid)
            return jsonify({"ok": False, "output": "".join(out) + "\n(la consola terminó)", "sid": None})
        if ln.rstrip("\n") == _REPL_DELIM:
            break
        out.append(ln)
    payload = "".join(out).strip()
    text, more = payload, False
    try:
        obj = json.loads(payload)
        text = obj.get("out", "")
        more = bool(obj.get("more"))
    except Exception:  # noqa
        pass
    return jsonify({"ok": True, "output": text, "more": more, "sid": sid})


@app.route("/replstop", methods=["POST"])
def replstop():
    if not _admin_ok():
        return jsonify({"ok": False}), 403
    data = request.get_json(force=True, silent=True) or {}
    _kill_repl(data.get("sid", ""))
    return jsonify({"ok": True})


# ======================================================================
#  Ventana en vivo (solo ver): corre un programa con GUI (pygame/tkinter/
#  turtle/cv2) en la PC y transmite SU VENTANA al navegador del usuario,
#  como compartir pantalla. Sin control. Solo administrador. Local y privado.
# ======================================================================
_user32 = ctypes.windll.user32
_gdi32 = ctypes.windll.gdi32
try:
    _user32.SetProcessDPIAware()
except Exception:  # noqa
    pass

_WNDENUMPROC = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)


class _BMIH(ctypes.Structure):
    _fields_ = [
        ("biSize", wintypes.DWORD), ("biWidth", wintypes.LONG), ("biHeight", wintypes.LONG),
        ("biPlanes", wintypes.WORD), ("biBitCount", wintypes.WORD), ("biCompression", wintypes.DWORD),
        ("biSizeImage", wintypes.DWORD), ("biXPelsPerMeter", wintypes.LONG), ("biYPelsPerMeter", wintypes.LONG),
        ("biClrUsed", wintypes.DWORD), ("biClrImportant", wintypes.DWORD),
    ]


class _BMI(ctypes.Structure):
    _fields_ = [("bmiHeader", _BMIH), ("bmiColors", wintypes.DWORD * 3)]


_gui_sessions = {}  # sid -> {proc, hwnd, running, workdir}


def _runner_pythonw() -> str:
    here = os.path.dirname(os.path.abspath(__file__))
    p = os.path.join(here, ".venv", "Scripts", "pythonw.exe")
    return p if os.path.exists(p) else _runner_python()


def _descendants(pid):
    s = {pid}
    if psutil is not None:
        try:
            for c in psutil.Process(pid).children(recursive=True):
                s.add(c.pid)
        except Exception:  # noqa
            pass
    return s


def _find_window(pids):
    out = []

    def cb(hwnd, lparam):
        if _user32.IsWindowVisible(hwnd):
            p = wintypes.DWORD()
            _user32.GetWindowThreadProcessId(hwnd, ctypes.byref(p))
            if p.value in pids:
                r = wintypes.RECT()
                _user32.GetWindowRect(hwnd, ctypes.byref(r))
                if (r.right - r.left) > 30 and (r.bottom - r.top) > 30:
                    out.append(hwnd)
        return True

    _user32.EnumWindows(_WNDENUMPROC(cb), 0)
    return out[0] if out else None


def _capture_window(hwnd):
    """Copia el área cliente de la ventana a una imagen (PrintWindow). Funciona
    aunque la ventana esté tapada. Devuelve una imagen PIL o None."""
    from PIL import Image

    r = wintypes.RECT()
    _user32.GetClientRect(hwnd, ctypes.byref(r))
    w, h = r.right - r.left, r.bottom - r.top
    if w <= 0 or h <= 0:
        return None
    hdc = _user32.GetDC(hwnd)
    memdc = _gdi32.CreateCompatibleDC(hdc)
    bmp = _gdi32.CreateCompatibleBitmap(hdc, w, h)
    old = _gdi32.SelectObject(memdc, bmp)
    try:
        _user32.PrintWindow(hwnd, memdc, 2)  # PW_RENDERFULLCONTENT
        bmi = _BMI()
        bmi.bmiHeader.biSize = ctypes.sizeof(_BMIH)
        bmi.bmiHeader.biWidth = w
        bmi.bmiHeader.biHeight = -h
        bmi.bmiHeader.biPlanes = 1
        bmi.bmiHeader.biBitCount = 32
        bmi.bmiHeader.biCompression = 0
        buf = ctypes.create_string_buffer(w * h * 4)
        _gdi32.GetDIBits(memdc, bmp, 0, h, buf, ctypes.byref(bmi), 0)
        return Image.frombuffer("RGB", (w, h), buf, "raw", "BGRX", 0, 1)
    finally:
        _gdi32.SelectObject(memdc, old)
        _gdi32.DeleteObject(bmp)
        _gdi32.DeleteDC(memdc)
        _user32.ReleaseDC(hwnd, hdc)


def _kill_tree(proc, hwnd=None):
    """Cierra el programa y su ventana de verdad: mata el proceso, sus hijos
    (el venv relanza un hijo que es el dueño de la ventana) y el proceso que
    posee la ventana, por si el lanzador ya había terminado."""
    pids = set()
    if hwnd:
        pid = wintypes.DWORD()
        _user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if pid.value:
            pids.add(pid.value)
    if proc is not None:
        pids.add(proc.pid)
        pids |= _descendants(proc.pid)
    for pid in pids:
        if psutil is not None:
            try:
                psutil.Process(pid).kill()
            except Exception:  # noqa
                pass
    try:
        if proc is not None:
            proc.kill()
    except Exception:  # noqa
        pass


def _cleanup_session(sid):
    sess = _gui_sessions.pop(sid, None)
    if not sess:
        return
    sess["running"] = False
    _kill_tree(sess.get("proc"), sess.get("hwnd"))
    try:
        import shutil
        shutil.rmtree(sess.get("workdir", ""), ignore_errors=True)
    except Exception:  # noqa
        pass


@app.route("/guistart", methods=["POST"])
def guistart():
    import tempfile
    import subprocess

    if not _admin_ok():
        return jsonify({"ok": False, "error": "Se requiere la contraseña de administrador."}), 403
    if psutil is None:
        return jsonify({"ok": False, "error": "Falta 'psutil' en el servidor."}), 500

    data = request.get_json(force=True, silent=True) or {}
    code = data.get("code", "")
    if not isinstance(code, str) or not code.strip():
        return jsonify({"ok": False, "error": "No hay código para ejecutar."}), 400

    for sid0 in list(_gui_sessions):  # limpiar muertas
        s0 = _gui_sessions.get(sid0)
        if s0 and s0["proc"].poll() is not None:
            _cleanup_session(sid0)

    workdir = tempfile.mkdtemp(prefix="yuki_gui_")
    script = os.path.join(workdir, "app.py")
    with open(script, "w", encoding="utf-8") as f:
        f.write(code)
    outpath = os.path.join(workdir, "out.txt")
    outf = open(outpath, "w+", encoding="utf-8", errors="replace")
    env = dict(os.environ, PYTHONIOENCODING="utf-8")
    proc = subprocess.Popen(
        [_runner_pythonw(), script], cwd=workdir, stdout=outf, stderr=outf, env=env
    )

    hwnd = None
    for _ in range(50):  # ~10 s esperando a que abra la ventana
        time.sleep(0.2)
        if proc.poll() is not None:
            break
        hwnd = _find_window(_descendants(proc.pid))
        if hwnd:
            break

    if not hwnd:
        try:
            outf.flush()
            outf.seek(0)
            msg = outf.read()[:4000]
        except Exception:  # noqa
            msg = ""
        _kill_tree(proc)
        import shutil
        shutil.rmtree(workdir, ignore_errors=True)
        if proc.poll() is not None and msg.strip():
            return jsonify({"ok": False, "error": "El programa terminó:\n" + msg})
        return jsonify({"ok": False, "error": "No se abrió ninguna ventana. ¿El programa crea una ventana (pygame/tkinter/turtle)?"})

    sid = secrets.token_urlsafe(16)
    _gui_sessions[sid] = {"proc": proc, "hwnd": hwnd, "running": True, "workdir": workdir}
    r = wintypes.RECT()
    _user32.GetClientRect(hwnd, ctypes.byref(r))
    return jsonify({"ok": True, "sid": sid, "width": r.right - r.left, "height": r.bottom - r.top})


@app.route("/guistream")
def guistream():
    sid = request.args.get("sid", "")
    sess = _gui_sessions.get(sid)
    if not sess:
        return ("sin sesión", 404)

    def gen():
        while sess.get("running"):
            if sess["proc"].poll() is not None:
                break
            try:
                img = _capture_window(sess["hwnd"])
            except Exception:  # noqa
                img = None
            if img is None:
                time.sleep(0.1)
                continue
            if img.width > 1100:  # limitar ancho para la red
                nh = int(img.height * 1100 / img.width)
                img = img.resize((1100, nh))
            b = io.BytesIO()
            img.save(b, "JPEG", quality=60)
            data = b.getvalue()
            yield (
                b"--frame\r\nContent-Type: image/jpeg\r\nContent-Length: "
                + str(len(data)).encode()
                + b"\r\n\r\n"
                + data
                + b"\r\n"
            )
            time.sleep(1 / 18.0)
        if sess["proc"].poll() is not None:
            _cleanup_session(sid)

    return Response(gen(), mimetype="multipart/x-mixed-replace; boundary=frame")


@app.route("/guistatus", methods=["POST"])
def guistatus():
    if not _admin_ok():
        return jsonify({"ok": False}), 403
    data = request.get_json(force=True, silent=True) or {}
    sess = _gui_sessions.get(data.get("sid", ""))
    return jsonify({"ok": True, "alive": bool(sess and sess["proc"].poll() is None)})


@app.route("/guistop", methods=["POST"])
def guistop():
    if not _admin_ok():
        return jsonify({"ok": False}), 403
    data = request.get_json(force=True, silent=True) or {}
    _cleanup_session(data.get("sid", ""))
    return jsonify({"ok": True})


@app.route("/generate", methods=["POST"])
def generate():
    if pipe is None:
        return jsonify({"error": "El modelo aún no está cargado.", "loading": loading}), 503
    data = request.get_json(force=True) or {}
    prompt = str(data.get("prompt", "")).strip()
    if not prompt:
        return jsonify({"error": "Falta el prompt."}), 400
    width = int(data.get("width", 512))
    height = int(data.get("height", 512))
    seed = data.get("seed", None)
    user_neg = str(data.get("negative_prompt", "")).strip()

    # El slider de la app manda un "nivel de calidad" 1-8.
    q = max(1, min(8, int(data.get("steps", 2))))
    if is_turbo:
        # sd-turbo: unos pocos pasos más = más detalle (sigue siendo rápido).
        steps = max(3, min(8, q + 2))  # nivel 1→3 … 6→8
        guidance = 1.5 if user_neg else 0.0
        negative = user_neg or None
    else:
        # Modelo con guía (DreamShaper): más pasos + guía + prompt negativo → calidad y fidelidad.
        steps = int(round(14 + q * 4))  # nivel 1→18 … 6→38 pasos
        guidance = float(data.get("guidance", 7.0))
        negative = (user_neg + ", " + DEFAULT_NEGATIVE) if user_neg else DEFAULT_NEGATIVE

    gen = None
    if seed is not None and str(seed) != "":
        try:
            gen = torch.Generator(device="cpu").manual_seed(int(seed))
        except Exception:  # noqa
            gen = None

    # La GPU de 8GB es justa: liberamos la VRAM que retiene Ollama antes de generar.
    _free_gpu_memory()

    def _run(w, h):
        return pipe(
            prompt=prompt,
            negative_prompt=negative,
            num_inference_steps=steps,
            guidance_scale=guidance,
            width=w,
            height=h,
            generator=gen,
        ).images[0]

    t0 = time.time()
    image = None
    for attempt in range(3):
        try:
            image = _run(width, height)
            break
        except (RuntimeError, MemoryError) as e:  # noqa
            msg = str(e).lower()
            if "memory" not in msg and "allocate" not in msg:
                print("[sd-server] ERROR generate:", e)
                return jsonify({"error": str(e)[:200]}), 500
            print(f"[sd-server] Sin VRAM (intento {attempt+1}); libero y reintento…")
            _free_gpu_memory()
            gc.collect()
            time.sleep(1.5)
            # en el último intento, bajamos la resolución para que quepa
            if attempt == 1 and width > 384:
                width, height = 384, 384
    if image is None:
        return jsonify({
            "error": "La GPU se quedó sin memoria. Cierra apps que usen la tarjeta (juegos, Discord, muchas pestañas) o reinicia imagenes.bat.",
        }), 507

    buf = io.BytesIO()
    image.save(buf, format="PNG")
    b64 = base64.b64encode(buf.getvalue()).decode()

    # Liberar memoria entre generaciones (DirectML no lo hace solo).
    del image
    gc.collect()

    return jsonify({"image": b64, "seconds": round(time.time() - t0, 1)})


@app.route("/transcribe", methods=["POST"])
def transcribe():
    if "audio" not in request.files:
        return jsonify({"error": "Falta el audio."}), 400
    f = request.files["audio"]
    lang = (request.form.get("lang", "es") or "").strip() or None

    import tempfile
    import os

    tmp = tempfile.NamedTemporaryFile(suffix=".webm", delete=False)
    try:
        f.save(tmp.name)
        tmp.close()
        model = get_whisper()
        segments, _info = model.transcribe(tmp.name, language=lang, vad_filter=True)
        text = "".join(seg.text for seg in segments).strip()
        return jsonify({"text": text})
    except Exception as e:  # noqa
        print("[sd-server] ERROR transcribe:", e)
        return jsonify({"error": str(e)}), 500
    finally:
        try:
            os.unlink(tmp.name)
        except Exception:  # noqa
            pass


# ---------------------------------------------------------------------------
# Generación de documentos (Word / PDF / Presentaciones / Excel / Póster)
# ---------------------------------------------------------------------------
import random

# Temas de diseño (se elige uno al azar por documento salvo que se indique).
THEMES = [
    {"name": "violeta", "accent": "6366F1", "dark": "6D28D9", "font": "Calibri"},
    {"name": "azul", "accent": "2563EB", "dark": "1E3A8A", "font": "Verdana"},
    {"name": "verde", "accent": "16A34A", "dark": "14532D", "font": "Calibri"},
    {"name": "naranja", "accent": "EA580C", "dark": "9A3412", "font": "Trebuchet MS"},
    {"name": "coral", "accent": "E11D48", "dark": "9F1239", "font": "Georgia"},
    {"name": "teal", "accent": "0D9488", "dark": "134E4A", "font": "Verdana"},
]


def pick_theme(hint=None):
    if hint:
        for t in THEMES:
            if t["name"] == str(hint).lower():
                return t
    return random.choice(THEMES)


def _hex(h):
    h = str(h).lstrip("#")
    return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)


def _img_stream(b64):
    if not b64:
        return None
    try:
        return io.BytesIO(base64.b64decode(b64))
    except Exception:  # noqa
        return None


def _pptx_transition(slide, kind="fade"):
    """Añade una transición suave a la diapositiva (PowerPoint la aplica al pasar)."""
    try:
        from pptx.oxml.ns import qn

        sld = slide.element
        for t in sld.findall(qn("p:transition")):
            sld.remove(t)
        trans = sld.makeelement(qn("p:transition"), {"spd": "med"})
        trans.append(sld.makeelement(qn("p:" + kind), {}))
        sld.append(trans)
    except Exception:  # noqa
        pass


def build_pptx(title, subtitle, slides, cover_b64, theme):
    from pptx import Presentation
    from pptx.util import Inches, Pt, Emu
    from pptx.dml.color import RGBColor
    from pptx.enum.shapes import MSO_SHAPE
    from pptx.enum.text import PP_ALIGN, MSO_ANCHOR, MSO_AUTO_SIZE

    ar, ag, ab = _hex(theme["accent"])
    dr, dg, db = _hex(theme["dark"])
    ACCENT = RGBColor(ar, ag, ab)
    DARK_BG = RGBColor(dr, dg, db)
    TEXT = RGBColor(0x1F, 0x27, 0x33)
    MUTED = RGBColor(0x56, 0x60, 0x70)
    WHITE = RGBColor(0xFF, 0xFF, 0xFF)
    LIGHT = RGBColor(0xF6, 0xF7, 0xFB)
    SOFT = RGBColor(0xEC, 0xEE, 0xF6)  # tarjeta suave
    FONT = theme["font"]

    prs = Presentation()
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)
    W, H = prs.slide_width, prs.slide_height
    blank = prs.slide_layouts[6]

    def rect(slide, x, y, w, h, color, shape=MSO_SHAPE.RECTANGLE, line=None):
        sp = slide.shapes.add_shape(shape, x, y, w, h)
        sp.fill.solid()
        sp.fill.fore_color.rgb = color
        if line is None:
            sp.line.fill.background()
        else:
            sp.line.color.rgb = line
            sp.line.width = Pt(1)
        sp.shadow.inherit = False
        return sp

    def set_notes(slide, text):
        if not text:
            return
        try:
            slide.notes_slide.notes_text_frame.text = str(text)
        except Exception:  # noqa
            pass

    # --- Portada ---
    s = prs.slides.add_slide(blank)
    rect(s, 0, 0, W, H, DARK_BG)
    rect(s, 0, 0, Inches(0.4), H, ACCENT)  # banda de acento izquierda
    try:  # círculos decorativos
        rect(s, Inches(10.6), Inches(-1.6), Inches(4.4), Inches(4.4), ACCENT, MSO_SHAPE.OVAL)
        deep = rect(s, Inches(9.2), Inches(4.9), Inches(2.4), Inches(2.4), WHITE, MSO_SHAPE.OVAL)
        deep.fill.fore_color.rgb = RGBColor(min(dr + 24, 255), min(dg + 24, 255), min(db + 30, 255))
    except Exception:  # noqa
        pass
    cover = _img_stream(cover_b64)
    if cover:
        try:
            s.shapes.add_picture(cover, Inches(8.7), Inches(2.05), height=Inches(3.9))
        except Exception:  # noqa
            pass
    tb = s.shapes.add_textbox(Inches(0.95), Inches(2.2), Inches(7.4), Inches(3.4))
    tf = tb.text_frame
    tf.word_wrap = True
    tf.auto_size = MSO_AUTO_SIZE.TEXT_TO_FIT_SHAPE
    r = tf.paragraphs[0].add_run()
    r.text = str(title)
    r.font.size = Pt(46)
    r.font.bold = True
    r.font.color.rgb = WHITE
    r.font.name = FONT
    if subtitle:
        p2 = tf.add_paragraph()
        p2.space_before = Pt(12)
        r2 = p2.add_run()
        r2.text = str(subtitle)
        r2.font.size = Pt(20)
        r2.font.color.rgb = RGBColor(0xDD, 0xE0, 0xF2)
        r2.font.name = FONT
    _pptx_transition(s, "fade")
    set_notes(s, "Diapositiva de portada.")

    # --- Diapositivas de contenido (descartando las vacías) ---
    clean = []
    for sl in slides:
        t = str(sl.get("title", "") or "").strip()
        b = str(sl.get("body", "") or "").strip()
        bl = [str(x).strip() for x in (sl.get("bullets") or []) if str(x).strip()]
        if not (t or b or bl):
            continue  # nada que mostrar → no crear diapositiva en blanco
        clean.append({**sl, "title": t, "body": b, "bullets": bl})
    total = len(clean)

    for idx, sl in enumerate(clean, start=1):
        cs = prs.slides.add_slide(blank)
        rect(cs, 0, 0, W, H, LIGHT)  # fondo

        img = _img_stream(sl.get("image"))
        has_img = img is not None
        emoji = str(sl.get("emoji", "") or "").strip()

        # Banda de cabecera (alterna acento / oscuro para dar variedad)
        head_color = ACCENT if idx % 2 == 1 else DARK_BG
        rect(cs, 0, 0, W, Inches(1.45), head_color)
        rect(cs, 0, Inches(1.45), W, Inches(0.09), DARK_BG if idx % 2 == 1 else ACCENT)

        # Titular (blanco sobre la banda) + emoji sticker
        head_txt_w = Inches(11.0) if emoji else Inches(12.1)
        tb = cs.shapes.add_textbox(Inches(0.7), Inches(0.2), head_txt_w, Inches(1.05))
        ttf = tb.text_frame
        ttf.word_wrap = True
        ttf.vertical_anchor = MSO_ANCHOR.MIDDLE
        ttf.auto_size = MSO_AUTO_SIZE.TEXT_TO_FIT_SHAPE
        tr = ttf.paragraphs[0].add_run()
        tr.text = sl["title"] or f"Diapositiva {idx}"
        tr.font.size = Pt(30)
        tr.font.bold = True
        tr.font.color.rgb = WHITE
        tr.font.name = FONT
        if emoji:
            eb = cs.shapes.add_textbox(Inches(11.7), Inches(0.15), Inches(1.4), Inches(1.15))
            etf = eb.text_frame
            etf.vertical_anchor = MSO_ANCHOR.MIDDLE
            ep = etf.paragraphs[0]
            ep.alignment = PP_ALIGN.CENTER
            er = ep.add_run()
            er.text = emoji
            er.font.size = Pt(44)

        # Región de contenido (una sola caja con auto-ajuste → nunca se superpone)
        cx, cy = Inches(0.75), Inches(1.9)
        cw = Inches(6.7) if has_img else Inches(11.85)
        ch = Inches(4.9)
        bt = cs.shapes.add_textbox(cx, cy, cw, ch)
        btf = bt.text_frame
        btf.word_wrap = True
        btf.auto_size = MSO_AUTO_SIZE.TEXT_TO_FIT_SHAPE

        first = True
        if sl["body"]:
            p = btf.paragraphs[0]
            p.space_after = Pt(12)
            rb = p.add_run()
            rb.text = sl["body"]
            rb.font.size = Pt(16)
            rb.font.color.rgb = MUTED
            rb.font.name = FONT
            first = False

        for b in sl["bullets"]:
            p = btf.paragraphs[0] if first else btf.add_paragraph()
            first = False
            p.space_after = Pt(9)
            mk = p.add_run()
            mk.text = "▸  "
            mk.font.size = Pt(18)
            mk.font.bold = True
            mk.font.color.rgb = ACCENT
            mk.font.name = FONT
            run = p.add_run()
            run.text = str(b)
            run.font.size = Pt(18)
            run.font.color.rgb = TEXT
            run.font.name = FONT

        # Imagen a la derecha, dentro de una tarjeta
        if has_img:
            try:
                rect(cs, Inches(7.7), Inches(1.95), Inches(5.0), Inches(4.75), SOFT, MSO_SHAPE.ROUNDED_RECTANGLE)
                cs.shapes.add_picture(img, Inches(7.95), Inches(2.2), width=Inches(4.5))
            except Exception:  # noqa
                pass

        # Pie: línea de acento + número en píldora
        rect(cs, 0, Inches(7.34), W, Inches(0.16), ACCENT)
        pill = rect(cs, Inches(11.75), Inches(6.78), Inches(1.15), Inches(0.42), ACCENT, MSO_SHAPE.ROUNDED_RECTANGLE)
        ptf = pill.text_frame
        ptf.word_wrap = False
        pr = ptf.paragraphs[0]
        pr.alignment = PP_ALIGN.CENTER
        prr = pr.add_run()
        prr.text = f"{idx} / {total}"
        prr.font.size = Pt(11)
        prr.font.bold = True
        prr.font.color.rgb = WHITE
        prr.font.name = FONT
        # Título del documento en el pie (izquierda)
        fb = cs.shapes.add_textbox(Inches(0.6), Inches(6.82), Inches(9.0), Inches(0.4))
        fr = fb.text_frame.paragraphs[0].add_run()
        fr.text = str(title)
        fr.font.size = Pt(10)
        fr.font.color.rgb = MUTED
        fr.font.name = FONT

        _pptx_transition(cs, "fade")
        set_notes(cs, sl.get("notes", ""))

    out = io.BytesIO()
    prs.save(out)
    return out.getvalue()


def build_docx(title, subtitle, sections, cover_b64, theme):
    from docx import Document
    from docx.shared import Pt, RGBColor, Inches
    from docx.enum.text import WD_ALIGN_PARAGRAPH

    ar, ag, ab = _hex(theme["accent"])
    ACCENT = RGBColor(ar, ag, ab)
    doc = Document()
    try:
        doc.styles["Normal"].font.name = theme["font"]
    except Exception:  # noqa
        pass
    cover = _img_stream(cover_b64)
    if cover:
        try:
            doc.add_picture(cover, width=Inches(5.5))
            doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
        except Exception:  # noqa
            pass
    tp = doc.add_paragraph()
    tr = tp.add_run(title)
    tr.bold = True
    tr.font.size = Pt(26)
    tr.font.color.rgb = ACCENT
    if subtitle:
        sp = doc.add_paragraph()
        sr = sp.add_run(subtitle)
        sr.italic = True
        sr.font.size = Pt(13)
        sr.font.color.rgb = RGBColor(0x66, 0x66, 0x66)
    doc.add_paragraph()
    for sec in sections:
        hp = doc.add_heading(str(sec.get("heading", "")), level=1)
        for run in hp.runs:
            run.font.color.rgb = ACCENT
        for para in sec.get("paragraphs", []) or []:
            doc.add_paragraph(str(para))
        for b in sec.get("bullets", []) or []:
            doc.add_paragraph(str(b), style="List Bullet")
    out = io.BytesIO()
    doc.save(out)
    return out.getvalue()


def build_pdf(title, subtitle, sections, cover_b64, theme):
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import cm
    from reportlab.lib import colors
    from reportlab.platypus import (
        SimpleDocTemplate,
        Paragraph,
        Spacer,
        ListFlowable,
        ListItem,
        Image,
    )

    ACCENT = colors.HexColor("#" + theme["accent"])
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, topMargin=2 * cm, bottomMargin=2 * cm)
    styles = getSampleStyleSheet()
    t_style = ParagraphStyle("T", parent=styles["Title"], textColor=ACCENT, fontSize=24)
    s_style = ParagraphStyle("S", parent=styles["Normal"], fontSize=12, textColor=colors.grey)
    h_style = ParagraphStyle("H", parent=styles["Heading2"], textColor=ACCENT, spaceBefore=14)
    body = styles["BodyText"]

    story = []
    cover = _img_stream(cover_b64)
    if cover:
        try:
            story.append(Image(cover, width=10 * cm, height=10 * cm))
            story.append(Spacer(1, 12))
        except Exception:  # noqa
            pass
    story.append(Paragraph(title, t_style))
    if subtitle:
        story.append(Paragraph(subtitle, s_style))
    story.append(Spacer(1, 16))
    for sec in sections:
        story.append(Paragraph(str(sec.get("heading", "")), h_style))
        for para in sec.get("paragraphs", []) or []:
            story.append(Paragraph(str(para), body))
        bl = sec.get("bullets", []) or []
        if bl:
            items = [ListItem(Paragraph(str(b), body)) for b in bl]
            story.append(ListFlowable(items, bulletType="bullet"))
        story.append(Spacer(1, 10))
    doc.build(story)
    return buf.getvalue()


def _num(v):
    if isinstance(v, (int, float)):
        return v
    s = str(v).strip()
    try:
        t = s.lstrip("-").replace(".", "", 1).replace(",", "", 1)
        if t.isdigit():
            return float(s.replace(",", ".")) if ("." in s or "," in s) else int(s)
    except Exception:  # noqa
        pass
    return s


def build_xlsx(title, sheets, theme):
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Border, Side, Alignment

    ACC = theme["accent"]
    wb = Workbook()
    wb.remove(wb.active)
    thin = Side(style="thin", color="DDDDDD")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    header_fill = PatternFill("solid", fgColor=ACC)

    for sh in (sheets or [{"name": "Hoja1", "headers": [], "rows": []}]):
        name = str(sh.get("name", "Hoja"))[:31] or "Hoja"
        ws = wb.create_sheet(title=name)
        headers = sh.get("headers", []) or []
        rows = sh.get("rows", []) or []
        if headers:
            ws.append([str(h) for h in headers])
            for c in ws[1]:
                c.font = Font(bold=True, color="FFFFFF")
                c.fill = header_fill
                c.alignment = Alignment(horizontal="center")
        for row in rows:
            ws.append([_num(v) for v in (row or [])])
        for col in ws.columns:
            width = max((len(str(c.value)) for c in col if c.value is not None), default=8)
            ws.column_dimensions[col[0].column_letter].width = min(45, max(10, width + 2))
            for c in col:
                c.border = border
        if headers:
            ws.freeze_panes = "A2"
    if not wb.sheetnames:
        wb.create_sheet("Hoja1")
    out = io.BytesIO()
    wb.save(out)
    return out.getvalue()


def build_poster(title, subtitle, sections, hero_b64, theme):
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import cm
    from reportlab.lib import colors
    from reportlab.platypus import (
        SimpleDocTemplate,
        Paragraph,
        Spacer,
        Image,
        Table,
        TableStyle,
    )

    ACCENT = colors.HexColor("#" + theme["accent"])
    buf = io.BytesIO()
    doc = SimpleDocTemplate(
        buf, pagesize=A4, topMargin=1 * cm, bottomMargin=1 * cm,
        leftMargin=1.4 * cm, rightMargin=1.4 * cm,
    )
    styles = getSampleStyleSheet()
    t_style = ParagraphStyle("PT", parent=styles["Title"], textColor=colors.white, fontSize=30)
    s_style = ParagraphStyle("PS", parent=styles["Normal"], textColor=colors.white, fontSize=13, alignment=1)
    h_style = ParagraphStyle("PH", parent=styles["Heading2"], textColor=ACCENT, spaceBefore=10)
    body = styles["BodyText"]

    story = []
    header = Table(
        [[Paragraph(title, t_style)], [Paragraph(subtitle or "", s_style)]],
        colWidths=[doc.width],
    )
    header.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), ACCENT),
        ("TOPPADDING", (0, 0), (-1, -1), 18),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 18),
        ("LEFTPADDING", (0, 0), (-1, -1), 14),
    ]))
    story.append(header)
    story.append(Spacer(1, 14))
    hero = _img_stream(hero_b64)
    if hero:
        try:
            story.append(Image(hero, width=doc.width, height=8 * cm))
            story.append(Spacer(1, 14))
        except Exception:  # noqa
            pass
    for sec in sections:
        story.append(Paragraph(str(sec.get("heading", "")), h_style))
        txt = sec.get("text") or " ".join(sec.get("paragraphs", []) or [])
        if txt:
            story.append(Paragraph(str(txt), body))
        for b in sec.get("bullets", []) or []:
            story.append(Paragraph("• " + str(b), body))
        story.append(Spacer(1, 8))
    doc.build(story)
    return buf.getvalue()


@app.route("/doc/build", methods=["POST"])
def doc_build():
    data = request.get_json(force=True) or {}
    dtype = str(data.get("type", "pptx"))
    title = str(data.get("title") or "Documento")
    content = data.get("content") or {}
    cover = data.get("cover_image")
    subtitle = str(content.get("subtitle", "") or "")
    theme = pick_theme(content.get("theme") or data.get("theme"))
    try:
        ext = dtype
        if dtype == "pptx":
            blob = build_pptx(title, subtitle, content.get("slides", []), cover, theme)
            mime = "application/vnd.openxmlformats-officedocument.presentationml.presentation"
        elif dtype == "docx":
            blob = build_docx(title, subtitle, content.get("sections", []), cover, theme)
            mime = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        elif dtype == "pdf":
            blob = build_pdf(title, subtitle, content.get("sections", []), cover, theme)
            mime = "application/pdf"
        elif dtype == "xlsx":
            blob = build_xlsx(title, content.get("sheets", []), theme)
            mime = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        elif dtype == "poster":
            blob = build_poster(title, subtitle, content.get("sections", []), cover, theme)
            ext = "pdf"
            mime = "application/pdf"
        else:
            return jsonify({"error": "tipo no soportado"}), 400
        safe = "".join(c for c in title if c.isalnum() or c in " -_").strip()
        safe = safe.replace(" ", "_")[:40] or "documento"
        return jsonify(
            {
                "filename": f"{safe}.{ext}",
                "mime": mime,
                "base64": base64.b64encode(blob).decode(),
            }
        )
    except Exception as e:  # noqa
        print("[sd-server] ERROR doc:", e)
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    threading.Thread(target=load_model, daemon=True).start()
    print(f"[sd-server] Escuchando en http://127.0.0.1:{PORT}")
    app.run(host="127.0.0.1", port=PORT, threaded=True)
