import { useEffect, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import { BichitosWorld, CHARACTERS, ORDER, BTN_COLORS } from '../lib/bichitos'

interface Props {
  profileId: string
  onClose: () => void
}

interface Saved {
  roster: { id: string; key: string }[]
  speed: number
  scale: number
  climb: boolean
}

const key = (pid: string) => `asistente:bichitos:${pid}`

function load(pid: string): Saved {
  try {
    const raw = localStorage.getItem(key(pid))
    if (raw) {
      const s = JSON.parse(raw)
      return {
        roster: Array.isArray(s.roster) ? s.roster.filter((r: any) => CHARACTERS[r?.key]) : [],
        speed: typeof s.speed === 'number' ? s.speed : 1,
        scale: typeof s.scale === 'number' ? s.scale : 1,
        climb: s.climb !== false,
      }
    }
  } catch { /* noop */ }
  return { roster: [{ id: 'seed1', key: 'pollito' }, { id: 'seed2', key: 'gato' }], speed: 1, scale: 1, climb: true }
}

const pipSupported = typeof window !== 'undefined' && 'documentPictureInPicture' in window

export default function DesktopPets({ profileId, onClose }: Props) {
  const overlayRef = useRef<HTMLDivElement | null>(null)
  const worldRef = useRef<BichitosWorld | null>(null)
  const pipRef = useRef<Window | null>(null)
  const tearingDown = useRef(false)
  const [count, setCount] = useState(0)
  const [speed, setSpeed] = useState(1)
  const [scale, setScale] = useState(1)
  const [climb, setClimb] = useState(true)
  const [min, setMin] = useState(false)
  const [pipOn, setPipOn] = useState(false)
  const [pipMsg, setPipMsg] = useState('')

  const snapshot = (): Saved => {
    const w = worldRef.current
    if (w) return { roster: w.list(), speed: w.speed, scale: w.scale, climb: w.climb }
    return load(profileId)
  }
  const applyState = (w: BichitosWorld, s: Saved) => {
    w.setSettings({ speed: s.speed, scale: s.scale, climb: s.climb })
    s.roster.forEach((r) => w.add(r.key, r.id))
  }

  // crear el mundo en la página una vez que la capa existe
  useEffect(() => {
    if (!overlayRef.current) return
    const saved = load(profileId)
    const w = new BichitosWorld(overlayRef.current)
    worldRef.current = w
    applyState(w, saved)
    setSpeed(saved.speed)
    setScale(saved.scale)
    setClimb(saved.climb)
    setCount(w.count())
    return () => {
      tearingDown.current = true
      try { pipRef.current?.close() } catch { /* noop */ }
      pipRef.current = null
      w.destroy()
      worldRef.current = null
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [profileId])

  const persist = () => {
    const w = worldRef.current
    if (!w) return
    const data: Saved = { roster: w.list(), speed: w.speed, scale: w.scale, climb: w.climb }
    try { localStorage.setItem(key(profileId), JSON.stringify(data)) } catch { /* noop */ }
  }

  const add = (k: string) => {
    const w = worldRef.current
    if (!w) return
    w.add(k)
    setCount(w.count())
    persist()
  }
  const removeLast = () => {
    const w = worldRef.current
    if (!w) return
    w.removeLast()
    setCount(w.count())
    persist()
  }
  const removeAll = () => {
    const w = worldRef.current
    if (!w) return
    w.removeAll()
    setCount(w.count())
    persist()
  }
  const changeSpeed = (v: number) => {
    setSpeed(v)
    worldRef.current?.setSettings({ speed: v })
    persist()
  }
  const changeScale = (v: number) => {
    setScale(v)
    worldRef.current?.setSettings({ scale: v })
    persist()
  }
  const changeClimb = (v: boolean) => {
    setClimb(v)
    worldRef.current?.setSettings({ climb: v })
    persist()
  }

  // --- ventana flotante SIEMPRE ENCIMA (Document Picture-in-Picture) ---
  const enterPip = async () => {
    setPipMsg('')
    const dpip = (window as any).documentPictureInPicture
    if (!dpip) {
      setPipMsg('Este dispositivo no permite la ventana flotante. Abre Yuki con https:// (o en localhost).')
      return
    }
    const snap = snapshot()
    let pip: Window
    try {
      pip = await dpip.requestWindow({ width: 420, height: 300 })
    } catch {
      setPipMsg('No se pudo abrir la ventana flotante (tu navegador o la escuela la bloquean).')
      return
    }
    const style = pip.document.createElement('style')
    style.textContent =
      'html,body{margin:0;height:100%;overflow:hidden;' +
      'background:linear-gradient(#dbeeff,#eaf7ea 66%,#d6ebc6);' +
      'font-family:system-ui,sans-serif;} *{box-sizing:border-box}'
    pip.document.head.appendChild(style)
    const hint = pip.document.createElement('div')
    hint.textContent = '🐾 Bichitos · arrástralos · esta ventana flota sobre todo'
    hint.style.cssText =
      'position:fixed;top:4px;left:0;right:0;text-align:center;font-size:10px;color:#5b6472;pointer-events:none;'
    pip.document.body.appendChild(hint)
    const cont = pip.document.createElement('div')
    cont.style.cssText = 'position:fixed;inset:0;overflow:hidden;'
    pip.document.body.appendChild(cont)

    worldRef.current?.destroy()
    const w = new BichitosWorld(cont, pip)
    worldRef.current = w
    applyState(w, snap)
    setCount(w.count())
    pipRef.current = pip
    setPipOn(true)

    pip.addEventListener('pagehide', () => {
      const snap2: Saved = { roster: w.list(), speed: w.speed, scale: w.scale, climb: w.climb }
      w.destroy()
      pipRef.current = null
      setPipOn(false)
      if (tearingDown.current || !overlayRef.current) return
      const w2 = new BichitosWorld(overlayRef.current)
      worldRef.current = w2
      applyState(w2, snap2)
      setCount(w2.count())
      try { localStorage.setItem(key(profileId), JSON.stringify(snap2)) } catch { /* noop */ }
    })
  }
  const exitPip = () => {
    try { pipRef.current?.close() } catch { /* noop */ }
  }

  const overlay = createPortal(
    <div
      ref={overlayRef}
      style={{
        position: 'fixed',
        inset: 0,
        pointerEvents: 'none',
        overflow: 'hidden',
        zIndex: 2147483000,
      }}
    />,
    document.body,
  )

  const panel = createPortal(
    min ? (
      <button
        onClick={() => setMin(false)}
        title="Bichitos"
        style={{ position: 'fixed', right: 16, bottom: 88, zIndex: 2147483001 }}
        className="w-12 h-12 rounded-full bg-indigo-600 text-white text-2xl shadow-lg hover:scale-105 transition grid place-items-center"
      >
        🐾
      </button>
    ) : (
      <div
        style={{ position: 'fixed', right: 16, bottom: 88, zIndex: 2147483001, width: 300, maxWidth: '92vw' }}
        className="rounded-2xl bg-white/95 dark:bg-zinc-900/95 backdrop-blur border border-black/10 dark:border-white/10 shadow-2xl p-3 text-zinc-800 dark:text-zinc-100"
      >
        <div className="flex items-center justify-between mb-2">
          <div className="font-semibold text-sm">🐾 Bichitos de escritorio</div>
          <div className="flex items-center gap-1">
            <button
              onClick={() => setMin(true)}
              title="Minimizar (siguen caminando)"
              className="w-7 h-7 rounded-lg hover:bg-black/10 dark:hover:bg-white/10 grid place-items-center"
            >
              —
            </button>
            <button
              onClick={onClose}
              title="Cerrar y quitar bichitos"
              className="w-7 h-7 rounded-lg hover:bg-black/10 dark:hover:bg-white/10 grid place-items-center"
            >
              ✕
            </button>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-1.5 mb-2">
          {ORDER.map((k) => (
            <button
              key={k}
              onClick={() => add(k)}
              style={{ background: BTN_COLORS[k] }}
              className="text-[11px] font-semibold text-zinc-900 rounded-lg px-1 py-1.5 hover:brightness-105 active:scale-95 transition"
            >
              {CHARACTERS[k].name}
            </button>
          ))}
        </div>

        <div className="text-[11px] text-zinc-500 dark:text-zinc-400 mb-2 text-center">
          {count} bichito{count !== 1 ? 's' : ''} en pantalla · arrástralos con el dedo o el mouse
        </div>

        <button
          onClick={pipOn ? exitPip : enterPip}
          className={`w-full text-xs rounded-lg py-2 mb-1 font-semibold ${
            pipOn
              ? 'bg-zinc-200 dark:bg-zinc-800 hover:bg-zinc-300 dark:hover:bg-zinc-700'
              : 'bg-indigo-600 text-white hover:bg-indigo-700'
          }`}
        >
          {pipOn ? '🪟 Traer de vuelta a Yuki' : '🪟 Ventana flotante (encima de todo)'}
        </button>
        {!pipOn && (
          <div className="text-[10px] text-zinc-500 dark:text-zinc-400 mb-2 text-center leading-tight">
            Saca los bichitos a una ventanita que flota sobre otras pestañas y apps
            {!pipSupported && ' · necesita https'}
          </div>
        )}
        {pipMsg && (
          <div className="text-[11px] text-amber-700 dark:text-amber-400 mb-2 text-center leading-tight">{pipMsg}</div>
        )}

        <label className="block text-xs mb-0.5">Velocidad</label>
        <input
          type="range" min={0.3} max={2.5} step={0.1} value={speed}
          onChange={(e) => changeSpeed(parseFloat(e.target.value))}
          className="w-full mb-2 accent-indigo-600"
        />
        <label className="block text-xs mb-0.5">Tamaño</label>
        <input
          type="range" min={0.6} max={1.8} step={0.1} value={scale}
          onChange={(e) => changeScale(parseFloat(e.target.value))}
          className="w-full mb-2 accent-indigo-600"
        />

        <label className="flex items-center gap-2 text-xs mb-2 cursor-pointer">
          <input type="checkbox" checked={climb} onChange={(e) => changeClimb(e.target.checked)} className="accent-indigo-600" />
          Treparse por los bordes de la pantalla
        </label>

        <div className="flex gap-1.5">
          <button
            onClick={removeLast}
            className="flex-1 text-xs rounded-lg bg-zinc-200 dark:bg-zinc-800 py-1.5 hover:bg-zinc-300 dark:hover:bg-zinc-700"
          >
            Quitar uno
          </button>
          <button
            onClick={removeAll}
            className="flex-1 text-xs rounded-lg bg-zinc-200 dark:bg-zinc-800 py-1.5 hover:bg-zinc-300 dark:hover:bg-zinc-700"
          >
            Quitar todos
          </button>
        </div>
      </div>
    ),
    document.body,
  )

  return (
    <>
      {overlay}
      {panel}
    </>
  )
}
