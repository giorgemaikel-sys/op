import type { WallPost } from './types'

export async function listWall(): Promise<WallPost[]> {
  try {
    const r = await fetch('/store/wall')
    const d = await r.json()
    return (d.posts ?? []) as WallPost[]
  } catch {
    return []
  }
}

export async function postWall(post: {
  author: string
  avatar: string
  text?: string
  sticker?: string
  ai?: boolean
}): Promise<WallPost | null> {
  try {
    const r = await fetch('/store/wall', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(post),
    })
    const d = await r.json()
    return (d.post ?? null) as WallPost | null
  } catch {
    return null
  }
}

export async function reactWall(id: string, emoji: string, author: string): Promise<WallPost | null> {
  try {
    const r = await fetch('/store/wall/react', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, emoji, author }),
    })
    const d = await r.json()
    return (d.post ?? null) as WallPost | null
  } catch {
    return null
  }
}

export async function replyWall(
  id: string,
  reply: { author: string; avatar: string; text: string },
): Promise<WallPost | null> {
  try {
    const r = await fetch('/store/wall/reply', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, ...reply }),
    })
    const d = await r.json()
    return (d.post ?? null) as WallPost | null
  } catch {
    return null
  }
}

export async function clearWall(ownerPass: string): Promise<boolean> {
  try {
    const r = await fetch('/store/wall/clear', {
      method: 'POST',
      headers: { 'x-owner-pass': ownerPass },
    })
    const d = await r.json()
    return !!d.ok
  } catch {
    return false
  }
}
