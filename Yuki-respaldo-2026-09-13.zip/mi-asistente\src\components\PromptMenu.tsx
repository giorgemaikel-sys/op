import { useEffect, useRef, useState } from 'react'
import type { PromptTemplate } from '../lib/types'

interface Props {
  prompts: PromptTemplate[]
  onPick: (text: string) => void
}

export default function PromptMenu({ prompts, onPick }: Props) {
  const [open, setOpen] = useState(false)
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    function onDoc(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false)
    }
    document.addEventListener('mousedown', onDoc)
    return () => document.removeEventListener('mousedown', onDoc)
  }, [])

  return (
    <div ref={ref} className="relative">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="p-1.5 rounded-lg hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-500 leading-none"
        title="Prompts guardados"
      >
        <img src="/ic-prompts.png" alt="Prompts" className="h-8 w-8 object-contain" />
      </button>
      {open && (
        <div className="absolute bottom-full mb-2 left-0 z-20 w-60 max-h-64 overflow-y-auto rounded-xl border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 shadow-lg py-1">
          {prompts.length === 0 && (
            <p className="text-xs text-zinc-400 px-3 py-2">
              Sin prompts. Créalos en ⚙️ Ajustes.
            </p>
          )}
          {prompts.map((p) => (
            <button
              key={p.id}
              onClick={() => {
                onPick(p.text)
                setOpen(false)
              }}
              className="w-full text-left text-sm px-3 py-2 hover:bg-zinc-100 dark:hover:bg-zinc-700"
            >
              {p.name}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}
