@echo off
title Asistente (escritorio)
cd /d "%~dp0"
echo ================================================
echo   Abriendo el Asistente como app de escritorio
echo ================================================
echo.
echo  - Necesita Ollama corriendo (se inicia solo con Windows).
echo  - Para imagenes / voz / documentos, ejecuta tambien imagenes.bat
echo  - Cierra la ventana de la app para salir.
echo.
call npm run build
npx electron .
