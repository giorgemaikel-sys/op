@echo off
title Asistente SEGURO (HTTPS con Tailscale)
echo ================================================
echo   Hacer el Asistente SEGURO (HTTPS, con candado)
echo ================================================
echo.
echo  Esto usa Tailscale para darte un certificado REAL (sin avisos de
echo  "No seguro") en tus dispositivos (PC y celular con Tailscale).
echo.
echo  ANTES (una sola vez): entra a tu cuenta de Tailscale y activa HTTPS:
echo    1) Abre:  https://login.tailscale.com/admin/dns
echo       y pulsa "Enable HTTPS".
echo    2) Si te lo pide, activa tambien "Serve" en:
echo       https://login.tailscale.com/admin/settings/features
echo.
echo  Ten corriendo la app (start.bat) antes de continuar.
echo.
pause

set TS="C:\Program Files\Tailscale\tailscale.exe"
echo.
echo  Configurando HTTPS - localhost:5173 ...
%TS% serve --bg --https=443 http://127.0.0.1:5173
echo.
echo ================================================
echo  Si NO salio ningun error arriba, ya esta LISTO.
echo  Entra en tus dispositivos (con Tailscale activo) a:
echo.
echo       https://maikel.tail1907d2.ts.net
echo.
echo  (Deberia salir el CANDADO, sin "No seguro".)
echo ================================================
echo.
%TS% serve status
echo.
echo  Para apagar el HTTPS:  tailscale serve reset
pause
