@echo off
setlocal
title Yuki - Enlace FIJO (siempre el mismo, para amigos)
cd /d "%~dp0"

echo ================================================
echo   Enlace FIJO de Yuki (NO cambia nunca)
echo ================================================
echo.
echo  Tu enlace para amigos, siempre el mismo:
echo.
echo       https://maikel.tail1907d2.ts.net
echo.
echo  Tus amigos lo abren SIN instalar nada, ponen la
echo  contrasena y crean su perfil.
echo.
echo  UNA SOLA VEZ, activa esto en tu cuenta de Tailscale:
echo    1) https://login.tailscale.com/admin/dns  -^> boton "Enable HTTPS"
echo    2) https://login.tailscale.com/admin/settings/features  -^> activa "Funnel"
echo.
echo  Y ten corriendo start.bat (la app) antes de seguir.
echo.
pause

REM --- Contrasena para amigos (Enter para dejar la de antes) ---
set "PASS="
set /p "PASS=Contrasena para amigos (Enter = dejar la actual): "
if not "%PASS%"=="" if not exist "data" mkdir "data"
if not "%PASS%"=="" > "data\share.txt" echo %PASS%
echo.

set TS="C:\Program Files\Tailscale\tailscale.exe"
echo  Publicando el enlace fijo (Funnel)...
%TS% funnel --bg 5173
echo.
%TS% funnel status
echo.
echo ================================================
echo  LISTO. Comparte SIEMPRE este mismo enlace:
echo.
echo       https://maikel.tail1907d2.ts.net
echo.
echo  Para que funcione: deja la PC encendida, Tailscale
echo  activo y start.bat corriendo.
echo.
echo  Para dejar de compartir con todos:  tailscale funnel reset
echo ================================================
pause
