import type { Conversation, MemoryItem, Settings } from './types'

const CONV_KEY = 'asistente:conversations'
const SETTINGS_KEY = 'asistente:settings'
const MEMORY_KEY = 'asistente:memory'

export const defaultSettings: Settings = {
  model: '',
  systemPrompt:
    'Eres un asistente útil, claro y amable. Respondes en español salvo que te pidan otro idioma.',
  theme: 'dark',
  autoMemory: true,
  activePersonaId: 'general',
  webEffort: 3,
  imageSteps: 2,
  imageWidth: 512,
  imageHeight: 512,
  autoSpeak: false,
  ttsVoice: '',
  ttsRate: 1,
  ttsLang: 'es-ES',
  autoModel: true,
  accent: '#4f46e5',
}

export function loadConversations(): Conversation[] {
  try {
    const raw = localStorage.getItem(CONV_KEY)
    if (!raw) return []
    const parsed = JSON.parse(raw)
    return Array.isArray(parsed) ? (parsed as Conversation[]) : []
  } catch {
    return []
  }
}

export function saveConversations(convs: Conversation[]) {
  try {
    localStorage.setItem(CONV_KEY, JSON.stringify(convs))
  } catch {
    // Probablemente se excedió la cuota (imágenes grandes).
    // Reintentar guardando el texto pero sin las imágenes.
    try {
      const light = convs.map((c) => ({
        ...c,
        messages: c.messages.map((m) =>
          m.images && m.images.length ? { ...m, images: [] } : m,
        ),
      }))
      localStorage.setItem(CONV_KEY, JSON.stringify(light))
    } catch {
      // no hay nada más que hacer
    }
  }
}

export function loadSettings(): Settings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY)
    if (!raw) return { ...defaultSettings }
    return { ...defaultSettings, ...(JSON.parse(raw) as Partial<Settings>) }
  } catch {
    return { ...defaultSettings }
  }
}

export function saveSettings(s: Settings) {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(s))
  } catch {
    // ignorar
  }
}

export function loadMemory(): MemoryItem[] {
  try {
    const raw = localStorage.getItem(MEMORY_KEY)
    if (!raw) return []
    const parsed = JSON.parse(raw)
    return Array.isArray(parsed) ? (parsed as MemoryItem[]) : []
  } catch {
    return []
  }
}

export function saveMemory(items: MemoryItem[]) {
  try {
    localStorage.setItem(MEMORY_KEY, JSON.stringify(items))
  } catch {
    // ignorar
  }
}
