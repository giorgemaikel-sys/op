import { createRoot } from 'react-dom/client'
import App from './App'
import './styles/index.css'
import 'katex/dist/katex.min.css'

createRoot(document.getElementById('root')!).render(<App />)

// Registrar el service worker (para instalar Yuki como app y uso sin conexión).
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch(() => {
      /* sin service worker: la app sigue funcionando igual */
    })
  })
}
