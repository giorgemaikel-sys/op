import { useRef, useState, lazy, Suspense } from 'react'
import ReactMarkdown from 'react-markdown'
import remarkGfm from 'remark-gfm'
import remarkMath from 'remark-math'
import rehypeKatex from 'rehype-katex'
import rehypeHighlight from 'rehype-highlight'
import type { ChatMessage } from '../lib/types'
import { downloadDocFile } from '../lib/docs'
import { useOwner } from '../lib/owner'
import { verifyOwnerPassword } from '../lib/profiles'
import Survey from './Survey'
import Flashcards from './Flashcards'
import Quiz from './Quiz'
// Diagramas y gráficas: carga diferida (solo cuando una respuesta los usa).
const Mermaid = lazy(() => import('./Mermaid'))
const FunctionPlot = lazy(() => import('./FunctionPlot'))
const SvgBlock = lazy(() => import('./SvgBlock'))

function VizFallback() {
  return <div className="text-xs text-zinc-400 py-2">Cargando…</div>
}

/**
 * Los modelos suelen escribir matemáticas con delimitadores LaTeX \( \) y \[ \],
 * pero remark-math solo entiende $…$ y $$…$$. Los convertimos para que KaTeX los
 * dibuje. (Se evita tocar el interior de bloques de código ``` ```.)
 */
function normalizeMath(src: string): string {
  const parts = src.split(/(```[\s\S]*?```)/g)
  return parts
    .map((seg, i) => {
      if (i % 2 === 1) return seg // bloque de código: sin cambios
      return seg
        .replace(/\\\[/g, '$$$$')
        .replace(/\\\]/g, '$$$$')
        .replace(/\\\(/g, '$')
        .replace(/\\\)/g, '$')
    })
    .join('')
}

interface Props {
  message: ChatMessage
  isLast: boolean
  isStreaming: boolean
  onRegenerate: () => void
  onEdit: (newText: string) => void
  onSpeak: () => void
  onQuick: (text: string) => void
  onFollowups?: () => Promise<string[]>
}

const LANGS = ['inglés', 'portugués', 'francés', 'alemán', 'italiano', 'japonés', 'chino']

const QUICK_ACTIONS: [string, string][] = [
  ['🔎 Más simple', 'Explícalo más simple, como si tuviera 12 años.'],
  ['📚 A fondo', 'Explícalo con más profundidad y detalle.'],
  ['💡 Un ejemplo', 'Dame un ejemplo concreto de esto.'],
  ['✍️ Un ejercicio', 'Ponme un ejercicio para practicar esto y espera mi respuesta.'],
  ['⏩ Continuar', 'Continúa desde donde te quedaste.'],
  ['✍️ Mejóralo', 'Reescribe tu respuesta anterior para que sea más clara, ordenada y mejor redactada.'],
]

export default function MessageBubble({
  message,
  isLast,
  isStreaming,
  onRegenerate,
  onEdit,
  onSpeak,
  onQuick,
  onFollowups,
}: Props) {
  const isUser = message.role === 'user'
  const [copied, setCopied] = useState(false)
  const [editing, setEditing] = useState(false)
  const [draft, setDraft] = useState(message.content)
  const [langsOpen, setLangsOpen] = useState(false)
  const [followups, setFollowups] = useState<string[]>([])
  const [fuLoading, setFuLoading] = useState(false)

  function copyMsg() {
    const { answer } = splitThink(message.content)
    navigator.clipboard?.writeText(answer || message.content)
    setCopied(true)
    setTimeout(() => setCopied(false), 1500)
  }
  function saveEdit() {
    const t = draft.trim()
    setEditing(false)
    if (t && t !== message.content) onEdit(t)
  }

  return (
    <div className={`msg-in flex flex-col ${isUser ? 'items-end' : 'items-start'}`}>
      <div
        className={`max-w-[85%] md:max-w-[75%] rounded-2xl px-4 py-3 ${
          isUser
            ? 'bg-indigo-600 text-white rounded-br-md'
            : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100 rounded-bl-md'
        }`}
      >
        {message.images && message.images.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-2">
            {message.images.map((img, i) => (
              <img
                key={i}
                src={`data:${img.mime};base64,${img.data}`}
                alt={isUser ? 'imagen adjunta' : 'imagen generada'}
                className={isUser ? 'max-h-48 rounded-lg' : 'rounded-lg max-h-96 w-full'}
              />
            ))}
          </div>
        )}

        {message.docs && message.docs.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-2">
            {message.docs.map((d, i) => (
              <span
                key={i}
                className={`inline-flex items-center gap-1 text-xs rounded-lg px-2 py-1 ${
                  isUser ? 'bg-indigo-500/60' : 'bg-zinc-200 dark:bg-zinc-700'
                }`}
              >
                📄 {d.name}
              </span>
            ))}
          </div>
        )}

        {editing ? (
          <div>
            <textarea
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              rows={3}
              className="w-[70vw] max-w-md resize-y rounded-lg text-zinc-900 dark:text-zinc-100 bg-white dark:bg-zinc-900 border border-black/10 dark:border-white/10 text-sm p-2 outline-none"
            />
            <div className="flex gap-2 mt-2">
              <button
                onClick={saveEdit}
                className="text-xs px-2 py-1 rounded bg-white text-indigo-700 font-medium"
              >
                Guardar y reenviar
              </button>
              <button
                onClick={() => {
                  setEditing(false)
                  setDraft(message.content)
                }}
                className="text-xs px-2 py-1 rounded bg-black/20 text-white"
              >
                Cancelar
              </button>
            </div>
          </div>
        ) : isUser ? (
          <p className="whitespace-pre-wrap break-words">{message.content}</p>
        ) : message.content ? (
          <AssistantContent
            content={message.content}
            live={isLast && isStreaming}
          />
        ) : (
          <TypingDots />
        )}

        {!isUser && message.sources && message.sources.length > 0 && (
          <div className="mt-3 pt-2 border-t border-zinc-200 dark:border-zinc-700">
            <p className="text-[11px] font-medium text-zinc-500 mb-1">
              🌐 Fuentes
            </p>
            <ol className="space-y-0.5">
              {message.sources.map((s, i) => (
                <li key={i} className="text-xs truncate">
                  <span className="text-zinc-400">[{i + 1}]</span>{' '}
                  <a
                    href={s.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-indigo-500 hover:underline"
                    title={s.url}
                  >
                    {s.title || s.url}
                  </a>
                </li>
              ))}
            </ol>
          </div>
        )}

        {message.file && (
          <button
            onClick={() => downloadDocFile(message.file!)}
            className="mt-2 inline-flex items-center gap-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-sm px-3 py-2"
          >
            ⬇️ Descargar {message.file.filename}
          </button>
        )}

        {message.survey && <Survey survey={message.survey} />}
        {message.flashcards && <Flashcards set={message.flashcards} />}
        {message.quiz && <Quiz quiz={message.quiz} />}
      </div>

      {!editing && (
        <div className="flex items-center gap-3 mt-1 px-1 text-[11px] text-zinc-400">
          {isUser ? (
            !isStreaming && (
              <button
                onClick={() => {
                  setDraft(message.content)
                  setEditing(true)
                }}
                className="hover:text-zinc-600 dark:hover:text-zinc-200"
              >
                ✏️ Editar
              </button>
            )
          ) : message.content ? (
            <>
              <button
                onClick={copyMsg}
                className="hover:text-zinc-600 dark:hover:text-zinc-200"
              >
                {copied ? '✓ Copiado' : '📋 Copiar'}
              </button>
              <button
                onClick={onSpeak}
                className="hover:text-zinc-600 dark:hover:text-zinc-200"
                title="Leer en voz alta"
              >
                🔊 Leer
              </button>
              {isLast && !isStreaming && (
                <button
                  onClick={onRegenerate}
                  className="hover:text-zinc-600 dark:hover:text-zinc-200"
                >
                  ↻ Regenerar
                </button>
              )}
              {message.stats && message.stats.tokensPerSec > 0 && (
                <span title="Velocidad y tiempo de generación">
                  ⚡ {message.stats.tokensPerSec} tok/s ·{' '}
                  {(message.stats.totalMs / 1000).toFixed(1)} s
                </span>
              )}
              {message.model && (
                <span title="Modelo usado" className="truncate max-w-[9rem]">
                  🤖 {message.model}
                </span>
              )}
            </>
          ) : null}
        </div>
      )}

      {!isUser && isLast && !isStreaming && !!message.content && (
        <div className="mt-2 px-1 space-y-1.5">
          <div className="flex flex-wrap gap-1.5">
            {QUICK_ACTIONS.map(([label, prompt]) => (
              <button key={label} onClick={() => onQuick(prompt)} className={CHIP}>
                {label}
              </button>
            ))}
            <button onClick={() => setLangsOpen((v) => !v)} className={CHIP}>
              🌍 Traducir
            </button>
            {onFollowups && (
              <button
                onClick={async () => {
                  setFuLoading(true)
                  try {
                    setFollowups(await onFollowups())
                  } finally {
                    setFuLoading(false)
                  }
                }}
                disabled={fuLoading}
                className={CHIP}
              >
                {fuLoading ? '💡 pensando…' : '💡 ¿Qué más preguntar?'}
              </button>
            )}
          </div>
          {langsOpen && (
            <div className="flex flex-wrap gap-1.5">
              {LANGS.map((l) => (
                <button
                  key={l}
                  onClick={() => {
                    onQuick(`Traduce tu última respuesta al ${l}. Devuelve solo la traducción.`)
                    setLangsOpen(false)
                  }}
                  className={CHIP}
                >
                  {l}
                </button>
              ))}
            </div>
          )}
          {followups.length > 0 && (
            <div className="flex flex-col gap-1.5 items-start">
              {followups.map((q, i) => (
                <button key={i} onClick={() => onQuick(q)} className={CHIP + ' text-left'}>
                  💡 {q}
                </button>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  )
}

const CHIP =
  'text-[11px] px-2.5 py-1 rounded-full border border-zinc-200 dark:border-zinc-700 text-zinc-600 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors disabled:opacity-50'

/** Separa el razonamiento (<think>…</think>) de la respuesta final. */
function splitThink(content: string): { thinking: string | null; answer: string } {
  const open = content.indexOf('<think>')
  if (open === -1) return { thinking: null, answer: content }
  const before = content.slice(0, open)
  const rest = content.slice(open + '<think>'.length)
  const close = rest.indexOf('</think>')
  if (close === -1) {
    // Todavía razonando (llega en streaming, sin cerrar la etiqueta).
    return { thinking: rest.trim(), answer: before.trim() }
  }
  const thinking = rest.slice(0, close).trim()
  const after = rest.slice(close + '</think>'.length)
  return { thinking, answer: (before + after).trim() }
}

/** Contenido del asistente: muestra el razonamiento colapsable + la respuesta. */
function AssistantContent({ content, live }: { content: string; live: boolean }) {
  const { thinking, answer } = splitThink(content)
  const [expanded, setExpanded] = useState(false)
  const hasAnswer = answer.trim().length > 0
  // Mientras aún piensa (sin respuesta), mostrar el razonamiento; luego colapsar.
  const showThink = thinking !== null && (expanded || (live && !hasAnswer))
  return (
    <>
      {thinking !== null && (
        <div className="mb-2">
          <button
            onClick={() => setExpanded((v) => !v)}
            className="flex items-center gap-1 text-[11px] font-medium text-zinc-500 hover:text-zinc-700 dark:hover:text-zinc-300"
          >
            <span className={`transition-transform ${showThink ? 'rotate-90' : ''}`}>▸</span>
            💭 Razonamiento{live && !hasAnswer ? ' (pensando…)' : ''}
          </button>
          {showThink && (
            <div className="mt-1 rounded-lg bg-zinc-200/60 dark:bg-zinc-900/60 border border-zinc-200 dark:border-zinc-700 px-3 py-2 text-xs text-zinc-600 dark:text-zinc-400 whitespace-pre-wrap break-words">
              {thinking || '…'}
            </div>
          )}
        </div>
      )}
      {hasAnswer ? (
        <div className="prose-chat">
          <ReactMarkdown
            remarkPlugins={[remarkGfm, remarkMath]}
            rehypePlugins={[rehypeKatex, [rehypeHighlight, { ignoreMissing: true }]]}
            components={{ pre: Pre }}
          >
            {normalizeMath(answer)}
          </ReactMarkdown>
        </div>
      ) : (
        <TypingDots />
      )}
    </>
  )
}

/** Aplana el contenido de un nodo (string o spans resaltados) a texto plano. */
function nodeText(node: any): string {
  if (node == null) return ''
  if (typeof node === 'string') return node
  if (Array.isArray(node)) return node.map(nodeText).join('')
  if (typeof node === 'object' && node.props) return nodeText(node.props.children)
  return ''
}

/** Bloque de código con botón de copiar (o un diagrama Mermaid si aplica). */
function Pre({ children }: any) {
  const ref = useRef<HTMLPreElement>(null)
  const [copied, setCopied] = useState(false)

  // Detectar bloques especiales y renderizar un dibujo en vez del código.
  const codeEl = Array.isArray(children) ? children[0] : children
  const cls: string = codeEl?.props?.className || ''
  if (cls.includes('language-mermaid')) {
    return (
      <Suspense fallback={<VizFallback />}>
        <Mermaid code={nodeText(codeEl.props.children)} />
      </Suspense>
    )
  }
  if (cls.includes('language-plot') || cls.includes('language-grafica') || cls.includes('language-gráfica')) {
    return (
      <Suspense fallback={<VizFallback />}>
        <FunctionPlot code={nodeText(codeEl.props.children)} />
      </Suspense>
    )
  }
  if (cls.includes('language-svg')) {
    return (
      <Suspense fallback={<VizFallback />}>
        <SvgBlock code={nodeText(codeEl.props.children)} />
      </Suspense>
    )
  }

  const code = nodeText(codeEl?.props?.children)
  const isHtml =
    cls.includes('language-html') || /<!doctype html|<html[\s>]/i.test(code)
  const isPython = cls.includes('language-python') || cls.includes('language-py')

  function copy() {
    const t = ref.current?.innerText ?? ''
    navigator.clipboard?.writeText(t)
    setCopied(true)
    setTimeout(() => setCopied(false), 1500)
  }
  return (
    <div className="relative group/code">
      <button
        onClick={copy}
        className="absolute top-2 right-2 text-[11px] px-2 py-0.5 rounded bg-white/10 hover:bg-white/20 text-zinc-300 opacity-0 group-hover/code:opacity-100 transition-opacity"
      >
        {copied ? '✓' : 'Copiar'}
      </button>
      <pre ref={ref}>{children}</pre>
      {isHtml && <HtmlRunner code={code} />}
      {isPython && <PyRunner code={code} />}
    </div>
  )
}

/** Botón ▶️ Ejecutar Python: SOLO en modo administrador. Manda el código a la PC
 *  (servidor local) y muestra la salida (texto y, si dibuja, la imagen). */
function PyRunner({ code }: { code: string }) {
  const { ownerPass, unlock, lock } = useOwner()
  const [running, setRunning] = useState(false)
  const [res, setRes] = useState<{
    ok: boolean
    stdout?: string
    stderr?: string
    error?: string
    image?: string | null
    images?: string[]
  } | null>(null)

  // --- Candado: si no está desbloqueado, pedir la contraseña de administrador. ---
  const [pass, setPass] = useState('')
  const [checking, setChecking] = useState(false)
  const [lockErr, setLockErr] = useState('')

  async function tryUnlock() {
    const p = pass.trim()
    if (!p) return
    setChecking(true)
    setLockErr('')
    try {
      const ok = await verifyOwnerPassword(p)
      if (ok) {
        setPass('')
        unlock(p)
      } else setLockErr('Contraseña incorrecta')
    } catch {
      setLockErr('No se pudo verificar (¿servidor apagado?)')
    } finally {
      setChecking(false)
    }
  }

  if (!ownerPass) {
    return (
      <div className="mt-2 not-prose rounded-lg border border-zinc-300 dark:border-zinc-700 bg-zinc-100 dark:bg-zinc-800/60 p-2.5">
        <p className="text-xs text-zinc-500 mb-1.5">
          🔒 Ejecutar Python es solo para el administrador.
        </p>
        <div className="flex flex-wrap gap-1.5">
          <input
            type="password"
            value={pass}
            onChange={(e) => {
              setPass(e.target.value)
              setLockErr('')
            }}
            onKeyDown={(e) => e.key === 'Enter' && tryUnlock()}
            placeholder="Contraseña de administrador"
            className="flex-1 min-w-[10rem] rounded-lg border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-900 px-2.5 py-1.5 text-xs outline-none"
          />
          <button
            onClick={tryUnlock}
            disabled={checking}
            className="text-xs px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 disabled:opacity-60 text-white"
          >
            {checking ? 'Comprobando…' : '🔓 Desbloquear'}
          </button>
        </div>
        {lockErr && <p className="text-xs text-red-500 mt-1">{lockErr}</p>}
      </div>
    )
  }

  async function run() {
    setRunning(true)
    setRes(null)
    try {
      const r = await fetch('/sd/runpython', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-owner-pass': ownerPass || '',
        },
        body: JSON.stringify({ code }),
      })
      if (r.status === 401 || r.status === 403) {
        lock() // la contraseña ya no vale: volver a pedirla
        setRes({
          ok: false,
          error: '🔒 Contraseña de administrador incorrecta o caducada.',
        })
        return
      }
      const data = await r.json()
      setRes(data)
    } catch {
      setRes({
        ok: false,
        error:
          'No se pudo conectar con el servidor de Python. ¿Está encendido? (imagenes.bat)',
      })
    } finally {
      setRunning(false)
    }
  }

  const imgs = res
    ? res.images && res.images.length
      ? res.images
      : res.image
        ? [res.image]
        : []
    : []
  const hasOut = res && (res.stdout || res.stderr || res.error || imgs.length)
  return (
    <div className="mt-2 not-prose">
      <div className="flex flex-wrap gap-2 items-center">
        <button
          onClick={run}
          disabled={running}
          className="text-xs px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-60 text-white"
        >
          {running ? '⏳ Ejecutando…' : '▶️ Ejecutar Python'}
        </button>
        {res && !running && (
          <>
            <button
              onClick={run}
              className="text-xs px-3 py-1.5 rounded-lg border border-zinc-300 dark:border-zinc-700"
            >
              🔄 Otra vez
            </button>
            <button
              onClick={() => setRes(null)}
              className="text-xs px-3 py-1.5 rounded-lg border border-zinc-300 dark:border-zinc-700"
            >
              ✖ Limpiar
            </button>
          </>
        )}
        <button
          onClick={lock}
          className="text-[11px] text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-300 ml-auto"
          title="Bloquear (salir de modo administrador en este dispositivo)"
        >
          🔒 Bloquear
        </button>
      </div>

      {hasOut && (
        <div className="mt-2 space-y-2">
          {res!.stdout && (
            <pre className="whitespace-pre-wrap break-words text-xs rounded-lg bg-zinc-900 text-zinc-100 border border-zinc-700 p-3 overflow-x-auto">
              {res!.stdout}
            </pre>
          )}
          {imgs.map((im, i) => (
            <img
              key={i}
              src={`data:image/png;base64,${im}`}
              alt={`Resultado de Python ${i + 1}`}
              className="rounded-lg border border-zinc-300 dark:border-zinc-700 max-w-full"
            />
          ))}
          {(res!.stderr || res!.error) && (
            <pre className="whitespace-pre-wrap break-words text-xs rounded-lg bg-red-950/40 text-red-300 border border-red-800/50 p-3 overflow-x-auto">
              {res!.error ? '⚠️ ' + res!.error + '\n' : ''}
              {res!.stderr}
            </pre>
          )}
        </div>
      )}
      {res && !running && !hasOut && (
        <p className="mt-2 text-xs text-emerald-600 dark:text-emerald-400">
          ✓ Ejecutado (sin salida de texto)
        </p>
      )}
    </div>
  )
}

/** Botón ▶️ Ejecutar: corre HTML/JS autónomo en un iframe con sandbox (seguro). */
function HtmlRunner({ code }: { code: string }) {
  const [run, setRun] = useState(false)
  const [k, setK] = useState(0)
  const [full, setFull] = useState(false)
  return (
    <div className="mt-2 not-prose">
      <div className="flex flex-wrap gap-2">
        <button
          onClick={() => {
            setRun(true)
            setK((x) => x + 1)
          }}
          className="text-xs px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white"
        >
          ▶️ Ejecutar
        </button>
        {run && (
          <>
            <button
              onClick={() => setK((x) => x + 1)}
              className="text-xs px-3 py-1.5 rounded-lg border border-zinc-300 dark:border-zinc-700"
            >
              🔄 Reiniciar
            </button>
            <button
              onClick={() => setFull((f) => !f)}
              className="text-xs px-3 py-1.5 rounded-lg border border-zinc-300 dark:border-zinc-700"
            >
              {full ? '🗕 Reducir' : '⛶ Grande'}
            </button>
            <button
              onClick={() => setRun(false)}
              className="text-xs px-3 py-1.5 rounded-lg border border-zinc-300 dark:border-zinc-700"
            >
              ✖ Cerrar
            </button>
          </>
        )}
      </div>
      {run && (
        <iframe
          key={k}
          title="preview"
          srcDoc={code}
          sandbox="allow-scripts allow-pointer-lock allow-modals"
          className="mt-2 w-full rounded-lg border border-zinc-300 dark:border-zinc-700 bg-white"
          style={{ height: full ? '80vh' : 520 }}
        />
      )}
    </div>
  )
}

function TypingDots() {
  return (
    <div className="flex gap-1 py-1">
      <span className="h-2 w-2 rounded-full bg-zinc-400 animate-bounce [animation-delay:-0.3s]" />
      <span className="h-2 w-2 rounded-full bg-zinc-400 animate-bounce [animation-delay:-0.15s]" />
      <span className="h-2 w-2 rounded-full bg-zinc-400 animate-bounce" />
    </div>
  )
}
