import { useEffect, useState } from 'react'

export type DeviceKind = 'phone' | 'laptop' | 'desktop'

/** Detecta el tipo de dispositivo por tamaño de pantalla y tipo de puntero. */
export function detectDevice(): DeviceKind {
  if (typeof window === 'undefined') return 'desktop'
  const w = window.innerWidth
  const coarse = window.matchMedia?.('(pointer: coarse)')?.matches ?? false
  // Celular: pantalla pequeña o puntero táctil grueso en pantalla no muy ancha.
  if (w < 700 || (coarse && w < 900)) return 'phone'
  // PC de escritorio: monitor grande con ratón (Chromebooks ~1366 → laptop).
  if (w >= 1500 && !coarse) return 'desktop'
  // El resto: laptops / Chromebooks (pantalla mediana).
  return 'laptop'
}

export const deviceLabel: Record<DeviceKind, string> = {
  phone: '📱 Celular',
  laptop: '💻 Laptop / Chromebook',
  desktop: '🖥️ PC',
}

/** Hook de React: devuelve el tipo de dispositivo y se actualiza al cambiar el tamaño. */
export function useDevice(): DeviceKind {
  const [device, setDevice] = useState<DeviceKind>(() => detectDevice())
  useEffect(() => {
    let t: number | undefined
    const onResize = () => {
      window.clearTimeout(t)
      t = window.setTimeout(() => setDevice(detectDevice()), 150)
    }
    window.addEventListener('resize', onResize)
    return () => {
      window.clearTimeout(t)
      window.removeEventListener('resize', onResize)
    }
  }, [])
  return device
}
