import { useMemo, useState } from 'react'
import type { FlashcardSet } from '../lib/types'

/** Tarjetas de estudio: voltear, avanzar, y repasar las que fallaste. */
export default function Flashcards({ set }: { set: FlashcardSet }) {
  const [order, setOrder] = useState<number[]>(() => set.cards.map((_, i) => i))
  const [pos, setPos] = useState(0)
  const [flipped, setFlipped] = useState(false)
  const [wrong, setWrong] = useState<number[]>([])
  const [done, setDone] = useState(false)

  const total = order.length
  const cardIdx = order[pos]
  const card = set.cards[cardIdx]

  function mark(known: boolean) {
    const nextWrong = known ? wrong : [...wrong, cardIdx]
    setWrong(nextWrong)
    if (pos + 1 < total) {
      setPos(pos + 1)
      setFlipped(false)
    } else {
      // fin de la ronda
      if (nextWrong.length) {
        setOrder(nextWrong)
        setWrong([])
        setPos(0)
        setFlipped(false)
      } else {
        setDone(true)
      }
    }
  }

  function restart() {
    setOrder(set.cards.map((_, i) => i))
    setPos(0)
    setFlipped(false)
    setWrong([])
    setDone(false)
  }

  const progress = useMemo(() => `${pos + 1} / ${total}`, [pos, total])

  if (done) {
    return (
      <div className="mt-1 w-full rounded-xl border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-900/60 p-4 text-center">
        <p className="text-2xl">🎉</p>
        <p className="font-semibold mt-1">¡Repasaste todas las tarjetas!</p>
        <button
          onClick={restart}
          className="mt-3 text-sm px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white"
        >
          Repasar otra vez
        </button>
      </div>
    )
  }

  return (
    <div className="mt-1 w-full rounded-xl border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-900/60 p-3">
      <div className="flex items-center justify-between mb-2">
        <p className="font-semibold text-sm">🃏 {set.title}</p>
        <span className="text-xs text-zinc-500">{progress}</span>
      </div>

      <button
        onClick={() => setFlipped((f) => !f)}
        className="w-full min-h-[7rem] rounded-xl border-2 border-indigo-300 dark:border-indigo-700 bg-indigo-50 dark:bg-indigo-950/40 p-4 flex flex-col items-center justify-center text-center transition-colors"
      >
        <span className="text-[10px] uppercase tracking-wide text-zinc-400 mb-1">
          {flipped ? 'Respuesta' : 'Pregunta'} · toca para voltear
        </span>
        <span className="text-base">{flipped ? card.back : card.front}</span>
      </button>

      {flipped ? (
        <div className="flex gap-2 mt-3">
          <button
            onClick={() => mark(false)}
            className="flex-1 text-sm px-3 py-2 rounded-lg bg-rose-100 dark:bg-rose-950/50 text-rose-700 dark:text-rose-300"
          >
            ✗ No la sabía
          </button>
          <button
            onClick={() => mark(true)}
            className="flex-1 text-sm px-3 py-2 rounded-lg bg-emerald-100 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300"
          >
            ✓ La sabía
          </button>
        </div>
      ) : (
        <button
          onClick={() => setFlipped(true)}
          className="w-full mt-3 text-sm px-3 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white"
        >
          Ver respuesta
        </button>
      )}
    </div>
  )
}
