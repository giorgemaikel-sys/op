import { useState } from 'react'
import type { MemoryItem } from '../lib/types'

interface Props {
  memory: MemoryItem[]
  autoMemory: boolean
  onChange: (m: MemoryItem[]) => void
  onToggleAuto: (v: boolean) => void
  onClose: () => void
}

function uid() {
  return Math.random().toString(36).slice(2) + Date.now().toString(36)
}

export default function MemoryPanel({
  memory,
  autoMemory,
  onChange,
  onToggleAuto,
  onClose,
}: Props) {
  const [newText, setNewText] = useState('')

  function add() {
    const t = newText.trim()
    if (!t) return
    onChange([{ id: uid(), text: t, createdAt: Date.now() }, ...memory])
    setNewText('')
  }

  return (
    <div
      className="fixed inset-0 z-40 flex items-center justify-center p-4 bg-black/50"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 p-5 space-y-4 max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold">🧠 Memoria</h2>
          <button
            onClick={onClose}
            className="text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200"
          >
            ✕
          </button>
        </div>
        <p className="text-xs text-zinc-500 dark:text-zinc-400">
          Lo que el asistente recuerda de ti. Se usa en todas tus conversaciones.
        </p>

        <label className="flex items-center gap-2 text-sm cursor-pointer">
          <input
            type="checkbox"
            checked={autoMemory}
            onChange={(e) => onToggleAuto(e.target.checked)}
            className="accent-indigo-600"
          />
          Memoria automática (detectar y guardar datos por sí solo)
        </label>

        <div className="flex gap-2">
          <input
            value={newText}
            onChange={(e) => setNewText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') add()
            }}
            placeholder="Añadir algo que recuerde…"
            className="flex-1 rounded-lg border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-sm p-2 outline-none"
          />
          <button
            onClick={add}
            className="px-3 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-sm"
          >
            Añadir
          </button>
        </div>

        <div className="space-y-2">
          {memory.length === 0 && (
            <p className="text-sm text-zinc-400 text-center py-4">
              Todavía no hay recuerdos.
            </p>
          )}
          {memory.map((m) => (
            <div key={m.id} className="flex items-center gap-2">
              <span
                className="text-xs shrink-0"
                title={m.auto ? 'Detectado automáticamente' : 'Añadido por ti'}
              >
                {m.auto ? '🤖' : '✍️'}
              </span>
              <input
                value={m.text}
                onChange={(e) =>
                  onChange(
                    memory.map((x) =>
                      x.id === m.id ? { ...x, text: e.target.value } : x,
                    ),
                  )
                }
                className="flex-1 rounded-lg border border-zinc-200 dark:border-zinc-700 bg-transparent text-sm p-1.5 outline-none focus:border-indigo-500"
              />
              <button
                onClick={() => onChange(memory.filter((x) => x.id !== m.id))}
                className="text-zinc-400 hover:text-red-500 shrink-0"
                title="Borrar"
              >
                ✕
              </button>
            </div>
          ))}
        </div>

        {memory.length > 0 && (
          <button
            onClick={() => onChange([])}
            className="text-xs text-red-500 hover:underline"
          >
            Borrar toda la memoria
          </button>
        )}
      </div>
    </div>
  )
}
