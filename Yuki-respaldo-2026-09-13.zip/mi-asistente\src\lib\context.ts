/**
 * Arma el "prompt de tema" combinando lo que pidió el usuario con el contexto
 * reciente de la conversación. Así, si el usuario escribe poco (o nada) al
 * activar un modo, el modelo usa la conversación para saber de qué va.
 */
export function topicPrompt(topic: string, context?: string): string {
  const t = (topic || '').trim()
  if (t && context)
    return `Tema pedido por el usuario: ${t}\n\n[Contexto reciente de la conversación — úsalo para acertar mejor]\n${context}`
  if (t) return `Tema: ${t}`
  if (context)
    return `[Contexto reciente de la conversación]\n${context}\n\nUsa el tema principal de esa conversación.`
  return 'Tema: general'
}
