import type { Survey, SurveyQuestion, SurveyQuestionType } from './types'
import { complete } from './ollama'
import { extractJson } from './docs'
import { topicPrompt } from './context'

const SYSTEM = `Eres un generador de encuestas/formularios. Devuelve SOLO un JSON válido:
{"title":"Título de la encuesta","intro":"1 frase de contexto","questions":[
  {"q":"pregunta","type":"single","options":["opción 1","opción 2","opción 3"]},
  {"q":"pregunta de varias respuestas","type":"multi","options":["a","b","c"]},
  {"q":"pregunta abierta","type":"text"},
  {"q":"del 1 al 5, ¿...?","type":"scale","min":1,"max":5}
]}
Reglas: entre 4 y 8 preguntas variadas y relevantes al tema; usa "single" (una opción), "multi" (varias), "text" (respuesta libre) o "scale" (número). En español. Nada fuera del JSON.`

const VALID: SurveyQuestionType[] = ['single', 'multi', 'text', 'scale']

/** Pide al modelo una encuesta sobre el tema y la normaliza a nuestro tipo. */
export async function makeSurvey(
  topic: string,
  model: string,
  context?: string,
): Promise<Survey> {
  let survey: Survey | null = null
  try {
    const raw = await complete({ model, system: SYSTEM, prompt: topicPrompt(topic, context), format: 'json' })
    const j = extractJson(raw)
    if (j && Array.isArray(j.questions) && j.questions.length) {
      const questions: SurveyQuestion[] = (j.questions as any[])
        .map((q) => {
          const type: SurveyQuestionType = VALID.includes(q.type) ? q.type : 'text'
          const out: SurveyQuestion = { q: String(q.q || 'Pregunta'), type }
          if (type === 'single' || type === 'multi') {
            const opts = Array.isArray(q.options) ? q.options.map(String) : []
            out.options = opts
            if (!opts.length) out.type = 'text'
          }
          if (type === 'scale') {
            out.min = Number.isFinite(q.min) ? Number(q.min) : 1
            out.max = Number.isFinite(q.max) ? Number(q.max) : 5
          }
          return out
        })
        .filter((q) => q.q)
      if (questions.length) {
        survey = {
          title: String(j.title || topic),
          intro: j.intro ? String(j.intro) : undefined,
          questions,
        }
      }
    }
  } catch {
    /* fallback abajo */
  }
  if (!survey) {
    survey = {
      title: topic,
      intro: 'Responde las siguientes preguntas.',
      questions: [
        { q: `¿Qué opinas sobre ${topic}?`, type: 'text' },
        { q: 'Del 1 al 5, ¿qué tan interesado estás?', type: 'scale', min: 1, max: 5 },
      ],
    }
  }
  return survey
}
