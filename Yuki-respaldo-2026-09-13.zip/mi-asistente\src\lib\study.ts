import type { StudyPlan, StudyLesson, StudyVideo } from './types'
import { complete } from './ollama'
import { searchWeb, fetchPage } from './websearch'
import { extractJson } from './docs'
import { topicPrompt } from './context'

/** Genera un plan de estudio por lecciones a partir de un tema. */
export async function makePlan(
  topic: string,
  model: string,
  context?: string,
): Promise<StudyPlan> {
  const system = `Eres un profesor que diseña planes de estudio. Devuelve SOLO un JSON válido:
{"topic":"tema","lessons":[{"title":"Título de la lección","objectives":["objetivo 1","objetivo 2"],"summary":"1-2 frases de qué se aprende"}]}
Reglas: entre 4 y 6 lecciones en orden pedagógico (de lo básico a lo avanzado), objetivos concretos y medibles. En español. Nada fuera del JSON.`
  let plan: StudyPlan | null = null
  try {
    const raw = await complete({ model, system, prompt: topicPrompt(topic, context), format: 'json' })
    const j = extractJson(raw)
    if (j && Array.isArray(j.lessons) && j.lessons.length) {
      plan = {
        topic: String(j.topic || topic),
        lessons: (j.lessons as any[]).map((l) => ({
          title: String(l.title || 'Lección'),
          objectives: Array.isArray(l.objectives) ? l.objectives.map(String) : [],
          summary: String(l.summary || ''),
        })) as StudyLesson[],
      }
    }
  } catch {
    /* usamos el fallback */
  }
  if (!plan) {
    plan = {
      topic,
      lessons: [
        { title: `Introducción a ${topic}`, objectives: ['Entender los conceptos básicos'], summary: 'Fundamentos del tema.' },
        { title: 'Práctica guiada', objectives: ['Resolver ejemplos paso a paso'], summary: 'Aplicar lo aprendido.' },
        { title: 'Ejercicios', objectives: ['Practicar por tu cuenta'], summary: 'Consolidar con ejercicios.' },
      ],
    }
  }
  return plan
}

/**
 * Busca videos en internet y los VETA con el modelo antes de recomendarlos:
 * solo se usan URLs reales de los resultados (no inventadas). El modelo lee
 * título + descripción/página y elige los mejores explicando por qué.
 */
export async function findVideos(
  topic: string,
  model: string,
  onStatus?: (s: string) => void,
): Promise<StudyVideo[]> {
  onStatus?.('🔎 Buscando videos…')
  const seen = new Set<string>()
  const candidates: { title: string; url: string; snippet: string }[] = []
  const queries = [
    `${topic} tutorial explicación en español youtube`,
    `${topic} clase explicado paso a paso video`,
  ]
  for (const q of queries) {
    const rs = await searchWeb(q, 8)
    for (const r of rs) {
      const isVideo = /youtube\.com\/watch|youtu\.be\/|vimeo\.com\//i.test(r.url)
      if (isVideo && r.url && !seen.has(r.url)) {
        seen.add(r.url)
        candidates.push({ title: r.title, url: r.url, snippet: r.snippet })
      }
    }
  }
  if (!candidates.length) return []

  // Leer la descripción de los primeros candidatos para poder juzgarlos.
  onStatus?.('📄 Analizando videos…')
  const top = candidates.slice(0, 5)
  const pages = await Promise.all(
    top.map((c) => fetchPage(c.url).catch(() => ({ title: '', text: '' }))),
  )

  const listing = top
    .map((c, i) => {
      const desc = (pages[i]?.text || c.snippet || '').slice(0, 400)
      return `[${i}] Título: ${c.title}\nURL: ${c.url}\nDescripción: ${desc}`
    })
    .join('\n\n')

  const system = `Eres un profesor que evalúa videos educativos. Te doy una lista numerada de videos (título + descripción). Elige SOLO los que realmente sirvan para aprender el tema (relevantes, claros, no clickbait, no spam). Devuelve SOLO un JSON:
{"videos":[{"index":0,"why":"por qué es útil (una frase)"}]}
Elige como máximo 2, los mejores. Si ninguno sirve, devuelve {"videos":[]}. Nada fuera del JSON.`
  try {
    const raw = await complete({
      model,
      system,
      prompt: `Tema: ${topic}\n\nVideos:\n${listing}`,
      format: 'json',
    })
    const j = extractJson(raw)
    const picks = Array.isArray(j?.videos) ? j.videos : []
    const out: StudyVideo[] = []
    for (const p of picks) {
      const idx = Number(p.index)
      if (Number.isInteger(idx) && top[idx]) {
        out.push({ title: top[idx].title, url: top[idx].url, why: String(p.why || '') })
      }
    }
    return out.slice(0, 2)
  } catch {
    // sin veto del modelo, devolvemos los 2 primeros candidatos
    return top.slice(0, 2).map((c) => ({ title: c.title, url: c.url, why: '' }))
  }
}

/** System prompt del tutor, sembrado con el plan y la lección actual. */
export function tutorSystemPrompt(plan: StudyPlan, lesson: number): string {
  const list = plan.lessons
    .map((l, i) => `${i + 1}. ${l.title}${i === lesson ? '  ← lección actual' : ''}`)
    .join('\n')
  const cur = plan.lessons[lesson]
  const objectives = cur?.objectives?.length
    ? `\nObjetivos de la lección actual:\n- ${cur.objectives.join('\n- ')}`
    : ''
  return `Eres un TUTOR paciente y motivador que enseña "${plan.topic}" paso a paso, como un buen profesor particular.

Plan de estudio:
${list}
${objectives}

Cómo enseñar:
- Enseña UNA lección a la vez, con explicaciones claras y ejemplos concretos; no vuelques todo de golpe.
- Comprueba que se entendió: haz 1 pregunta o propón un ejercicio corto al final de cada explicación.
- Corrige con amabilidad y da pistas antes que la respuesta completa.
- Adapta el ritmo: si dicen "no entendí", explícalo más simple o con otro ejemplo; si dicen "siguiente" o responden bien, avanza a la siguiente lección.
- Habla en español, cercano pero riguroso.

MUY IMPORTANTE — enseña de forma VISUAL (todo se dibuja en el chat). Tienes 4 herramientas y en CADA explicación debes usar al menos una (la que mejor ayude), no solo texto:

1) Matemáticas con LaTeX: escribe TODA fórmula o paso en $...$ (en línea) o $$...$$ (centrado). Ej: $$2x + 3x - 5 = 5x - 6$$. Muestra el paso a paso, una línea por operación.

2) GRÁFICAS de funciones o datos (¡úsalas mucho en mates y física!) con un bloque \`\`\`plot. Formato:
\`\`\`plot
title: Tiro parabólico
y = -5x^2 + 20x
x: 0..4
\`\`\`
Puedes poner varias líneas "y = ...", el rango "x: min..max", y datos inventados con "data: 0,0 1,15 2,20 3,15". Usa ^ para potencias y funciones sin, cos, sqrt, abs, exp, ln, pi. Ideal para: parábolas, rectas, senos, crecimiento, gráficas de movimiento (posición/velocidad/tiempo), etc.

3) DIBUJOS libres (geometría, diagramas de física: fuerzas, vectores, circuitos, figuras) con un bloque \`\`\`svg que contenga un SVG válido y SIMPLE (usa viewBox, líneas, polígonos, flechas, textos). Ejemplo de un triángulo:
\`\`\`svg
<svg viewBox="0 0 200 130" xmlns="http://www.w3.org/2000/svg">
  <polygon points="30,110 170,110 100,30" fill="none" stroke="#6366f1" stroke-width="2"/>
  <text x="100" y="125" font-size="10" text-anchor="middle">base</text>
</svg>
\`\`\`

4) PROCESOS o mapas de conceptos con un bloque \`\`\`mermaid (flujo de pasos, clasificación). Pon el texto de cada nodo entre comillas dobles. Ejemplo:
\`\`\`mermaid
flowchart TD
  A["2x + 3x - 5 = 5x - 6"] --> B["Junta términos: 5x - 5 = 5x - 6"]
  B --> C["Resta 5x: -5 = -6"]
  C --> D["Es falso → no tiene solución"]
\`\`\`

Elige la herramienta correcta: una FUNCIÓN o datos → \`\`\`plot; una FIGURA/diagrama físico → \`\`\`svg; un PROCESO/clasificación → \`\`\`mermaid; una FÓRMULA → $$...$$. Mantén cada dibujo simple y con sintaxis correcta.

Empieza siempre por dónde va el alumno según la conversación.`
}
