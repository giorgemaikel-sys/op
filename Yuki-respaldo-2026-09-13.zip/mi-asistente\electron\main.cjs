const { app, BrowserWindow, shell } = require('electron')
const { startServer } = require('./server.cjs')

let win

async function createWindow() {
  const port = await startServer(5174)
  win = new BrowserWindow({
    width: 1200,
    height: 820,
    minWidth: 380,
    minHeight: 500,
    title: 'Asistente',
    autoHideMenuBar: true,
    backgroundColor: '#09090b',
    webPreferences: { contextIsolation: true },
  })
  win.loadURL(`http://localhost:${port}`)
  // Los enlaces externos (fuentes de búsqueda) se abren en el navegador del sistema.
  win.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url)
    return { action: 'deny' }
  })
}

app.whenReady().then(createWindow)
app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow()
})
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit()
})
