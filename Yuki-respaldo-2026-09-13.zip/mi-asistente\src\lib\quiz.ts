import type { Quiz, QuizQuestion } from './types'
import { complete } from './ollama'
import { extractJson } from './docs'
import { topicPrompt } from './context'

const SYSTEM = `Eres un generador de exámenes tipo test. Devuelve SOLO un JSON válido:
{"title":"Título del examen","questions":[{"q":"pregunta","options":["a","b","c","d"],"answer":0,"explanation":"por qué es correcta"}]}
Reglas: entre 5 y 8 preguntas de opción múltiple con 3 o 4 opciones; "answer" es el índice (empezando en 0) de la opción CORRECTA; incluye una explicación breve. En español. Nada fuera del JSON.`

export async function makeQuiz(
  topic: string,
  model: string,
  context?: string,
): Promise<Quiz> {
  try {
    const raw = await complete({ model, system: SYSTEM, prompt: topicPrompt(topic, context), format: 'json' })
    const j = extractJson(raw)
    if (j && Array.isArray(j.questions) && j.questions.length) {
      const questions: QuizQuestion[] = (j.questions as any[])
        .map((q) => {
          const options = Array.isArray(q.options) ? q.options.map(String) : []
          let answer = Number(q.answer)
          if (!Number.isInteger(answer) || answer < 0 || answer >= options.length)
            answer = 0
          return {
            q: String(q.q || ''),
            options,
            answer,
            explanation: q.explanation ? String(q.explanation) : undefined,
          }
        })
        .filter((q) => q.q && q.options.length >= 2)
      if (questions.length) return { title: String(j.title || topic), questions }
    }
  } catch {
    /* fallback abajo */
  }
  return {
    title: topic,
    questions: [
      {
        q: `Pregunta de ejemplo sobre ${topic}`,
        options: ['Opción A', 'Opción B'],
        answer: 0,
      },
    ],
  }
}
