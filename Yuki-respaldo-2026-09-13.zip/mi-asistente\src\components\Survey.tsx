import { useState } from 'react'
import type { Survey as SurveyT } from '../lib/types'

interface Props {
  survey: SurveyT
}

type Answer = string | string[] | number | undefined

export default function Survey({ survey }: Props) {
  const [answers, setAnswers] = useState<Answer[]>(
    () => survey.questions.map((q) => (q.type === 'multi' ? [] : undefined)),
  )
  const [done, setDone] = useState(false)
  const [copied, setCopied] = useState(false)

  function set(i: number, v: Answer) {
    setAnswers((a) => a.map((x, j) => (j === i ? v : x)))
  }
  function toggleMulti(i: number, opt: string) {
    setAnswers((a) =>
      a.map((x, j) => {
        if (j !== i) return x
        const arr = Array.isArray(x) ? x : []
        return arr.includes(opt) ? arr.filter((o) => o !== opt) : [...arr, opt]
      }),
    )
  }

  function summaryText(): string {
    const lines = survey.questions.map((q, i) => {
      const a = answers[i]
      const val = Array.isArray(a) ? a.join(', ') : a === undefined ? '—' : String(a)
      return `${i + 1}. ${q.q}\n   → ${val || '—'}`
    })
    return `${survey.title}\n\n${lines.join('\n')}`
  }

  function copySummary() {
    navigator.clipboard?.writeText(summaryText())
    setCopied(true)
    setTimeout(() => setCopied(false), 1500)
  }

  const inputCls =
    'w-full rounded-lg border border-zinc-300 dark:border-zinc-600 bg-white dark:bg-zinc-900 px-2 py-1.5 text-sm outline-none focus:border-indigo-500'

  return (
    <div className="mt-1 w-full rounded-xl border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-900/60 p-3">
      <p className="font-semibold text-sm">📋 {survey.title}</p>
      {survey.intro && (
        <p className="text-xs text-zinc-500 mt-0.5">{survey.intro}</p>
      )}

      {done ? (
        <div className="mt-3">
          <p className="text-xs font-medium text-emerald-600 dark:text-emerald-400 mb-2">
            ✓ ¡Gracias! Tus respuestas:
          </p>
          <pre className="whitespace-pre-wrap break-words text-xs bg-zinc-50 dark:bg-zinc-800 rounded-lg p-2 border border-zinc-200 dark:border-zinc-700">
            {summaryText()}
          </pre>
          <div className="flex gap-2 mt-2">
            <button
              onClick={copySummary}
              className="text-xs px-2.5 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white"
            >
              {copied ? '✓ Copiado' : '📋 Copiar respuestas'}
            </button>
            <button
              onClick={() => setDone(false)}
              className="text-xs px-2.5 py-1 rounded-lg bg-zinc-200 dark:bg-zinc-700"
            >
              ✏️ Editar
            </button>
          </div>
        </div>
      ) : (
        <div className="mt-3 space-y-3">
          {survey.questions.map((q, i) => (
            <div key={i}>
              <p className="text-sm font-medium mb-1">
                {i + 1}. {q.q}
              </p>
              {q.type === 'text' && (
                <textarea
                  rows={2}
                  value={(answers[i] as string) ?? ''}
                  onChange={(e) => set(i, e.target.value)}
                  className={inputCls + ' resize-y'}
                  placeholder="Tu respuesta…"
                />
              )}
              {q.type === 'single' && (
                <div className="space-y-1">
                  {(q.options ?? []).map((opt) => (
                    <label key={opt} className="flex items-center gap-2 text-sm cursor-pointer">
                      <input
                        type="radio"
                        name={`q-${i}`}
                        checked={answers[i] === opt}
                        onChange={() => set(i, opt)}
                        className="accent-indigo-600"
                      />
                      {opt}
                    </label>
                  ))}
                </div>
              )}
              {q.type === 'multi' && (
                <div className="space-y-1">
                  {(q.options ?? []).map((opt) => (
                    <label key={opt} className="flex items-center gap-2 text-sm cursor-pointer">
                      <input
                        type="checkbox"
                        checked={Array.isArray(answers[i]) && (answers[i] as string[]).includes(opt)}
                        onChange={() => toggleMulti(i, opt)}
                        className="accent-indigo-600"
                      />
                      {opt}
                    </label>
                  ))}
                </div>
              )}
              {q.type === 'scale' && (
                <div className="flex items-center gap-1 flex-wrap">
                  {Array.from(
                    { length: (q.max ?? 5) - (q.min ?? 1) + 1 },
                    (_, k) => (q.min ?? 1) + k,
                  ).map((n) => (
                    <button
                      key={n}
                      type="button"
                      onClick={() => set(i, n)}
                      className={`h-8 w-8 rounded-lg text-sm ${
                        answers[i] === n
                          ? 'bg-indigo-600 text-white'
                          : 'bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700'
                      }`}
                    >
                      {n}
                    </button>
                  ))}
                </div>
              )}
            </div>
          ))}
          <button
            onClick={() => setDone(true)}
            className="text-sm px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white"
          >
            Enviar respuestas
          </button>
        </div>
      )}
    </div>
  )
}
