// Texto a voz usando el sintetizador del navegador (local, gratis, offline).

export function getVoices(): SpeechSynthesisVoice[] {
  try {
    return window.speechSynthesis?.getVoices?.() ?? []
  } catch {
    return []
  }
}

/** Espera a que el navegador cargue la lista de voces (a veces llega tarde). */
export function loadVoices(): Promise<SpeechSynthesisVoice[]> {
  return new Promise((resolve) => {
    const synth = window.speechSynthesis
    if (!synth) return resolve([])
    const now = synth.getVoices()
    if (now.length) return resolve(now)
    let done = false
    const finish = () => {
      if (done) return
      done = true
      resolve(synth.getVoices())
    }
    synth.onvoiceschanged = finish
    setTimeout(finish, 1000)
  })
}

/** Limpia el markdown para que la voz no lea símbolos raros. */
function cleanForSpeech(md: string): string {
  return md
    .replace(/```[\s\S]*?```/g, ' (bloque de código) ')
    .replace(/`([^`]+)`/g, '$1')
    .replace(/!?\[([^\]]*)\]\([^)]+\)/g, '$1')
    .replace(/^[#>\-*]\s?/gm, '')
    .replace(/[*_~|]/g, '')
    .replace(/https?:\/\/\S+/g, ' (enlace) ')
    .replace(/\s+/g, ' ')
    .trim()
}

export function isSpeaking(): boolean {
  return !!window.speechSynthesis?.speaking
}

export function stopSpeaking() {
  try {
    window.speechSynthesis?.cancel()
  } catch {
    /* ignore */
  }
}

/** Habla el texto. onEnd se llama cuando termina (útil para manos libres). */
export function speak(
  text: string,
  opts: { voice?: string; rate?: number; lang?: string; onEnd?: () => void } = {},
) {
  const synth = window.speechSynthesis
  if (!synth) {
    opts.onEnd?.()
    return
  }
  synth.cancel()
  const clean = cleanForSpeech(text)
  if (!clean) {
    opts.onEnd?.()
    return
  }
  const u = new SpeechSynthesisUtterance(clean)
  const voices = getVoices()
  if (opts.voice) {
    const v = voices.find((vv) => vv.name === opts.voice)
    if (v) u.voice = v
  }
  if (opts.lang) u.lang = opts.lang
  if (opts.rate) u.rate = Math.max(0.5, Math.min(2, opts.rate))
  if (opts.onEnd) u.onend = opts.onEnd
  synth.speak(u)
}
