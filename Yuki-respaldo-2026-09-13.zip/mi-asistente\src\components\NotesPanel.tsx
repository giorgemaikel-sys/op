import { useEffect, useState } from 'react'

interface Props {
  profileId: string
  onClose: () => void
}

/** Libretita de notas rápidas, guardada por perfil en este dispositivo. */
export default function NotesPanel({ profileId, onClose }: Props) {
  const key = `asistente:notes:${profileId}`
  const [text, setText] = useState<string>(() => {
    try {
      return localStorage.getItem(key) || ''
    } catch {
      return ''
    }
  })
  const [saved, setSaved] = useState(true)

  useEffect(() => {
    setSaved(false)
    const t = setTimeout(() => {
      try {
        localStorage.setItem(key, text)
      } catch {
        /* ignore */
      }
      setSaved(true)
    }, 400)
    return () => clearTimeout(t)
  }, [text, key])

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
      <div className="w-full max-w-lg h-[75vh] flex flex-col rounded-2xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 shadow-xl">
        <div className="flex items-center justify-between px-5 h-14 border-b border-zinc-200 dark:border-zinc-800 shrink-0">
          <h2 className="font-semibold flex items-center gap-2">📝 Notas rápidas</h2>
          <div className="flex items-center gap-2">
            <span className="text-[11px] text-zinc-400">{saved ? 'Guardado ✓' : 'Guardando…'}</span>
            <button
              onClick={onClose}
              className="p-2 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800"
              title="Cerrar"
            >
              ✕
            </button>
          </div>
        </div>
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          autoFocus
          placeholder="Escribe aquí lo que quieras recordar… (se guarda solo)"
          className="flex-1 min-h-0 resize-none w-full p-5 bg-transparent outline-none text-sm leading-relaxed"
        />
        <div className="px-5 py-2 border-t border-zinc-200 dark:border-zinc-800 text-[11px] text-zinc-400 shrink-0">
          Se guarda automáticamente · privadas de tu perfil, en este dispositivo.
        </div>
      </div>
    </div>
  )
}
