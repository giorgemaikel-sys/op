import type { DocFile } from './types'
import { complete } from './ollama'
import { topicPrompt } from './context'

export type DocType = 'pptx' | 'docx' | 'pdf' | 'xlsx' | 'poster'

/** Plantillas de texto para Word/PDF (adaptan el prompt y la estructura). */
export type DocTemplate =
  | 'general'
  | 'cv'
  | 'carta'
  | 'receta'
  | 'guion'
  | 'blog'

export const DOC_TEMPLATES: { id: DocTemplate; label: string }[] = [
  { id: 'general', label: 'General' },
  { id: 'cv', label: 'CV' },
  { id: 'carta', label: 'Carta' },
  { id: 'receta', label: 'Receta' },
  { id: 'guion', label: 'Guion' },
  { id: 'blog', label: 'Blog' },
]

const TEMPLATE_HINTS: Record<DocTemplate, string> = {
  general: '',
  cv: ' El documento es un CURRÍCULUM (CV): secciones típicas como Perfil, Experiencia, Educación, Habilidades y Contacto; usa "bullets" para logros y aptitudes.',
  carta: ' El documento es una CARTA formal: encabezado con lugar y fecha, saludo, cuerpo en párrafos y despedida. Usa "sections" con pocos encabezados y párrafos bien redactados.',
  receta: ' El documento es una RECETA de cocina: secciones Ingredientes (bullets con cantidades) y Preparación (pasos numerados como párrafos), más una intro breve.',
  guion: ' El documento es un GUION: secciones por escena (encabezado ESCENA - lugar - día/noche), con acción en párrafos y diálogos "PERSONAJE: ..." como párrafos.',
  blog: ' El documento es un ARTÍCULO DE BLOG: introducción que engancha, subtítulos con desarrollo, ejemplos, y una conclusión con llamada a la acción.',
}

/** Prompt para que el modelo devuelva el contenido estructurado en JSON. */
export function docSystemPrompt(type: DocType, template: DocTemplate = 'general'): string {
  if (type === 'pptx') {
    return `Eres un experto en crear presentaciones COMPLETAS y bien desarrolladas, al nivel de herramientas como Gamma. Devuelve SOLO un JSON válido con esta forma exacta:
{"title":"Título de la presentación","subtitle":"subtítulo atractivo de una línea","slides":[{"title":"Titular claro de la diapositiva","body":"1 a 3 frases que introducen o explican la idea con contenido real","bullets":["punto desarrollado, una frase completa e informativa","otro punto con datos o ejemplos concretos"],"image_prompt":"short English visual description","notes":"notas del presentador: qué decir en voz alta en esta diapositiva"}]}
Reglas para que quede COMPLETA y bien hecha:
- OBLIGATORIO: genera AL MENOS 9 diapositivas de contenido (idealmente 11 o 12). NO te quedes corto; desarrolla varias secciones. La portada con el título se genera aparte, NO la incluyas. Empieza por una de índice/agenda, sigue con el desarrollo por secciones, y termina con conclusiones y una de cierre.
- CADA diapositiva de desarrollo lleva "body" (1-3 frases que explican de verdad) Y 3 a 5 "bullets" con FRASES COMPLETAS e informativas (datos, ejemplos, definiciones) — nada de una sola palabra ni genérico.
- Contenido con sustancia y profundidad: explica, da ejemplos y datos. Es una presentación seria y completa, no un esquema pobre.
- Añade "notes" (lo que diría el presentador) en TODAS las de desarrollo.
- Añade "image_prompt" (descripción visual corta en INGLÉS) SOLO en 3-4 diapositivas clave.
- Todo el texto visible en español. No escribas NADA fuera del JSON.`
  }
  if (type === 'xlsx') {
    return `Eres un generador de hojas de cálculo. Devuelve SOLO un JSON válido con esta forma exacta:
{"title":"Título","sheets":[{"name":"Hoja","headers":["Columna A","Columna B"],"rows":[["valor","123"],["valor","456"]]}]}
Reglas: 1 a 3 hojas con nombres claros; encabezados en la primera fila; rellena filas con datos realistas y coherentes con el tema (los números como texto numérico, sin símbolos de moneda). En español. No escribas NADA fuera del JSON.`
  }
  if (type === 'poster') {
    return `Eres un diseñador de infografías/pósters de una página. Devuelve SOLO un JSON válido con esta forma exacta:
{"title":"TÍTULO IMPACTANTE","subtitle":"frase gancho","sections":[{"heading":"Sección","text":"texto breve","bullets":["dato clave","dato clave"]}]}
Reglas: 3 a 5 secciones cortas y llamativas (datos, consejos, pasos); textos breves (una infografía, no un ensayo). En español. No escribas NADA fuera del JSON.`
  }
  // docx / pdf
  return `Eres un redactor profesional de documentos. Devuelve SOLO un JSON válido con esta forma exacta:
{"title":"Título del documento","subtitle":"subtítulo breve","sections":[{"heading":"Encabezado","paragraphs":["párrafo bien redactado..."],"bullets":["punto..."]}]}
Reglas: entre 4 y 7 secciones, párrafos claros y con contenido real (no relleno), usa "bullets" solo cuando aporten.${TEMPLATE_HINTS[template]} En español. No escribas NADA fuera del JSON.`
}

/** Repara un JSON truncado: cierra cadenas, llaves y corchetes abiertos. */
function repairJson(s: string): string {
  let inStr = false
  let esc = false
  const stack: string[] = []
  let out = ''
  for (let i = 0; i < s.length; i++) {
    const ch = s[i]
    out += ch
    if (esc) {
      esc = false
      continue
    }
    if (ch === '\\') {
      if (inStr) esc = true
      continue
    }
    if (ch === '"') {
      inStr = !inStr
      continue
    }
    if (inStr) continue
    if (ch === '{' || ch === '[') stack.push(ch)
    else if (ch === '}') {
      if (stack[stack.length - 1] === '{') stack.pop()
    } else if (ch === ']') {
      if (stack[stack.length - 1] === '[') stack.pop()
    }
  }
  if (inStr) out += '"'
  out = out.replace(/,\s*$/, '')
  // quitar una clave colgante sin valor al final: ..."algo":
  out = out.replace(/,?\s*"[^"]*"\s*:\s*$/, '')
  out = out.replace(/,\s*$/, '')
  for (let i = stack.length - 1; i >= 0; i--) out += stack[i] === '{' ? '}' : ']'
  return out
}

/** Extrae el primer objeto JSON del texto del modelo (tolerante a ruido y a JSON cortado). */
export function extractJson(raw: string): any | null {
  const cleaned = raw.replace(/```json/gi, '').replace(/```/g, '')
  const start = cleaned.indexOf('{')
  if (start < 0) return null
  const body = cleaned.slice(start)
  // 1) intento directo (hasta el último '}')
  const end = body.lastIndexOf('}')
  if (end > 0) {
    try {
      return JSON.parse(body.slice(0, end + 1))
    } catch {
      /* probamos a reparar */
    }
  }
  // 2) reparar JSON truncado
  try {
    return JSON.parse(repairJson(body))
  } catch {
    return null
  }
}

/** Si el JSON falla, arma la estructura troceando el markdown por encabezados. */
export function fallbackFromMarkdown(type: DocType, topic: string, raw: string): any {
  // Si el texto es JSON (que no se pudo parsear), NO lo volcamos crudo al documento.
  const looksJson = raw.trim().startsWith('{') || /[{[]\s*"[a-z_]+"\s*:/i.test(raw)
  const cleanLines = looksJson
    ? ['No pude estructurar bien el contenido esta vez. Vuelve a intentarlo, por favor.']
    : raw.split('\n').map((l) => l.trim()).filter(Boolean).slice(0, 8)
  const lines = raw.split('\n')
  if (type === 'pptx') {
    const slides: { title: string; bullets: string[] }[] = []
    let cur: { title: string; bullets: string[] } | null = null
    for (const ln of lines) {
      const h = ln.match(/^#{1,3}\s+(.*)/)
      const b = ln.match(/^\s*[-*•]\s+(.*)/)
      if (h) {
        cur = { title: h[1].trim(), bullets: [] }
        slides.push(cur)
      } else if (b && cur) cur.bullets.push(b[1].trim())
    }
    if (!slides.length) slides.push({ title: topic, bullets: cleanLines })
    return { title: topic, slides }
  }
  if (type === 'xlsx') {
    const rows = (looksJson ? [] : cleanLines).slice(0, 30).map((l) => [l])
    return { title: topic, sheets: [{ name: 'Datos', headers: [topic], rows }] }
  }
  const sections: any[] = []
  let cur: any = null
  for (const ln of lines) {
    const h = ln.match(/^#{1,3}\s+(.*)/)
    const b = ln.match(/^\s*[-*•]\s+(.*)/)
    if (h) {
      cur = { heading: h[1].trim(), paragraphs: [], bullets: [] }
      sections.push(cur)
    } else if (b && cur) cur.bullets.push(b[1].trim())
    else if (ln.trim() && cur) cur.paragraphs.push(ln.trim())
  }
  if (!sections.length)
    sections.push({ heading: topic, paragraphs: cleanLines, bullets: [] })
  return { title: topic, sections }
}

// --- Presentaciones POR PARTES (para que cada petición sea corta y no la
// corte el túnel de Cloudflare a los 100s). Esquema primero, luego lotes. ---
const PPTX_OUTLINE_SYS = `Eres un experto en presentaciones completas. Devuelve SOLO un JSON con el ESQUEMA (solo los títulos) de una presentación:
{"title":"Título de la presentación","subtitle":"subtítulo de una línea","slides":[{"title":"Titular de la diapositiva","image_prompt":"short English visual description"}]}
Reglas: entre 9 y 12 diapositivas (NO incluyas portada; empieza por índice/agenda, sigue con desarrollo por secciones, y termina con conclusiones y cierre). Añade "image_prompt" SOLO en 3-4 diapositivas clave. Texto en español. Nada fuera del JSON.`

const PPTX_DETAIL_SYS = `Eres un experto en presentaciones. Te doy los títulos de unas diapositivas y devuelves SOLO un JSON con el CONTENIDO de cada una, en el MISMO orden y con el MISMO título:
{"slides":[{"title":"(el mismo título)","emoji":"1 emoji que represente el tema de la diapositiva","body":"1 a 3 frases que explican de verdad, con contenido real","bullets":["frase completa e informativa con datos o ejemplos","otra frase completa"],"notes":"qué diría el presentador en voz alta"}]}
Reglas: "emoji" = UN solo emoji relevante en cada diapositiva. "body" con contenido real (no relleno) y 3 a 5 "bullets" con FRASES COMPLETAS e informativas. "notes" en todas. En español. Nada fuera del JSON.`

export async function buildPptxContent(
  topic: string,
  context: string | undefined,
  model: string,
  onStatus?: (s: string) => void,
): Promise<any> {
  // 1) Esquema (títulos) — petición corta.
  onStatus?.('🖋️ Creando el esquema…')
  let outline: any = null
  try {
    const raw = await complete({
      model,
      system: PPTX_OUTLINE_SYS,
      prompt: topicPrompt(topic, context),
      format: 'json',
      numPredict: 1500,
    })
    outline = extractJson(raw)
  } catch {
    /* usamos fallback */
  }
  let titles: any[] =
    outline && Array.isArray(outline.slides)
      ? outline.slides.filter((s: any) => s && s.title)
      : []
  if (!titles.length)
    titles = [
      { title: 'Introducción' },
      { title: 'Desarrollo' },
      { title: 'Ejemplos' },
      { title: 'Conclusiones' },
    ]
  const deckTitle = (outline && outline.title) || topic
  const subtitle = (outline && outline.subtitle) || ''

  // 2) Detalles por lotes de 3 (cada petición corta → no la corta el túnel).
  const slides: any[] = []
  const B = 3
  for (let i = 0; i < titles.length; i += B) {
    const batch = titles.slice(i, i + B)
    onStatus?.(
      `🖋️ Redactando diapositivas ${i + 1}-${Math.min(i + B, titles.length)} de ${titles.length}…`,
    )
    const list = batch.map((b, k) => `${i + k + 1}. ${b.title}`).join('\n')
    let det: any = null
    try {
      const raw = await complete({
        model,
        system: PPTX_DETAIL_SYS,
        prompt: `Tema general: ${topic}\n\nDesarrolla EXACTAMENTE estas diapositivas (mismos títulos, en este orden):\n${list}`,
        format: 'json',
        numPredict: 2200,
      })
      det = extractJson(raw)
    } catch {
      /* seguimos con lo que haya */
    }
    const got: any[] = det && Array.isArray(det.slides) ? det.slides : []
    batch.forEach((b, k) => {
      const g = got[k] || {}
      slides.push({
        title: g.title || b.title,
        emoji: typeof g.emoji === 'string' ? g.emoji.trim().slice(0, 4) : '',
        body: String(g.body || ''),
        bullets: Array.isArray(g.bullets) ? g.bullets : [],
        image_prompt: b.image_prompt || undefined,
        notes: String(g.notes || ''),
      })
    })
  }
  return { title: deckTitle, subtitle, slides }
}

export async function buildDoc(opts: {
  type: DocType
  title: string
  content: any
  coverImage?: string
}): Promise<DocFile> {
  const res = await fetch('/doc/build', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      type: opts.type,
      title: opts.title,
      content: opts.content,
      cover_image: opts.coverImage,
    }),
  })
  const d = await res.json().catch(() => ({}))
  if (!res.ok || d.error) {
    throw new Error(d.error || `Servidor de documentos: error ${res.status}`)
  }
  return { filename: d.filename, mime: d.mime, data: d.base64 }
}

/** Descarga un DocFile (base64) como archivo. */
export function downloadDocFile(file: DocFile) {
  const bin = atob(file.data)
  const bytes = new Uint8Array(bin.length)
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i)
  const blob = new Blob([bytes], { type: file.mime })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = file.filename
  document.body.appendChild(a)
  a.click()
  a.remove()
  setTimeout(() => URL.revokeObjectURL(url), 1000)
}
