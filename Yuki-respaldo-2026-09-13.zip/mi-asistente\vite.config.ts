import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'
import { webSearchPlugin } from './websearch-plugin'
import { storagePlugin } from './storage-plugin'

// El proxy hace que el frontend hable con Ollama a través del propio
// servidor de la app (/api -> localhost:11434). Así no hay problemas de
// CORS y el celular solo necesita una dirección.
// El plugin webSearchPlugin añade /websearch y /webfetch en el mismo servidor.
export default defineConfig({
  plugins: [react(), tailwindcss(), webSearchPlugin(), storagePlugin()],
  server: {
    host: true, // expone en la red local (para el celular)
    port: 5173,
    // Permite acceder por IP/host de la red local y de Tailscale (acceso remoto).
    allowedHosts: true,
    proxy: {
      '/api': {
        target: 'http://localhost:11434',
        changeOrigin: true,
        configure: (proxy) => {
          // Ollama rechaza (403) peticiones con Origin que no sea localhost.
          // Desde el celular/Tailscale el Origin es http://100.x:5173 → lo quitamos
          // para que Ollama acepte la petición.
          proxy.on('proxyReq', (proxyReq: any) => {
            proxyReq.removeHeader('origin')
            proxyReq.removeHeader('referer')
          })
        },
      },
      // Servidor local de imágenes (Stable Diffusion / sd-server).
      '/sd': {
        target: 'http://127.0.0.1:7861',
        changeOrigin: true,
        rewrite: (p) => p.replace(/^\/sd/, ''),
      },
      // Servidor local de voz (Whisper), en el mismo proceso Python.
      '/voice': {
        target: 'http://127.0.0.1:7861',
        changeOrigin: true,
        rewrite: (p) => p.replace(/^\/voice/, ''),
      },
      // Generación de documentos (Word/PDF/pptx), mismo proceso Python.
      // (sin rewrite: el endpoint del servidor es /doc/build)
      '/doc': {
        target: 'http://127.0.0.1:7861',
        changeOrigin: true,
      },
    },
  },
})
