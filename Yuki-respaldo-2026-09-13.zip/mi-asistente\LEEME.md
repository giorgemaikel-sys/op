# 🐱 Yuki — Guía completa

> Tu asistente de inteligencia artificial **100 % local, gratis y privado**.
> Todo corre en **tu propia PC**: los chats, las imágenes, la voz y los documentos
> **nunca salen a internet** (salvo que tú actives el enlace para compartir).

Este documento explica **qué es Yuki, qué hace, cómo funciona por dentro, cómo
encenderlo, cómo compartirlo, y cómo restaurarlo** desde este respaldo.

---

## 1) ¿Qué es Yuki?

Yuki es una **aplicación web** (se abre en el navegador) que funciona como un
ChatGPT personal, pero **corriendo en tu computadora**, sin cuentas ni pagos ni
enviar tus datos a ninguna empresa. Usa modelos de IA **abiertos** que viven en
tu PC a través de **Ollama**.

- **Gratis**: no usa APIs de pago ni suscripciones.
- **Privado**: tus conversaciones se guardan en tu disco (`data/`), no en la nube.
- **Local**: la IA piensa en tu PC (con **Ollama**). Las imágenes se generan en tu
  tarjeta gráfica (con **Stable Diffusion**).
- **Multi-dispositivo**: puedes abrirlo desde el celular, laptop o Chromebook si
  enciendes el enlace para compartir (ver sección 5).

---

## 2) ¿Qué hace? (Funciones)

- **💬 Chat con IA** — conversa, pregunta, resume, traduce, programa, etc. Elige
  el modelo o deja "Auto" para que escoja el mejor.
- **👁️ Visión** — pega o adjunta una **imagen** y la IA la analiza (modelo LLaVA).
- **📄 Leer documentos** — adjunta un **PDF** y pregúntale sobre su contenido.
- **🎨 Generar imágenes** — describe algo y lo dibuja con **Stable Diffusion** en
  tu GPU. Mejora tu texto automáticamente para imágenes más fieles.
- **🗣️ Voz** — dictado por voz (Whisper) y lectura en voz alta (TTS).
- **📝 Crear documentos** — Word, PDF, Excel y **presentaciones (PowerPoint)** con
  diseño, transiciones y stickers.
- **🧑‍💻 Studio de código** — un editor tipo VS Code (Python / HTML / JavaScript)
  con:
  - Ejecutar el código **en el navegador** (Pyodide) o en tu PC.
  - **Terminal** (REPL de Python y línea de comandos).
  - **Asistente de IA** integrado (Ollama): explica, arregla errores, mejora,
    optimiza, traduce, escribe tests, **autocompleta** con IA, y busca/reemplaza.
- **🐾 Bichitos de escritorio** — animalitos que caminan por la pantalla de Yuki
  (versión web del programa nativo).
- **🧠 Memoria** — recuerda datos tuyos entre conversaciones.
- **🏆 Progreso / rachas**, **📌 perfiles** (varios usuarios), **🎭 personas**
  (Tutor, Chef, Programador…), **🧩 muro de amigos**, **📓 notas rápidas**,
  **🔎 búsqueda web**, **tema claro/oscuro**, e instalable como **app (PWA)**.

---

## 3) ¿Cómo funciona por dentro? (Arquitectura)

Yuki son **cuatro piezas** que trabajan juntas en tu PC:

```
   NAVEGADOR (tú)
        │
        ▼
  ┌─────────────────────────────┐        ┌────────────────────────┐
  │  App Yuki (Vite/React)      │──/api─▶│  Ollama  (la IA)       │  puerto 11434
  │  puerto 5173                │        └────────────────────────┘
  │  - interfaz                 │        ┌────────────────────────┐
  │  - guarda datos en data/    │──/sd──▶│  sd-server (Python)    │  puerto 7861
  │  - proxys a los servidores  │  /voice│  - imágenes (SD)       │
  └─────────────────────────────┘  /doc  │  - voz (Whisper)       │
        │                                │  - documentos          │
        ▼ (para compartir)               │  - ejecutar código     │
  ┌─────────────────────────────┐        └────────────────────────┘
  │  Tailscale Funnel           │
  │  https://…ts.net (público)  │
  └─────────────────────────────┘
```

- **App Yuki** — hecha con **Vite + React + TypeScript + Tailwind**. Corre en el
  **puerto 5173** con `npm run host`. Además del sitio, incluye pequeños
  "plugins" de servidor:
  - `storage-plugin.ts` → guarda/lee **perfiles, acceso, muro, ajustes** en
    `data/*.json` (rutas `/store/...`).
  - `websearch-plugin.ts` → **búsqueda web** (`/websearch`, `/webfetch`).
  - Un **proxy**: `/api`→Ollama, `/sd` y `/voice` y `/doc`→sd-server. Así el
    celular solo necesita **una** dirección.
- **Ollama** — el motor de IA (chat, visión). Escucha en el **puerto 11434**.
  Suele arrancar solo (ícono en la barra de tareas).
- **sd-server** (`sd-server/server.py`) — servidor en **Python** (puerto **7861**)
  que hace lo pesado: **generar imágenes** (Stable Diffusion con `torch-directml`
  en la GPU), **voz** (Whisper), **documentos** (python-docx / python-pptx / PDF)
  y **ejecutar código**.
- **Tailscale Funnel** — solo para **compartir**: publica el puerto 5173 en un
  enlace `https://…ts.net` que otros abren **sin instalar nada**.

**Dónde viven tus datos:** todo en la carpeta **`data/`** (perfiles, chats,
ajustes, muro). Es lo más importante para respaldar.

---

## 4) Cómo ENCENDER Yuki (correctamente)

**Lo más fácil:** doble clic en **`Encender Yuki.bat`**. Ese lanzador:
1. Comprueba que **Ollama** esté corriendo (si no, lo arranca).
2. Enciende el **sd-server** (imágenes/voz/documentos).
3. Enciende la **app** (puerto 5173).
4. Espera a que la app levante y **publica el enlace** para compartir.
5. Abre el navegador en `http://localhost:5173`.

> ⚠️ **NO cierres** las ventanas negras que dicen *"no cerrar"*. Cada una es un
> servidor; si la cierras, esa parte se apaga. Para **apagar todo**, cierra esas
> ventanas.

**A mano (si prefieres):**
- `start.bat` — enciende sd-server + la app.
- `enlace-fijo.bat` — publica el enlace para compartir (ver sección 5).

**Requisitos en la PC:** Node.js, Python 3.10, Ollama (con modelos descargados),
y para imágenes una GPU compatible con DirectML.

---

## 5) Cómo COMPARTIRLO (que entren desde otro aparato)

Para que el **celular / Chromebook / un amigo** entren **sin Tailscale**, el
enlace debe estar en modo **PÚBLICO** ("Funnel on").

- ✅ **`enlace-fijo.bat`** → pone el enlace **público**. Debe decir
  **"Funnel on" / "Available on the internet"**.
- 🚫 **`seguro.bat`** → pone el enlace en **"solo Tailscale"** (tailnet only), que
  **ROMPE** el compartir. **No lo uses** si quieres que entren desde fuera.

**Enlace para compartir (siempre el mismo):**
```
https://maikel.tail1907d2.ts.net
```
Tus amigos lo abren, ponen la **contraseña de acceso** y crean su perfil.

**Si el Chromebook/celular no entra:** casi siempre es que el enlace quedó en
"solo Tailscale". Solución: doble clic a **`enlace-fijo.bat`** y verifica que diga
**"Funnel on"**.

---

## 6) Contraseñas (dónde están)

- **Contraseña de acceso** (para entrar al sitio): guardada en **`data/share.txt`**.
- **PIN de cada perfil**: guardados (como hash) en **`data/profiles.json`**.
- **Contraseña de administrador** (para el Studio de código y ejecutar código):
  configurada en el servidor (`sd-server/server.py`) / variable de entorno. Es la
  que tú definiste.

> 🔒 Este respaldo contiene tus datos y hashes de contraseñas. Guárdalo en un
> lugar seguro y **no lo subas a internet**.

---

## 7) Estructura de archivos

```
mi-asistente/
├─ src/                  Código de la app (React/TypeScript)
│  ├─ App.tsx            Componente principal
│  ├─ components/        Vistas (Chat, CodeStudio, Wall, Bichitos, etc.)
│  └─ lib/               Lógica (ollama, pyodide, docs, imagegen, bichitos…)
├─ public/               Archivos estáticos servidos tal cual
│  └─ bichitos/          Sprites de los bichitos + overlay/mascotas.js
├─ sd-server/            Servidor Python (imágenes, voz, documentos, código)
│  └─ server.py          El servidor (puerto 7861)
├─ electron/             Empaquetado como app de escritorio (opcional)
├─ data/                 TUS DATOS: perfiles, chats, ajustes, muro
├─ storage-plugin.ts     Endpoints /store (perfiles/acceso/muro/ajustes)
├─ websearch-plugin.ts   Endpoints /websearch y /webfetch
├─ vite.config.ts        Config de Vite + proxys (/api, /sd, /voice, /doc)
├─ package.json          Dependencias y scripts (dev/host/build)
├─ Encender Yuki.bat     ▶ Enciende TODO en orden (recomendado)
├─ start.bat             Enciende sd-server + app
├─ enlace-fijo.bat       Publica el enlace para compartir (Funnel público)
├─ seguro.bat            (NO usar para compartir: pone "solo Tailscale")
└─ LEEME.md              Este documento
```
> No se incluyen en el respaldo: `node_modules/`, `dist/`, `release/`,
> `sd-server/.venv/` (se **regeneran**, ver sección 8).

---

## 8) Cómo RESTAURAR desde este respaldo

1. **Descomprime** el ZIP donde quieras (ej. `C:\Users\TU\mi-asistente`).
2. Instala **Node.js** (nodejs.org) y **Python 3.10** (python.org).
3. Instala **Ollama** (ollama.com) y descarga los modelos, por ejemplo:
   ```
   ollama pull qwen2.5:14b
   ollama pull qwen2.5-coder:14b
   ollama pull llama3.2
   ollama pull llava
   ollama pull nomic-embed-text
   ```
4. En la carpeta del proyecto, instala las dependencias de la app:
   ```
   npm install
   ```
5. (Opcional, para imágenes/voz/documentos) crea el entorno de Python del
   sd-server e instala sus librerías:
   ```
   cd sd-server
   python -m venv .venv
   .venv\Scripts\python.exe -m pip install -r requirements.txt
   ```
   > Si no hay `requirements.txt`, las principales son: `flask`, `torch-directml`,
   > `diffusers`, `transformers`, `pillow`, `openai-whisper`, `python-docx`,
   > `python-pptx`. (Instálalas con `pip install ...`.)
6. Enciéndelo con **`Encender Yuki.bat`**.

---

## 9) Solución de problemas

| Síntoma | Causa probable | Solución |
|---|---|---|
| "No responde el servidor" | La app (5173) está apagada | Corre `Encender Yuki.bat`. No cierres las ventanas negras. |
| El Chromebook/amigo no entra | Enlace en "solo Tailscale" | Corre `enlace-fijo.bat` (debe decir **Funnel on**). No uses `seguro.bat`. |
| No genera imágenes | sd-server apagado o GPU ocupada | Revisa la ventana "Imágenes"; Ollama libera la GPU antes de generar. |
| La IA no responde | Ollama apagado o sin modelos | Abre Ollama; verifica `ollama list`. |
| "Contraseña incorrecta" | Caché vieja / PIN de perfil | Recarga fuerte (Ctrl+Shift+R); revisa `data/`. |

**Comprobar puertos** (en PowerShell):
```
curl http://localhost:5173   # app
curl http://localhost:11434  # Ollama
curl http://localhost:7861   # sd-server
```

---

## 10) Privacidad

- Los **chats y datos** viven en `data/` en tu PC. No se envían a ninguna empresa.
- La **IA** (Ollama) y las **imágenes** (Stable Diffusion) corren **localmente**.
- Solo sale a internet si **tú** activas el enlace para compartir, o si usas la
  **búsqueda web** (esa sí consulta la web, por diseño).

---

*Hecho con cariño. Yuki = tu IA privada, en tu propia PC. 🐱*
