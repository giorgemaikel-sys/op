import { useEffect, useRef, useState } from 'react'
import type { ChatDoc, ChatImage, PromptTemplate } from '../lib/types'
import { fileToChatImage } from '../lib/image'
import { extractText, isImage, isSupportedDoc } from '../lib/files'
import { effortLabel } from '../lib/websearch'
import { startRecording, transcribeBlob, type Recording } from '../lib/stt'
import { DOC_TEMPLATES, type DocType, type DocTemplate } from '../lib/docs'
import { useDevice } from '../lib/device'
import PromptMenu from './PromptMenu'

export interface WebOptions {
  enabled: boolean
  effort: number
}
export interface ImageOptions {
  enabled: boolean
  steps: number
  width: number
  height: number
  seed?: number
  negative?: string
}
export interface DocOptions {
  enabled: boolean
  type: DocType
  template: DocTemplate
}
export interface SendOptions {
  web: WebOptions
  image: ImageOptions
  doc: DocOptions
  survey: boolean
  study: boolean
  flashcards: boolean
  quiz: boolean
  summarize: boolean
  solve: boolean
  mindmap: boolean
  think: boolean
}

interface Props {
  value: string
  onChange: (v: string) => void
  onSend: (
    text: string,
    images: ChatImage[],
    docs: ChatDoc[],
    opts: SendOptions,
  ) => void
  isStreaming: boolean
  onStop: () => void
  disabled?: boolean
  prompts: PromptTemplate[]
  webEffort: number
  onWebEffortChange: (e: number) => void
  imageSteps: number
  onImageStepsChange: (n: number) => void
  imageWidth: number
  imageHeight: number
  onImageSizeChange: (w: number, h: number) => void
}

function stepsLabel(n: number): string {
  if (n <= 2) return 'Rápida'
  if (n <= 4) return 'Normal'
  return 'Detallada'
}

export default function Composer({
  value,
  onChange,
  onSend,
  isStreaming,
  onStop,
  disabled,
  prompts,
  webEffort,
  onWebEffortChange,
  imageSteps,
  onImageStepsChange,
  imageWidth,
  imageHeight,
  onImageSizeChange,
}: Props) {
  const [images, setImages] = useState<ChatImage[]>([])
  const [docs, setDocs] = useState<ChatDoc[]>([])
  const [dragOver, setDragOver] = useState(false)
  const [busy, setBusy] = useState(false)
  const [webOn, setWebOn] = useState(false)
  const [imageOn, setImageOn] = useState(false)
  const [docMode, setDocMode] = useState(false)
  const [docType, setDocType] = useState<DocType>('pptx')
  const [docTemplate, setDocTemplate] = useState<DocTemplate>('general')
  const [surveyMode, setSurveyMode] = useState(false)
  const [studyMode, setStudyMode] = useState(false)
  const [flashMode, setFlashMode] = useState(false)
  const [quizMode, setQuizMode] = useState(false)
  const [summarizeMode, setSummarizeMode] = useState(false)
  const [solveMode, setSolveMode] = useState(false)
  const [mindMode, setMindMode] = useState(false)
  const [thinkOn, setThinkOn] = useState(false)
  const [toolsOpen, setToolsOpen] = useState(false)
  const [seed, setSeed] = useState('')
  const [negative, setNegative] = useState('')
  const [recording, setRecording] = useState(false)
  const [transcribing, setTranscribing] = useState(false)
  const recRef = useRef<Recording | null>(null)
  const taRef = useRef<HTMLTextAreaElement>(null)
  const device = useDevice()

  useEffect(() => {
    const ta = taRef.current
    if (!ta) return
    ta.style.height = 'auto'
    ta.style.height = Math.min(ta.scrollHeight, 200) + 'px'
  }, [value])

  async function addFiles(files: FileList | File[]) {
    setBusy(true)
    const newImgs: ChatImage[] = []
    const newDocs: ChatDoc[] = []
    for (const f of Array.from(files)) {
      try {
        if (isImage(f)) newImgs.push(await fileToChatImage(f))
        else if (isSupportedDoc(f)) newDocs.push(await extractText(f))
      } catch {
        /* ignorar archivo inválido */
      }
    }
    if (newImgs.length) setImages((prev) => [...prev, ...newImgs])
    if (newDocs.length) setDocs((prev) => [...prev, ...newDocs])
    setBusy(false)
  }

  function submit() {
    const text = value.trim()
    if ((!text && images.length === 0 && docs.length === 0) || isStreaming) return
    onSend(text, images, docs, {
      web: { enabled: webOn, effort: webEffort },
      image: {
        enabled: imageOn,
        steps: imageSteps,
        width: imageWidth,
        height: imageHeight,
        seed: seed.trim() ? Number(seed) : undefined,
        negative: negative.trim() || undefined,
      },
      doc: { enabled: docMode, type: docType, template: docTemplate },
      survey: surveyMode,
      study: studyMode,
      flashcards: flashMode,
      quiz: quizMode,
      summarize: summarizeMode,
      solve: solveMode,
      mindmap: mindMode,
      think: thinkOn,
    })
    onChange('')
    setImages([])
    setDocs([])
    // Tras iniciar un plan de estudio, se continúa chateando normal (el tutor
    // sigue activo por la conversación), así que desactivamos el modo 📚.
    if (studyMode) setStudyMode(false)
    // El modo resolver-foto es de un solo uso (se adjunta la imagen y se envía).
    if (solveMode) setSolveMode(false)
  }

  function insertPrompt(text: string) {
    onChange(text + value)
    taRef.current?.focus()
  }

  function clearModes() {
    setWebOn(false)
    setImageOn(false)
    setDocMode(false)
    setSurveyMode(false)
    setStudyMode(false)
    setFlashMode(false)
    setQuizMode(false)
    setSummarizeMode(false)
    setSolveMode(false)
    setMindMode(false)
    setThinkOn(false)
  }
  function toggleWeb() {
    const next = !webOn
    clearModes()
    setWebOn(next)
  }
  function toggleThink() {
    const next = !thinkOn
    clearModes()
    setThinkOn(next)
  }
  function toggleImage() {
    const next = !imageOn
    clearModes()
    setImageOn(next)
  }
  function toggleDoc() {
    const next = !docMode
    clearModes()
    setDocMode(next)
  }
  /** Activa un modo del menú 🎓 (mutuamente excluyente) y cierra el menú. */
  function pickTool(set: (v: boolean) => void, current: boolean) {
    const next = !current
    clearModes()
    set(next)
    setToolsOpen(false)
  }
  function toggleSolve() {
    const next = !solveMode
    clearModes()
    setSolveMode(next)
  }

  async function toggleMic() {
    if (recording) {
      setRecording(false)
      const rec = recRef.current
      recRef.current = null
      if (!rec) return
      setTranscribing(true)
      try {
        const blob = await rec.stop()
        const text = await transcribeBlob(blob, 'es')
        if (text) onChange(value ? value.trimEnd() + ' ' + text : text)
      } catch (e: any) {
        onChange(
          value +
            (value ? '\n' : '') +
            '[No pude transcribir: ¿está corriendo el servidor de voz (voz.bat)?]',
        )
      } finally {
        setTranscribing(false)
        taRef.current?.focus()
      }
    } else {
      try {
        recRef.current = await startRecording()
        setRecording(true)
      } catch {
        alert('No pude acceder al micrófono. Da permiso en el navegador.')
      }
    }
  }

  return (
    <div className="border-t border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 px-3 py-3">
      <div
        className={`max-w-3xl mx-auto rounded-2xl border p-2 transition-colors ${
          dragOver
            ? 'border-indigo-500 ring-2 ring-indigo-500/30'
            : 'border-zinc-300 dark:border-zinc-700'
        } bg-zinc-50 dark:bg-zinc-800/60`}
        onDragOver={(e) => {
          e.preventDefault()
          setDragOver(true)
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={(e) => {
          e.preventDefault()
          setDragOver(false)
          addFiles(e.dataTransfer.files)
        }}
      >
        {webOn && (
          <div className="flex items-center gap-3 px-1 pb-2 text-xs text-zinc-600 dark:text-zinc-300">
            <span className="shrink-0">🎚️ Esfuerzo:</span>
            <input
              type="range"
              min={1}
              max={5}
              step={1}
              value={webEffort}
              onChange={(e) => onWebEffortChange(parseInt(e.target.value, 10))}
              className="flex-1 accent-indigo-600"
            />
            <span className="shrink-0 w-16 font-medium">{effortLabel(webEffort)}</span>
          </div>
        )}

        {imageOn && (
          <div className="space-y-2 pb-2">
            <div className="flex items-center gap-3 px-1 text-xs text-zinc-600 dark:text-zinc-300">
              <span className="shrink-0">🎨 Calidad:</span>
              <input
                type="range"
                min={1}
                max={6}
                step={1}
                value={imageSteps}
                onChange={(e) => onImageStepsChange(parseInt(e.target.value, 10))}
                className="flex-1 accent-indigo-600"
              />
              <span className="shrink-0 w-20 font-medium">
                {stepsLabel(imageSteps)} ({imageSteps})
              </span>
            </div>
            <div className="flex flex-wrap items-center gap-2 px-1 text-xs text-zinc-600 dark:text-zinc-300">
              <select
                value={`${imageWidth}x${imageHeight}`}
                onChange={(e) => {
                  const [w, h] = e.target.value.split('x').map(Number)
                  onImageSizeChange(w, h)
                }}
                className="rounded border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 px-1.5 py-1 outline-none"
                title="Tamaño"
              >
                <option value="384x384">384² (rápido)</option>
                <option value="512x512">512² (normal)</option>
                <option value="512x768">512×768 (vertical)</option>
                <option value="768x512">768×512 (horizontal)</option>
              </select>
              <input
                value={seed}
                onChange={(e) => setSeed(e.target.value.replace(/[^0-9]/g, ''))}
                placeholder="Semilla"
                className="w-24 rounded border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 px-2 py-1 outline-none"
                title="Semilla (vacío = aleatoria)"
              />
              <input
                value={negative}
                onChange={(e) => setNegative(e.target.value)}
                placeholder="Negativo: lo que NO quieres…"
                className="flex-1 min-w-[8rem] rounded border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 px-2 py-1 outline-none"
                title="Prompt negativo"
              />
            </div>
          </div>
        )}

        {docMode && (
          <div className="flex flex-wrap items-center gap-2 px-1 pb-2 text-xs text-zinc-600 dark:text-zinc-300">
            <span className="shrink-0">📄 Tipo:</span>
            <div className="flex flex-wrap gap-1 rounded-lg border border-zinc-300 dark:border-zinc-700 p-0.5">
              {(
                [
                  ['pptx', 'Presentación'],
                  ['docx', 'Word'],
                  ['pdf', 'PDF'],
                  ['xlsx', 'Excel'],
                  ['poster', 'Póster'],
                ] as const
              ).map(([t, label]) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setDocType(t)}
                  className={`px-2.5 py-1 rounded-md ${
                    docType === t ? 'bg-indigo-600 text-white' : ''
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
            {(docType === 'docx' || docType === 'pdf') && (
              <label className="flex items-center gap-1.5">
                <span className="shrink-0">Plantilla:</span>
                <select
                  value={docTemplate}
                  onChange={(e) => setDocTemplate(e.target.value as DocTemplate)}
                  className="rounded border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 px-1.5 py-1 outline-none"
                >
                  {DOC_TEMPLATES.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.label}
                    </option>
                  ))}
                </select>
              </label>
            )}
          </div>
        )}

        {images.length > 0 && (
          <div className="px-1 pb-2">
            <button
              type="button"
              onClick={toggleSolve}
              className={`text-xs px-2.5 py-1.5 rounded-lg border ${
                solveMode
                  ? 'bg-indigo-600 text-white border-indigo-600'
                  : 'border-zinc-300 dark:border-zinc-700 text-zinc-600 dark:text-zinc-300'
              }`}
              title="Resolver el ejercicio de la foto paso a paso"
            >
              📷 Resolver el ejercicio de la foto paso a paso
            </button>
          </div>
        )}

        {(images.length > 0 || docs.length > 0 || busy) && (
          <div className="flex flex-wrap gap-2 p-1 pb-2">
            {images.map((img, i) => (
              <div key={`img-${i}`} className="relative">
                <img
                  src={`data:${img.mime};base64,${img.data}`}
                  alt="adjunto"
                  className="h-16 w-16 object-cover rounded-lg"
                />
                <button
                  onClick={() => setImages((p) => p.filter((_, j) => j !== i))}
                  className="absolute -top-1.5 -right-1.5 h-5 w-5 rounded-full bg-zinc-900 text-white text-xs flex items-center justify-center"
                  title="Quitar"
                >
                  ✕
                </button>
              </div>
            ))}
            {docs.map((d, i) => (
              <div
                key={`doc-${i}`}
                className="relative inline-flex items-center gap-1 text-xs rounded-lg pl-2 pr-6 py-2 bg-zinc-200 dark:bg-zinc-700 max-w-[180px]"
                title={d.truncated ? 'Texto recortado a 20.000 caracteres' : d.name}
              >
                <span className="truncate">📄 {d.name}</span>
                <button
                  onClick={() => setDocs((p) => p.filter((_, j) => j !== i))}
                  className="absolute top-1/2 -translate-y-1/2 right-1.5 text-zinc-500 hover:text-red-500"
                  title="Quitar"
                >
                  ✕
                </button>
              </div>
            ))}
            {busy && (
              <span className="text-xs text-zinc-400 self-center px-1">
                procesando…
              </span>
            )}
          </div>
        )}

        <div className="flex flex-wrap items-end gap-1.5">
          <div className="flex flex-wrap sm:flex-nowrap items-end gap-1 sm:gap-1.5 order-2 sm:order-1 basis-full sm:basis-auto">
          <PromptMenu prompts={prompts} onPick={insertPrompt} />

          <label
            className="cursor-pointer p-2 rounded-lg hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-500 text-lg leading-none"
            title="Adjuntar imagen o documento (PDF, TXT…)"
          >
            <input
              type="file"
              accept="image/*,.pdf,.txt,.md,.markdown,.csv,.json,.log,.tsv,.xml,.yml,.yaml"
              multiple
              className="hidden"
              onChange={(e) => {
                if (e.target.files) addFiles(e.target.files)
                e.target.value = ''
              }}
            />
            <img src="/ic-adjuntar.png" alt="Adjuntar" className="h-8 w-8 object-contain" />
          </label>

          {/* 📱 Celular: tomar foto con la cámara (ideal para resolver ejercicios) */}
          {device === 'phone' && (
            <label
              className="cursor-pointer p-2 rounded-lg hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-500 leading-none"
              title="Tomar una foto con la cámara"
            >
              <input
                type="file"
                accept="image/*"
                capture="environment"
                className="hidden"
                onChange={(e) => {
                  if (e.target.files) addFiles(e.target.files)
                  e.target.value = ''
                }}
              />
              <span className="text-3xl leading-none">📷</span>
            </label>
          )}

          <button
            type="button"
            onClick={toggleMic}
            disabled={transcribing}
            className={`p-2 rounded-lg text-lg leading-none transition-colors ${
              recording
                ? 'bg-red-500 text-white animate-pulse'
                : 'hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-500'
            }`}
            title={
              recording
                ? 'Detener y transcribir'
                : transcribing
                  ? 'Transcribiendo…'
                  : 'Hablar (dictado por voz)'
            }
          >
            {transcribing ? (
              '⏳'
            ) : (
              <img src="/ic-voz.png" alt="Voz" className="h-8 w-8 object-contain" />
            )}
          </button>

          <button
            type="button"
            onClick={toggleThink}
            className={`p-2 rounded-lg text-xl leading-none h-9 w-9 flex items-center justify-center transition-colors ${
              thinkOn
                ? 'bg-indigo-600 text-white'
                : 'hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-500'
            }`}
            title={thinkOn ? 'Modo pensar activado: razona paso a paso' : 'Pensar paso a paso (razonamiento visible)'}
          >
            💭
          </button>

          <button
            type="button"
            onClick={toggleWeb}
            className={`p-2 rounded-lg text-lg leading-none transition-colors ${
              webOn
                ? 'bg-indigo-600 text-white'
                : 'hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-500'
            }`}
            title={webOn ? 'Búsqueda web activada' : 'Buscar en internet'}
          >
            <img src="/ic-buscar.png" alt="Buscar" className="h-8 w-8 object-contain" />
          </button>

          <button
            type="button"
            onClick={toggleImage}
            className={`p-2 rounded-lg text-lg leading-none transition-colors ${
              imageOn
                ? 'bg-indigo-600 text-white'
                : 'hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-500'
            }`}
            title={imageOn ? 'Modo imagen activado' : 'Generar imagen'}
          >
            <img src="/ic-imagen.png" alt="Imagen" className="h-8 w-8 object-contain" />
          </button>

          <button
            type="button"
            onClick={toggleDoc}
            className={`p-2 rounded-lg text-lg leading-none transition-colors ${
              docMode
                ? 'bg-indigo-600 text-white'
                : 'hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-500'
            }`}
            title={docMode ? 'Modo documento activado' : 'Crear documento (Word/PDF/Excel/presentación/póster)'}
          >
            <img src="/ic-doc.png" alt="Documento" className="h-8 w-8 object-contain" />
          </button>

          <div className="relative">
            <button
              type="button"
              onClick={() => setToolsOpen((o) => !o)}
              className={`p-2 rounded-lg text-lg leading-none transition-colors ${
                surveyMode || studyMode || flashMode || quizMode || summarizeMode || mindMode
                  ? 'bg-indigo-600 text-white'
                  : 'hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-500'
              }`}
              title="Herramientas de estudio"
            >
              <img src="/ic-estudio.png" alt="Estudio" className="h-8 w-8 object-contain" />
            </button>
            {toolsOpen && (
              <>
                <div
                  className="fixed inset-0 z-10"
                  onClick={() => setToolsOpen(false)}
                />
                <div className="absolute bottom-full mb-2 left-0 z-20 w-52 rounded-xl border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 shadow-lg p-1 text-sm">
                  {(
                    [
                      ['📚', 'Plan de estudio', studyMode, setStudyMode],
                      ['📊', 'Encuesta', surveyMode, setSurveyMode],
                      ['🃏', 'Tarjetas de estudio', flashMode, setFlashMode],
                      ['📝', 'Examen / quiz', quizMode, setQuizMode],
                      ['🗺️', 'Mapa mental', mindMode, setMindMode],
                      ['🔗', 'Resumir un enlace', summarizeMode, setSummarizeMode],
                    ] as const
                  ).map(([icon, label, active, setter]) => (
                    <button
                      key={label}
                      type="button"
                      onClick={() => pickTool(setter, active)}
                      className={`w-full flex items-center gap-2 px-2.5 py-2 rounded-lg text-left ${
                        active
                          ? 'bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300'
                          : 'hover:bg-zinc-100 dark:hover:bg-zinc-700'
                      }`}
                    >
                      <span>{icon}</span>
                      <span className="flex-1">{label}</span>
                      {active && <span>✓</span>}
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>
          </div>

          <textarea
            ref={taRef}
            value={value}
            onChange={(e) => onChange(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault()
                submit()
              }
            }}
            onPaste={(e) => {
              const files = Array.from(e.clipboardData.files)
              if (files.length) {
                e.preventDefault()
                addFiles(files)
              }
            }}
            rows={1}
            placeholder={
              recording
                ? 'Escuchando… toca 🎤 para terminar'
                : summarizeMode
                  ? 'Pega el enlace (YouTube o página web)…'
                  : mindMode
                    ? '¿De qué tema quieres el mapa mental?'
                    : flashMode
                      ? '¿De qué tema quieres tarjetas?'
                      : quizMode
                        ? '¿De qué tema quieres el examen?'
                      : studyMode
                        ? '¿Qué tema quieres estudiar? (ej: ecuaciones lineales)'
                        : surveyMode
                          ? '¿Sobre qué tema es la encuesta?'
                          : docMode
                            ? '¿Sobre qué tema? (ej: la energía solar)'
                            : imageOn
                              ? 'Describe la imagen que quieres generar…'
                              : webOn
                                ? 'Pregunta algo para buscar en internet…'
                                : solveMode
                                  ? 'Adjunta la foto y describe qué resolver…'
                                  : 'Escribe un mensaje…  (o toca 🎤 para hablar)'
            }
            className="order-1 sm:order-2 basis-full sm:basis-0 flex-1 min-w-0 resize-none bg-transparent outline-none py-2 text-sm max-h-[200px]"
          />

          {isStreaming ? (
            <button
              onClick={onStop}
              className="order-3 ml-auto sm:ml-0 px-4 py-2 rounded-lg bg-red-500 hover:bg-red-600 text-white text-sm shrink-0"
            >
              Detener
            </button>
          ) : (
            <button
              onClick={submit}
              disabled={disabled}
              className="order-3 ml-auto sm:ml-0 px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white text-sm shrink-0"
            >
              {studyMode
                ? 'Aprender'
                : summarizeMode
                  ? 'Resumir'
                  : flashMode || quizMode || surveyMode || docMode || mindMode
                    ? 'Crear'
                    : imageOn
                      ? 'Generar'
                      : 'Enviar'}
            </button>
          )}
        </div>
      </div>
      <p className="max-w-3xl mx-auto text-[11px] text-zinc-400 mt-1.5 px-2">
        {summarizeMode
          ? '🔗 Pega un enlace y te lo resume (usa internet)'
          : mindMode
            ? '🗺️ Dibuja un mapa mental del tema en el chat'
            : flashMode
              ? '🃏 Creará tarjetas para repasar en el chat'
              : quizMode
                ? '📝 Creará un examen tipo test que te corrige'
              : solveMode
                ? '📷 Lee el ejercicio de la foto y lo resuelve paso a paso'
                : studyMode
                  ? '📚 Arma un plan y te enseña paso a paso; busca y veta videos (usa internet)'
                  : surveyMode
                    ? '📊 Creará un formulario interactivo para responder en el chat'
                    : docMode
                      ? '📄 Creará un documento con diseño (requiere el servidor de documentos)'
                      : imageOn
                        ? '🎨 Generará una imagen desde tu descripción (requiere el servidor de imágenes)'
                        : webOn
                          ? '🌐 Buscará en internet y citará fuentes · Enter envía'
                          : '🎤 dictado por voz local · Enter envía · Shift+Enter salto de línea'}
      </p>
    </div>
  )
}
