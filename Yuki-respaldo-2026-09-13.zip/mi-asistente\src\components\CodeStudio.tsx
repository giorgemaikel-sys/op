import { useCallback, useEffect, useRef, useState } from 'react'
import CodeMirror from '@uiw/react-codemirror'
import { python, globalCompletion, localCompletionSource } from '@codemirror/lang-python'
import { html } from '@codemirror/lang-html'
import { javascript } from '@codemirror/lang-javascript'
import { oneDark } from '@codemirror/theme-one-dark'
import { EditorView, keymap } from '@codemirror/view'
import { autocompletion, completeFromList, snippetCompletion } from '@codemirror/autocomplete'
import { search, searchKeymap, openSearchPanel } from '@codemirror/search'
import { indentWithTab, toggleComment } from '@codemirror/commands'
import { useOwner } from '../lib/owner'
import { verifyOwnerPassword } from '../lib/profiles'
import { chat, complete, listModels } from '../lib/ollama'
import { runProgram, replPush, replReset, pipInstall, listLibs } from '../lib/pyodide'

const CODE_KEY = 'asistente:studioCode' // prefijo; la clave real es por perfil
const SNIP_KEY = 'asistente:studioSnips' // prefijo; guardados por perfil

interface Snippet {
  name: string
  code: string
}

/** Ejemplos listos para probar (uno carga en el editor). */
const EXAMPLES: { label: string; win?: boolean; code: string }[] = [
  {
    label: '👋 Básico (variables y bucle)',
    code: `nombre = "Yuki"\nfor i in range(1, 6):\n    print(i, "hola", nombre)\nprint("suma 1..100 =", sum(range(1, 101)))\n`,
  },
  {
    label: '📊 Gráfica (matplotlib)',
    code: `import matplotlib.pyplot as plt\nimport numpy as np\n\nx = np.linspace(0, 2 * np.pi, 200)\nplt.plot(x, np.sin(x), label="sin")\nplt.plot(x, np.cos(x), label="cos")\nplt.legend(); plt.title("Seno y coseno"); plt.grid(True)\nprint("gráfica lista")\n`,
  },
  {
    label: '🐼 Datos (pandas)',
    code: `import pandas as pd\n\ndf = pd.DataFrame({\n    "producto": ["A", "B", "C", "D"],\n    "ventas": [120, 340, 200, 90],\n})\nprint(df)\nprint("\\nTotal:", df["ventas"].sum())\nprint("Promedio:", df["ventas"].mean())\n`,
  },
  {
    label: '⌨️ Con entrada (input)',
    code: `nombre = input("¿Cómo te llamas? ")\nedad = int(input("¿Cuántos años tienes? "))\nprint(f"Hola {nombre}, en 10 años tendrás {edad + 10}.")\n# Activa ⌨️ Entrada abajo y escribe: tu nombre y tu edad en dos líneas\n`,
  },
  {
    label: '🐢 Ventana: dibujo (turtle)',
    win: true,
    code: `import turtle\nt = turtle.Turtle()\nt.speed(0)\nt.pensize(3)\ncolores = ["red", "orange", "green", "blue", "purple"]\nfor i in range(60):\n    t.color(colores[i % len(colores)])\n    t.forward(i * 4)\n    t.left(59)\nturtle.done()\n`,
  },
  {
    label: '🎮 Ventana: juego (pygame)',
    win: true,
    code: `import pygame, sys, random\npygame.init()\nW, H = 480, 360\ns = pygame.display.set_mode((W, H))\npygame.display.set_caption("Yuki demo")\nclock = pygame.time.Clock()\nx, y, dx, dy, r = W // 2, H // 2, 4, 3, 25\ncol = [random.randint(60, 255) for _ in range(3)]\nwhile True:\n    for e in pygame.event.get():\n        if e.type == pygame.QUIT:\n            pygame.quit(); sys.exit()\n    x += dx; y += dy\n    if x < r or x > W - r: dx = -dx; col = [random.randint(60,255) for _ in range(3)]\n    if y < r or y > H - r: dy = -dy; col = [random.randint(60,255) for _ in range(3)]\n    s.fill((15, 15, 30))\n    pygame.draw.circle(s, col, (x, y), r)\n    pygame.display.flip(); clock.tick(60)\n`,
  },
]
const SAMPLE = `# 🐍 Studio de Python — escribe aquí y pulsa ▶️ Ejecutar (Ctrl+Enter)
# Puedes usar las librerías de tu PC e instalar nuevas con 📦.

import numpy as np

datos = np.array([4, 8, 15, 16, 23, 42])
print("promedio:", datos.mean())
print("máximo:", datos.max())

# Para ver una gráfica, descomenta:
# import matplotlib.pyplot as plt
# plt.plot(datos); plt.title("mis datos")
`

// Sugerencias de código extra (builtins comunes, imports y plantillas).
const EXTRA_COMPLETIONS = completeFromList([
  'print', 'range', 'len', 'input', 'int', 'str', 'float', 'bool', 'list', 'dict',
  'set', 'tuple', 'enumerate', 'zip', 'sum', 'min', 'max', 'sorted', 'abs', 'round',
  'open', 'type', 'map', 'filter', 'append', 'format',
  'import numpy as np', 'import pandas as pd', 'import matplotlib.pyplot as plt',
  'import pygame', 'import turtle', 'import random', 'import math', 'import os',
  snippetCompletion('for ${i} in range(${n}):\n    ${}', { label: 'for', type: 'keyword', detail: 'bucle for' }),
  snippetCompletion('def ${nombre}(${args}):\n    ${cuerpo}', { label: 'def', type: 'keyword', detail: 'función' }),
  snippetCompletion('if ${cond}:\n    ${}', { label: 'if', type: 'keyword', detail: 'condición' }),
  snippetCompletion('while ${cond}:\n    ${}', { label: 'while', type: 'keyword', detail: 'bucle while' }),
  snippetCompletion('try:\n    ${}\nexcept Exception as e:\n    print(e)', { label: 'try', type: 'keyword', detail: 'try/except' }),
])

const PY_AUTOCOMPLETE = autocompletion({
  activateOnTyping: true,
  override: [globalCompletion, localCompletionSource, EXTRA_COMPLETIONS],
})

// Autocompletado para HTML (etiquetas y atributos vienen del propio lenguaje).
const HTML_AUTOCOMPLETE = autocompletion({ activateOnTyping: true })

const HTML_SAMPLE = `<!-- 🌐 Editor HTML — escribe aquí y pulsa ▶️ Ejecutar para ver la vista previa -->
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <style>
    body { font-family: system-ui, sans-serif; text-align: center; padding: 2rem;
           background: #0f172a; color: #e2e8f0; }
    h1 { color: #818cf8; }
    button { font-size: 1.1rem; padding: .6rem 1.2rem; border: none; border-radius: .6rem;
             background: #6366f1; color: white; cursor: pointer; }
  </style>
</head>
<body>
  <h1>¡Hola desde Yuki! 🌐</h1>
  <p id="msg">Pulsa el botón:</p>
  <button onclick="document.getElementById('msg').textContent = '¡Funciona! ' + new Date().toLocaleTimeString()">
    Tócame
  </button>
</body>
</html>
`

const HTML_EXAMPLES: { label: string; code: string }[] = [
  {
    label: '🌐 Página básica',
    code: HTML_SAMPLE,
  },
  {
    label: '🎨 Tarjeta con estilo',
    code: `<!doctype html>\n<html><head><meta charset="utf-8"><style>\n  body{margin:0;display:grid;place-items:center;height:100vh;background:linear-gradient(135deg,#6366f1,#a855f7);font-family:system-ui}\n  .card{background:#fff;padding:2rem;border-radius:1rem;box-shadow:0 10px 40px rgba(0,0,0,.3);text-align:center;max-width:300px}\n  .card h2{margin:.2rem 0;color:#4f46e5}\n</style></head>\n<body>\n  <div class="card">\n    <div style="font-size:3rem">🐱</div>\n    <h2>Yuki</h2>\n    <p style="color:#555">Tu asistente local y gratis.</p>\n  </div>\n</body></html>\n`,
  },
  {
    label: '🎮 Cuadros que rebotan (canvas)',
    code: `<!doctype html>\n<html><head><meta charset="utf-8"><style>body{margin:0;background:#111}</style></head>\n<body>\n<canvas id="c"></canvas>\n<script>\nconst c=document.getElementById('c'),x=c.getContext('2d');\nc.width=innerWidth;c.height=innerHeight;\nlet b={x:100,y:100,dx:4,dy:3,r:24,col:'#6366f1'};\nfunction loop(){\n  x.fillStyle='#111';x.fillRect(0,0,c.width,c.height);\n  b.x+=b.dx;b.y+=b.dy;\n  if(b.x<b.r||b.x>c.width-b.r)b.dx*=-1;\n  if(b.y<b.r||b.y>c.height-b.r)b.dy*=-1;\n  x.beginPath();x.arc(b.x,b.y,b.r,0,7);x.fillStyle=b.col;x.fill();\n  requestAnimationFrame(loop);\n}\nloop();\n</script>\n</body></html>\n`,
  },
]

const JS_SAMPLE = `// 🟨 Editor JavaScript — escribe aquí y pulsa ▶️ Ejecutar
// Lo que imprimas con console.log aparece en la terminal.

console.log("¡Hola desde JavaScript! 🟨")

const nums = [4, 8, 15, 16, 23, 42]
const total = nums.reduce((a, b) => a + b, 0)
console.log("suma:", total)
console.log("dobles:", nums.map(n => n * 2))
`

const JS_EXAMPLES: { label: string; code: string }[] = [
  { label: '👋 Básico', code: JS_SAMPLE },
  {
    label: '🔢 Números y arrays',
    code: `const n = [5, 3, 9, 1, 7]\nconsole.log("ordenado:", [...n].sort((a,b)=>a-b))\nconsole.log("mayor:", Math.max(...n))\nconsole.log("pares:", n.filter(x => x % 2 === 0))\n`,
  },
  {
    label: '⏱️ Temporizador (async)',
    code: `console.log("empieza…")\nlet i = 0\nconst t = setInterval(() => {\n  i++\n  console.log("tick", i)\n  if (i >= 3) { clearInterval(t); console.log("listo ✅") }\n}, 300)\n`,
  },
]

/** Ejecuta JavaScript en un iframe aislado y captura console.log/errores. */
function runJs(code: string): Promise<{ out: string; err: string }> {
  return new Promise((resolve) => {
    const id = 'jsrun_' + Math.random().toString(36).slice(2)
    const logs: string[] = []
    let err = ''
    let done = false
    function finish() {
      if (done) return
      done = true
      window.removeEventListener('message', onMsg)
      try {
        iframe.remove()
      } catch {
        /* ignore */
      }
      resolve({ out: logs.join('\n'), err: err.trim() })
    }
    function onMsg(e: MessageEvent) {
      const d = e.data
      if (!d || d.__id !== id) return
      if (d.type === 'log') logs.push(d.text)
      else if (d.type === 'err') err += d.text + '\n'
      else if (d.type === 'done') finish()
    }
    window.addEventListener('message', onMsg)
    const doc =
      '<!doctype html><meta charset="utf-8"><script>\n' +
      'var ID=' + JSON.stringify(id) + ';\n' +
      'function _s(t,x){parent.postMessage({__id:ID,type:t,text:String(x)},"*")}\n' +
      'function _f(a){return Array.prototype.map.call(a,function(x){try{return (typeof x==="object")?JSON.stringify(x):String(x)}catch(e){return String(x)}}).join(" ")}\n' +
      'console.log=function(){_s("log",_f(arguments))};console.info=console.log;console.warn=console.log;\n' +
      'console.error=function(){_s("err",_f(arguments))};\n' +
      'window.onerror=function(m){_s("err",m);return true};\n' +
      'try{\n' + code + '\n}catch(e){_s("err",(e&&e.stack)||e)}\n' +
      'setTimeout(function(){_s("done")},1200);\n' +
      '<\/script>'
    const iframe = document.createElement('iframe')
    iframe.sandbox.add('allow-scripts')
    iframe.style.display = 'none'
    iframe.srcdoc = doc
    document.body.appendChild(iframe)
    setTimeout(finish, 6000) // tope de seguridad
  })
}

interface Props {
  onClose: () => void
  model: string
  profileId: string
}

/** Parte la respuesta de la IA en segmentos de texto y de código, para
 *  renderizar cada bloque de código con sus botones (copiar / usar). */
type AiSeg = { type: 'text'; content: string } | { type: 'code'; content: string; lang: string }
function parseAiSegments(text: string): AiSeg[] {
  const segs: AiSeg[] = []
  const re = /```([a-zA-Z0-9+#-]*)\s*\n?([\s\S]*?)```/g
  let last = 0
  let m: RegExpExecArray | null
  while ((m = re.exec(text))) {
    if (m.index > last) segs.push({ type: 'text', content: text.slice(last, m.index) })
    segs.push({ type: 'code', content: m[2].replace(/\n$/, ''), lang: (m[1] || '').toLowerCase() })
    last = m.index + m[0].length
  }
  if (last < text.length) segs.push({ type: 'text', content: text.slice(last) })
  return segs
}

interface AiMsg {
  role: 'user' | 'assistant'
  content: string
}

export default function CodeStudio({ onClose, model, profileId }: Props) {
  const { ownerPass, unlock } = useOwner()
  const [lang, setLang] = useState<'py' | 'html' | 'js'>('py')
  const codeKey = `${CODE_KEY}:${profileId}:${lang}`

  // --- Candado de administrador ---
  const [pass, setPass] = useState('')
  const [checking, setChecking] = useState(false)
  const [lockErr, setLockErr] = useState('')
  async function tryUnlock() {
    const p = pass.trim()
    if (!p) return
    setChecking(true)
    setLockErr('')
    try {
      if (await verifyOwnerPassword(p)) {
        setPass('')
        unlock(p)
      } else setLockErr('Contraseña incorrecta')
    } catch {
      setLockErr('No se pudo verificar (¿servidor apagado?)')
    } finally {
      setChecking(false)
    }
  }

  // --- Editor ---
  const [code, setCode] = useState<string>(() => {
    try {
      return (
        localStorage.getItem(`${CODE_KEY}:${profileId}:py`) ??
        localStorage.getItem(`${CODE_KEY}:${profileId}`) ?? // clave vieja (migración)
        SAMPLE
      )
    } catch {
      return SAMPLE
    }
  })

  // Cambiar de lenguaje guardando/cargando el buffer de cada uno.
  function switchLang(nl: 'py' | 'html' | 'js') {
    if (nl === lang) return
    try {
      localStorage.setItem(codeKey, code)
    } catch {
      /* ignore */
    }
    const fallback = nl === 'html' ? HTML_SAMPLE : nl === 'js' ? JS_SAMPLE : SAMPLE
    let next = fallback
    try {
      next = localStorage.getItem(`${CODE_KEY}:${profileId}:${nl}`) ?? fallback
    } catch {
      /* ignore */
    }
    setCode(next)
    setLang(nl)
  }
  useEffect(() => {
    const t = setTimeout(() => {
      try {
        localStorage.setItem(codeKey, code)
      } catch {
        /* ignore */
      }
    }, 400)
    return () => clearTimeout(t)
  }, [code, codeKey])

  const [tab, setTab] = useState<'term' | 'ai'>('term')
  const [panelSize, setPanelSize] = useState<'min' | 'normal' | 'max'>('normal')
  const [running, setRunning] = useState(false)
  const [pyStatus, setPyStatus] = useState('') // mensaje mientras carga Python

  const [pkg, setPkg] = useState('')
  const [installing, setInstalling] = useState(false)

  const [aiQ, setAiQ] = useState('')
  const [aiBusy, setAiBusy] = useState(false)
  const [aiMsgs, setAiMsgs] = useState<AiMsg[]>([])
  const aiAbort = useRef<AbortController | null>(null)
  const viewRef = useRef<EditorView | null>(null)
  // Selector de modelo para el asistente (elige un modelo de código si hay).
  const [models, setModels] = useState<{ name: string }[]>([])
  const [aiModel, setAiModel] = useState<string>(model)
  const [completing, setCompleting] = useState(false)
  useEffect(() => {
    listModels()
      .then((ms) => {
        setModels(ms)
        const coder = ms.find((m) => /coder|code/i.test(m.name))
        setAiModel((cur) => cur || coder?.name || model || ms[0]?.name || '')
      })
      .catch(() => {})
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // Ventana en vivo (solo ver)
  const [guiSid, setGuiSid] = useState<string | null>(null)
  const [guiBusy, setGuiBusy] = useState(false)
  const [guiErr, setGuiErr] = useState<string | null>(null)

  // Ajustes del editor + extras
  const [fontSize, setFontSize] = useState(14)
  const [wrap, setWrap] = useState(false)
  const [stdinOn, setStdinOn] = useState(false)
  const [stdinText, setStdinText] = useState('')

  // Terminal (consola Python por defecto; modo 'cmd' = sistema)
  const [termMode, setTermMode] = useState<'py' | 'cmd'>('py')
  const [termMore, setTermMore] = useState(false) // bloque multilínea en curso (prompt …)
  const [termLog, setTermLog] = useState<
    {
      kind: 'py' | 'cmd' | 'run' | 'html'
      cmd?: string
      out: string
      err?: string
      ok: boolean
      cont?: boolean
      images?: string[]
    }[]
  >([])
  const [termCwd, setTermCwd] = useState('')
  const [termCmd, setTermCmd] = useState('')
  const [termBusy, setTermBusy] = useState(false)
  const [termHist, setTermHist] = useState<string[]>([])
  const [histIdx, setHistIdx] = useState(-1)

  // Librerías instaladas
  const [showLibs, setShowLibs] = useState(false)
  const [libs, setLibs] = useState<string[] | null>(null)
  const [pyVer, setPyVer] = useState('')
  const [libFilter, setLibFilter] = useState('')

  // Fragmentos guardados (por perfil)
  const snipKey = `${SNIP_KEY}:${profileId}`
  const [snippets, setSnippets] = useState<Snippet[]>(() => {
    try {
      return JSON.parse(localStorage.getItem(snipKey) || '[]')
    } catch {
      return []
    }
  })
  function persistSnippets(list: Snippet[]) {
    setSnippets(list)
    try {
      localStorage.setItem(snipKey, JSON.stringify(list))
    } catch {
      /* ignore */
    }
  }

  const authHeaders = {
    'Content-Type': 'application/json',
    'x-owner-pass': ownerPass || '',
  }

  // Reemplaza la salida anterior (cierra la "ventana" previa) y deja solo la nueva.
  type TermEntry = {
    kind: 'py' | 'cmd' | 'run' | 'html'
    cmd?: string
    out: string
    err?: string
    ok: boolean
    cont?: boolean
    images?: string[]
  }
  function showOutput(entry: TermEntry) {
    setTermLog((l) => [...l.filter((e) => e.kind !== 'run' && e.kind !== 'html'), entry])
  }

  // Vista previa HTML activa (si hay): ocupa TODO el panel, no un recuadro.
  const htmlPreview = [...termLog].reverse().find((e) => e.kind === 'html')

  const run = useCallback(async () => {
    if (running) return
    setTab('term')
    setPanelSize('max') // pantalla completa para ver bien la salida/vista previa
    // HTML: mostrar vista previa en vivo (iframe en la terminal), reemplazando la anterior.
    if (lang === 'html') {
      showOutput({ kind: 'html', out: code, ok: true })
      return
    }
    // JavaScript: correr en un iframe aislado y mostrar la consola.
    if (lang === 'js') {
      setRunning(true)
      try {
        const r = await runJs(code)
        showOutput({ kind: 'run', out: r.out, err: r.err, ok: !r.err })
      } finally {
        setRunning(false)
      }
      return
    }
    setRunning(true)
    try {
      // Corre EN EL NAVEGADOR (no en la PC). La salida aparece en la terminal.
      const res = await runProgram(code, stdinOn ? stdinText : '', setPyStatus)
      showOutput({
        kind: 'run',
        out: res.stdout.replace(/\n+$/, ''),
        err: (res.stderr || '').replace(/\n+$/, ''),
        images: res.images,
        ok: !res.stderr,
      })
    } catch (e: any) {
      showOutput({ kind: 'run', out: '', err: e?.message ?? String(e), ok: false })
    } finally {
      setPyStatus('')
      setRunning(false)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [code, running, stdinOn, stdinText, lang])

  // Ctrl/Cmd + Enter = ejecutar
  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
        e.preventDefault()
        run()
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [run])

  async function install() {
    const p = pkg.trim()
    if (!p || installing) return
    setInstalling(true)
    setTab('term')
    setPanelSize((s) => (s === 'min' ? 'normal' : s))
    try {
      const out = await pipInstall(p, setPyStatus)
      setTermLog((l) => [...l, { kind: 'cmd', cmd: '📦 pip install ' + p, out: out.replace(/\n+$/, ''), ok: !out.includes('✗') }])
      if (!out.includes('✗')) setPkg('')
    } catch (e: any) {
      setTermLog((l) => [...l, { kind: 'cmd', cmd: '📦 pip install ' + p, out: e?.message ?? 'No se pudo instalar.', ok: false }])
    } finally {
      setPyStatus('')
      setInstalling(false)
    }
  }

  async function runWindow() {
    if (guiBusy) return
    setGuiBusy(true)
    setGuiErr(null)
    // cerrar una sesión anterior si la hubiera
    if (guiSid) {
      fetch('/sd/guistop', { method: 'POST', headers: authHeaders, body: JSON.stringify({ sid: guiSid }) }).catch(() => {})
      setGuiSid(null)
    }
    setTab('term')
    setPanelSize('max')
    try {
      const r = await fetch('/sd/guistart', {
        method: 'POST',
        headers: authHeaders,
        body: JSON.stringify({ code }),
      })
      const d = await r.json()
      if (d.ok && d.sid) setGuiSid(d.sid)
      else setGuiErr(d.error || 'No se pudo abrir la ventana.')
    } catch {
      setGuiErr('No se pudo conectar con el servidor de Python (imagenes.bat).')
    } finally {
      setGuiBusy(false)
    }
  }

  function stopWindow() {
    if (guiSid) {
      fetch('/sd/guistop', {
        method: 'POST',
        headers: authHeaders,
        body: JSON.stringify({ sid: guiSid }),
      }).catch(() => {})
    }
    setGuiSid(null)
  }

  // Detectar cuando el programa se cierra solo (ventana cerrada) para limpiar.
  useEffect(() => {
    if (!guiSid) return
    const t = setInterval(async () => {
      try {
        const r = await fetch('/sd/guistatus', {
          method: 'POST',
          headers: authHeaders,
          body: JSON.stringify({ sid: guiSid }),
        })
        const d = await r.json()
        if (!d.alive) setGuiSid(null)
      } catch {
        /* ignore */
      }
    }, 2500)
    return () => clearInterval(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [guiSid])

  // Al cerrar el Studio, cortar cualquier ventana en vivo.
  useEffect(() => {
    return () => {
      if (guiSid) {
        fetch('/sd/guistop', {
          method: 'POST',
          headers: authHeaders,
          body: JSON.stringify({ sid: guiSid }),
        }).catch(() => {})
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [guiSid])

  const LANG_NAME = { py: 'Python', html: 'HTML', js: 'JavaScript' } as const
  const FENCE = { py: 'python', html: 'html', js: 'javascript' } as const

  /** Devuelve el texto seleccionado en el editor (o '' si no hay selección). */
  function selectedText(): string {
    const v = viewRef.current
    if (!v) return ''
    const { from, to } = v.state.selection.main
    return from === to ? '' : v.state.sliceDoc(from, to)
  }

  /** Reemplaza TODO el código del editor por el bloque dado. */
  function replaceAllCode(block: string) {
    setCode(block)
  }
  /** Inserta el bloque en la posición del cursor (o reemplaza la selección). */
  function insertAtCursor(block: string) {
    const v = viewRef.current
    if (!v) {
      setCode((c) => c + (c.endsWith('\n') || !c ? '' : '\n') + block)
      return
    }
    const sel = v.state.selection.main
    v.dispatch({
      changes: { from: sel.from, to: sel.to, insert: block },
      selection: { anchor: sel.from + block.length },
    })
    v.focus()
  }

  function stopAi() {
    aiAbort.current?.abort()
    aiAbort.current = null
    setAiBusy(false)
  }
  function clearAi() {
    stopAi()
    setAiMsgs([])
  }

  async function ask(question: string) {
    const useModel = aiModel || model
    if (aiBusy || !useModel || !question.trim()) return
    setTab('ai')
    setAiBusy(true)
    const ln = LANG_NAME[lang]
    const fence = FENCE[lang]
    const sel = selectedText()
    const lastErr = [...termLog].reverse().find((e) => e.err)?.err
    // El código actual va en el system para que la IA SIEMPRE vea la versión
    // más reciente del editor, aunque la charla tenga varios turnos.
    const sys =
      `Eres un programador experto que ayuda DENTRO de un editor de código. ` +
      `El usuario programa en ${ln}. Responde en español, claro y al grano. ` +
      `Cuando propongas código, ponlo SIEMPRE en un bloque \`\`\`${fence} ... \`\`\`. ` +
      `Este es el código completo del editor ahora mismo:\n\n\`\`\`${fence}\n${code}\n\`\`\`` +
      (sel ? `\n\nEl usuario tiene SELECCIONADO este fragmento (enfócate en él):\n\n\`\`\`${fence}\n${sel}\n\`\`\`` : '') +
      (lastErr ? `\n\nAl ejecutar, el último error fue:\n${lastErr}` : '')

    const history = aiMsgs.slice(-6)
    const userMsg: AiMsg = { role: 'user', content: question }
    setAiMsgs((m) => [...m, userMsg, { role: 'assistant', content: '' }])

    const ac = new AbortController()
    aiAbort.current = ac
    try {
      await chat({
        model: useModel,
        systemPrompt: sys,
        signal: ac.signal,
        messages: [...history, userMsg].map((mm, i) => ({
          id: 'ai' + i,
          role: mm.role,
          content: mm.content,
          createdAt: 0,
        })),
        onToken: (chunk) => {
          setAiMsgs((m) => {
            const copy = m.slice()
            const last = copy[copy.length - 1]
            if (last && last.role === 'assistant') copy[copy.length - 1] = { role: 'assistant', content: last.content + chunk }
            return copy
          })
        },
      })
    } catch (e: any) {
      if (e?.name !== 'AbortError') {
        setAiMsgs((m) => {
          const copy = m.slice()
          const last = copy[copy.length - 1]
          const msg = '⚠️ Error al preguntar a la IA: ' + (e?.message ?? e)
          if (last && last.role === 'assistant' && !last.content) copy[copy.length - 1] = { role: 'assistant', content: msg }
          else copy.push({ role: 'assistant', content: msg })
          return copy
        })
      }
    } finally {
      aiAbort.current = null
      setAiBusy(false)
    }
  }

  /** Autocompletar con IA: continúa el código desde el cursor. */
  async function aiComplete() {
    const v = viewRef.current
    const useModel = aiModel || model
    if (completing || aiBusy || !useModel || !v) return
    setCompleting(true)
    try {
      const pos = v.state.selection.main.head
      const before = v.state.sliceDoc(0, pos)
      const after = v.state.sliceDoc(pos)
      const sys =
        `Eres un autocompletador de código ${LANG_NAME[lang]} (como Copilot). ` +
        `Devuelve SOLO el código que continúa a partir del cursor, sin explicaciones y SIN comillas triples. ` +
        `No repitas el código anterior. Mantén el estilo y la indentación.`
      const prompt =
        `Código ANTES del cursor:\n${before || '(vacío)'}\n\n` +
        `Código DESPUÉS del cursor:\n${after || '(vacío)'}\n\n` +
        `Escribe únicamente lo que debe ir en el cursor.`
      let out = await complete({ model: useModel, system: sys, prompt, numPredict: 160 })
      out = out.replace(/```[a-zA-Z0-9+#-]*\n?/g, '').replace(/```/g, '').replace(/\s+$/, '')
      if (out && viewRef.current) {
        const w = viewRef.current
        const at = w.state.selection.main.head
        const charBefore = at > 0 ? w.state.sliceDoc(at - 1, at) : '\n'
        // Si el cursor está pegado a texto y la IA no trae salto, añádelo para no pegar palabras.
        if (charBefore !== '\n' && charBefore !== ' ' && !/^[\s)\].,:;]/.test(out)) out = '\n' + out
        w.dispatch({ changes: { from: at, insert: out }, selection: { anchor: at + out.length } })
        w.focus()
      }
    } catch {
      /* noop */
    } finally {
      setCompleting(false)
    }
  }

  function loadExample(ex: { code: string; win?: boolean }) {
    const t = code.trim()
    const isSample = t === SAMPLE.trim() || t === HTML_SAMPLE.trim() || t === JS_SAMPLE.trim()
    if (t && !isSample && !confirm('¿Reemplazar el código actual por el ejemplo?')) return
    setCode(ex.code)
    setGuiErr(null)
  }

  function saveSnippet() {
    const name = prompt('Nombre para guardar este código:')?.trim()
    if (!name) return
    const list = snippets.filter((s) => s.name !== name)
    list.unshift({ name, code })
    persistSnippets(list)
  }

  function openSnippet(name: string) {
    const s = snippets.find((x) => x.name === name)
    if (!s) return
    if (code.trim() && code.trim() !== s.code.trim() && !confirm('¿Reemplazar el código actual por "' + name + '"?')) return
    setCode(s.code)
  }

  function deleteSnippet(name: string) {
    if (!confirm('¿Borrar el guardado "' + name + '"?')) return
    persistSnippets(snippets.filter((s) => s.name !== name))
  }

  async function loadLibs() {
    setShowLibs(true)
    try {
      const names = await listLibs(setPyStatus)
      setLibs(names)
      setPyVer('')
    } catch {
      setLibs([])
    } finally {
      setPyStatus('')
    }
  }

  function downloadPy() {
    const blob = new Blob([code], { type: 'text/x-python' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'script.py'
    a.click()
    setTimeout(() => URL.revokeObjectURL(url), 2000)
  }

  async function runCmd() {
    if (termBusy) return
    if (termMode === 'py') return runPyLine()

    // Modo sistema (cmd)
    const c = termCmd.trim()
    if (!c) return
    setTermHist((h) => [c, ...h.filter((x) => x !== c)].slice(0, 50))
    setHistIdx(-1)
    setTermCmd('')
    if (c === 'clear' || c === 'cls') {
      setTermLog([])
      return
    }
    setTermBusy(true)
    try {
      const r = await fetch('/sd/runcmd', {
        method: 'POST',
        headers: authHeaders,
        body: JSON.stringify({ cmd: c, cwd: termCwd }),
      })
      const d = await r.json()
      setTermLog((l) => [...l, { cmd: c, out: (d.output ?? d.error ?? '').replace(/\n+$/, ''), ok: !!d.ok, kind: 'cmd' }])
      if (d.cwd) setTermCwd(d.cwd)
    } catch {
      setTermLog((l) => [...l, { cmd: c, out: 'No se pudo conectar con el servidor (imagenes.bat).', ok: false, kind: 'cmd' }])
    } finally {
      setTermBusy(false)
    }
  }

  // Consola Python: envía una línea; soporta bloques (def/for/while) con continuación.
  async function runPyLine() {
    const raw = termCmd
    const trimmed = raw.trim()
    if (!termMore && (trimmed === 'cls' || trimmed === 'clear')) {
      setTermCmd('')
      setTermLog([])
      return
    }
    let toSend = raw
    if (termMore && trimmed === '') toSend = '' // línea vacía cierra el bloque
    else if (!termMore && trimmed === '') return // vacío sin bloque: nada
    if (trimmed) setTermHist((h) => [raw, ...h.filter((x) => x !== raw)].slice(0, 50))
    setHistIdx(-1)
    const wasCont = termMore
    setTermCmd('')
    setTermBusy(true)
    try {
      // Corre EN EL NAVEGADOR (no en la PC).
      const d = await replPush(toSend, setPyStatus)
      setTermLog((l) => [...l, { cmd: toSend, out: (d.out ?? '').replace(/\n+$/, ''), ok: true, kind: 'py', cont: wasCont }])
      setTermMore(!!d.more)
      if (d.more) {
        const base = raw.match(/^\s*/)?.[0].length ?? 0
        const extra = /:\s*$/.test(raw) ? 4 : 0
        setTermCmd(' '.repeat(base + extra))
      }
    } catch (e: any) {
      setTermLog((l) => [...l, { cmd: toSend, out: e?.message ?? 'Error al iniciar Python.', ok: false, kind: 'py', cont: wasCont }])
      setTermMore(false)
    } finally {
      setPyStatus('')
      setTermBusy(false)
    }
  }

  function handleTermKey(e: { key: string; preventDefault: () => void }) {
    if (e.key === 'Enter') {
      e.preventDefault()
      runCmd()
    } else if (e.key === 'ArrowUp') {
      e.preventDefault()
      const ni = Math.min(histIdx + 1, termHist.length - 1)
      if (ni >= 0) {
        setHistIdx(ni)
        setTermCmd(termHist[ni])
      }
    } else if (e.key === 'ArrowDown') {
      e.preventDefault()
      const ni = histIdx - 1
      if (ni < 0) {
        setHistIdx(-1)
        setTermCmd('')
      } else {
        setHistIdx(ni)
        setTermCmd(termHist[ni])
      }
    }
  }

  // ---- Pantalla de candado ----
  if (!ownerPass) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
        <div className="w-full max-w-sm rounded-2xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 shadow-xl p-5 space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="font-semibold">🧑‍💻 Studio de código</h2>
            <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800">✕</button>
          </div>
          <p className="text-sm text-zinc-500">
            🔒 El Studio ejecuta código en tu PC, así que es solo para el administrador.
          </p>
          <input
            type="password"
            value={pass}
            onChange={(e) => {
              setPass(e.target.value)
              setLockErr('')
            }}
            onKeyDown={(e) => e.key === 'Enter' && tryUnlock()}
            placeholder="Contraseña de administrador"
            className="w-full rounded-lg border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-900 px-3 py-2 text-sm outline-none"
          />
          {lockErr && <p className="text-xs text-red-500">{lockErr}</p>}
          <button
            onClick={tryUnlock}
            disabled={checking}
            className="w-full rounded-lg bg-indigo-600 hover:bg-indigo-500 disabled:opacity-60 text-white py-2 text-sm font-medium"
          >
            {checking ? 'Comprobando…' : '🔓 Entrar al Studio'}
          </button>
        </div>
      </div>
    )
  }

  // ---- Studio ----
  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-zinc-950 text-zinc-100">
      {/* Barra superior (2 filas: acciones e instalar) — se adapta al móvil */}
      <div
        className="border-b border-zinc-800 bg-zinc-900 shrink-0 px-3 py-2 space-y-2"
        style={{ paddingTop: 'max(0.5rem, env(safe-area-inset-top))' }}
      >
        <div className="flex items-center gap-2">
          <span className="hidden sm:inline font-semibold text-sm truncate">🧑‍💻 Studio</span>
          {/* Selector de lenguaje */}
          <div className="flex items-center rounded-lg border border-zinc-700 overflow-hidden shrink-0">
            <button
              onClick={() => switchLang('py')}
              className={`px-2 py-1 text-xs ${lang === 'py' ? 'bg-indigo-600 text-white' : 'hover:bg-zinc-800 text-zinc-300'}`}
            >
              🐍 Python
            </button>
            <button
              onClick={() => switchLang('html')}
              className={`px-2 py-1 text-xs border-l border-zinc-700 ${lang === 'html' ? 'bg-indigo-600 text-white' : 'hover:bg-zinc-800 text-zinc-300'}`}
            >
              🌐 HTML
            </button>
            <button
              onClick={() => switchLang('js')}
              className={`px-2 py-1 text-xs border-l border-zinc-700 ${lang === 'js' ? 'bg-indigo-600 text-white' : 'hover:bg-zinc-800 text-zinc-300'}`}
            >
              🟨 JS
            </button>
          </div>
          <button
            onClick={run}
            disabled={running}
            className="text-xs px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-60 font-medium shrink-0"
          >
            {running ? '⏳ Ejecutando…' : lang === 'html' ? '▶️ Ver' : '▶️ Ejecutar'}
          </button>
          {lang === 'py' && (
            <button
              onClick={runWindow}
              disabled={guiBusy}
              title="Para programas con ventana (pygame, tkinter, turtle): ábrelos y velos en vivo aquí"
              className="text-xs px-3 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-500 disabled:opacity-60 font-medium shrink-0"
            >
              {guiBusy ? '⏳ Abriendo…' : '🪟 Ventana'}
            </button>
          )}
          <span className="hidden md:inline text-[11px] text-zinc-500">Ctrl+Enter</span>
          <button
            onClick={onClose}
            className="ml-auto text-xs px-2.5 py-1.5 rounded-lg border border-zinc-700 hover:bg-zinc-800 shrink-0"
          >
            ✕ Cerrar
          </button>
        </div>

        {/* Fila de herramientas */}
        <div className="flex flex-wrap items-center gap-1.5 text-xs">
          <select
            value=""
            onChange={(e) => {
              const list = lang === 'html' ? HTML_EXAMPLES : lang === 'js' ? JS_EXAMPLES : EXAMPLES
              const ex = list.find((x) => x.label === e.target.value)
              if (ex) loadExample(ex)
            }}
            className="rounded-lg bg-zinc-800 border border-zinc-700 px-2 py-1.5 outline-none max-w-[9rem]"
            title="Cargar un ejemplo listo"
          >
            <option value="">📚 Ejemplos…</option>
            {(lang === 'html' ? HTML_EXAMPLES : lang === 'js' ? JS_EXAMPLES : EXAMPLES).map((ex) => (
              <option key={ex.label} value={ex.label}>
                {ex.label}
                {'win' in ex && (ex as any).win ? ' 🪟' : ''}
              </option>
            ))}
          </select>
          <button onClick={saveSnippet} className="px-2 py-1.5 rounded-lg border border-zinc-700 hover:bg-zinc-800" title="Guardar este código">
            💾 Guardar
          </button>
          {snippets.length > 0 && (
            <select
              value=""
              onChange={(e) => e.target.value && openSnippet(e.target.value)}
              className="rounded-lg bg-zinc-800 border border-zinc-700 px-2 py-1.5 outline-none max-w-[8rem]"
              title="Abrir un código guardado"
            >
              <option value="">📂 Abrir…</option>
              {snippets.map((s) => (
                <option key={s.name} value={s.name}>
                  {s.name}
                </option>
              ))}
            </select>
          )}
          <button
            onClick={aiComplete}
            disabled={completing}
            className="px-2 py-1.5 rounded-lg border border-indigo-500 text-indigo-200 hover:bg-indigo-600/25 disabled:opacity-50"
            title="Autocompletar con IA desde el cursor (Alt+I)"
          >
            {completing ? '✨ …' : '✨ Completar'}
          </button>
          <button
            onClick={() => viewRef.current && openSearchPanel(viewRef.current)}
            className="px-2 py-1.5 rounded-lg border border-zinc-700 hover:bg-zinc-800"
            title="Buscar y reemplazar (Ctrl+F)"
          >
            🔎 Buscar
          </button>
          <button onClick={loadLibs} className="px-2 py-1.5 rounded-lg border border-zinc-700 hover:bg-zinc-800" title="Ver librerías instaladas">
            📚 Librerías
          </button>
          <button onClick={downloadPy} className="px-2 py-1.5 rounded-lg border border-zinc-700 hover:bg-zinc-800" title="Descargar como .py">
            ⬇️ .py
          </button>
          <button
            onClick={() => setStdinOn((v) => !v)}
            className={`px-2 py-1.5 rounded-lg border ${stdinOn ? 'bg-indigo-600 border-indigo-600' : 'border-zinc-700 hover:bg-zinc-800'}`}
            title="Entrada para programas con input()"
          >
            ⌨️ Entrada
          </button>
          <div className="flex items-center rounded-lg border border-zinc-700 overflow-hidden">
            <button onClick={() => setFontSize((f) => Math.max(10, f - 1))} className="px-2 py-1.5 hover:bg-zinc-800" title="Letra más pequeña">A-</button>
            <button onClick={() => setFontSize((f) => Math.min(26, f + 1))} className="px-2 py-1.5 hover:bg-zinc-800 border-l border-zinc-700" title="Letra más grande">A+</button>
          </div>
          <button
            onClick={() => setWrap((w) => !w)}
            className={`px-2 py-1.5 rounded-lg border ${wrap ? 'bg-indigo-600 border-indigo-600' : 'border-zinc-700 hover:bg-zinc-800'}`}
            title="Ajustar líneas largas"
          >
            ↩ Ajuste
          </button>
        </div>

        <div className="flex items-center gap-1.5">
          <input
            value={pkg}
            onChange={(e) => setPkg(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && install()}
            placeholder="📦 instalar librería (ej: rich, seaborn)…"
            className="flex-1 sm:max-w-xs rounded-lg bg-zinc-800 border border-zinc-700 px-2.5 py-1.5 text-xs outline-none"
          />
          <button
            onClick={install}
            disabled={installing}
            className="text-xs px-3 py-1.5 rounded-lg border border-zinc-700 hover:bg-zinc-800 disabled:opacity-60 shrink-0"
          >
            {installing ? 'Instalando…' : 'Instalar'}
          </button>
        </div>
      </div>

      {/* Cuerpo: editor arriba, panel abajo */}
      <div className="flex-1 min-h-0 flex flex-col">
        <div className={panelSize === 'max' ? 'hidden' : 'flex-1 min-h-0 overflow-auto'}>
          <CodeMirror
            value={code}
            onChange={setCode}
            onCreateEditor={(v) => { viewRef.current = v }}
            theme={oneDark}
            extensions={[
              lang === 'html' ? html() : lang === 'js' ? javascript() : python(),
              lang === 'py' ? PY_AUTOCOMPLETE : HTML_AUTOCOMPLETE,
              search({ top: true }),
              keymap.of([
                ...searchKeymap,
                indentWithTab,
                { key: 'Mod-/', run: toggleComment },
                { key: 'Alt-i', run: () => { aiComplete(); return true } },
              ]),
              ...(wrap ? [EditorView.lineWrapping] : []),
            ]}
            height="100%"
            style={{ height: '100%', fontSize }}
            basicSetup={{ lineNumbers: true, highlightActiveLine: true, tabSize: 4, autocompletion: false }}
          />
        </div>

        {stdinOn && panelSize !== 'max' && (
          <div className="shrink-0 border-t border-zinc-800 bg-zinc-900 px-3 py-2">
            <label className="text-[11px] text-zinc-400">
              ⌨️ Entrada — una línea por cada <code>input()</code> que pida el programa:
            </label>
            <textarea
              value={stdinText}
              onChange={(e) => setStdinText(e.target.value)}
              rows={2}
              placeholder={'Yuki\n15'}
              className="w-full mt-1 rounded-lg bg-zinc-800 border border-zinc-700 px-2.5 py-1.5 text-xs outline-none resize-y font-mono"
            />
          </div>
        )}

        {/* Panel inferior (minimizable / maximizable) */}
        <div
          className={`border-t border-zinc-800 bg-zinc-900 flex flex-col ${
            panelSize === 'min'
              ? 'shrink-0'
              : panelSize === 'max'
                ? 'flex-1 min-h-0'
                : 'shrink-0 h-[42%] min-h-[180px]'
          }`}
          style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
        >
          <div className="flex items-center gap-1 px-2 h-9 border-b border-zinc-800 shrink-0">
            <button
              onClick={() => {
                setTab('term')
                if (panelSize === 'min') setPanelSize('normal')
              }}
              className={`text-xs px-3 py-1 rounded-md ${tab === 'term' ? 'bg-zinc-800' : 'text-zinc-400 hover:text-zinc-200'}`}
            >
              💻 Terminal
            </button>
            <button
              onClick={() => {
                setTab('ai')
                if (panelSize === 'min') setPanelSize('normal')
              }}
              className={`text-xs px-3 py-1 rounded-md ${tab === 'ai' ? 'bg-zinc-800' : 'text-zinc-400 hover:text-zinc-200'}`}
            >
              🤖 Ayuda IA
            </button>
            {/* Controles minimizar / maximizar */}
            <div className="ml-auto flex items-center gap-0.5">
              <button
                onClick={() => setPanelSize('min')}
                className={`px-2 py-0.5 rounded text-zinc-400 hover:bg-zinc-800 hover:text-zinc-200 ${panelSize === 'min' ? 'bg-zinc-800 text-zinc-200' : ''}`}
                title="Minimizar"
              >
                🗕
              </button>
              <button
                onClick={() => setPanelSize('normal')}
                className={`px-2 py-0.5 rounded text-zinc-400 hover:bg-zinc-800 hover:text-zinc-200 ${panelSize === 'normal' ? 'bg-zinc-800 text-zinc-200' : ''}`}
                title="Tamaño normal"
              >
                🗗
              </button>
              <button
                onClick={() => setPanelSize('max')}
                className={`px-2 py-0.5 rounded text-zinc-400 hover:bg-zinc-800 hover:text-zinc-200 ${panelSize === 'max' ? 'bg-zinc-800 text-zinc-200' : ''}`}
                title="Maximizar"
              >
                🗖
              </button>
            </div>
          </div>

          {panelSize !== 'min' && tab === 'ai' && (
            <div className="flex-1 min-h-0 flex flex-col">
              <div className="flex items-center gap-1.5 p-2 border-b border-zinc-800 shrink-0 overflow-x-auto">
                {([
                  ['🧐 Explica', 'Explica qué hace este código, paso a paso, en español.'],
                  ['🐞 Arregla', 'Encuentra por qué falla o qué está mal y devuélveme el código corregido completo.'],
                  ['💬 Comenta', 'Añade comentarios claros y devuélveme el código completo.'],
                  ['✨ Mejora', 'Mejora el código (más claro, corto y eficiente) y devuélvemelo completo.'],
                  ['⚡ Optimiza', 'Optimiza el rendimiento y explica brevemente los cambios.'],
                  ['🧪 Tests', 'Escribe pruebas para este código.'],
                  ...(lang === 'py' ? [['🔁 A JavaScript', 'Traduce este código a JavaScript equivalente.']] : []),
                  ...(lang === 'js' ? [['🔁 A Python', 'Traduce este código a Python equivalente.']] : []),
                ] as [string, string][]).map(([label, q]) => (
                  <button
                    key={label}
                    onClick={() => ask(q)}
                    disabled={aiBusy}
                    className="text-[11px] whitespace-nowrap px-2 py-1 rounded-full border border-zinc-700 hover:bg-zinc-800 disabled:opacity-50 shrink-0"
                  >
                    {label}
                  </button>
                ))}
                <span className="flex-1" />
                {models.length > 0 && (
                  <select
                    value={aiModel}
                    onChange={(e) => setAiModel(e.target.value)}
                    title="Modelo de IA que usa el asistente"
                    className="text-[11px] bg-zinc-800 border border-zinc-700 rounded-md px-1 py-0.5 shrink-0 max-w-[120px] outline-none"
                  >
                    {models.map((m) => (
                      <option key={m.name} value={m.name}>{m.name}</option>
                    ))}
                  </select>
                )}
                {aiMsgs.length > 0 && (
                  <button
                    onClick={clearAi}
                    className="text-[11px] whitespace-nowrap px-2 py-1 rounded-full text-zinc-400 hover:text-zinc-200 shrink-0"
                    title="Empezar de nuevo"
                  >
                    🗑 Nuevo
                  </button>
                )}
              </div>

              <div className="flex-1 min-h-0 overflow-auto px-3 py-2 text-xs space-y-3">
                {aiMsgs.length === 0 && (
                  <p className="text-zinc-500">
                    La IA ve tu código (y el último error) para ayudarte. Pregúntale, usa los botones de arriba,
                    o <b>selecciona un trozo</b> del código para que se enfoque en él.
                  </p>
                )}
                {aiMsgs.map((mm, i) =>
                  mm.role === 'user' ? (
                    <div key={i} className="flex justify-end">
                      <div className="max-w-[85%] rounded-xl bg-indigo-600/90 text-white px-3 py-1.5 whitespace-pre-wrap break-words">
                        {mm.content}
                      </div>
                    </div>
                  ) : (
                    <div key={i} className="space-y-2">
                      {mm.content === '' && aiBusy ? (
                        <p className="text-zinc-400">🤖 Pensando…</p>
                      ) : (
                        parseAiSegments(mm.content).map((seg, j) =>
                          seg.type === 'text' ? (
                            seg.content.trim() && (
                              <p key={j} className="whitespace-pre-wrap break-words text-zinc-200 leading-relaxed">
                                {seg.content.trim()}
                              </p>
                            )
                          ) : (
                            <div key={j} className="rounded-lg border border-zinc-700 overflow-hidden">
                              <div className="flex items-center gap-1 bg-zinc-800/70 px-2 py-1">
                                <span className="text-[10px] text-zinc-400 mr-auto">{seg.lang || 'código'}</span>
                                <button onClick={() => navigator.clipboard?.writeText(seg.content)} className="text-[10px] px-1.5 py-0.5 rounded hover:bg-zinc-700" title="Copiar">📋 Copiar</button>
                                <button onClick={() => insertAtCursor(seg.content)} className="text-[10px] px-1.5 py-0.5 rounded hover:bg-zinc-700" title="Insertar en el cursor">➕ Insertar</button>
                                <button onClick={() => replaceAllCode(seg.content)} className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-700 hover:bg-emerald-600" title="Reemplazar todo el editor">⬇️ Usar</button>
                              </div>
                              <pre className="whitespace-pre-wrap break-words text-zinc-100 p-2 font-mono text-[11px] leading-relaxed">{seg.content}</pre>
                            </div>
                          ),
                        )
                      )}
                    </div>
                  ),
                )}
              </div>

              <div className="flex gap-1.5 p-2 border-t border-zinc-800 shrink-0">
                <input
                  value={aiQ}
                  onChange={(e) => setAiQ(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && aiQ.trim() && !aiBusy) {
                      ask(aiQ.trim())
                      setAiQ('')
                    }
                  }}
                  placeholder={aiBusy ? 'La IA está respondiendo…' : 'Pregúntale a la IA (o pídele que genere código)…'}
                  className="flex-1 rounded-lg bg-zinc-800 border border-zinc-700 px-2.5 py-1.5 text-xs outline-none"
                />
                {aiBusy ? (
                  <button
                    onClick={stopAi}
                    className="text-xs px-3 py-1.5 rounded-lg bg-red-600 hover:bg-red-500"
                  >
                    ⏹ Detener
                  </button>
                ) : (
                  <button
                    onClick={() => {
                      if (aiQ.trim()) {
                        ask(aiQ.trim())
                        setAiQ('')
                      }
                    }}
                    className="text-xs px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 disabled:opacity-60"
                  >
                    Preguntar
                  </button>
                )}
              </div>
            </div>
          )}
          {panelSize !== 'min' && tab === 'term' && htmlPreview && (
            <div className="flex-1 min-h-0 flex flex-col">
              <div className="flex items-center gap-2 px-2 py-1.5 border-b border-zinc-800 shrink-0 text-[11px]">
                <span className="text-sky-400">🌐 Vista previa</span>
                <span className="text-zinc-500 hidden sm:inline">— toca 🗖 para pantalla completa</span>
                <button
                  onClick={() => setTermLog((l) => l.filter((e) => e.kind !== 'html'))}
                  className="ml-auto px-2 py-0.5 rounded border border-zinc-700 hover:bg-zinc-800"
                >
                  ✖ Cerrar vista
                </button>
              </div>
              <iframe
                title="vista-previa"
                srcDoc={htmlPreview.out}
                sandbox="allow-scripts allow-modals allow-pointer-lock allow-forms"
                className="flex-1 w-full bg-white border-0"
              />
            </div>
          )}
          {panelSize !== 'min' && tab === 'term' && !htmlPreview && (
            <div className="flex-1 min-h-0 flex flex-col">
              <div className="flex items-center gap-1 px-2 py-1.5 border-b border-zinc-800 shrink-0 text-[11px]">
                <button
                  onClick={() => {
                    setTermMode('py')
                    setTermMore(false)
                    setTermCmd('')
                  }}
                  className={`px-2 py-0.5 rounded ${termMode === 'py' ? 'bg-indigo-600 text-white' : 'text-zinc-400 hover:text-zinc-200'}`}
                >
                  🐍 Python
                </button>
                <button
                  onClick={() => {
                    setTermMode('cmd')
                    setTermMore(false)
                    setTermCmd('')
                  }}
                  className={`px-2 py-0.5 rounded ${termMode === 'cmd' ? 'bg-indigo-600 text-white' : 'text-zinc-400 hover:text-zinc-200'}`}
                >
                  💻 Sistema
                </button>
                {termMode === 'py' && (
                  <button
                    onClick={() => {
                      replReset()
                      setTermMore(false)
                      setTermCmd('')
                    }}
                    className="ml-auto text-zinc-500 hover:text-zinc-300"
                    title="Reiniciar la consola (borra las variables)"
                  >
                    ↻ Reiniciar
                  </button>
                )}
              </div>
              <div className="flex-1 min-h-0 overflow-auto p-3 font-mono text-[11px] leading-relaxed">
                {guiErr && (
                  <pre className="whitespace-pre-wrap break-words text-red-400 mb-2">⚠️ {guiErr}</pre>
                )}
                {guiSid && (
                  <div className="mb-2 space-y-1.5">
                    <div className="flex items-center gap-2">
                      <span className="text-sky-400">🪟 Ventana en vivo (desde la PC)</span>
                      <button
                        onClick={stopWindow}
                        className="text-[11px] px-2 py-0.5 rounded border border-zinc-700 hover:bg-zinc-800"
                      >
                        ⏹ Detener
                      </button>
                    </div>
                    <img
                      src={`/sd/guistream?sid=${guiSid}`}
                      alt="ventana en vivo"
                      className="rounded-lg border border-zinc-700 bg-black max-w-full"
                    />
                  </div>
                )}
                {termLog.length === 0 && !guiSid && (
                  <p className="text-zinc-500">
                    Aquí aparece la salida. Pulsa <b>▶️ Ejecutar</b> para correr el código del editor, o escribe abajo:{' '}
                    {termMode === 'py' ? (
                      <><code>print("hola mundo")</code>, <code>x = 5</code>…</>
                    ) : (
                      <><code>dir</code>, <code>git status</code>…</>
                    )}
                  </p>
                )}
                {termLog.map((e, i) =>
                  e.kind === 'html' ? (
                    <div key={i} className="mb-2">
                      <div className="text-sky-400 mb-1">🌐 Vista previa</div>
                      <iframe
                        title={`preview-${i}`}
                        srcDoc={e.out}
                        sandbox="allow-scripts allow-modals allow-pointer-lock"
                        className="w-full h-80 rounded-lg border border-zinc-700 bg-white"
                      />
                    </div>
                  ) : e.kind === 'run' ? (
                    <div key={i} className="mb-2">
                      <div className="text-sky-400">▶ Ejecutado{e.ok ? '' : ' (con error)'}</div>
                      {e.out && (
                        <pre className="whitespace-pre-wrap break-words text-zinc-200">{e.out}</pre>
                      )}
                      {e.images?.map((im, j) => (
                        <img
                          key={j}
                          src={`data:image/png;base64,${im}`}
                          alt={`gráfica ${j + 1}`}
                          className="mt-1 rounded-lg border border-zinc-700 bg-white max-w-full"
                        />
                      ))}
                      {e.err && (
                        <pre className="whitespace-pre-wrap break-words text-red-400">{e.err}</pre>
                      )}
                      {!e.out && !e.err && !(e.images && e.images.length) && (
                        <span className="text-emerald-400">✓ sin salida de texto</span>
                      )}
                    </div>
                  ) : (
                    <div key={i} className="mb-1.5">
                      <div className="text-emerald-400 break-all whitespace-pre-wrap">
                        {e.kind === 'py' ? (e.cont ? '... ' : '>>> ') : '> '}
                        {e.cmd}
                      </div>
                      {e.out && (
                        <pre className={`whitespace-pre-wrap break-words ${e.ok ? 'text-zinc-300' : 'text-red-400'}`}>
                          {e.out}
                        </pre>
                      )}
                    </div>
                  ),
                )}
                {(termBusy || running) && <div className="text-sky-400">{pyStatus || '…'}</div>}
              </div>
              <div className="shrink-0 flex items-center gap-1.5 p-2 border-t border-zinc-800">
                <span className="text-[10px] text-sky-400 font-mono truncate max-w-[45%]" title={termMode === 'cmd' ? termCwd : 'Python'}>
                  {termMode === 'py'
                    ? termMore
                      ? '...'
                      : '>>>'
                    : `${(termCwd || 'proyecto').replace(/^.*[\\/]/, '') || termCwd}>`}
                </span>
                <input
                  value={termCmd}
                  onChange={(e) => setTermCmd(e.target.value)}
                  onKeyDown={handleTermKey}
                  placeholder={
                    termMode === 'py'
                      ? termMore
                        ? 'sigue el bloque (Enter en vacío = ejecutar)'
                        : 'código Python y Enter…'
                      : 'comando y Enter…'
                  }
                  spellCheck={false}
                  autoCapitalize="off"
                  autoCorrect="off"
                  className="flex-1 rounded-lg bg-zinc-800 border border-zinc-700 px-2.5 py-1.5 text-xs outline-none font-mono"
                />
                <button
                  onClick={runCmd}
                  disabled={termBusy}
                  className="text-xs px-3 py-1.5 rounded-lg border border-zinc-700 hover:bg-zinc-800 disabled:opacity-60"
                >
                  ▶
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {showLibs && (
        <div
          className="fixed inset-0 z-[60] flex items-center justify-center bg-black/60 p-4"
          onClick={() => setShowLibs(false)}
        >
          <div
            className="w-full max-w-md max-h-[80vh] flex flex-col rounded-2xl border border-zinc-700 bg-zinc-900 shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between px-4 h-12 border-b border-zinc-800 shrink-0">
              <h3 className="font-semibold text-sm">
                📚 Librerías{pyVer ? ` · Python ${pyVer}` : ''}
              </h3>
              <button onClick={() => setShowLibs(false)} className="p-1.5 rounded-lg hover:bg-zinc-800">
                ✕
              </button>
            </div>
            <div className="p-3 shrink-0">
              <input
                value={libFilter}
                onChange={(e) => setLibFilter(e.target.value)}
                placeholder="🔎 Buscar librería…"
                className="w-full rounded-lg bg-zinc-800 border border-zinc-700 px-2.5 py-1.5 text-xs outline-none"
              />
            </div>
            <div className="flex-1 min-h-0 overflow-auto px-3 pb-2 text-xs font-mono">
              {libs === null ? (
                <p className="text-zinc-500">Cargando…</p>
              ) : (
                (() => {
                  const f = libFilter.trim().toLowerCase()
                  const list = f ? libs.filter((l) => l.toLowerCase().includes(f)) : libs
                  return list.length ? (
                    list.map((l, i) => (
                      <div key={i} className="py-0.5 border-b border-zinc-800/50 text-zinc-300">
                        {l}
                      </div>
                    ))
                  ) : (
                    <p className="text-zinc-500">Sin resultados.</p>
                  )
                })()
              )}
            </div>
            <div className="px-3 py-2 border-t border-zinc-800 text-[11px] text-zinc-500 shrink-0">
              Instala más con 📦. Total: {libs ? libs.length : '…'}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
