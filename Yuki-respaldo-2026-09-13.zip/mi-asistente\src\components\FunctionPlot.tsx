import { useMemo } from 'react'
import { compileExpr } from '../lib/mathexpr'

interface Series {
  label?: string
  points: [number, number][]
}
interface Spec {
  title?: string
  xmin: number
  xmax: number
  funcs: { label: string; fn: (x: number) => number }[]
  series: Series[]
}

const COLORS = ['#6366f1', '#10b981', '#f59e0b', '#ef4444', '#0ea5e9', '#a855f7']

function parseSpec(raw: string): Spec | null {
  const src = raw.trim()
  let title: string | undefined
  let xmin = -10
  let xmax = 10
  const funcs: { label: string; fn: (x: number) => number }[] = []
  const series: Series[] = []

  // Intento 1: JSON
  if (src.startsWith('{')) {
    try {
      const j = JSON.parse(src)
      if (j.title) title = String(j.title)
      if (Number.isFinite(j.xmin)) xmin = j.xmin
      if (Number.isFinite(j.xmax)) xmax = j.xmax
      const fs: string[] = Array.isArray(j.functions)
        ? j.functions
        : j.function
          ? [j.function]
          : []
      for (const f of fs) {
        try {
          funcs.push({ label: String(f), fn: compileExpr(String(f)) })
        } catch {
          /* función inválida: ignorar */
        }
      }
      const ser = Array.isArray(j.series) ? j.series : []
      for (const s of ser) {
        const pts = (s.points || s.data || [])
          .map((p: any) => (Array.isArray(p) ? [Number(p[0]), Number(p[1])] : null))
          .filter((p: any) => p && Number.isFinite(p[0]) && Number.isFinite(p[1]))
        if (pts.length) series.push({ label: s.label, points: pts })
      }
      if (funcs.length || series.length) return { title, xmin, xmax, funcs, series }
    } catch {
      /* sigue con el formato por líneas */
    }
  }

  // Intento 2: por líneas (title:, x:, y=, data:)
  for (const line of src.split('\n')) {
    const l = line.trim()
    if (!l) continue
    let m: RegExpMatchArray | null
    if ((m = l.match(/^(?:title|t[íi]tulo)\s*:\s*(.+)$/i))) {
      title = m[1].trim()
    } else if (
      (m = l.match(/^x\s*:\s*(-?[\d.]+)\s*(?:\.\.|a|to|,|;)\s*(-?[\d.]+)/i))
    ) {
      xmin = parseFloat(m[1])
      xmax = parseFloat(m[2])
    } else if ((m = l.match(/^data\s*(?:\[(.+?)\])?\s*:\s*(.+)$/i))) {
      const pts: [number, number][] = []
      for (const pair of m[2].split(/\s+/)) {
        const [a, b] = pair.split(',').map(Number)
        if (Number.isFinite(a) && Number.isFinite(b)) pts.push([a, b])
      }
      if (pts.length) series.push({ label: m[1]?.trim(), points: pts })
    } else if ((m = l.match(/^(?:y|f\(x\))\s*=\s*(.+)$/i))) {
      try {
        funcs.push({ label: 'y=' + m[1].trim(), fn: compileExpr(m[1].trim()) })
      } catch {
        /* ignorar */
      }
    }
  }
  if (funcs.length || series.length) return { title, xmin, xmax, funcs, series }
  return null
}

export default function FunctionPlot({ code }: { code: string }) {
  const spec = useMemo(() => parseSpec(code), [code])

  if (!spec) {
    return (
      <pre className="text-xs overflow-x-auto rounded-lg bg-zinc-100 dark:bg-zinc-800 p-2 my-2 opacity-70">
        {code.trim()}
      </pre>
    )
  }

  const W = 480
  const H = 320
  const pad = 34
  let { xmin, xmax } = spec
  if (!(xmax > xmin)) {
    xmin = -10
    xmax = 10
  }
  const N = 240

  // Muestreo para el rango Y
  const ys: number[] = []
  const sampled = spec.funcs.map((f) => {
    const pts: (number | null)[] = []
    for (let i = 0; i <= N; i++) {
      const x = xmin + ((xmax - xmin) * i) / N
      const y = f.fn(x)
      if (Number.isFinite(y) && Math.abs(y) < 1e6) {
        pts.push(y)
        ys.push(y)
      } else pts.push(null)
    }
    return pts
  })
  for (const s of spec.series) for (const [, y] of s.points) ys.push(y)

  let ymin = ys.length ? Math.min(...ys) : -10
  let ymax = ys.length ? Math.max(...ys) : 10
  if (ymin === ymax) {
    ymin -= 1
    ymax += 1
  }
  const padY = (ymax - ymin) * 0.08
  ymin -= padY
  ymax += padY

  const px = (x: number) => pad + ((x - xmin) / (xmax - xmin)) * (W - 2 * pad)
  const py = (y: number) => H - pad - ((y - ymin) / (ymax - ymin)) * (H - 2 * pad)

  // Líneas de cuadrícula "bonitas"
  function ticks(a: number, b: number, count = 6): number[] {
    const span = b - a
    const step0 = span / count
    const mag = Math.pow(10, Math.floor(Math.log10(step0)))
    const norm = step0 / mag
    const step = (norm >= 5 ? 5 : norm >= 2 ? 2 : 1) * mag
    const start = Math.ceil(a / step) * step
    const out: number[] = []
    for (let v = start; v <= b + 1e-9; v += step) out.push(Math.round(v / step) * step)
    return out
  }
  const xticks = ticks(xmin, xmax)
  const yticks = ticks(ymin, ymax)

  // Construye el path de una función partiéndolo en saltos/asíntotas
  function pathFor(pts: (number | null)[]): string {
    let d = ''
    let penDown = false
    let prevPy = 0
    for (let i = 0; i <= N; i++) {
      const y = pts[i]
      const x = xmin + ((xmax - xmin) * i) / N
      if (y === null) {
        penDown = false
        continue
      }
      const X = px(x)
      const Y = py(y)
      if (!penDown || Math.abs(Y - prevPy) > H) {
        d += `M ${X.toFixed(1)} ${Y.toFixed(1)} `
        penDown = true
      } else {
        d += `L ${X.toFixed(1)} ${Y.toFixed(1)} `
      }
      prevPy = Y
    }
    return d
  }

  const axisY = ymin <= 0 && ymax >= 0 ? py(0) : null
  const axisX = xmin <= 0 && xmax >= 0 ? px(0) : null
  const legend = [
    ...spec.funcs.map((f) => f.label),
    ...spec.series.map((s, i) => s.label || `datos ${i + 1}`),
  ]

  return (
    <div className="my-2 rounded-xl border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-900/60 p-2 overflow-x-auto">
      {spec.title && (
        <p className="text-sm font-medium text-center mb-1">{spec.title}</p>
      )}
      <svg
        viewBox={`0 0 ${W} ${H}`}
        className="w-full max-w-full h-auto text-zinc-700 dark:text-zinc-300"
        style={{ minWidth: 320 }}
      >
        {/* cuadrícula */}
        {xticks.map((t, i) => (
          <line
            key={`gx${i}`}
            x1={px(t)}
            y1={pad}
            x2={px(t)}
            y2={H - pad}
            stroke="currentColor"
            strokeOpacity={0.1}
          />
        ))}
        {yticks.map((t, i) => (
          <line
            key={`gy${i}`}
            x1={pad}
            y1={py(t)}
            x2={W - pad}
            y2={py(t)}
            stroke="currentColor"
            strokeOpacity={0.1}
          />
        ))}
        {/* ejes */}
        {axisY !== null && (
          <line x1={pad} y1={axisY} x2={W - pad} y2={axisY} stroke="currentColor" strokeOpacity={0.5} />
        )}
        {axisX !== null && (
          <line x1={axisX} y1={pad} x2={axisX} y2={H - pad} stroke="currentColor" strokeOpacity={0.5} />
        )}
        {/* etiquetas de ejes */}
        {xticks.map((t, i) => (
          <text
            key={`tx${i}`}
            x={px(t)}
            y={H - pad + 12}
            fontSize={9}
            textAnchor="middle"
            fill="currentColor"
            fillOpacity={0.6}
          >
            {(+t.toFixed(2)).toString()}
          </text>
        ))}
        {yticks.map((t, i) => (
          <text
            key={`ty${i}`}
            x={pad - 4}
            y={py(t) + 3}
            fontSize={9}
            textAnchor="end"
            fill="currentColor"
            fillOpacity={0.6}
          >
            {(+t.toFixed(2)).toString()}
          </text>
        ))}
        {/* funciones */}
        {sampled.map((pts, i) => (
          <path
            key={`f${i}`}
            d={pathFor(pts)}
            fill="none"
            stroke={COLORS[i % COLORS.length]}
            strokeWidth={2}
          />
        ))}
        {/* series de datos */}
        {spec.series.map((s, si) => {
          const color = COLORS[(spec.funcs.length + si) % COLORS.length]
          const d = s.points
            .map((p, i) => `${i ? 'L' : 'M'} ${px(p[0]).toFixed(1)} ${py(p[1]).toFixed(1)}`)
            .join(' ')
          return (
            <g key={`s${si}`}>
              <path d={d} fill="none" stroke={color} strokeWidth={2} />
              {s.points.map((p, i) => (
                <circle key={i} cx={px(p[0])} cy={py(p[1])} r={2.5} fill={color} />
              ))}
            </g>
          )
        })}
      </svg>
      {legend.length > 0 && (
        <div className="flex flex-wrap justify-center gap-x-3 gap-y-1 mt-1">
          {legend.map((lbl, i) => (
            <span key={i} className="inline-flex items-center gap-1 text-[11px]">
              <span
                className="inline-block h-2 w-3 rounded-sm"
                style={{ background: COLORS[i % COLORS.length] }}
              />
              {lbl}
            </span>
          ))}
        </div>
      )}
    </div>
  )
}
