import { useState } from 'react'

interface Props {
  verify: (pass: string) => Promise<boolean>
  onUnlock: (pass: string) => void
}

/** Pantalla de contraseña compartida (cuando el asistente se comparte por internet). */
export default function AccessGate({ verify, onUnlock }: Props) {
  const [pass, setPass] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<'' | 'wrong' | 'net'>('')

  async function submit() {
    const p = pass.trim()
    if (!p) return
    setBusy(true)
    try {
      const ok = await verify(p)
      if (ok) onUnlock(p)
      else setError('wrong')
    } catch {
      setError('net')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="h-dvh flex flex-col items-center justify-center bg-zinc-50 dark:bg-zinc-950 text-zinc-900 dark:text-zinc-100 px-6">
      <div className="w-full max-w-sm text-center">
        <img
          src="/icon-192.png"
          alt="Yuki"
          className="h-16 w-16 mx-auto rounded-2xl object-cover mb-4 shadow-lg"
        />
        <h1 className="text-2xl font-semibold mb-1">Yuki · Acceso privado 🔒</h1>
        <p className="text-sm text-zinc-500 dark:text-zinc-400 mb-6">
          Escribe la contraseña que te compartieron para entrar.
        </p>
        <input
          type="password"
          autoFocus
          value={pass}
          onChange={(e) => {
            setPass(e.target.value)
            setError('')
          }}
          onKeyDown={(e) => e.key === 'Enter' && submit()}
          placeholder="Contraseña"
          className={`w-full text-center rounded-xl border px-4 py-3 bg-white dark:bg-zinc-900 outline-none ${
            error ? 'border-red-500' : 'border-zinc-300 dark:border-zinc-700'
          }`}
        />
        {error === 'wrong' && (
          <p className="text-sm text-red-500 mt-2">Contraseña incorrecta</p>
        )}
        {error === 'net' && (
          <p className="text-sm text-amber-500 mt-2">
            No me pude conectar. ¿La PC (con Yuki) está encendida?
          </p>
        )}
        <button
          onClick={submit}
          disabled={busy || !pass.trim()}
          className="mt-4 w-full rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white py-3 font-medium disabled:opacity-40"
        >
          Entrar
        </button>
      </div>
      <p className="mt-8 text-[11px] text-zinc-400">100% local · privado</p>
    </div>
  )
}
