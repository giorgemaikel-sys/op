import { useEffect, useState } from 'react'
import {
  verifyOwnerPassword,
  getSmtp,
  saveSmtp,
  testSmtp,
  listEmails,
  sendToFriends,
  type FriendEmail,
} from '../lib/profiles'
import { ownerKey } from '../lib/owner'

/** Sección de Ajustes SOLO para el dueño: se abre con la contraseña maestra.
 *  El desbloqueo es POR PERFIL (no se comparte entre perfiles del dispositivo). */
export default function OwnerSettings({ profileId }: { profileId: string }) {
  const OWNER_KEY = ownerKey(profileId)
  const cachedOwner = (): string => {
    try {
      return localStorage.getItem(OWNER_KEY) || ''
    } catch {
      return ''
    }
  }
  const [unlocked, setUnlocked] = useState(false)
  const [pass, setPass] = useState('')
  const [err, setErr] = useState('')

  const [smtp, setSmtp] = useState({
    host: '',
    port: 465,
    secure: true,
    user: '',
    pass: '',
    from: '',
  })
  const [smtpMsg, setSmtpMsg] = useState('')

  const [friends, setFriends] = useState<FriendEmail[]>([])
  const [subject, setSubject] = useState('')
  const [body, setBody] = useState('')
  const [sendMsg, setSendMsg] = useState('')

  useEffect(() => {
    const p = cachedOwner()
    if (p)
      verifyOwnerPassword(p).then((ok) => {
        if (ok) openPanel(p)
      })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  async function openPanel(p: string) {
    setUnlocked(true)
    try {
      localStorage.setItem(OWNER_KEY, p)
    } catch {
      /* ignore */
    }
    const info = await getSmtp(p)
    if (info)
      setSmtp((s) => ({
        ...s,
        host: info.host || s.host,
        port: info.port || s.port,
        secure: info.secure,
        user: info.user,
        from: info.from,
        pass: '',
      }))
    listEmails(p).then(setFriends)
  }

  async function unlock() {
    const p = pass.trim()
    if (!p) return
    const ok = await verifyOwnerPassword(p)
    if (ok) {
      setErr('')
      setPass('')
      openPanel(p)
    } else setErr('Contraseña incorrecta')
  }

  function lock() {
    try {
      localStorage.removeItem(OWNER_KEY)
    } catch {
      /* ignore */
    }
    setUnlocked(false)
  }

  async function saveSmtpCfg() {
    setSmtpMsg('Guardando…')
    const r = await saveSmtp(smtp, cachedOwner())
    setSmtpMsg(r.ok ? '✓ Guardado' : r.error || 'Error')
  }

  async function testCfg() {
    setSmtpMsg('Enviando prueba…')
    const r = await testSmtp(cachedOwner())
    setSmtpMsg(
      r.ok
        ? '✓ Enviado. Revisa tu correo (y la carpeta de Spam).'
        : r.error || 'Error',
    )
  }

  async function sendAll() {
    const to = friends.map((f) => f.email)
    if (!to.length) {
      setSendMsg('No hay correos de amigos todavía.')
      return
    }
    if (!subject.trim() && !body.trim()) {
      setSendMsg('Escribe un asunto o mensaje.')
      return
    }
    setSendMsg('Enviando…')
    const r = await sendToFriends(to, subject.trim() || '(sin asunto)', body, cachedOwner())
    if (r.ok) {
      setSendMsg(`✓ Enviado a ${r.sent} amigo(s)${r.failed ? `, ${r.failed} fallaron` : ''}.`)
      setSubject('')
      setBody('')
    } else setSendMsg(r.error || 'Error')
  }

  const inputCls =
    'w-full rounded-lg border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-900 px-3 py-2 text-sm outline-none'

  if (!unlocked) {
    return (
      <div className="space-y-2">
        <p className="text-xs text-zinc-400">
          Estas opciones son solo para el dueño. Escribe la contraseña de
          administrador para abrirlas.
        </p>
        <div className="flex gap-2">
          <input
            type="password"
            value={pass}
            onChange={(e) => {
              setPass(e.target.value)
              setErr('')
            }}
            onKeyDown={(e) => e.key === 'Enter' && unlock()}
            placeholder="Contraseña de administrador"
            className={inputCls}
          />
          <button
            onClick={unlock}
            className="text-sm px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white shrink-0"
          >
            Entrar
          </button>
        </div>
        {err && <p className="text-xs text-red-500">{err}</p>}
      </div>
    )
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <p className="text-xs text-emerald-600 dark:text-emerald-400">
          ✓ Modo administrador activo
        </p>
        <button onClick={lock} className="text-xs text-zinc-400 hover:text-zinc-600">
          Salir
        </button>
      </div>

      {/* SMTP */}
      <div className="space-y-2">
        <label className="text-sm font-medium">📤 Enviar correos</label>
        <p className="text-xs text-zinc-400">
          Con Gmail: servidor <code>smtp.gmail.com</code>, puerto <code>465</code>{' '}
          (seguro), tu correo, y una <b>contraseña de aplicación</b>.
        </p>
        <div className="grid grid-cols-2 gap-2">
          <input
            value={smtp.host}
            onChange={(e) => setSmtp({ ...smtp, host: e.target.value })}
            placeholder="smtp.gmail.com"
            className={inputCls}
          />
          <input
            type="number"
            value={smtp.port}
            onChange={(e) => setSmtp({ ...smtp, port: Number(e.target.value) })}
            placeholder="Puerto"
            className={inputCls}
          />
        </div>
        <input
          value={smtp.user}
          onChange={(e) => setSmtp({ ...smtp, user: e.target.value })}
          placeholder="Tu correo (usuario)"
          className={inputCls}
        />
        <input
          type="password"
          value={smtp.pass}
          onChange={(e) => setSmtp({ ...smtp, pass: e.target.value })}
          placeholder="Contraseña de aplicación (vacío = no cambiar)"
          className={inputCls}
        />
        <input
          value={smtp.from}
          onChange={(e) => setSmtp({ ...smtp, from: e.target.value })}
          placeholder="Remitente, ej: Tu Nombre <tucorreo@gmail.com>"
          className={inputCls}
        />
        <label className="flex items-center gap-2 text-xs">
          <input
            type="checkbox"
            checked={smtp.secure}
            onChange={(e) => setSmtp({ ...smtp, secure: e.target.checked })}
            className="accent-indigo-600"
          />
          Conexión segura (SSL, puerto 465)
        </label>
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={saveSmtpCfg}
            className="text-sm px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white"
          >
            Guardar correo
          </button>
          <button
            onClick={testCfg}
            className="text-sm px-3 py-1.5 rounded-lg border border-zinc-300 dark:border-zinc-700"
          >
            ✉️ Enviar prueba
          </button>
          {smtpMsg && <span className="text-xs text-zinc-500">{smtpMsg}</span>}
        </div>
      </div>

      {/* Escribir a los amigos */}
      <div className="space-y-2 border-t border-zinc-200 dark:border-zinc-800 pt-3">
        <label className="text-sm font-medium">✉️ Escribir a mis amigos</label>
        <p className="text-xs text-zinc-400">
          {friends.length
            ? `Se enviará a ${friends.length} amigo(s) con correo.`
            : 'Aún no hay amigos con correo.'}
        </p>
        <input
          value={subject}
          onChange={(e) => setSubject(e.target.value)}
          placeholder="Asunto"
          className={inputCls}
        />
        <textarea
          value={body}
          onChange={(e) => setBody(e.target.value)}
          placeholder="Tu mensaje…"
          rows={4}
          className={inputCls + ' resize-y'}
        />
        <div className="flex items-center gap-2">
          <button
            onClick={sendAll}
            className="text-sm px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white"
          >
            Enviar a todos
          </button>
          {sendMsg && <span className="text-xs text-zinc-500">{sendMsg}</span>}
        </div>
      </div>

      {/* Lista de correos */}
      {friends.length > 0 && (
        <div className="space-y-1 border-t border-zinc-200 dark:border-zinc-800 pt-3">
          <label className="text-sm font-medium">📇 Correos de amigos</label>
          <ul className="text-xs text-zinc-500 space-y-0.5">
            {friends.map((f, i) => (
              <li key={i}>
                {f.avatar || '🙂'} {f.name} — {f.email}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  )
}
