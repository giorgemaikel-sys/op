import { useEffect, useRef, useState } from 'react'
import type { WallPost } from '../lib/types'
import { listWall, postWall, clearWall, reactWall, replyWall } from '../lib/wall'
import { complete } from '../lib/ollama'
import { useOwner } from '../lib/owner'

interface Props {
  authorName: string
  authorAvatar: string
  model: string
  onClose: () => void
}

const EMOJI_STICKERS = ['👍', '❤️', '😂', '🔥', '🎉', '😎', '🙌', '😢', '🤔', '👀', '💯', '🥳', '😴', '🤯', '👏', '🍕']
const ANIM_STICKERS = ['spin:🎉', 'bounce:⚽', 'beat:❤️', 'shake:😂', 'spin:⭐', 'bounce:🐸', 'beat:🥳', 'shake:🤪']
const REACTS = ['👍', '❤️', '😂', '🔥', '🎉', '😮', '😢']

function StickerView({ s, size = 46 }: { s: string; size?: number }) {
  const m = s.match(/^(spin|bounce|beat|shake):(.+)$/)
  if (!m) return <span style={{ fontSize: size, lineHeight: 1 }}>{s}</span>
  const type = m[1]
  const emoji = m[2]
  return (
    <svg viewBox="0 0 60 60" width={size} height={size} style={{ overflow: 'visible' }}>
      <style>{`
        .stk{transform-origin:30px 34px}
        .spin{animation:stkspin 1.6s linear infinite}
        .bounce{animation:stkbounce .8s ease-in-out infinite}
        .beat{animation:stkbeat .7s ease-in-out infinite}
        .shake{animation:stkshake .5s ease-in-out infinite}
        @keyframes stkspin{to{transform:rotate(360deg)}}
        @keyframes stkbounce{0%,100%{transform:translateY(0)}50%{transform:translateY(-8px)}}
        @keyframes stkbeat{0%,100%{transform:scale(1)}50%{transform:scale(1.25)}}
        @keyframes stkshake{0%,100%{transform:rotate(-12deg)}50%{transform:rotate(12deg)}}
      `}</style>
      <text className={`stk ${type}`} x="30" y="44" fontSize="34" textAnchor="middle">
        {emoji}
      </text>
    </svg>
  )
}

function timeAgo(ts: number): string {
  const s = Math.floor((Date.now() - ts) / 1000)
  if (s < 60) return 'ahora'
  if (s < 3600) return `hace ${Math.floor(s / 60)} min`
  if (s < 86400) return `hace ${Math.floor(s / 3600)} h`
  return new Date(ts).toLocaleDateString('es-ES')
}

export default function Wall({ authorName, authorAvatar, model, onClose }: Props) {
  const { ownerPass } = useOwner()
  const [posts, setPosts] = useState<WallPost[]>([])
  const [text, setText] = useState('')
  const [showStickers, setShowStickers] = useState(false)
  const [aiBusy, setAiBusy] = useState(false)
  const [pickerFor, setPickerFor] = useState<string | null>(null)
  const [replyFor, setReplyFor] = useState<string | null>(null)
  const [replyText, setReplyText] = useState('')
  const listRef = useRef<HTMLDivElement>(null)

  async function refresh() {
    setPosts(await listWall())
  }

  async function react(id: string, emoji: string) {
    setPickerFor(null)
    // pinta al instante (optimista) y luego confirma con el servidor
    setPosts((ps) =>
      ps.map((p) => {
        if (p.id !== id) return p
        const reactions = { ...(p.reactions || {}) }
        const list = [...(reactions[emoji] || [])]
        const i = list.indexOf(authorName)
        if (i >= 0) list.splice(i, 1)
        else list.push(authorName)
        if (list.length) reactions[emoji] = list
        else delete reactions[emoji]
        return { ...p, reactions }
      }),
    )
    await reactWall(id, emoji, authorName)
  }

  async function doReply(id: string) {
    const t = replyText.trim()
    if (!t) return
    setReplyText('')
    setReplyFor(null)
    await replyWall(id, { author: authorName, avatar: authorAvatar, text: t })
    await refresh()
  }

  useEffect(() => {
    refresh()
    const t = setInterval(refresh, 4000)
    return () => clearInterval(t)
  }, [])

  useEffect(() => {
    // auto-scroll al final cuando llegan posts
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight })
  }, [posts.length])

  async function send(sticker?: string) {
    const t = text.trim()
    if (!t && !sticker) return
    setText('')
    setShowStickers(false)
    await postWall({ author: authorName, avatar: authorAvatar, text: sticker ? '' : t, sticker })
    await refresh()
  }

  async function askAI() {
    setAiBusy(true)
    try {
      const recent = posts
        .slice(-8)
        .map((p) => `${p.ai ? 'IA' : p.author}: ${p.sticker ? '(sticker)' : p.text}`)
        .join('\n')
      const reply = await complete({
        model,
        system:
          'Eres un miembro simpático, cercano y con humor de un grupo de amigos en un muro de mensajes. Responde MUY breve (1-2 frases), en español, reaccionando al último mensaje. Nada de listas ni formalidades.',
        prompt: `Muro reciente:\n${recent}\n\nEscribe tu respuesta al grupo:`,
      })
      const clean = (reply || '').trim().slice(0, 500)
      if (clean) await postWall({ author: 'Asistente', avatar: '🤖', text: clean, ai: true })
      await refresh()
    } catch {
      /* ignore */
    } finally {
      setAiBusy(false)
    }
  }

  async function clearAll() {
    const pass = ownerPass || ''
    if (!pass) {
      alert('Solo el administrador puede vaciar el muro (entra como admin en Ajustes).')
      return
    }
    if (!confirm('¿Vaciar todo el muro?')) return
    const ok = await clearWall(pass)
    if (ok) refresh()
    else alert('No se pudo (¿eres el administrador?).')
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 sm:p-4" onClick={onClose}>
      <div
        className="w-full sm:max-w-lg h-dvh sm:h-[85vh] flex flex-col bg-white dark:bg-zinc-900 sm:rounded-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-4 py-3 border-b border-zinc-200 dark:border-zinc-800">
          <h2 className="font-semibold flex items-center gap-2">
            <img src="/forum.png" alt="" className="h-7 w-7 object-contain" />
            Muro de amigos
          </h2>
          <div className="flex items-center gap-1">
            <button onClick={clearAll} className="text-xs text-zinc-400 hover:text-red-500 px-2 py-1" title="Vaciar (admin)">
              🗑️
            </button>
            <button onClick={onClose} className="text-zinc-400 hover:text-zinc-600 text-xl leading-none px-2">
              ✕
            </button>
          </div>
        </div>

        <div ref={listRef} className="flex-1 overflow-y-auto p-3 space-y-3">
          {posts.length === 0 && (
            <p className="text-center text-sm text-zinc-400 mt-8">
              Aún no hay mensajes. ¡Escribe el primero! 👋
            </p>
          )}
          {posts.map((p) => (
            <div key={p.id} className="flex gap-2">
              <div className="text-2xl shrink-0">{p.ai ? '🤖' : p.avatar || '🙂'}</div>
              <div className="min-w-0">
                <div className="flex items-baseline gap-2">
                  <span className={`text-sm font-medium ${p.ai ? 'text-indigo-500' : ''}`}>
                    {p.ai ? 'Asistente' : p.author}
                  </span>
                  <span className="text-[10px] text-zinc-400">{timeAgo(p.createdAt)}</span>
                </div>
                {p.sticker ? (
                  <StickerView s={p.sticker} />
                ) : (
                  <p className="text-sm whitespace-pre-wrap break-words">{p.text}</p>
                )}

                {/* Reacciones */}
                <div className="flex flex-wrap items-center gap-1 mt-1">
                  {p.reactions &&
                    Object.entries(p.reactions).map(([em, names]) => (
                      <button
                        key={em}
                        onClick={() => react(p.id, em)}
                        title={names.join(', ')}
                        className={`text-[11px] px-1.5 py-0.5 rounded-full border transition-colors ${
                          names.includes(authorName)
                            ? 'border-indigo-500 bg-indigo-500/10 text-indigo-500'
                            : 'border-zinc-300 dark:border-zinc-700 text-zinc-500'
                        }`}
                      >
                        {em} {names.length}
                      </button>
                    ))}
                  <div className="relative">
                    <button
                      onClick={() => setPickerFor(pickerFor === p.id ? null : p.id)}
                      className="text-[11px] px-1.5 py-0.5 rounded-full text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-300"
                      title="Reaccionar"
                    >
                      ＋😊
                    </button>
                    {pickerFor === p.id && (
                      <div className="absolute z-10 mt-1 flex gap-1 rounded-lg border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-900 p-1 shadow-lg">
                        {REACTS.map((em) => (
                          <button
                            key={em}
                            onClick={() => react(p.id, em)}
                            className="text-lg hover:scale-125 transition-transform"
                          >
                            {em}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                  <button
                    onClick={() => {
                      setReplyFor(replyFor === p.id ? null : p.id)
                      setReplyText('')
                    }}
                    className="text-[11px] text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-300 ml-1"
                  >
                    💬 Responder
                  </button>
                </div>

                {/* Respuestas */}
                {p.replies && p.replies.length > 0 && (
                  <div className="mt-1 space-y-0.5 border-l-2 border-zinc-200 dark:border-zinc-800 pl-2">
                    {p.replies.map((r, i) => (
                      <div key={i} className="text-xs break-words">
                        <span className="mr-1">{r.avatar}</span>
                        <span className="font-medium">{r.author}</span> {r.text}
                      </div>
                    ))}
                  </div>
                )}
                {replyFor === p.id && (
                  <div className="mt-1 flex gap-1">
                    <input
                      value={replyText}
                      onChange={(e) => setReplyText(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && doReply(p.id)}
                      placeholder="Responder…"
                      autoFocus
                      className="flex-1 min-w-0 text-xs rounded-lg border border-zinc-300 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-800 px-2 py-1 outline-none"
                    />
                    <button
                      onClick={() => doReply(p.id)}
                      className="text-xs px-2 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white shrink-0"
                    >
                      Enviar
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        {showStickers && (
          <div className="border-t border-zinc-200 dark:border-zinc-800 p-2 max-h-40 overflow-y-auto">
            <p className="text-[11px] text-zinc-400 px-1 mb-1">Animados</p>
            <div className="flex flex-wrap gap-1 mb-2">
              {ANIM_STICKERS.map((s) => (
                <button key={s} onClick={() => send(s)} className="p-1 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800">
                  <StickerView s={s} size={34} />
                </button>
              ))}
            </div>
            <p className="text-[11px] text-zinc-400 px-1 mb-1">Emojis</p>
            <div className="flex flex-wrap gap-1">
              {EMOJI_STICKERS.map((s) => (
                <button key={s} onClick={() => send(s)} className="text-2xl p-1 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800">
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}

        <div className="border-t border-zinc-200 dark:border-zinc-800 p-2">
          <div className="flex items-end gap-2">
            <button
              onClick={() => setShowStickers((s) => !s)}
              className="p-2 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 text-lg"
              title="Stickers y gifs"
            >
              😀
            </button>
            <button
              onClick={askAI}
              disabled={aiBusy}
              className="p-2 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 text-lg disabled:opacity-40"
              title="Que responda la IA"
            >
              {aiBusy ? '⏳' : '🤖'}
            </button>
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault()
                  send()
                }
              }}
              rows={1}
              placeholder="Escribe en el muro…"
              className="flex-1 resize-none rounded-xl border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 px-3 py-2 text-sm outline-none max-h-24"
            />
            <button
              onClick={() => send()}
              className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-sm shrink-0"
            >
              Enviar
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
