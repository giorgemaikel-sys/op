import type { ChatImage } from './types'

const MAX_DIM = 1280
const JPEG_QUALITY = 0.85

/**
 * Convierte un archivo de imagen en base64 (sin prefijo), reescalándolo
 * para que no sea gigante: mejora la velocidad del modelo y el guardado.
 */
export function fileToChatImage(file: File): Promise<ChatImage> {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file)
    const img = new Image()
    img.onload = () => {
      URL.revokeObjectURL(url)
      let width = img.naturalWidth
      let height = img.naturalHeight
      const scale = Math.min(1, MAX_DIM / Math.max(width, height))
      width = Math.max(1, Math.round(width * scale))
      height = Math.max(1, Math.round(height * scale))

      const canvas = document.createElement('canvas')
      canvas.width = width
      canvas.height = height
      const ctx = canvas.getContext('2d')
      if (!ctx) {
        reject(new Error('No se pudo procesar la imagen'))
        return
      }
      ctx.drawImage(img, 0, 0, width, height)
      const dataUrl = canvas.toDataURL('image/jpeg', JPEG_QUALITY)
      const base64 = dataUrl.split(',')[1] ?? ''
      resolve({ data: base64, mime: 'image/jpeg' })
    }
    img.onerror = () => {
      URL.revokeObjectURL(url)
      reject(new Error('No se pudo leer la imagen'))
    }
    img.src = url
  })
}
