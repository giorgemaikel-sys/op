import type { FlashcardSet } from './types'
import { complete } from './ollama'
import { extractJson } from './docs'
import { topicPrompt } from './context'

const SYSTEM = `Eres un generador de tarjetas de estudio (flashcards). Devuelve SOLO un JSON válido:
{"title":"Título","cards":[{"front":"pregunta o concepto","back":"respuesta clara y breve"}]}
Reglas: entre 6 y 12 tarjetas útiles sobre el tema; el frente es una pregunta o término, el dorso la respuesta corta. En español. Nada fuera del JSON.`

export async function makeFlashcards(
  topic: string,
  model: string,
  context?: string,
): Promise<FlashcardSet> {
  try {
    const raw = await complete({ model, system: SYSTEM, prompt: topicPrompt(topic, context), format: 'json' })
    const j = extractJson(raw)
    if (j && Array.isArray(j.cards) && j.cards.length) {
      const cards = (j.cards as any[])
        .map((c) => ({ front: String(c.front || ''), back: String(c.back || '') }))
        .filter((c) => c.front && c.back)
      if (cards.length) return { title: String(j.title || topic), cards }
    }
  } catch {
    /* fallback abajo */
  }
  return {
    title: topic,
    cards: [{ front: `¿Qué es ${topic}?`, back: 'Repasa este tema con tu asistente.' }],
  }
}
