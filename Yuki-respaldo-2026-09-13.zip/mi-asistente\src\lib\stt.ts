// Dictado por voz: graba del micrófono y transcribe con Whisper local
// (servidor Python en /voice/transcribe). 100% offline y privado.

export interface Recording {
  stop: () => Promise<Blob>
  cancel: () => void
}

/** Empieza a grabar del micrófono. Llama stop() para obtener el audio. */
export async function startRecording(): Promise<Recording> {
  const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
  const mr = new MediaRecorder(stream)
  const chunks: BlobPart[] = []
  mr.ondataavailable = (e) => {
    if (e.data && e.data.size) chunks.push(e.data)
  }
  mr.start()

  const cleanup = () => stream.getTracks().forEach((t) => t.stop())

  return {
    stop: () =>
      new Promise<Blob>((resolve) => {
        mr.onstop = () => {
          cleanup()
          resolve(new Blob(chunks, { type: mr.mimeType || 'audio/webm' }))
        }
        try {
          mr.stop()
        } catch {
          cleanup()
          resolve(new Blob(chunks, { type: 'audio/webm' }))
        }
      }),
    cancel: () => {
      try {
        mr.stop()
      } catch {
        /* ignore */
      }
      cleanup()
    },
  }
}

/** Envía el audio al servidor de voz y devuelve el texto transcrito. */
export async function transcribeBlob(blob: Blob, lang = 'es'): Promise<string> {
  const form = new FormData()
  form.append('audio', blob, 'audio.webm')
  form.append('lang', lang)
  const res = await fetch('/voice/transcribe', { method: 'POST', body: form })
  const data = await res.json().catch(() => ({}))
  if (!res.ok || data.error) {
    throw new Error(data.error || `Servidor de voz: error ${res.status}`)
  }
  return (data.text ?? '').trim()
}

/**
 * Graba del micrófono y se detiene sola cuando detecta silencio tras hablar
 * (VAD sencillo con WebAudio). Para el modo manos libres.
 */
export async function recordUntilSilence(opts: {
  silenceMs?: number
  maxMs?: number
  onState?: (s: 'listening' | 'recording') => void
} = {}): Promise<Blob> {
  const silenceMs = opts.silenceMs ?? 1400
  const maxMs = opts.maxMs ?? 15000
  const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
  const mr = new MediaRecorder(stream)
  const chunks: BlobPart[] = []
  mr.ondataavailable = (e) => {
    if (e.data && e.data.size) chunks.push(e.data)
  }

  const ac = new AudioContext()
  const src = ac.createMediaStreamSource(stream)
  const analyser = ac.createAnalyser()
  analyser.fftSize = 512
  src.connect(analyser)
  const buf = new Uint8Array(analyser.fftSize)

  return new Promise<Blob>((resolve) => {
    let started = false
    let lastLoud = Date.now()
    const startTime = Date.now()
    let raf = 0
    const cleanup = () => {
      cancelAnimationFrame(raf)
      try {
        ac.close()
      } catch {
        /* ignore */
      }
      stream.getTracks().forEach((t) => t.stop())
    }
    mr.onstop = () => {
      cleanup()
      resolve(new Blob(chunks, { type: mr.mimeType || 'audio/webm' }))
    }
    mr.start()
    opts.onState?.('listening')
    const THRESH = 0.02
    const tick = () => {
      analyser.getByteTimeDomainData(buf)
      let sum = 0
      for (let i = 0; i < buf.length; i++) {
        const v = (buf[i] - 128) / 128
        sum += v * v
      }
      const rms = Math.sqrt(sum / buf.length)
      const now = Date.now()
      if (rms > THRESH) {
        if (!started) {
          started = true
          opts.onState?.('recording')
        }
        lastLoud = now
      }
      if ((started && now - lastLoud > silenceMs) || now - startTime > maxMs) {
        try {
          mr.stop()
        } catch {
          cleanup()
          resolve(new Blob(chunks, { type: 'audio/webm' }))
        }
        return
      }
      raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)
  })
}

export async function voiceServerAvailable(): Promise<boolean> {
  try {
    const res = await fetch('/voice/health')
    return res.ok
  } catch {
    return false
  }
}
