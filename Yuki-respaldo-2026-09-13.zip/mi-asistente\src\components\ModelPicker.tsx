import type { OllamaModel } from '../lib/ollama'

interface Props {
  models: OllamaModel[]
  value: string
  onChange: (m: string) => void
}

export default function ModelPicker({ models, value, onChange }: Props) {
  return (
    <select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className="rounded-lg border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-sm px-2 py-1.5 max-w-[45vw] md:max-w-xs outline-none"
      title="Modelo"
    >
      <option value="__auto__">🤖 Auto (elige el mejor)</option>
      {models.length === 0 && <option value="">(sin modelos)</option>}
      {models.map((m) => (
        <option key={m.name} value={m.name}>
          {m.name}
        </option>
      ))}
    </select>
  )
}
