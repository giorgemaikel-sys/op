// Service worker de Yuki: "red primero" para archivos estáticos (para instalar
// como app y abrir sin conexión). NUNCA cachea las APIs (/store, /api, /sd…):
// esas siempre van a la red, así la contraseña y los datos nunca salen viejos.
const CACHE = 'yuki-cache-v2'
const API_PREFIXES = ['/store', '/api', '/sd', '/voice', '/doc']

self.addEventListener('install', () => self.skipWaiting())

self.addEventListener('activate', (e) => {
  e.waitUntil(
    (async () => {
      const keys = await caches.keys()
      await Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))
      await self.clients.claim()
    })(),
  )
})

self.addEventListener('fetch', (e) => {
  const req = e.request
  if (req.method !== 'GET') return
  let url
  try {
    url = new URL(req.url)
  } catch {
    return
  }
  if (url.origin !== self.location.origin) return
  // Nunca interceptar/cachear las APIs: siempre a la red (datos frescos).
  if (API_PREFIXES.some((p) => url.pathname.startsWith(p))) return

  e.respondWith(
    fetch(req)
      .then((res) => {
        if (res && res.status === 200 && res.type === 'basic') {
          const copy = res.clone()
          caches.open(CACHE).then((c) => c.put(req, copy)).catch(() => {})
        }
        return res
      })
      .catch(() => caches.match(req).then((hit) => hit || caches.match('/'))),
  )
})
