import type { MemoryItem } from './types'
import { complete } from './ollama'

const EXTRACT_SYSTEM = `Eres un extractor de memoria para un asistente personal. Extrae los datos personales duraderos que el usuario afirme SOBRE SÍ MISMO: nombre, ubicación, trabajo o estudios, gustos y aficiones, relaciones, preferencias y metas.
Reglas estrictas:
- SOLO hechos que el usuario declare sobre sí mismo. Extrae cada dato distinto en su propia línea.
- Si el mensaje es una PREGUNTA, una PETICIÓN o una TAREA (traduce, resume, "según el archivo…", "dime…"), responde NONE.
- NO incluyas instrucciones, peticiones ni frases que suenen a lo que diría el asistente.
- NO inventes nada.
- Escribe en tercera persona y breve.
- Si no hay datos personales, responde EXACTAMENTE: NONE

Ejemplos:
Usuario: "Soy Ana, vivo en Lima, me encanta correr y trabajo como enfermera."
Respuesta:
Se llama Ana
Vive en Lima
Le gusta correr
Trabaja como enfermera

Usuario: "Según la factura adjunta, dime el total y el cliente."
Respuesta:
NONE

Usuario: "¿Cómo me llamo?"
Respuesta:
NONE`

/** Extrae nuevos recuerdos del mensaje del usuario, evitando duplicados. */
export async function extractMemories(
  userText: string,
  existing: MemoryItem[],
  model: string,
): Promise<string[]> {
  if (!userText.trim()) return []
  let raw = ''
  try {
    raw = await complete({ model, system: EXTRACT_SYSTEM, prompt: userText })
  } catch {
    return []
  }
  const trimmed = raw.trim()
  if (!trimmed || /^none$/i.test(trimmed)) return []

  const existingLower = existing.map((m) => m.text.toLowerCase())
  const out: string[] = []

  for (let line of trimmed.split('\n')) {
    line = line.replace(/^[-*•\d.)\s]+/, '').trim()
    if (!line || /^none$/i.test(line)) continue
    if (line.length > 200) line = line.slice(0, 200)
    const low = line.toLowerCase()
    if (existingLower.includes(low)) continue
    if (out.some((o) => o.toLowerCase() === low)) continue
    // evitar casi-duplicados por subcadena
    if (existingLower.some((e) => e.includes(low) || low.includes(e))) continue
    out.push(line)
  }
  return out.slice(0, 5)
}

/** Construye el bloque de memoria que se inyecta al system prompt. */
export function buildMemoryBlock(memory: MemoryItem[]): string {
  if (!memory.length) return ''
  const list = memory.map((m) => `- ${m.text}`).join('\n')
  return `\n\n[Memoria — lo que sabes del usuario]\n${list}\nUsa esta información cuando sea relevante; no la menciones a menos que ayude.`
}
