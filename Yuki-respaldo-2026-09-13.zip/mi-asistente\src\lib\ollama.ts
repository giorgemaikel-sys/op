import type { ChatMessage, MsgStats } from './types'

export interface OllamaModel {
  name: string
  size: number
}

/**
 * Descarga de memoria los modelos que Ollama tenga cargados (keep_alive: 0),
 * para liberar la GPU antes de generar imágenes (evita OOM en la tarjeta de 8GB).
 */
async function loadedModels(): Promise<string[]> {
  try {
    const res = await fetch('/api/ps')
    const data = await res.json()
    return (data.models ?? []).map((m: any) => m.name)
  } catch {
    return []
  }
}

export async function unloadModels(): Promise<void> {
  try {
    let loaded = await loadedModels()
    if (!loaded.length) return
    // Pedir la descarga de cada modelo cargado (keep_alive: 0).
    await Promise.all(
      loaded.map((name) =>
        fetch('/api/generate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ model: name, keep_alive: 0, prompt: '' }),
        }).catch(() => {}),
      ),
    )
    // keep_alive:0 no libera al instante: sondeamos /api/ps hasta que se
    // vacíe (la VRAM de la tarjeta de 8GB debe quedar libre para Stable
    // Diffusion). Máximo ~8s para no bloquear demasiado.
    for (let i = 0; i < 16; i++) {
      await new Promise((r) => setTimeout(r, 500))
      loaded = await loadedModels()
      if (!loaded.length) break
    }
    // margen extra para que el driver libere del todo
    await new Promise((r) => setTimeout(r, 500))
  } catch {
    /* si falla, seguimos igualmente */
  }
}

/** Lista los modelos instalados en Ollama (GET /api/tags). */
export async function listModels(): Promise<OllamaModel[]> {
  const res = await fetch('/api/tags')
  if (!res.ok) throw new Error(`Ollama respondió ${res.status}`)
  const data = await res.json()
  return (data.models ?? []).map((m: any) => ({ name: m.name, size: m.size ?? 0 }))
}

/** Convierte un mensaje interno al formato de la API, metiendo el texto de los
 *  documentos adjuntos dentro del contenido y las imágenes en `images`. */
function toApiMessage(m: ChatMessage): any {
  let content = m.content
  if (m.docs && m.docs.length) {
    const docText = m.docs
      .map(
        (d) =>
          `[Archivo adjunto: ${d.name}${d.truncated ? ' (texto recortado)' : ''}]\n${d.text}`,
      )
      .join('\n\n')
    content = docText + (content ? `\n\n${content}` : '')
  }
  const msg: any = { role: m.role, content }
  if (m.images && m.images.length) {
    msg.images = m.images.map((img) => img.data)
  }
  return msg
}

interface ChatOptions {
  model: string
  messages: ChatMessage[]
  systemPrompt?: string
  signal?: AbortSignal
  onToken: (chunk: string) => void
  onStats?: (stats: MsgStats) => void
}

/**
 * Envía la conversación a Ollama (POST /api/chat, stream NDJSON) y llama a
 * onToken con cada fragmento de texto. Devuelve la respuesta completa.
 */
export async function chat({
  model,
  messages,
  systemPrompt,
  signal,
  onToken,
  onStats,
}: ChatOptions): Promise<string> {
  const apiMessages: any[] = []
  if (systemPrompt && systemPrompt.trim()) {
    apiMessages.push({ role: 'system', content: systemPrompt.trim() })
  }
  for (const m of messages) apiMessages.push(toApiMessage(m))

  const res = await fetch('/api/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model,
      messages: apiMessages,
      stream: true,
      // Limitar el contexto evita un KV-cache enorme (los modelos traen 128k por
      // defecto → mucha RAM/VRAM y lentitud en una PC de 16GB).
      options: { num_ctx: 8192 },
    }),
    signal,
  })

  if (!res.ok || !res.body) {
    const text = await res.text().catch(() => '')
    throw new Error(`Ollama error ${res.status}: ${text}`)
  }

  const reader = res.body.getReader()
  const decoder = new TextDecoder()
  let buffer = ''
  let full = ''

  while (true) {
    const { done, value } = await reader.read()
    if (done) break
    buffer += decoder.decode(value, { stream: true })
    let idx: number
    while ((idx = buffer.indexOf('\n')) !== -1) {
      const line = buffer.slice(0, idx).trim()
      buffer = buffer.slice(idx + 1)
      if (!line) continue
      try {
        const json = JSON.parse(line)
        const piece = json.message?.content ?? ''
        if (piece) {
          full += piece
          onToken(piece)
        }
        if (json.done && onStats) {
          const evalCount = json.eval_count ?? 0
          const evalDur = json.eval_duration ?? 0
          const totalDur = json.total_duration ?? 0
          const tps = evalDur > 0 ? evalCount / (evalDur / 1e9) : 0
          onStats({
            tokensPerSec: Math.round(tps * 10) / 10,
            totalMs: Math.round(totalDur / 1e6),
            evalCount,
          })
        }
      } catch {
        // línea incompleta o no-JSON; se ignora
      }
    }
  }
  return full
}

/**
 * Llamada única y NO-streaming (para tareas internas: extraer memoria, generar
 * títulos, etc.). Devuelve el texto de la respuesta.
 */
export async function complete({
  model,
  system,
  prompt,
  signal,
  format,
  numPredict,
}: {
  model: string
  system?: string
  prompt: string
  signal?: AbortSignal
  format?: 'json' // fuerza salida JSON válida (constrained decoding de Ollama)
  numPredict?: number // límite de tokens de salida (por defecto sin límite)
}): Promise<string> {
  const messages: any[] = []
  if (system) messages.push({ role: 'system', content: system })
  messages.push({ role: 'user', content: prompt })

  const body: any = {
    model,
    messages,
    stream: false,
    options: { temperature: 0.2, num_ctx: 8192, num_predict: numPredict ?? 4096 },
  }
  if (format) body.format = format

  const res = await fetch('/api/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
    signal,
  })
  if (!res.ok) throw new Error(`Ollama error ${res.status}`)
  const data = await res.json()
  return data.message?.content ?? ''
}

/** Genera un título corto para una conversación a partir del primer intercambio. */
export async function generateTitle(
  userText: string,
  assistantText: string,
  model: string,
): Promise<string> {
  try {
    const raw = await complete({
      model,
      system:
        'Genera un título muy corto (máximo 5 palabras) que resuma el tema. Responde SOLO el título, sin comillas, sin punto final, sin explicación.',
      prompt: `Usuario: ${userText}\nAsistente: ${assistantText}`,
    })
    let t = (raw.split('\n')[0] || '').trim()
    t = t.replace(/^["'#*\s]+/, '').replace(/["'.\s]+$/, '')
    if (t.length > 60) t = t.slice(0, 60)
    return t
  } catch {
    return ''
  }
}
