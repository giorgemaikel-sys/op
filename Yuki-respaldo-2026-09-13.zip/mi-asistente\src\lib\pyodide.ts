// Python que corre DENTRO del navegador (Pyodide = CPython en WebAssembly).
// Así el código se ejecuta en el dispositivo del usuario, sin necesitar la PC.
// Se descarga una sola vez (queda en caché) y luego funciona local y privado.

const PYODIDE_VERSION = 'v0.26.4'
const PYODIDE_URL = `https://cdn.jsdelivr.net/pyodide/${PYODIDE_VERSION}/full/`

let pyodidePromise: Promise<any> | null = null
let replReady = false

export interface PyResult {
  stdout: string
  stderr: string
  images: string[]
}

/** Respuestas pre-cargadas (caja ⌨️ Entrada); se consumen antes de preguntar. */
let _inputLines: string[] | null = null
let _inputIdx = 0

/** input(): usa primero las líneas pre-cargadas; si no hay, pregunta con un cuadro. */
function askInput(msg?: string): string | null {
  if (_inputLines && _inputIdx < _inputLines.length) return _inputLines[_inputIdx++]
  try {
    const v = window.prompt(msg || '⌨️ Entrada del programa:')
    return v === null ? null : v
  } catch {
    return null
  }
}

/** Carga Pyodide una sola vez (singleton). onStatus informa el progreso. */
export function getPyodide(onStatus?: (s: string) => void): Promise<any> {
  if (pyodidePromise) return pyodidePromise
  pyodidePromise = (async () => {
    onStatus?.('⬇️ Descargando Python (solo la primera vez)…')
    if (!(window as any).loadPyodide) {
      await new Promise<void>((resolve, reject) => {
        const s = document.createElement('script')
        s.src = PYODIDE_URL + 'pyodide.js'
        s.onload = () => resolve()
        s.onerror = () => reject(new Error('No se pudo descargar Python (¿hay internet la primera vez?).'))
        document.head.appendChild(s)
      })
    }
    onStatus?.('🐍 Iniciando Python…')
    const py = await (window as any).loadPyodide({ indexURL: PYODIDE_URL })
    // input(): muestra un cuadro con la pregunta real y hace eco de la respuesta.
    py.globals.set('_yuki_ask', (p: string) => askInput(p))
    py.setStdin({ stdin: () => askInput() }) // por si leen sys.stdin directamente
    await py.runPythonAsync(
      'import builtins as _b, sys as _sys\n' +
        'def _yuki_input(_p=""):\n' +
        '    _sys.stdout.write(str(_p))\n' +
        '    _r = _yuki_ask(str(_p))\n' +
        '    if _r is None:\n' +
        '        raise EOFError("entrada cancelada")\n' +
        '    _sys.stdout.write(str(_r) + "\\n")\n' +
        '    return str(_r)\n' +
        '_b.input = _yuki_input\n',
    )
    onStatus?.('')
    return py
  })()
  return pyodidePromise
}

/** ¿Ya está Python cargado (sin forzar la descarga)? */
export function pyodideLoaded(): boolean {
  return replReady || !!(window as any).pyodide
}

const _COLLECT_IMGS = `
import sys as _sys, json as _json
_imgs = []
if 'matplotlib' in _sys.modules:
    try:
        import matplotlib.pyplot as _plt, io as _io, base64 as _b64
        for _n in _plt.get_fignums():
            _b = _io.BytesIO()
            _plt.figure(_n).savefig(_b, format='png', bbox_inches='tight')
            _imgs.append(_b64.b64encode(_b.getvalue()).decode())
        _plt.close('all')
    except Exception:
        pass
_json.dumps(_imgs)
`

/** Ejecuta un PROGRAMA completo. Captura texto, errores e imágenes (matplotlib). */
export async function runProgram(
  code: string,
  stdin = '',
  onStatus?: (s: string) => void,
): Promise<PyResult> {
  const py = await getPyodide(onStatus)
  let out = ''
  let err = ''
  const add = (s: string) => (s.endsWith('\n') ? s : s + '\n')
  py.setStdout({ batched: (s: string) => (out += add(s)) })
  py.setStderr({ batched: (s: string) => (err += add(s)) })

  // Cargar las respuestas de la caja ⌨️ Entrada (si hay); luego preguntará solo.
  _inputLines = stdin ? stdin.split('\n') : null
  _inputIdx = 0

  try {
    // Fijar backend sin ventana para matplotlib (por si lo usan).
    await py.runPythonAsync("import os as _os; _os.environ.setdefault('MPLBACKEND', 'AGG')")
    onStatus?.('📦 Preparando librerías…')
    await py.loadPackagesFromImports(code)
    onStatus?.('')
    await py.runPythonAsync(code)
  } catch (e: any) {
    err += cleanTrace(e?.message ?? String(e))
  } finally {
    _inputLines = null // limpiar para la próxima ejecución / consola
  }

  let images: string[] = []
  try {
    const raw = await py.runPythonAsync(_COLLECT_IMGS)
    images = JSON.parse(raw)
  } catch {
    /* sin imágenes */
  }
  return { stdout: out, stderr: err, images }
}

const _REPL_SETUP = `
import io as _io, json as _json, code as _code, sys as _sys, traceback as _tb
_yuki_con = _code.InteractiveConsole({'__name__': '__main__'})
def _yuki_push(_src):
    _buf = _io.StringIO(); _o, _e = _sys.stdout, _sys.stderr
    _sys.stdout = _buf; _sys.stderr = _buf
    _more = False
    try:
        _more = _yuki_con.push(_src)
    except SystemExit:
        _yuki_con.resetbuffer()
    except BaseException:
        _tb.print_exc()
    finally:
        _sys.stdout = _o; _sys.stderr = _e
    return _json.dumps({'out': _buf.getvalue(), 'more': bool(_more)})
`

async function ensureRepl(py: any) {
  if (replReady) return
  await py.runPythonAsync(_REPL_SETUP)
  replReady = true
}

/** Consola interactiva: envía UNA línea; devuelve {out, more} (more = bloque incompleto). */
export async function replPush(
  line: string,
  onStatus?: (s: string) => void,
): Promise<{ out: string; more: boolean }> {
  const py = await getPyodide(onStatus)
  await ensureRepl(py)
  try {
    await py.loadPackagesFromImports(line)
  } catch {
    /* ignorar */
  }
  const fn = py.globals.get('_yuki_push')
  try {
    const raw = fn(line)
    return JSON.parse(raw)
  } finally {
    fn?.destroy?.()
  }
}

/** Instala una o varias librerías EN EL NAVEGADOR (micropip / paquetes de Pyodide). */
export async function pipInstall(pkg: string, onStatus?: (s: string) => void): Promise<string> {
  const py = await getPyodide(onStatus)
  onStatus?.('📦 Instalando…')
  await py.loadPackage('micropip')
  const micropip = py.pyimport('micropip')
  const results: string[] = []
  for (const p of pkg.split(/\s+/).filter(Boolean)) {
    try {
      await micropip.install(p)
      results.push('✓ ' + p)
    } catch (e: any) {
      try {
        await py.loadPackage(p)
        results.push('✓ ' + p)
      } catch {
        results.push('✗ ' + p + ': ' + (e?.message ?? 'no disponible en el navegador'))
      }
    }
  }
  micropip?.destroy?.()
  onStatus?.('')
  return results.join('\n')
}

/** Lista los paquetes ya cargados en el navegador. */
export async function listLibs(onStatus?: (s: string) => void): Promise<string[]> {
  const py = await getPyodide(onStatus)
  try {
    const names = Object.keys(py.loadedPackages || {})
    return names.sort()
  } catch {
    return []
  }
}

/** Reinicia la consola (borra variables). */
export async function replReset() {
  if (!pyodidePromise) return
  const py = await pyodidePromise
  replReady = false
  await ensureRepl(py)
}

/** Quita rutas internas del traceback para que se lea limpio. */
function cleanTrace(msg: string): string {
  return msg
    .split('\n')
    .filter((l) => !l.includes('/lib/python') && !l.includes('pyodide.asm'))
    .join('\n')
    .trim()
}
