import { useEffect, useRef, useState } from 'react'
import mermaid from 'mermaid'

let counter = 0

/**
 * Renderiza un diagrama Mermaid dentro del chat. Es tolerante al streaming: si
 * el bloque aún está incompleto (o tiene un error), muestra el código como texto
 * hasta que sea válido. `securityLevel: 'strict'` evita cualquier HTML/JS del modelo.
 */
export default function Mermaid({ code }: { code: string }) {
  const ref = useRef<HTMLDivElement>(null)
  const [ok, setOk] = useState(false)
  const idRef = useRef(`mmd-${counter++}`)
  // recalcular en cada render para reaccionar al cambio de tema claro/oscuro
  const dark =
    typeof document !== 'undefined' &&
    document.documentElement.classList.contains('dark')

  useEffect(() => {
    const source = code.trim()
    if (!source) {
      setOk(false)
      return
    }
    let cancelled = false
    mermaid.initialize({
      startOnLoad: false,
      securityLevel: 'strict',
      theme: dark ? 'dark' : 'default',
      fontFamily: 'inherit',
    })
    ;(async () => {
      try {
        // parse lanza si el diagrama es inválido o está a medio escribir
        await mermaid.parse(source)
        const { svg } = await mermaid.render(`${idRef.current}-${Date.now()}`, source)
        if (!cancelled && ref.current) {
          ref.current.innerHTML = svg
          setOk(true)
        }
      } catch {
        if (!cancelled) setOk(false)
      }
    })()
    return () => {
      cancelled = true
    }
  }, [code, dark])

  return (
    <>
      <div
        ref={ref}
        className={`my-2 flex justify-center overflow-x-auto rounded-xl bg-white dark:bg-zinc-900/60 p-2 [&_svg]:max-w-full [&_svg]:h-auto ${
          ok ? '' : 'hidden'
        }`}
      />
      {!ok && (
        <pre className="text-xs overflow-x-auto rounded-lg bg-zinc-100 dark:bg-zinc-800 p-2 my-2 opacity-70">
          {code.trim() || '…'}
        </pre>
      )}
    </>
  )
}
