@echo off
title Asistente
cd /d "%~dp0"
echo ============================================
echo   Iniciando tu Asistente...
echo ============================================
echo.
echo  - Servidor de imagenes / voz / documentos...
if exist "sd-server\.venv\Scripts\python.exe" start "Asistente - Imagenes" cmd /k "cd sd-server && .venv\Scripts\python.exe server.py"
echo  - Servidor principal (la app)...
start "Asistente - App" cmd /k "npm run host"
echo  - Abriendo el navegador (espera unos segundos)...
timeout /t 8 /nobreak >nul
start "" "http://localhost:5173"
echo.
set /p "SHARE=Compartir con amigos por internet ahora? (s/n): "
if /i "%SHARE%"=="s" call "%~dp0compartir.bat"
echo.
echo  Listo. Deja abiertas las ventanas negras del asistente.
pause
