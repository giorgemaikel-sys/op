@echo off
title Servidor de imagenes (sd-server)
cd /d "%~dp0sd-server"
echo ================================================
echo   Servidor de imagenes (Stable Diffusion local)
echo ================================================
echo.
echo  - La PRIMERA vez descarga el modelo (~2.5 GB): paciencia.
echo  - Cuando veas "Modelo listo." ya puedes generar imagenes.
echo  - Deja esta ventana abierta mientras uses el modo imagen.
echo.
".venv\Scripts\python.exe" server.py
pause
