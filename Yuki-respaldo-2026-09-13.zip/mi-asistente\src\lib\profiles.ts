import type {
  Conversation,
  MemoryItem,
  Persona,
  PromptTemplate,
  Settings,
  UserStats,
} from './types'

export interface Profile {
  id: string
  name: string
  avatar: string
  hasPin: boolean
}

export interface ProfileData {
  conversations: Conversation[]
  memory: MemoryItem[]
  personas: Persona[]
  prompts: PromptTemplate[]
  settings: Partial<Settings>
  stats?: UserStats
}

export async function listProfiles(): Promise<Profile[]> {
  try {
    const r = await fetch('/store/profiles')
    const d = await r.json()
    return (d.profiles ?? []) as Profile[]
  } catch {
    return []
  }
}

export async function createProfile(
  name: string,
  avatar: string,
  pin?: string,
  email?: string,
): Promise<Profile | null> {
  try {
    const r = await fetch('/store/profiles', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name,
        avatar,
        pin: pin || undefined,
        email: email || undefined,
      }),
    })
    const d = await r.json()
    return (d.profile ?? null) as Profile | null
  } catch {
    return null
  }
}

/** ¿El servidor pide contraseña de acceso (modo compartido)? */
export async function accessRequired(): Promise<boolean> {
  try {
    const r = await fetch('/store/access')
    const d = await r.json()
    return !!d.required
  } catch {
    return false
  }
}

/** Verifica la contraseña compartida. Lanza error si no se pudo conectar
 *  (para distinguir "contraseña mala" de "servidor/PC apagado"). */
export async function checkAccess(password: string): Promise<boolean> {
  const r = await fetch('/store/access', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ password }),
  })
  const d = await r.json()
  return !!d.ok
}

export interface FriendEmail {
  name: string
  avatar: string
  email: string
}

/** Lista los correos de los perfiles (solo el dueño, con la contraseña de admin). */
export async function listEmails(ownerPass: string): Promise<FriendEmail[]> {
  try {
    const r = await fetch('/store/emails', {
      headers: ownerPass ? { 'x-owner-pass': ownerPass } : {},
    })
    if (!r.ok) return []
    const d = await r.json()
    return (d.emails ?? []) as FriendEmail[]
  } catch {
    return []
  }
}

// ---- Administrador (dueño) — contraseña maestra ----
export async function verifyOwnerPassword(password: string): Promise<boolean> {
  try {
    const r = await fetch('/store/owner/verify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ password }),
    })
    const d = await r.json()
    return !!d.ok
  } catch {
    return false
  }
}

// ---- Config de correo (SMTP) ----
export interface SmtpInfo {
  configured: boolean
  host: string
  port: number
  secure: boolean
  user: string
  from: string
}

export async function getSmtp(ownerPass: string): Promise<SmtpInfo | null> {
  try {
    const r = await fetch('/store/smtp', {
      headers: ownerPass ? { 'x-owner-pass': ownerPass } : {},
    })
    if (!r.ok) return null
    return (await r.json()) as SmtpInfo
  } catch {
    return null
  }
}

export async function saveSmtp(
  cfg: { host: string; port: number; secure: boolean; user: string; pass?: string; from: string },
  ownerPass: string,
): Promise<{ ok: boolean; error?: string }> {
  try {
    const r = await fetch('/store/smtp', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(ownerPass ? { 'x-owner-pass': ownerPass } : {}),
      },
      body: JSON.stringify(cfg),
    })
    const d = await r.json().catch(() => ({}))
    if (!r.ok || d.error) return { ok: false, error: d.error || 'Error' }
    return { ok: true }
  } catch {
    return { ok: false, error: 'Error de conexión' }
  }
}

export async function testSmtp(
  ownerPass: string,
): Promise<{ ok: boolean; error?: string }> {
  try {
    const r = await fetch('/store/smtp/test', {
      method: 'POST',
      headers: { 'x-owner-pass': ownerPass },
    })
    const d = await r.json().catch(() => ({}))
    if (d.ok) return { ok: true }
    return { ok: false, error: d.error || 'No se pudo enviar' }
  } catch {
    return { ok: false, error: 'Error de conexión' }
  }
}

export async function sendToFriends(
  to: string[],
  subject: string,
  text: string,
  ownerPass: string,
): Promise<{ ok: boolean; sent?: number; failed?: number; error?: string }> {
  try {
    const r = await fetch('/store/sendmail', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-owner-pass': ownerPass },
      body: JSON.stringify({ to, subject, text }),
    })
    const d = await r.json().catch(() => ({}))
    if (d.ok) return { ok: true, sent: d.sent, failed: d.failed }
    return { ok: false, error: d.error || 'No se pudo enviar' }
  } catch {
    return { ok: false, error: 'Error de conexión' }
  }
}

// ---- Recuperar PIN por correo ----
export async function recoverPin(
  email: string,
): Promise<{ ok: boolean; error?: string }> {
  try {
    const r = await fetch('/store/recover', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email }),
    })
    const d = await r.json().catch(() => ({}))
    if (d.ok) return { ok: true }
    return { ok: false, error: d.error || 'No se pudo recuperar' }
  } catch {
    return { ok: false, error: 'Error de conexión' }
  }
}

export async function deleteProfile(
  id: string,
  ownerPass?: string,
): Promise<{ ok: boolean; error?: string }> {
  try {
    const r = await fetch('/store/profiles/delete', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(ownerPass ? { 'x-owner-pass': ownerPass } : {}),
      },
      body: JSON.stringify({ id }),
    })
    const d = await r.json().catch(() => ({}))
    if (!r.ok || d.error) return { ok: false, error: d.error || 'No se pudo borrar' }
    return { ok: true }
  } catch {
    return { ok: false, error: 'Error de conexión' }
  }
}

export async function verifyPin(id: string, pin: string): Promise<boolean> {
  try {
    const r = await fetch('/store/profiles/verify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, pin }),
    })
    const d = await r.json()
    return !!d.ok
  } catch {
    return false
  }
}

export async function loadProfileData(id: string): Promise<Partial<ProfileData>> {
  try {
    const r = await fetch(`/store/data?id=${encodeURIComponent(id)}`)
    const d = await r.json()
    return (d.data ?? {}) as Partial<ProfileData>
  } catch {
    return {}
  }
}

export async function saveProfileData(
  id: string,
  data: ProfileData,
): Promise<void> {
  try {
    await fetch('/store/data', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, data }),
    })
  } catch {
    /* ignore */
  }
}
