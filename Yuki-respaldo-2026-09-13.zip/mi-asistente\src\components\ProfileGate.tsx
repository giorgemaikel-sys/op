import { useState } from 'react'
import { recoverPin, type Profile } from '../lib/profiles'

interface Props {
  profiles: Profile[]
  onSelect: (p: Profile) => void
  onCreate: (
    name: string,
    avatar: string,
    pin?: string,
    email?: string,
  ) => Promise<Profile | null>
  onDelete: (id: string, ownerPass?: string) => Promise<{ ok: boolean; error?: string }>
  verifyPin: (id: string, pin: string) => Promise<boolean>
}

function isEmail(s: string): boolean {
  return /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(s.trim())
}

const AVATARS = ['🙂', '😎', '🧑', '👩', '👨', '🐱', '🐼', '🦊', '🚀', '🌟', '🎧', '🎮']

function Avatar({ p, size = 'lg' }: { p: Profile; size?: 'lg' | 'sm' }) {
  const cls = size === 'lg' ? 'h-16 w-16 text-3xl' : 'h-10 w-10 text-xl'
  return (
    <div
      className={`${cls} rounded-full bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center text-white shrink-0`}
    >
      {p.avatar || p.name.slice(0, 1).toUpperCase()}
    </div>
  )
}

export default function ProfileGate({
  profiles,
  onSelect,
  onCreate,
  onDelete,
  verifyPin,
}: Props) {
  const [view, setView] = useState<'list' | 'create' | 'pin' | 'recover'>(
    profiles.length ? 'list' : 'create',
  )
  const [editing, setEditing] = useState(false)
  const [target, setTarget] = useState<Profile | null>(null)
  const [pin, setPin] = useState('')
  const [pinError, setPinError] = useState(false)
  const [busy, setBusy] = useState(false)
  // recuperar PIN
  const [recEmail, setRecEmail] = useState('')
  const [recMsg, setRecMsg] = useState('')
  const [recOk, setRecOk] = useState(false)
  // borrar perfil (pide contraseña de administrador)
  const [delTarget, setDelTarget] = useState<Profile | null>(null)
  const [delPass, setDelPass] = useState('')
  const [delMsg, setDelMsg] = useState('')

  // crear
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [avatar, setAvatar] = useState(AVATARS[0])
  const [usePin, setUsePin] = useState(false)
  const [newPin, setNewPin] = useState('')

  function pickProfile(p: Profile) {
    if (p.hasPin) {
      setTarget(p)
      setPin('')
      setPinError(false)
      setView('pin')
    } else {
      onSelect(p)
    }
  }

  async function submitPin() {
    if (!target) return
    setBusy(true)
    const ok = await verifyPin(target.id, pin)
    setBusy(false)
    if (ok) onSelect(target)
    else setPinError(true)
  }

  async function submitRecover() {
    if (!isEmail(recEmail)) {
      setRecMsg('Escribe un correo válido')
      setRecOk(false)
      return
    }
    setBusy(true)
    const r = await recoverPin(recEmail.trim())
    setBusy(false)
    setRecOk(r.ok)
    setRecMsg(
      r.ok
        ? '✓ Te enviamos un correo con tu nuevo PIN. Revisa tu bandeja (y spam).'
        : r.error || 'No se pudo recuperar',
    )
  }

  async function confirmDelete() {
    if (!delTarget) return
    setBusy(true)
    const r = await onDelete(delTarget.id, delPass || undefined)
    setBusy(false)
    if (r.ok) {
      setDelTarget(null)
      setDelPass('')
      setDelMsg('')
    } else {
      setDelMsg(r.error || 'No se pudo borrar')
    }
  }

  async function submitCreate() {
    const n = name.trim()
    if (!n || !isEmail(email)) return
    setBusy(true)
    const p = await onCreate(
      n,
      avatar,
      usePin ? newPin.trim() : undefined,
      email.trim(),
    )
    setBusy(false)
    if (p) {
      setName('')
      setEmail('')
      setNewPin('')
      setUsePin(false)
      onSelect(p)
    }
  }

  return (
    <div className="h-dvh flex flex-col items-center justify-center bg-zinc-50 dark:bg-zinc-950 text-zinc-900 dark:text-zinc-100 px-6">
      <div className="w-full max-w-md">
        <div className="flex flex-col items-center mb-8">
          <img
            src="/icon-192.png"
            alt="Yuki"
            className="h-16 w-16 rounded-2xl object-cover mb-3 shadow-lg"
          />
          <h1 className="text-2xl font-semibold">
            {view === 'create'
              ? 'Crear perfil'
              : view === 'pin'
                ? `Hola, ${target?.name}`
                : '¿Quién eres?'}
          </h1>
          {view === 'list' && (
            <p className="text-sm text-zinc-500 dark:text-zinc-400 mt-1">
              Elige tu perfil. Tus chats y ajustes viven en tu PC.
            </p>
          )}
        </div>

        {/* Lista de perfiles */}
        {view === 'list' && (
          <div className="space-y-4">
            <div className="grid grid-cols-3 gap-4">
              {profiles.map((p) => (
                <div key={p.id} className="relative flex flex-col items-center gap-2">
                  <button
                    onClick={() => (editing ? undefined : pickProfile(p))}
                    className="flex flex-col items-center gap-2 group"
                  >
                    <Avatar p={p} />
                    <span className="text-sm truncate max-w-[5.5rem]">{p.name}</span>
                    {p.hasPin && <span className="text-[10px] text-zinc-400">🔒</span>}
                  </button>
                  {editing && (
                    <button
                      onClick={() => {
                        setDelTarget(p)
                        setDelPass('')
                        setDelMsg('')
                      }}
                      className="absolute -top-1 right-2 h-6 w-6 rounded-full bg-red-500 text-white text-xs flex items-center justify-center"
                      title="Borrar perfil"
                    >
                      ✕
                    </button>
                  )}
                </div>
              ))}
              <button
                onClick={() => setView('create')}
                className="flex flex-col items-center gap-2"
              >
                <div className="h-16 w-16 rounded-full border-2 border-dashed border-zinc-300 dark:border-zinc-700 flex items-center justify-center text-2xl text-zinc-400">
                  ＋
                </div>
                <span className="text-sm text-zinc-500">Nuevo</span>
              </button>
            </div>
            {profiles.length > 0 && (
              <div className="text-center">
                <button
                  onClick={() => setEditing((e) => !e)}
                  className="text-xs text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200"
                >
                  {editing ? 'Listo' : 'Editar perfiles'}
                </button>
              </div>
            )}
          </div>
        )}

        {/* PIN */}
        {view === 'pin' && (
          <div className="space-y-4">
            <input
              type="password"
              inputMode="numeric"
              autoFocus
              value={pin}
              onChange={(e) => {
                setPin(e.target.value)
                setPinError(false)
              }}
              onKeyDown={(e) => e.key === 'Enter' && submitPin()}
              placeholder="PIN"
              className={`w-full text-center text-2xl tracking-widest rounded-xl border px-4 py-3 bg-white dark:bg-zinc-900 outline-none ${
                pinError
                  ? 'border-red-500'
                  : 'border-zinc-300 dark:border-zinc-700'
              }`}
            />
            {pinError && (
              <p className="text-sm text-red-500 text-center">PIN incorrecto</p>
            )}
            <button
              onClick={submitPin}
              disabled={busy}
              className="w-full rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white py-3 font-medium disabled:opacity-50"
            >
              Entrar
            </button>
            <button
              onClick={() => {
                setRecEmail('')
                setRecMsg('')
                setRecOk(false)
                setView('recover')
              }}
              className="w-full text-sm text-indigo-500"
            >
              ¿Olvidaste tu PIN?
            </button>
            <button
              onClick={() => setView('list')}
              className="w-full text-sm text-zinc-500"
            >
              ← Volver
            </button>
          </div>
        )}

        {/* Recuperar PIN por correo */}
        {view === 'recover' && (
          <div className="space-y-4">
            <p className="text-sm text-zinc-500 dark:text-zinc-400 text-center">
              Escribe el correo con el que creaste tu perfil. Te enviaremos un
              PIN nuevo.
            </p>
            <input
              type="email"
              inputMode="email"
              autoFocus
              value={recEmail}
              onChange={(e) => {
                setRecEmail(e.target.value)
                setRecMsg('')
              }}
              onKeyDown={(e) => e.key === 'Enter' && submitRecover()}
              placeholder="Tu correo"
              className="w-full rounded-xl border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-900 px-4 py-3 outline-none"
            />
            {recMsg && (
              <p
                className={`text-sm text-center ${
                  recOk ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-500'
                }`}
              >
                {recMsg}
              </p>
            )}
            {!recOk && (
              <button
                onClick={submitRecover}
                disabled={busy}
                className="w-full rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white py-3 font-medium disabled:opacity-50"
              >
                Enviarme un PIN nuevo
              </button>
            )}
            <button
              onClick={() => setView(target ? 'pin' : 'list')}
              className="w-full text-sm text-zinc-500"
            >
              ← Volver
            </button>
          </div>
        )}

        {/* Crear */}
        {view === 'create' && (
          <div className="space-y-4">
            <div className="flex justify-center">
              <div className="h-16 w-16 rounded-full bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center text-white text-3xl">
                {avatar}
              </div>
            </div>
            <div className="flex flex-wrap justify-center gap-2">
              {AVATARS.map((a) => (
                <button
                  key={a}
                  onClick={() => setAvatar(a)}
                  className={`h-9 w-9 rounded-lg text-xl flex items-center justify-center ${
                    avatar === a
                      ? 'bg-indigo-600'
                      : 'hover:bg-zinc-100 dark:hover:bg-zinc-800'
                  }`}
                >
                  {a}
                </button>
              ))}
            </div>
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && submitCreate()}
              placeholder="Tu nombre"
              autoFocus
              className="w-full rounded-xl border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-900 px-4 py-3 outline-none"
            />
            <div>
              <input
                type="email"
                inputMode="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && submitCreate()}
                placeholder="Tu correo (email)"
                className={`w-full rounded-xl border px-4 py-3 outline-none bg-white dark:bg-zinc-900 ${
                  email && !isEmail(email)
                    ? 'border-red-500'
                    : 'border-zinc-300 dark:border-zinc-700'
                }`}
              />
              <p className="text-[11px] text-zinc-400 mt-1 px-1">
                Lo usamos para avisarte novedades. Solo lo ve el dueño del asistente.
              </p>
            </div>
            <label className="flex items-center gap-2 text-sm cursor-pointer">
              <input
                type="checkbox"
                checked={usePin}
                onChange={(e) => setUsePin(e.target.checked)}
                className="accent-indigo-600"
              />
              Proteger con un PIN
            </label>
            {usePin && (
              <input
                type="password"
                inputMode="numeric"
                value={newPin}
                onChange={(e) => setNewPin(e.target.value)}
                placeholder="PIN (números)"
                className="w-full rounded-xl border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-900 px-4 py-3 outline-none tracking-widest"
              />
            )}
            <button
              onClick={submitCreate}
              disabled={busy || !name.trim() || !isEmail(email)}
              className="w-full rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white py-3 font-medium disabled:opacity-40"
            >
              Crear y entrar
            </button>
            {profiles.length > 0 && (
              <button
                onClick={() => setView('list')}
                className="w-full text-sm text-zinc-500"
              >
                ← Volver
              </button>
            )}
          </div>
        )}
      </div>
      <p className="mt-8 text-[11px] text-zinc-400">
        100% local · privado · sincronizado en tu PC
      </p>

      {/* Confirmar borrado (solo el dueño con la contraseña de administrador) */}
      {delTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 px-6">
          <div className="w-full max-w-sm rounded-2xl bg-white dark:bg-zinc-900 p-5 space-y-3">
            <p className="font-semibold">Borrar el perfil “{delTarget.name}”</p>
            <p className="text-xs text-zinc-500">
              Esto borra sus chats y datos para siempre. Solo el dueño puede
              hacerlo: escribe la <b>contraseña de administrador</b>.
            </p>
            <input
              type="password"
              autoFocus
              value={delPass}
              onChange={(e) => {
                setDelPass(e.target.value)
                setDelMsg('')
              }}
              onKeyDown={(e) => e.key === 'Enter' && confirmDelete()}
              placeholder="Contraseña de administrador"
              className="w-full rounded-lg border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-900 px-3 py-2 text-sm outline-none"
            />
            {delMsg && <p className="text-xs text-red-500">{delMsg}</p>}
            <div className="flex gap-2 justify-end">
              <button
                onClick={() => {
                  setDelTarget(null)
                  setDelPass('')
                  setDelMsg('')
                }}
                className="text-sm px-3 py-1.5 rounded-lg border border-zinc-300 dark:border-zinc-700"
              >
                Cancelar
              </button>
              <button
                onClick={confirmDelete}
                disabled={busy}
                className="text-sm px-3 py-1.5 rounded-lg bg-red-500 hover:bg-red-600 text-white disabled:opacity-50"
              >
                Borrar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
