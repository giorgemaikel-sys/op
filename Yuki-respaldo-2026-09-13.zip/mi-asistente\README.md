# Mi Asistente (local, privado y gratis)

Un asistente de IA con el que **chateas** y que **analiza imágenes**, corriendo
**100% en tu PC** con [Ollama](https://ollama.com). Sin costo, sin nube, sin API keys.
Funciona offline y también desde el **celular** (por WiFi).

---

## ▶️ Cómo arrancarlo

**Opción fácil:** doble clic en **`start.bat`**. Se abre solo en el navegador.

**Opción manual** (desde una terminal en esta carpeta):

```bash
npm run host
```

Luego abre <http://localhost:5173>.

> La primera vez, Windows puede preguntar si permites a **Node.js** en la red:
> marca **redes privadas** y acepta (así funciona el celular).

Para **cerrar** el asistente: cierra la ventana negra (o Ctrl+C en la terminal).

---

## 📱 Usarlo en el celular

1. El celular debe estar en la **misma red WiFi** que la PC.
2. Con el asistente corriendo, en el navegador del celular abre:

   **http://192.168.1.65:5173**

   (Esa es la IP de tu PC ahora. Si cambia, arranca `start.bat` y mira la línea
   *"Network: http://…:5173"* en la ventana negra.)
3. Menú del navegador → **"Agregar a pantalla de inicio"** para tenerlo como app.

---

## 🌍 Usarlo FUERA de casa (Tailscale)

Para usarlo desde datos móviles u otra WiFi, usamos **Tailscale** (red privada gratis,
cifrada, solo entre tus dispositivos):

1. Ten **Tailscale activo** en la PC y en el celular (misma cuenta).
2. En el celular abre: **http://100.104.246.89:5173**
   (la IP de Tailscale de tu PC; es **fija**, funciona en casa y fuera).
3. Requiere la **PC encendida** con los servidores corriendo.

> Ventaja: con Tailscale, esa dirección funciona en todos lados; ya no dependes de la
> IP `192.168…` de la WiFi de casa.

---

## 🔒 Hacerlo SEGURO (HTTPS, sin el aviso "No seguro")

Cuando entras por `http://192.168…` o `http://100.104…` el navegador dice **"No seguro"**
(porque es HTTP). Para tener **HTTPS de verdad** (candado, sin avisos) en **tus** dispositivos,
usa **Tailscale** que te da un **certificado real gratis**:

1. **Una sola vez**, en tu cuenta de Tailscale, activa HTTPS:
   - Abre <https://login.tailscale.com/admin/dns> y pulsa **"Enable HTTPS"**.
   - Si te lo pide, activa **"Serve"** en <https://login.tailscale.com/admin/settings/features>.
2. Con la app corriendo (`start.bat`), doble clic en **`seguro.bat`**.
3. Entra en tus dispositivos (con Tailscale activo) a:

   **https://maikel.tail1907d2.ts.net**

   Sale el **candado** 🔒, sin "No seguro". Úsala en casa y fuera; ya no necesitas la IP.

> Bonus: con HTTPS, el **micrófono** (dictar por voz) funciona en el celular (los
> navegadores solo lo permiten en sitios seguros).
>
> Para tus **amigos** (que no usan Tailscale), el enlace de `compartir.bat`
> (`https://…trycloudflare.com`) **ya es seguro** (HTTPS) por sí solo.
>
> Para apagarlo: `tailscale serve reset`.

---

## 🤝 Compartir con AMIGOS (que no viven contigo)

Tailscale sirve para **tus** dispositivos. Para que **amigos** entren desde su celular (con
datos móviles, otra WiFi, sin instalar nada), usa **`compartir.bat`**: crea un **enlace público**
(túnel de Cloudflare, gratis) y protege la entrada con una **contraseña**.

**Una sola vez**, instala la herramienta del túnel (en una terminal):

```bash
winget install Cloudflare.cloudflared
```

**Cada vez que quieras compartir:**

1. Ten corriendo **`start.bat`** (y `imagenes.bat` si quieres imágenes/voz/documentos).
2. Doble clic en **`compartir.bat`** → te pide una **contraseña** (simple, letras y números).
3. Aparece un enlace tipo **`https://algo-algo.trycloudflare.com`**.
4. Manda a tus amigos **ese enlace + la contraseña**. Cada uno abre el enlace, escribe la
   contraseña, **crea su propio perfil** (nombre, avatar y **su correo**) y ya puede chatear.

> Notas importantes:
> - Tu **PC debe estar encendida** con las ventanas abiertas mientras ellos lo usen.
> - Es **tu GPU**: si varios escriben a la vez, va por turnos (bien para pocos amigos).
> - El enlace **cambia cada vez** que abres `compartir.bat`. Para uno fijo hace falta una
>   cuenta de Cloudflare + un dominio (otro día).
> - La contraseña se guarda en `data/share.txt`. **Bórralo** (o cierra `compartir.bat`) para
>   volver a uso solo-local sin contraseña.

**Los correos de tus amigos** quedan guardados: ábrelos en **⚙️ Ajustes → 📧 Correos de amigos**
(botón "Ver correos"), para poder escribirles cuando quieras. Solo los ves tú.

### 🔐 Contraseña de administrador (para que solo TÚ borres perfiles)

Cuando compartes, para que **nadie más pueda borrar perfiles**, ve a **⚙️ Ajustes → 🔐
Administrador** y **crea tu contraseña de administrador**. A partir de ahí, borrar un perfil
(y ver los correos) pedirá esa contraseña. *Sin compartir (uso solo local) no hace falta.*

### 🔑 Si un amigo olvida su PIN

En la pantalla del PIN hay **"¿Olvidaste tu PIN?"**: el amigo escribe su correo y le llega un
**PIN nuevo** por email. Para que esto funcione, **configura tu correo** una vez en **⚙️ Ajustes
→ 🔐 Administrador → 📤 Enviar correos**:

- Con **Gmail**: servidor `smtp.gmail.com`, puerto `465` (marca "conexión segura"), tu correo,
  y una **contraseña de aplicación** (Google → Seguridad → Verificación en 2 pasos → Contraseñas
  de aplicaciones). No uses tu contraseña normal.
- Esa misma configuración te sirve para **escribirles tú** a tus amigos más adelante.

---

## 👤 Perfiles (cuentas) sincronizados

Al abrir la app eliges un **perfil**. Tus **chats, memoria, personas y ajustes** se guardan
en **tu PC** (carpeta `data/`), así son **los mismos en la PC y el celular** (ambos usan tu
PC por Tailscale). Sin Google, sin nube: local y privado.

- **Crear perfil**: nombre, avatar (emoji) y **PIN opcional**.
- **Cambiar de perfil**: botón "Cambiar" abajo en la barra lateral.
- **Sincronización**: escribe en la PC, entra con el mismo perfil en el celular y verás lo
  mismo (recarga para traer lo último). *Consejo: no edites a la vez en dos dispositivos.*

La app está pensada también para **móvil**: en el celular el escritorio de texto va a ancho
completo y las acciones extra se agrupan en un menú **⋯**.

---

## 📊 Documentos y auto-modelo (Fase 7)

- 🤖 **Auto-modelo**: el selector de arriba tiene **"🤖 Auto"** (por defecto). El asistente
  **elige solo el mejor modelo** para cada tarea: código → qwen2.5-coder, imágenes →
  gemma3/llava, razonamiento → qwen2.5:14b, charla simple → llama3.2:1b, etc. Cada respuesta
  muestra qué modelo usó. También puedes fijar uno manualmente.
- 📄 **Crear documentos**: toca **📄** en la barra, elige **Presentación / Word / PDF**, y
  describe el tema. El asistente redacta el contenido, genera una **portada** con tu IA local
  y arma el archivo con diseño (colores, tipografía). Aparece un botón para **descargarlo**.
  - *Nota de hardware:* la portada usa la GPU (8 GB) igual que el chat; si la GPU está muy
    ocupada puede saltarse la portada (el documento se crea igual). Si las imágenes empiezan a
    fallar tras mucho uso, reinicia `imagenes.bat`.

## 🎨 Documentos ricos, encuestas y tutor (Fase 8)

- 📄 **Más formatos y mejor diseño**: en el modo **📄** ahora eliges **Presentación / Word /
  PDF / Excel / Póster**. Para Word y PDF hay **plantillas** (General, CV, Carta, Receta,
  Guion, Blog). Las presentaciones usan **temas variados** (cambian de color/tipografía en
  cada una) y llevan **imágenes dentro** de las diapositivas (portada + 2-3 clave), no solo la
  portada. El contenido lo redacta el modelo más capaz (qwen2.5:14b).
  - *Hardware:* generar varias imágenes usa la GPU (8 GB); el asistente libera primero los
    modelos de chat para que quepan. Si las imágenes empiezan a fallar tras mucho uso, reinicia
    `imagenes.bat`.
- 📊 **Encuestas / formularios**: toca **📊**, escribe el tema y responde el formulario **dentro
  del chat** (opción única, varias, texto o escala del 1 al 5). Al enviar ves un **resumen** que
  puedes copiar.
- 📚 **Plan de estudio interactivo (tutor)**: toca **📚** y escribe un tema (p. ej.
  *"ecuaciones lineales 2x+3x-5=5x-6"*). El asistente arma un **plan por lecciones**, **busca
  videos en internet y los revisa** antes de recomendártelos (con un por qué), y luego te
  **enseña paso a paso como un profesor**: te explica, te pregunta y avanza a tu ritmo. Después
  de empezar, sigue la clase escribiendo normal ("siguiente", "no entendí", "otro ejemplo").
  - 🎨 **Explica de forma visual dentro del chat**: fórmulas como **matemáticas de verdad**,
    **gráficas de funciones y datos** (parábolas, rectas, gráficas de física…), **dibujos** de
    geometría y física (fuerzas, figuras), y **diagramas** de flujo/mapas de conceptos. El tutor
    elige el dibujo que mejor explique. Funciona en cualquier respuesta, no solo en el tutor.
  - *Nota:* el tutor usa el modelo más capaz (qwen2.5:14b), que en esta PC es **lento**; ten
    paciencia con cada respuesta.

## 🖥️ App de escritorio (.exe)

Puedes abrir el asistente en su **propia ventana** (como un programa) con **`escritorio.bat`**
(usa Electron; necesita Ollama corriendo, e `imagenes.bat` para imágenes/voz/documentos).

> Para generar un **`.exe` instalable** aparte, ejecuta `npm run exe`. En algunas PC el
> antivirus de Windows bloquea el empaquetado (error `EPERM`); si pasa, reintenta, o excluye la
> carpeta del proyecto en Windows Defender, o abre la terminal **como administrador**.

## 💻 Instalarlo como app en la PC

En Chrome/Edge, con la app abierta, haz clic en el icono de **instalar** (a la
derecha de la barra de direcciones). Se abre en su propia ventana, como un programa.

---

## 🧠 Modelos (el "cerebro")

El selector de arriba lista todos tus modelos de Ollama. Recomendaciones:

| Para… | Modelo | Nota |
|---|---|---|
| Chat + imágenes (por defecto) | `gemma3:4b` | Buen equilibrio. Visión ~30-40s por imagen. |
| **Imágenes más rápidas** | `moondream` | Más chico y veloz. Instálalo con: `ollama pull moondream` |
| Solo chat, más listo | `llama3.1:8b` | No ve imágenes. |
| Programar | `qwen2.5-coder:7b` | No ve imágenes. |

Cambiar de modelo: menú de arriba, o **⚙️ Ajustes → Modelo**.

---

## ✨ Funciones (Fase 2)

- 🧠 **Memoria**: recuerda datos tuyos entre conversaciones (nombre, gustos, trabajo…).
  Los detecta solo y también puedes verlos/editarlos en el botón **🧠**. Se usa en
  todos los chats.
- 🎭 **Personas / roles**: cambia rápido entre General, Traductor, Programador, Chef,
  Tutor… o crea las tuyas (⚙️ Ajustes). Selector arriba, junto al modelo.
- 📄 **Leer archivos y PDFs**: adjunta un `.pdf`, `.txt`, `.md`, `.csv`… y pregunta
  sobre su contenido.
- 💬 **Mejoras de chat**: copiar respuestas y bloques de código, **regenerar**,
  **editar** tu mensaje y reenviar, **buscar** en el historial, **renombrar** chats
  (doble clic) y **títulos automáticos**.
- 💾 **Respaldo**: exporta/importa todo (conversaciones, memoria, personas, ajustes)
  desde ⚙️ Ajustes.

## 🌐 Funciones (Fase 3)

- 🌐 **Búsqueda en internet**: activa el botón **🌐** en la barra de escritura y el
  asistente **busca en la web** (DuckDuckGo, con respaldo de Wikipedia), lee páginas y
  responde **citando las fuentes** con enlaces. Gratis y sin API key. Solo usa internet
  cuando activas 🌐.
- 🎚️ **Barrita de esfuerzo**: aparece al activar 🌐. Controla qué tan a fondo busca —
  **Rápido** (3 resultados, solo resúmenes) → **Profundo** (varias consultas, 8
  resultados, lee hasta 4 páginas).
- 📅 **Sabe la fecha y hora** actual (útil para "últimas noticias", "hoy"…).
- ⚡ **Estadísticas**: cada respuesta muestra velocidad (tokens/seg) y tiempo.
- 📥 **Exportar chat a Markdown**: botón 📥 arriba para guardar la conversación activa.
- ✨ **Prompts guardados**: botón ✨ con plantillas reutilizables (Resume, Corrige,
  Explícalo simple, Traduce…). Créalos/edítalos en ⚙️ Ajustes.

## 🎨 Generar imágenes (Fase 4)

El asistente puede **crear imágenes** con tu descripción, **100% local en tu GPU AMD**
(Stable Diffusion / sd-turbo, gratis y privado). Genera un 512×512 en **~5 segundos**.

**Requiere arrancar el servidor de imágenes** (usa la GPU, por eso va aparte):

1. Doble clic en **`imagenes.bat`** (la primera vez descarga el modelo ~2.5 GB).
   Espera a ver *"Modelo listo."*.
2. En la app, toca el botón **🎨** de la barra de escritura.
3. Ajusta la **Calidad** (barrita: Rápida → Detallada) y describe la imagen.
4. Pulsa **Generar**. La imagen aparece en el chat (Copiar / Regenerar).

> Nota: comparte la GPU (8 GB) con el chat. El servidor de imágenes baja cada parte del
> modelo a la RAM y solo sube a la GPU la que usa, así cabe todo. Si Ollama tiene un modelo
> muy grande cargado a la vez, puede faltar memoria; deja pasar unos minutos (Ollama libera
> solo) o usa un modelo de chat más chico.

## ⚙️ Ajustes

Botón **⚙️** arriba a la derecha:
- **Modelo** por defecto.
- **Memoria automática** (activar/desactivar la detección automática).
- **Esfuerzo de búsqueda web** por defecto.
- **Personas / roles**: crear, editar y borrar.
- **Prompts guardados**: crear, editar y borrar.
- **Tema** claro / oscuro.
- **Respaldo**: exportar / importar.

Tus conversaciones, memoria y personas se guardan en el navegador (localStorage),
en tu equipo. Nada sale de tu PC.

---

## 🔧 Detalles técnicos

- **Frontend:** Vite + React + TypeScript + Tailwind CSS.
- **IA:** Ollama en `http://localhost:11434`. La app usa un **proxy** (`/api`)
  configurado en `vite.config.ts`, así el celular solo necesita una dirección.
- **Imágenes:** se reescalan a máx. 1280 px y se envían como base64 al modelo.
- **PDFs:** el texto se extrae en el navegador con `pdfjs-dist` (máx. 20.000
  caracteres por archivo).
- **Memoria:** se guarda en `localStorage` y se inyecta al *system prompt*.
- **Búsqueda web:** un middleware en el propio servidor de Vite (`websearch-plugin.ts`)
  expone `/websearch` y `/webfetch` (parseo con `cheerio`). La app orquesta la búsqueda y
  le pasa los resultados al modelo (no depende del *tool-calling* del modelo).
- **Imágenes (generación):** servidor Python aparte en `sd-server/` (Flask + `diffusers`
  + `torch-directml`, modelo `sd-turbo`). La app llega por el proxy `/sd` de Vite. Usa un
  venv con **Python 3.10** (`sd-server/.venv`), independiente del Python del sistema.

---

## 🚀 Ideas para más adelante (Fase 5+)

- 🎙️ Voz (dictar y que responda hablando).
- 🖼️ Más modelos de imagen y opciones (tamaño, semilla, negativos).
- 📦 Empaquetarlo como `.exe` de escritorio.
