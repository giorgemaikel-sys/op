import { complete } from './ollama'

export interface ImageResult {
  image: string // base64 PNG (sin prefijo)
  seconds: number
}

/** Convierte una petición corta (en cualquier idioma) en un prompt rico en INGLÉS
 *  para Stable Diffusion: más detalle, estilo y calidad → imágenes mejores y más fieles. */
export async function enhanceImagePrompt(desc: string, model: string): Promise<string> {
  const d = desc.trim()
  if (!d || !model) return d
  try {
    const raw = await complete({
      model,
      system:
        'You expand a short image request (any language) into ONE detailed English prompt for a ' +
        'Stable Diffusion image generator. Describe the subject vividly, then add style, lighting, ' +
        'composition, colors and quality terms (e.g. "highly detailed, sharp focus, professional ' +
        'lighting, intricate, 8k"). Keep the user\'s intent exactly. Under 60 words. ' +
        'Output ONLY the prompt — no quotes, no labels, no negatives, no explanation.',
      prompt: d,
      numPredict: 150,
    })
    const out = raw
      .trim()
      .replace(/^["'`]+|["'`]+$/g, '')
      .replace(/^(prompt|image)\s*[:：]/i, '')
      .trim()
    return out.length > 4 ? out : d
  } catch {
    return d
  }
}

export interface ImageHealth {
  ready: boolean
  loading: boolean
  error: string | null
  device?: string
  model?: string
}

/** Estado del servidor de imágenes (o null si no responde). */
export async function imageServerHealth(): Promise<ImageHealth | null> {
  try {
    const res = await fetch('/sd/health')
    if (!res.ok) return null
    return (await res.json()) as ImageHealth
  } catch {
    return null
  }
}

/** Genera una imagen a partir de un prompt (POST /sd/generate). */
export async function generateImage(opts: {
  prompt: string
  steps?: number
  width?: number
  height?: number
  seed?: number
  negative?: string
  signal?: AbortSignal
}): Promise<ImageResult> {
  const res = await fetch('/sd/generate', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      prompt: opts.prompt,
      steps: opts.steps ?? 2,
      width: opts.width ?? 512,
      height: opts.height ?? 512,
      seed: opts.seed,
      negative_prompt: opts.negative,
    }),
    signal: opts.signal,
  })
  const data = await res.json().catch(() => ({}))
  if (!res.ok || data.error) {
    throw new Error(data.error || `Servidor de imágenes: error ${res.status}`)
  }
  return { image: data.image, seconds: data.seconds }
}
