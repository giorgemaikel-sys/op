import json, urllib.request, base64, os
def build(payload, out):
    req = urllib.request.Request("http://127.0.0.1:7861/doc/build",
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={"Content-Type":"application/json; charset=utf-8"})
    r = urllib.request.urlopen(req, timeout=30)
    d = json.load(r)
    if "base64" not in d:
        print(out, "ERROR:", d); return
    blob = base64.b64decode(d["base64"])
    open(out,"wb").write(blob)
    magic = blob[:4]
    ok = (magic[:2]==b'PK') if out.endswith(('pptx','docx')) else (magic==b'%PDF')
    print(f"{out}: {len(blob)} bytes, filename={d['filename']}, valido={ok}")

build({"type":"pptx","title":"Los Planetas","content":{"subtitle":"El Sistema Solar","slides":[
    {"title":"Introducción","bullets":["Ocho planetas","Orbitan el Sol","Dos categorías"]},
    {"title":"Planetas rocosos","bullets":["Mercurio","Venus","La Tierra","Marte"]}]}}, "t.pptx")
build({"type":"docx","title":"Informe Técnico","content":{"subtitle":"Versión de prueba","sections":[
    {"heading":"Resumen","paragraphs":["Este es un párrafo de introducción con acentuación."],"bullets":["Rápido","Económico"]}]}}, "t.docx")
build({"type":"pdf","title":"Reporte Anual","content":{"subtitle":"Sección de prueba","sections":[
    {"heading":"Introducción","paragraphs":["Contenido del informe en español."],"bullets":["Uno","Dos"]}]}}, "t.pdf")
