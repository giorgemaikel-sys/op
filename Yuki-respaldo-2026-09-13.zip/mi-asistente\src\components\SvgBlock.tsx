import { useMemo } from 'react'
import DOMPurify from 'dompurify'

/**
 * Dibuja un SVG generado por el modelo (diagramas de física, geometría, etc.).
 * Se sanea con DOMPurify (perfil SVG) para quitar scripts/eventos: seguro incluso
 * cuando el asistente se comparte con amigos. Es tolerante al streaming.
 */
export default function SvgBlock({ code }: { code: string }) {
  const clean = useMemo(() => {
    const src = code.trim()
    if (!/<svg[\s>]/i.test(src) || !/<\/svg>/i.test(src)) return null
    try {
      return DOMPurify.sanitize(src, {
        USE_PROFILES: { svg: true, svgFilters: true },
      })
    } catch {
      return null
    }
  }, [code])

  if (!clean) {
    return (
      <pre className="text-xs overflow-x-auto rounded-lg bg-zinc-100 dark:bg-zinc-800 p-2 my-2 opacity-70">
        {code.trim() || '…'}
      </pre>
    )
  }

  return (
    <div
      className="my-2 flex justify-center overflow-x-auto rounded-xl border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-900/60 p-2 [&_svg]:max-w-full [&_svg]:h-auto"
      dangerouslySetInnerHTML={{ __html: clean }}
    />
  )
}
