import type { ChatDoc } from './types'
import * as pdfjs from 'pdfjs-dist'
import workerUrl from 'pdfjs-dist/build/pdf.worker.min.mjs?url'

pdfjs.GlobalWorkerOptions.workerSrc = workerUrl

const MAX_CHARS = 20000

const TEXT_EXTS = ['.txt', '.md', '.markdown', '.csv', '.json', '.log', '.tsv', '.xml', '.yml', '.yaml']

export function isImage(file: File): boolean {
  return file.type.startsWith('image/')
}

export function isSupportedDoc(file: File): boolean {
  const name = file.name.toLowerCase()
  if (file.type === 'application/pdf' || name.endsWith('.pdf')) return true
  if (file.type.startsWith('text/')) return true
  return TEXT_EXTS.some((ext) => name.endsWith(ext))
}

function trimDoc(name: string, text: string): ChatDoc {
  // normaliza espacios raros de PDF y colapsa blancos excesivos sin romper palabras
  const clean = text
    .replace(/ /g, ' ')
    .replace(/[ \t]{2,}/g, ' ')
    .replace(/\n{3,}/g, '\n\n')
    .trim()
  const truncated = clean.length > MAX_CHARS
  return { name, text: truncated ? clean.slice(0, MAX_CHARS) : clean, truncated }
}

/** Extrae el texto de un PDF o de un archivo de texto plano. */
export async function extractText(file: File): Promise<ChatDoc> {
  const name = file.name
  const isPdf = file.type === 'application/pdf' || name.toLowerCase().endsWith('.pdf')

  if (isPdf) {
    const buf = await file.arrayBuffer()
    const pdf = await pdfjs.getDocument({ data: buf }).promise
    let text = ''
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i)
      const content = await page.getTextContent()
      const pageText = content.items
        .map((it: any) => ('str' in it ? it.str : ''))
        .join(' ')
      text += pageText + '\n\n'
      if (text.length > MAX_CHARS) break
    }
    return trimDoc(name, text)
  }

  const text = await file.text()
  return trimDoc(name, text)
}
