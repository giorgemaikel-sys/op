import type { PromptTemplate } from './types'

const PROMPTS_KEY = 'asistente:prompts'

export const defaultPrompts: PromptTemplate[] = [
  {
    id: 'resume',
    name: 'Resume esto',
    text: 'Resume el siguiente texto en pocas frases claras:\n\n',
  },
  {
    id: 'ortografia',
    name: 'Corrige ortografía',
    text: 'Corrige la ortografía y la gramática del siguiente texto, manteniendo el sentido:\n\n',
  },
  {
    id: 'simple',
    name: 'Explícalo simple',
    text: 'Explícame de forma sencilla, como a un principiante:\n\n',
  },
  {
    id: 'traduce',
    name: 'Traduce al inglés',
    text: 'Traduce al inglés el siguiente texto:\n\n',
  },
]

export function loadPrompts(): PromptTemplate[] {
  try {
    const raw = localStorage.getItem(PROMPTS_KEY)
    if (!raw) return [...defaultPrompts]
    const parsed = JSON.parse(raw)
    return Array.isArray(parsed) ? (parsed as PromptTemplate[]) : [...defaultPrompts]
  } catch {
    return [...defaultPrompts]
  }
}

export function savePrompts(prompts: PromptTemplate[]) {
  try {
    localStorage.setItem(PROMPTS_KEY, JSON.stringify(prompts))
  } catch {
    // ignorar
  }
}
