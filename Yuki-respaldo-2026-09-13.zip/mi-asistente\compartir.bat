@echo off
setlocal
title Compartir el Asistente (internet)
cd /d "%~dp0"

echo ================================================
echo   Compartir tu Asistente con amigos (internet)
echo ================================================
echo.
echo  IMPORTANTE: deja corriendo start.bat en OTRA ventana
echo  (y imagenes.bat si quieres imagenes / voz / documentos).
echo.
echo  Usa una contrasena simple (letras y numeros, sin espacios).
echo.

set "PASS="
set /p "PASS=Escribe una CONTRASENA para tus amigos: "
if "%PASS%"=="" (
  echo.
  echo  No escribiste contrasena. Cancelado.
  pause
  exit /b
)

if not exist "data" mkdir "data"
> "data\share.txt" echo %PASS%
echo.
echo  Contrasena guardada.
echo.

REM Buscar cloudflared (en el PATH o en Archivos de programa)
set "CF="
where cloudflared >nul 2>&1 && set "CF=cloudflared"
if not defined CF if exist "C:\Program Files (x86)\cloudflared\cloudflared.exe" set "CF=C:\Program Files (x86)\cloudflared\cloudflared.exe"
if not defined CF if exist "C:\Program Files\cloudflared\cloudflared.exe" set "CF=C:\Program Files\cloudflared\cloudflared.exe"
if not defined CF (
  echo  No encontre cloudflared. Instalalo una vez con:
  echo      winget install Cloudflare.cloudflared
  echo  y vuelve a ejecutar este archivo.
  pause
  exit /b
)

echo  Creando el enlace publico (espera unos segundos)...
echo.
echo  Abajo aparecera una linea como:
echo      https://algo-algo-algo.trycloudflare.com
echo.
echo  Comparte con tus amigos ESE ENLACE y la CONTRASENA.
echo  Cada amigo abre el enlace, pone la contrasena y crea su perfil.
echo.
echo  DEJA ESTA VENTANA ABIERTA mientras quieras compartirlo.
echo  (Nota: cada vez que lo abres, el enlace CAMBIA.)
echo ================================================
echo.

"%CF%" tunnel --url http://localhost:5173
pause
