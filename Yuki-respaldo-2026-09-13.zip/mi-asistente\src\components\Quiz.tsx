import { useState } from 'react'
import type { Quiz as QuizT } from '../lib/types'

/** Examen interactivo: elige respuestas, corrige y muestra la nota + explicaciones. */
export default function Quiz({ quiz }: { quiz: QuizT }) {
  const [answers, setAnswers] = useState<(number | null)[]>(
    () => quiz.questions.map(() => null),
  )
  const [graded, setGraded] = useState(false)

  function pick(qi: number, oi: number) {
    if (graded) return
    setAnswers((a) => a.map((x, i) => (i === qi ? oi : x)))
  }

  const score = quiz.questions.reduce(
    (acc, q, i) => acc + (answers[i] === q.answer ? 1 : 0),
    0,
  )
  const allAnswered = answers.every((a) => a !== null)

  return (
    <div className="mt-1 w-full rounded-xl border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-900/60 p-3">
      <p className="font-semibold text-sm mb-1">📝 {quiz.title}</p>

      {graded && (
        <div className="mb-3 rounded-lg bg-indigo-50 dark:bg-indigo-950/40 p-2 text-center">
          <p className="text-lg font-bold">
            {score} / {quiz.questions.length}
          </p>
          <p className="text-xs text-zinc-500">
            {score === quiz.questions.length
              ? '¡Perfecto! 🎉'
              : score >= quiz.questions.length / 2
                ? '¡Bien! Sigue practicando.'
                : 'A repasar un poco más 💪'}
          </p>
        </div>
      )}

      <div className="space-y-3">
        {quiz.questions.map((q, qi) => (
          <div key={qi}>
            <p className="text-sm font-medium mb-1">
              {qi + 1}. {q.q}
            </p>
            <div className="space-y-1">
              {q.options.map((opt, oi) => {
                const chosen = answers[qi] === oi
                const isCorrect = q.answer === oi
                let cls =
                  'w-full text-left text-sm rounded-lg px-3 py-1.5 border transition-colors '
                if (graded) {
                  if (isCorrect)
                    cls +=
                      'border-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300'
                  else if (chosen)
                    cls +=
                      'border-rose-400 bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300'
                  else cls += 'border-zinc-200 dark:border-zinc-700'
                } else {
                  cls += chosen
                    ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-950/40'
                    : 'border-zinc-200 dark:border-zinc-700 hover:border-indigo-300'
                }
                return (
                  <button key={oi} onClick={() => pick(qi, oi)} className={cls}>
                    {opt}
                    {graded && isCorrect && ' ✓'}
                    {graded && chosen && !isCorrect && ' ✗'}
                  </button>
                )
              })}
            </div>
            {graded && q.explanation && (
              <p className="text-xs text-zinc-500 mt-1 pl-1">💡 {q.explanation}</p>
            )}
          </div>
        ))}
      </div>

      {!graded ? (
        <button
          onClick={() => setGraded(true)}
          disabled={!allAnswered}
          className="mt-3 text-sm px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white disabled:opacity-40"
        >
          Corregir
        </button>
      ) : (
        <button
          onClick={() => {
            setAnswers(quiz.questions.map(() => null))
            setGraded(false)
          }}
          className="mt-3 text-sm px-3 py-1.5 rounded-lg bg-zinc-200 dark:bg-zinc-700"
        >
          Reintentar
        </button>
      )}
    </div>
  )
}
