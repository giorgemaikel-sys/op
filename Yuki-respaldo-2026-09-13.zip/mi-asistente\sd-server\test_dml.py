"""Prueba mínima: ¿funciona torch-directml en esta GPU AMD?"""
import torch
import torch_directml

dml = torch_directml.device()
print("device:", dml)
a = torch.randn(512, 512, device=dml)
b = torch.randn(512, 512, device=dml)
c = (a @ b).cpu()
print("matmul ok, suma:", float(c.sum()))
print("DIRECTML_OK")
