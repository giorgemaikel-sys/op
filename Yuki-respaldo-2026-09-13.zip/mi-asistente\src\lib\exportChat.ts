import type { Conversation } from './types'

/** Convierte una conversación a Markdown legible. */
export function chatToMarkdown(conv: Conversation): string {
  const lines: string[] = []
  lines.push(`# ${conv.title || 'Conversación'}`)
  lines.push('')
  lines.push(`_Exportado: ${new Date().toLocaleString()}_`)
  lines.push('')
  for (const m of conv.messages) {
    if (m.role === 'user') lines.push('## 🧑 Tú')
    else if (m.role === 'assistant') lines.push('## 🤖 Asistente')
    else continue
    lines.push('')
    if (m.images?.length) lines.push(`*(${m.images.length} imagen(es) adjunta(s))*`)
    if (m.docs?.length)
      lines.push(`*(archivos: ${m.docs.map((d) => d.name).join(', ')})*`)
    lines.push(m.content || '')
    if (m.sources?.length) {
      lines.push('')
      lines.push('**Fuentes:**')
      m.sources.forEach((s, i) => lines.push(`${i + 1}. [${s.title}](${s.url})`))
    }
    lines.push('')
  }
  return lines.join('\n')
}

/** Descarga la conversación activa como archivo .md. */
export function exportChatMarkdown(conv: Conversation) {
  const md = chatToMarkdown(conv)
  const blob = new Blob([md], { type: 'text/markdown;charset=utf-8' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  const safe = (conv.title || 'chat')
    .replace(/[^\w\s-]+/g, '')
    .trim()
    .replace(/\s+/g, '_')
    .slice(0, 40)
  a.href = url
  a.download = `${safe || 'chat'}.md`
  document.body.appendChild(a)
  a.click()
  a.remove()
  setTimeout(() => URL.revokeObjectURL(url), 1000)
}
