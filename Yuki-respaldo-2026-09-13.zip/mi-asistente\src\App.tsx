import { useEffect, useMemo, useRef, useState, lazy, Suspense } from 'react'
import type {
  ChatDoc,
  ChatImage,
  ChatMessage,
  Conversation,
  MemoryItem,
  Persona,
  PromptTemplate,
  Settings,
} from './lib/types'
import {
  chat,
  complete,
  generateTitle,
  listModels,
  unloadModels,
  type OllamaModel,
} from './lib/ollama'
import { routeModel, pickModelForRole } from './lib/router'
import {
  docSystemPrompt,
  extractJson,
  fallbackFromMarkdown,
  buildDoc,
  buildPptxContent,
  type DocType,
  type DocTemplate,
} from './lib/docs'
import { makePlan, findVideos, tutorSystemPrompt } from './lib/study'
import { makeSurvey } from './lib/survey'
import { makeFlashcards } from './lib/flashcards'
import { makeQuiz } from './lib/quiz'
import { fetchPage } from './lib/websearch'
import { topicPrompt } from './lib/context'
import { emptyStats, recordActivity } from './lib/gamification'
import type { StudyPlan, UserStats } from './lib/types'
// Paneles pesados: carga diferida (lazy) para que Yuki arranque más rápido.
const AchievementsPanel = lazy(() => import('./components/AchievementsPanel'))
const Wall = lazy(() => import('./components/Wall'))
const ServerStatus = lazy(() => import('./components/ServerStatus'))
const HelpPanel = lazy(() => import('./components/HelpPanel'))
const CodeStudio = lazy(() => import('./components/CodeStudio'))
const NotesPanel = lazy(() => import('./components/NotesPanel'))
const DesktopPets = lazy(() => import('./components/DesktopPets'))
import { useDevice } from './lib/device'
import { OwnerContext, ownerKey, type OwnerCtx } from './lib/owner'
import { defaultSettings } from './lib/storage'
import { defaultPersonas } from './lib/personas'
import { defaultPrompts } from './lib/prompts'
import {
  listProfiles,
  createProfile,
  deleteProfile,
  verifyPin,
  loadProfileData,
  saveProfileData,
  accessRequired,
  checkAccess,
  type Profile,
} from './lib/profiles'
import { buildMemoryBlock, extractMemories } from './lib/memory'
import { runResearch } from './lib/websearch'
import { generateImage, enhanceImagePrompt } from './lib/imagegen'
import { speak, stopSpeaking } from './lib/tts'
import { recordUntilSilence, transcribeBlob } from './lib/stt'
import { exportChatMarkdown } from './lib/exportChat'
import Sidebar from './components/Sidebar'
import ChatView from './components/ChatView'
import Composer, { type SendOptions } from './components/Composer'
import ModelPicker from './components/ModelPicker'
import PersonaPicker from './components/PersonaPicker'
const SettingsPanel = lazy(() => import('./components/SettingsPanel'))
const MemoryPanel = lazy(() => import('./components/MemoryPanel'))
import ProfileGate from './components/ProfileGate'
import AccessGate from './components/AccessGate'

function uid() {
  return Math.random().toString(36).slice(2) + Date.now().toString(36)
}

function pickDefaultModel(models: OllamaModel[], current: string): string {
  if (current && models.some((m) => m.name === current)) return current
  const names = models.map((m) => m.name)
  return (
    names.find((n) => n.startsWith('gemma3')) ||
    names.find((n) => n.includes('llava')) ||
    names.find((n) => n.includes('vision') || n.includes('vl')) ||
    names[0] ||
    ''
  )
}

/** Bloque de fecha/hora actual que se añade al system prompt. */
function buildDateBlock(): string {
  const s = new Date().toLocaleString('es-ES', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  })
  return `\n\n[Contexto] Fecha y hora actual: ${s}.`
}

/** Capacidad de dibujar en el chat (disponible en cualquier conversación). */
/** Aclara (amt>0) u oscurece (amt<0) un color hex. */
function shadeHex(hex: string, amt: number): string {
  const h = hex.replace('#', '')
  const full = h.length === 3 ? h.split('').map((c) => c + c).join('') : h
  const n = parseInt(full, 16)
  let r = (n >> 16) & 255
  let g = (n >> 8) & 255
  let b = n & 255
  const mix = amt > 0 ? 255 : 0
  const t = Math.abs(amt)
  r = Math.round(r + (mix - r) * t)
  g = Math.round(g + (mix - g) * t)
  b = Math.round(b + (mix - b) * t)
  return '#' + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)
}

function buildVisualBlock(): string {
  return `\n\n[Puedes DIBUJAR en el chat cuando ayude a explicar]
- Fórmulas: en LaTeX con $...$ (en línea) o $$...$$ (centrado).
- Gráficas de funciones o datos: un bloque \`\`\`plot con líneas "y = expresión", "x: min..max" y/o "data: x,y x,y". Ej: y = x^2. Usa ^ para potencias y sin, cos, sqrt, ln, pi.
- Dibujos (geometría, física, figuras): un bloque \`\`\`svg con un SVG simple y válido (viewBox, líneas, polígonos, texto).
- Diagramas de procesos o mapas de conceptos: un bloque \`\`\`mermaid (flowchart).
- Código Python EJECUTABLE: cuando el usuario pida cálculos, datos o un programa en Python, ponlo en un bloque \`\`\`python autónomo (sin librerías raras; puedes usar la librería estándar, y numpy/pandas/matplotlib si hacen falta). El usuario podrá tocar ▶️ Ejecutar Python para correrlo en su PC y ver el resultado; si dibujas una gráfica con matplotlib, se mostrará la imagen.
Usa estos dibujos cuando de verdad aclaren la explicación (matemáticas, física, procesos, datos); no en una charla normal.`
}

/** Instrucciones extra del modo Programador (código completo y ejecutable). */
function buildCodeBlock(): string {
  return `\n\n[Modo Programador]
- Escribe código COMPLETO y que funcione tal cual; nunca dejes partes con "..." ni "// resto igual".
- Para cualquier cosa VISUAL o INTERACTIVA (juegos, animaciones, páginas, demos), entrega UN SOLO archivo HTML autónomo dentro de un bloque \`\`\`html, con <!DOCTYPE html>, y el <style> y el <script> INCLUIDOS. Nada de librerías externas ni enlaces a CDN (no hay internet dentro del reproductor).
- Para juegos usa <canvas> + requestAnimationFrame; controles con teclado Y también con click/toque (para móvil). Incluye reinicio y marcador.
- El juego debe EMPEZAR jugando (nunca arrancar en "Game Over"), con colores visibles, y el jugador NO debe morir al instante. Dibuja el fondo, los objetos y el marcador en CADA frame.
- NO uses localStorage ni almacenamiento del navegador (guarda el puntaje en una variable); el reproductor seguro los bloquea.
- Explica en 1-2 frases y luego pon el código. El usuario podrá tocar ▶️ Ejecutar para correrlo aquí mismo.`
}

/** Instrucciones extra del modo Tutor (la PERSONA "Tutor", para aprender de verdad). */
function buildTutorBlock(): string {
  return `\n\n[Modo Tutor — enseña de verdad]
Eres un profesor particular excelente, cercano y paciente. Tu meta es que el alumno ENTIENDA, no solo darle la respuesta.
- Explica PASO A PASO, de lo simple a lo complejo, con ejemplos concretos y analogías del día a día.
- No sueltes todo de golpe: enseña una idea, y al final haz UNA pregunta corta o un mini-ejercicio para comprobar que se entendió.
- Adapta el nivel: si dice "no entiendo", explícalo más simple o con otra analogía; si va bien, sube el nivel.
- Sé MUY visual: fórmulas en $$...$$, gráficas con bloques \`\`\`plot, dibujos/figuras con \`\`\`svg y esquemas con \`\`\`mermaid cuando ayuden.
- Corrige con amabilidad; celebra los aciertos y motiva.
- Cuando termines de explicar un tema, ofrece opciones para seguir aprendiendo: "¿quieres otro ejemplo, un ejercicio, un examen (📝) o tarjetas para repasar (🃏)?".`
}

export default function App() {
  const [conversations, setConversations] = useState<Conversation[]>([])
  const [activeId, setActiveId] = useState<string | null>(null)
  const [settings, setSettings] = useState<Settings>({ ...defaultSettings })
  const [memory, setMemory] = useState<MemoryItem[]>([])
  const [personas, setPersonas] = useState<Persona[]>(() => [...defaultPersonas])
  const [prompts, setPrompts] = useState<PromptTemplate[]>(() => [...defaultPrompts])

  // Perfiles (cuentas) — datos guardados en la PC, compartidos entre dispositivos.
  const [profiles, setProfiles] = useState<Profile[]>([])
  const [activeProfile, setActiveProfile] = useState<Profile | null>(null)
  const [dataLoaded, setDataLoaded] = useState(false)
  const [profilesLoaded, setProfilesLoaded] = useState(false)
  // Acceso compartido (contraseña) cuando se comparte por internet.
  const [accessChecked, setAccessChecked] = useState(false)
  const [locked, setLocked] = useState(false)
  const [models, setModels] = useState<OllamaModel[]>([])
  const [connError, setConnError] = useState<string | null>(null)
  const [isStreaming, setIsStreaming] = useState(false)
  const [researchStatus, setResearchStatus] = useState<string | null>(null)
  const [showSettings, setShowSettings] = useState(false)
  const [showMemory, setShowMemory] = useState(false)
  const [stats, setStats] = useState<UserStats>(emptyStats())
  const [showAchievements, setShowAchievements] = useState(false)
  const [showWall, setShowWall] = useState(false)
  const [focusMode, setFocusMode] = useState(false)
  const [showServers, setShowServers] = useState(false)
  const [showHelp, setShowHelp] = useState(false)
  const [showStudio, setShowStudio] = useState(false)
  const [showNotes, setShowNotes] = useState(false)
  const [showPets, setShowPets] = useState(false)
  const [installEvt, setInstallEvt] = useState<any>(null)
  // Desbloqueo de administrador POR PERFIL (no se comparte entre perfiles).
  const [ownerPass, setOwnerPass] = useState<string | null>(null)
  useEffect(() => {
    if (!activeProfile) {
      setOwnerPass(null)
      return
    }
    try {
      setOwnerPass(localStorage.getItem(ownerKey(activeProfile.id)))
    } catch {
      setOwnerPass(null)
    }
  }, [activeProfile?.id])
  // Bichitos de escritorio: recordar si estaban activos (por perfil).
  useEffect(() => {
    if (!activeProfile) {
      setShowPets(false)
      return
    }
    try {
      setShowPets(localStorage.getItem(`asistente:bichitosOn:${activeProfile.id}`) === '1')
    } catch {
      setShowPets(false)
    }
  }, [activeProfile?.id])
  const togglePets = (on: boolean) => {
    setShowPets(on)
    try {
      if (activeProfile) localStorage.setItem(`asistente:bichitosOn:${activeProfile.id}`, on ? '1' : '0')
    } catch {
      /* noop */
    }
  }
  const ownerValue = useMemo<OwnerCtx>(
    () => ({
      ownerPass,
      unlock: (p: string) => {
        try {
          localStorage.setItem(ownerKey(activeProfile?.id), p)
        } catch {
          /* ignore */
        }
        setOwnerPass(p)
      },
      lock: () => {
        try {
          localStorage.removeItem(ownerKey(activeProfile?.id))
        } catch {
          /* ignore */
        }
        setOwnerPass(null)
      },
    }),
    [ownerPass, activeProfile?.id],
  )
  const device = useDevice()
  const touchStartX = useRef<number | null>(null)
  const touchStartY = useRef<number | null>(null)
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [input, setInput] = useState('')
  const [toast, setToast] = useState<string | null>(null)
  const [handsFree, setHandsFree] = useState(false)
  const [showHeaderMenu, setShowHeaderMenu] = useState(false)

  const abortRef = useRef<AbortController | null>(null)
  const toastTimer = useRef<number | undefined>(undefined)
  const handsFreeRef = useRef(false)

  function speakText(text: string) {
    // No leer en voz alta el razonamiento interno (<think>…</think>).
    const clean = text.replace(/<think>[\s\S]*?<\/think>/gi, '').replace(/<\/?think>/gi, '').trim()
    speak(clean || text, {
      voice: settings.ttsVoice,
      rate: settings.ttsRate,
      lang: settings.ttsLang,
    })
  }

  function showToast(msg: string) {
    setToast(msg)
    if (toastTimer.current) clearTimeout(toastTimer.current)
    toastTimer.current = window.setTimeout(() => setToast(null), 5000)
  }

  useEffect(() => {
    document.documentElement.classList.toggle('dark', settings.theme === 'dark')
  }, [settings.theme])

  // Instalar como app (PWA): capturar el evento del navegador.
  useEffect(() => {
    const onBIP = (e: any) => {
      e.preventDefault()
      setInstallEvt(e)
    }
    const onInstalled = () => setInstallEvt(null)
    window.addEventListener('beforeinstallprompt', onBIP)
    window.addEventListener('appinstalled', onInstalled)
    return () => {
      window.removeEventListener('beforeinstallprompt', onBIP)
      window.removeEventListener('appinstalled', onInstalled)
    }
  }, [])

  async function installApp() {
    if (!installEvt) return
    try {
      installEvt.prompt()
      await installEvt.userChoice
    } catch {
      /* ignore */
    }
    setInstallEvt(null)
  }

  // Color de acento (por perfil): redefine las variables de color de Tailwind.
  useEffect(() => {
    const a = settings.accent || '#4f46e5'
    const s = document.documentElement.style
    s.setProperty('--color-indigo-600', a)
    s.setProperty('--color-indigo-500', shadeHex(a, 0.12))
    s.setProperty('--color-indigo-400', shadeHex(a, 0.26))
    s.setProperty('--color-indigo-700', shadeHex(a, -0.12))
    s.setProperty('--color-violet-600', shadeHex(a, -0.05))
  }, [settings.accent])

  // Guardado en el servidor (PC), por perfil, con debounce. Solo tras cargar los datos
  // del perfil (para no sobrescribir con valores por defecto).
  useEffect(() => {
    if (!activeProfile || !dataLoaded) return
    const t = setTimeout(() => {
      saveProfileData(activeProfile.id, {
        conversations,
        memory,
        personas,
        prompts,
        settings,
        stats,
      })
    }, 500)
    return () => clearTimeout(t)
  }, [conversations, memory, personas, prompts, settings, stats, activeProfile, dataLoaded])

  const refreshModels = async () => {
    try {
      const list = await listModels()
      setModels(list)
      setConnError(null)
    } catch (e: any) {
      setConnError(e?.message ?? 'No se pudo conectar con Ollama')
    }
  }

  // Elige un modelo válido cuando ya hay lista de modelos y datos del perfil cargados.
  useEffect(() => {
    if (!dataLoaded || !models.length) return
    setSettings((s) => {
      const m = pickDefaultModel(models, s.model)
      return m === s.model ? s : { ...s, model: m }
    })
  }, [models, dataLoaded])

  async function enterProfile(p: Profile) {
    const data = await loadProfileData(p.id)
    setConversations(data.conversations ?? [])
    setActiveId((data.conversations ?? [])[0]?.id ?? null)
    setMemory(data.memory ?? [])
    setPersonas(data.personas?.length ? data.personas : [...defaultPersonas])
    setPrompts(data.prompts?.length ? data.prompts : [...defaultPrompts])
    setSettings({ ...defaultSettings, ...(data.settings ?? {}) })
    setStats({ ...emptyStats(), ...(data.stats ?? {}) })
    setActiveProfile(p)
    setDataLoaded(true)
    try {
      localStorage.setItem('asistente:lastProfile', p.id)
    } catch {
      /* ignore */
    }
  }

  async function bootProfiles() {
    const list = await listProfiles()
    setProfiles(list)
    setProfilesLoaded(true)
    let lastId = ''
    try {
      lastId = localStorage.getItem('asistente:lastProfile') || ''
    } catch {
      /* ignore */
    }
    const last = lastId ? list.find((p) => p.id === lastId) : undefined
    if (last && !last.hasPin) enterProfile(last)
  }

  async function handleCreateProfile(
    name: string,
    avatar: string,
    pin?: string,
    email?: string,
  ) {
    const p = await createProfile(name, avatar, pin, email)
    if (p) setProfiles((ps) => [...ps, p])
    return p
  }

  /** Comprueba si el asistente pide contraseña de acceso (modo compartido). */
  async function checkAccessGate() {
    try {
      const req = await accessRequired()
      if (!req) {
        setLocked(false)
        setAccessChecked(true)
        return
      }
      let stored = ''
      try {
        stored = localStorage.getItem('asistente:sharePass') || ''
      } catch {
        /* ignore */
      }
      let ok = false
      if (stored) {
        try {
          ok = await checkAccess(stored)
        } catch {
          ok = false
        }
      }
      setLocked(!ok)
    } catch {
      setLocked(true)
    } finally {
      setAccessChecked(true)
    }
  }

  function unlockAccess(pass: string) {
    try {
      localStorage.setItem('asistente:sharePass', pass)
    } catch {
      /* ignore */
    }
    setLocked(false)
  }
  async function handleDeleteProfile(id: string, ownerPass?: string) {
    const r = await deleteProfile(id, ownerPass)
    if (r.ok) setProfiles((ps) => ps.filter((p) => p.id !== id))
    return r
  }
  function switchProfile() {
    setActiveProfile(null)
    setDataLoaded(false)
    setSidebarOpen(false)
    setShowSettings(false)
    listProfiles().then(setProfiles)
  }

  useEffect(() => {
    refreshModels()
    checkAccessGate()
    bootProfiles()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const active = useMemo(
    () => conversations.find((c) => c.id === activeId) ?? null,
    [conversations, activeId],
  )

  const headerPersonaId = useMemo(() => {
    const id = active?.personaId ?? settings.activePersonaId
    return personas.some((p) => p.id === id) ? id : personas[0]?.id ?? 'general'
  }, [active, settings.activePersonaId, personas])

  function newConversation(): string {
    const conv: Conversation = {
      id: uid(),
      title: 'Nuevo chat',
      messages: [],
      createdAt: Date.now(),
      updatedAt: Date.now(),
      personaId: settings.activePersonaId,
    }
    setConversations((cs) => [conv, ...cs])
    setActiveId(conv.id)
    return conv.id
  }

  function selectConversation(id: string) {
    setActiveId(id)
    setSidebarOpen(false)
  }

  function deleteConversation(id: string) {
    setConversations((cs) => cs.filter((c) => c.id !== id))
    setActiveId((cur) => (cur === id ? null : cur))
  }

  function renameConversation(id: string, title: string) {
    setConversations((cs) => cs.map((c) => (c.id === id ? { ...c, title } : c)))
  }

  function togglePinConversation(id: string) {
    setConversations((cs) =>
      cs.map((c) => (c.id === id ? { ...c, pinned: !c.pinned } : c)),
    )
  }

  function setConversationFolder(id: string, folder: string) {
    const f = folder.trim()
    setConversations((cs) =>
      cs.map((c) => (c.id === id ? { ...c, folder: f || undefined } : c)),
    )
  }

  function changePersona(id: string) {
    setSettings((s) => ({ ...s, activePersonaId: id }))
    if (activeId) {
      setConversations((cs) =>
        cs.map((c) => (c.id === activeId ? { ...c, personaId: id } : c)),
      )
    }
  }

  function updateMessages(
    convId: string,
    updater: (msgs: ChatMessage[]) => ChatMessage[],
  ) {
    setConversations((cs) =>
      cs.map((c) =>
        c.id === convId
          ? { ...c, messages: updater(c.messages), updatedAt: Date.now() }
          : c,
      ),
    )
  }

  async function generateInto(
    convId: string,
    apiHistory: ChatMessage[],
    assistantId: string,
    personaId?: string,
    extraContext?: string,
    modelOverride?: string,
  ): Promise<string> {
    const persona =
      personas.find((p) => p.id === (personaId ?? settings.activePersonaId)) ??
      personas[0]
    const system =
      (persona?.systemPrompt ?? '') +
      buildMemoryBlock(memory) +
      buildDateBlock() +
      buildVisualBlock() +
      (persona?.id === 'programador' ? buildCodeBlock() : '') +
      (persona?.id === 'tutor' ? buildTutorBlock() : '') +
      (extraContext ?? '')

    const model = modelOverride || settings.model
    // registrar qué modelo respondió (útil en modo Auto)
    updateMessages(convId, (msgs) =>
      msgs.map((m) => (m.id === assistantId ? { ...m, model } : m)),
    )

    const ac = new AbortController()
    abortRef.current = ac
    setIsStreaming(true)
    let full = ''
    try {
      full = await chat({
        model,
        messages: apiHistory,
        systemPrompt: system,
        signal: ac.signal,
        onToken: (chunk) => {
          updateMessages(convId, (msgs) =>
            msgs.map((m) =>
              m.id === assistantId ? { ...m, content: m.content + chunk } : m,
            ),
          )
        },
        onStats: (stats) => {
          updateMessages(convId, (msgs) =>
            msgs.map((m) => (m.id === assistantId ? { ...m, stats } : m)),
          )
        },
      })
    } catch (e: any) {
      const note =
        e?.name === 'AbortError'
          ? '\n\n_(Detenido)_'
          : `\n\n⚠️ Error: ${e?.message ?? e}`
      updateMessages(convId, (msgs) =>
        msgs.map((m) =>
          m.id === assistantId ? { ...m, content: m.content + note } : m,
        ),
      )
    } finally {
      setIsStreaming(false)
      abortRef.current = null
    }
    // Auto-hablar (en manos libres se habla aparte, con espera).
    if (settings.autoSpeak && !handsFreeRef.current && full.trim()) {
      speakText(full)
    }
    return full
  }

  function runAutoMemory(text: string) {
    if (!settings.autoMemory || !text.trim()) return
    extractMemories(text, memory, settings.model)
      .then((news) => {
        if (!news.length) return
        setMemory((prev) => {
          const lower = prev.map((m) => m.text.toLowerCase())
          const fresh = news
            .filter((t) => !lower.includes(t.toLowerCase()))
            .map((t) => ({ id: uid(), text: t, createdAt: Date.now(), auto: true }))
          if (!fresh.length) return prev
          showToast('🧠 Recordé: ' + fresh.map((f) => f.text).join(' · '))
          return [...fresh, ...prev]
        })
      })
      .catch(() => {})
  }

  /** Genera una imagen (usa el servidor local, no Ollama). */
  async function generateImageMessage(
    text: string,
    img: {
      steps: number
      width: number
      height: number
      seed?: number
      negative?: string
    },
  ) {
    let convId = activeId
    const existing = conversations.find((c) => c.id === convId)
    const prevMessages = existing?.messages ?? []
    if (!convId) convId = newConversation()

    const userMsg: ChatMessage = {
      id: uid(),
      role: 'user',
      content: text,
      createdAt: Date.now(),
    }
    const assistantMsg: ChatMessage = {
      id: uid(),
      role: 'assistant',
      content: '',
      createdAt: Date.now(),
    }
    const wasFirst = prevMessages.length === 0
    setConversations((cs) =>
      cs.map((c) => {
        if (c.id !== convId) return c
        const title =
          wasFirst && text.trim() ? '🎨 ' + text.trim().slice(0, 40) : c.title
        return {
          ...c,
          title,
          messages: [...c.messages, userMsg, assistantMsg],
          updatedAt: Date.now(),
        }
      }),
    )

    setIsStreaming(true)
    try {
      // 1) Mejorar el prompt (traducir + añadir detalle/estilo/calidad) con el modelo de chat.
      setResearchStatus('🎨 Mejorando la descripción…')
      const promptModel =
        (settings.autoModel ? pickModelForRole('general', models) : settings.model) ||
        settings.model
      const enhanced = await enhanceImagePrompt(text, promptModel)
      // 2) Liberar la GPU (descargar modelos de chat) para que Stable Diffusion
      // tenga VRAM en la tarjeta de 8GB (si no, da error 500 por falta de memoria).
      setResearchStatus('🎨 Liberando la GPU…')
      await unloadModels()
      setResearchStatus('🎨 Generando imagen…')
      const result = await generateImage({
        prompt: enhanced,
        steps: img.steps,
        width: img.width,
        height: img.height,
        seed: img.seed,
        negative: img.negative,
      })
      updateMessages(convId, (msgs) =>
        msgs.map((m) =>
          m.id === assistantMsg.id
            ? {
                ...m,
                content:
                  enhanced && enhanced !== text.trim()
                    ? `🎨 _${enhanced}_\n\n_Generada en ${result.seconds}s_`
                    : `_Imagen generada en ${result.seconds}s_`,
                images: [{ data: result.image, mime: 'image/png' }],
              }
            : m,
        ),
      )
    } catch (e: any) {
      updateMessages(convId, (msgs) =>
        msgs.map((m) =>
          m.id === assistantMsg.id
            ? {
                ...m,
                content: `⚠️ No pude generar la imagen. Asegúrate de que el servidor de imágenes esté corriendo (ejecuta \`imagenes.bat\`).\n\nDetalle: ${e?.message ?? e}`,
              }
            : m,
        ),
      )
    } finally {
      setIsStreaming(false)
      setResearchStatus(null)
    }
  }

  /** Crea un documento con diseño (temas variados) e imágenes (portada + clave). */
  async function generateDocMessage(
    topic: string,
    type: DocType,
    template: DocTemplate = 'general',
  ) {
    const ctx = recentContext()
    let convId = activeId
    const existing = conversations.find((c) => c.id === convId)
    const prevMessages = existing?.messages ?? []
    if (!convId) convId = newConversation()

    const userMsg: ChatMessage = {
      id: uid(),
      role: 'user',
      content: topic,
      createdAt: Date.now(),
    }
    const assistantMsg: ChatMessage = {
      id: uid(),
      role: 'assistant',
      content: '',
      createdAt: Date.now(),
    }
    const wasFirst = prevMessages.length === 0
    const typeLabel =
      type === 'pptx'
        ? 'Presentación'
        : type === 'docx'
          ? 'Word'
          : type === 'pdf'
            ? 'PDF'
            : type === 'xlsx'
              ? 'Excel'
              : 'Infografía'
    setConversations((cs) =>
      cs.map((c) => {
        if (c.id !== convId) return c
        const title =
          wasFirst && topic.trim() ? `📄 ${topic.trim().slice(0, 40)}` : c.title
        return {
          ...c,
          title,
          messages: [...c.messages, userMsg, assistantMsg],
          updatedAt: Date.now(),
        }
      }),
    )

    setIsStreaming(true)
    try {
      // 1. Contenido PRIMERO. Modelo GENERAL (8B): rápido y de buena calidad.
      setResearchStatus('🖋️ Redactando el contenido…')
      const model =
        (settings.autoModel
          ? pickModelForRole('general', models) || pickModelForRole('reasoning', models)
          : settings.model) || settings.model
      let content: any
      if (type === 'pptx') {
        // Presentación POR PARTES: esquema + lotes cortos, así ninguna petición
        // supera el límite de tiempo del túnel de Cloudflare (evita el error 524).
        content = await buildPptxContent(topic, ctx, model, setResearchStatus)
      } else {
        const raw = await complete({
          model,
          system: docSystemPrompt(type, template),
          prompt: topicPrompt(topic, ctx),
          format: 'json',
        })
        content = extractJson(raw)
        if (!content || (!content.slides && !content.sections && !content.sheets)) {
          content = fallbackFromMarkdown(type, topic, raw)
        }
      }
      const title = (content.title as string) || topic

      // 2. Imágenes (según el tipo). Liberamos la GPU antes (VRAM de 8GB).
      const wantsCover = type !== 'xlsx'
      let cover: string | undefined
      if (wantsCover) {
        setResearchStatus('🎨 Liberando la GPU para las imágenes…')
        await unloadModels()
        try {
          const img = await generateImage({
            prompt:
              type === 'poster'
                ? `${topic}, infografía llamativa, ilustración plana, colorido`
                : `${topic}, ilustración de portada, arte digital, colorido`,
            steps: settings.imageSteps,
          })
          cover = img.image
        } catch {
          /* sin portada si el servidor de imágenes no está disponible */
        }

        // Imágenes dentro de la presentación (solo las diapositivas clave).
        if (type === 'pptx' && Array.isArray(content.slides)) {
          const keySlides = content.slides
            .filter((s: any) => s && s.image_prompt)
            .slice(0, 3)
          for (let i = 0; i < keySlides.length; i++) {
            setResearchStatus(`🎨 Imagen ${i + 1} de ${keySlides.length}…`)
            try {
              const im = await generateImage({
                prompt: `${keySlides[i].image_prompt}, digital illustration, clean`,
                steps: settings.imageSteps,
              })
              keySlides[i].image = im.image
            } catch {
              /* la diapositiva queda sin imagen */
            }
          }
        }
      }

      // 3. Construir el archivo (el servidor elige un tema al azar).
      setResearchStatus('📄 Construyendo el documento…')
      const file = await buildDoc({ type, title, content, coverImage: cover })
      updateMessages(convId, (msgs) =>
        msgs.map((m) =>
          m.id === assistantMsg.id
            ? { ...m, content: `📄 **${typeLabel}** lista: _${file.filename}_`, file }
            : m,
        ),
      )
    } catch (e: any) {
      updateMessages(convId, (msgs) =>
        msgs.map((m) =>
          m.id === assistantMsg.id
            ? {
                ...m,
                content: `⚠️ No pude crear el documento. Asegúrate de que el servidor esté corriendo (\`imagenes.bat\`).\n\nDetalle: ${e?.message ?? e}`,
              }
            : m,
        ),
      )
    } finally {
      setIsStreaming(false)
      setResearchStatus(null)
    }
  }

  /** Crea una encuesta/formulario interactivo dentro del chat. */
  async function generateSurveyMessage(topic: string) {
    let convId = activeId
    const existing = conversations.find((c) => c.id === convId)
    const prevMessages = existing?.messages ?? []
    if (!convId) convId = newConversation()

    const userMsg: ChatMessage = {
      id: uid(),
      role: 'user',
      content: topic,
      createdAt: Date.now(),
    }
    const assistantMsg: ChatMessage = {
      id: uid(),
      role: 'assistant',
      content: '',
      createdAt: Date.now(),
    }
    const wasFirst = prevMessages.length === 0
    setConversations((cs) =>
      cs.map((c) => {
        if (c.id !== convId) return c
        const title =
          wasFirst && topic.trim() ? `📊 ${topic.trim().slice(0, 40)}` : c.title
        return {
          ...c,
          title,
          messages: [...c.messages, userMsg, assistantMsg],
          updatedAt: Date.now(),
        }
      }),
    )

    setIsStreaming(true)
    setResearchStatus('📊 Creando la encuesta…')
    try {
      const model =
        (settings.autoModel ? pickModelForRole('general', models) : settings.model) ||
        settings.model
      const survey = await makeSurvey(topic, model, recentContext())
      updateMessages(convId, (msgs) =>
        msgs.map((m) =>
          m.id === assistantMsg.id
            ? {
                ...m,
                content: `📊 Aquí tienes tu encuesta **${survey.title}**. Respóndela abajo:`,
                survey,
              }
            : m,
        ),
      )
    } catch (e: any) {
      updateMessages(convId, (msgs) =>
        msgs.map((m) =>
          m.id === assistantMsg.id
            ? { ...m, content: `⚠️ No pude crear la encuesta.\n\nDetalle: ${e?.message ?? e}` }
            : m,
        ),
      )
    } finally {
      setIsStreaming(false)
      setResearchStatus(null)
    }
  }

  /** Texto de los últimos mensajes de la conversación activa (para dar contexto a los modos). */
  function recentContext(limit = 6): string {
    const conv = conversations.find((c) => c.id === activeId)
    if (!conv || !conv.messages.length) return ''
    return conv.messages
      .slice(-limit)
      .map(
        (m) =>
          `${m.role === 'user' ? 'Usuario' : 'Asistente'}: ${(m.content || '').replace(/\s+/g, ' ').slice(0, 500)}`,
      )
      .filter((l) => l.length > 12)
      .join('\n')
  }

  /** Crea un mensaje del asistente con un userMsg y un assistantMsg vacío. Devuelve ids. */
  function startAssistantTurn(userText: string, titlePrefix: string) {
    let convId = activeId
    const existing = conversations.find((c) => c.id === convId)
    const prevMessages = existing?.messages ?? []
    if (!convId) convId = newConversation()
    const userMsg: ChatMessage = {
      id: uid(),
      role: 'user',
      content: userText,
      createdAt: Date.now(),
    }
    const assistantMsg: ChatMessage = {
      id: uid(),
      role: 'assistant',
      content: '',
      createdAt: Date.now(),
    }
    const wasFirst = prevMessages.length === 0
    setConversations((cs) =>
      cs.map((c) => {
        if (c.id !== convId) return c
        const title =
          wasFirst && userText.trim()
            ? `${titlePrefix} ${userText.trim().slice(0, 40)}`
            : c.title
        return {
          ...c,
          title,
          messages: [...c.messages, userMsg, assistantMsg],
          updatedAt: Date.now(),
        }
      }),
    )
    return { convId, assistantId: assistantMsg.id }
  }

  /** Genera tarjetas de estudio interactivas. */
  async function generateFlashcardsMessage(topic: string) {
    const ctx = recentContext()
    const { convId, assistantId } = startAssistantTurn(topic || '(según la conversación)', '🃏')
    setIsStreaming(true)
    setResearchStatus('🃏 Creando tarjetas…')
    try {
      const model =
        (settings.autoModel ? pickModelForRole('general', models) : settings.model) ||
        settings.model
      const set = await makeFlashcards(topic, model, ctx)
      updateMessages(convId, (msgs) =>
        msgs.map((m) =>
          m.id === assistantId
            ? { ...m, content: `🃏 Tarjetas de **${set.title}**. Toca para voltear:`, flashcards: set }
            : m,
        ),
      )
    } catch (e: any) {
      updateMessages(convId, (msgs) =>
        msgs.map((m) =>
          m.id === assistantId
            ? { ...m, content: `⚠️ No pude crear las tarjetas.\n\nDetalle: ${e?.message ?? e}` }
            : m,
        ),
      )
    } finally {
      setIsStreaming(false)
      setResearchStatus(null)
    }
  }

  /** Genera un examen/quiz interactivo. */
  async function generateQuizMessage(topic: string) {
    const ctx = recentContext()
    const { convId, assistantId } = startAssistantTurn(topic || '(según la conversación)', '📝')
    setIsStreaming(true)
    setResearchStatus('📝 Creando el examen…')
    try {
      const model =
        (settings.autoModel ? pickModelForRole('reasoning', models) : settings.model) ||
        settings.model
      const quiz = await makeQuiz(topic, model, ctx)
      updateMessages(convId, (msgs) =>
        msgs.map((m) =>
          m.id === assistantId
            ? { ...m, content: `📝 Examen de **${quiz.title}**. Responde y toca Corregir:`, quiz }
            : m,
        ),
      )
    } catch (e: any) {
      updateMessages(convId, (msgs) =>
        msgs.map((m) =>
          m.id === assistantId
            ? { ...m, content: `⚠️ No pude crear el examen.\n\nDetalle: ${e?.message ?? e}` }
            : m,
        ),
      )
    } finally {
      setIsStreaming(false)
      setResearchStatus(null)
    }
  }

  /** Resume un enlace (YouTube o página web). */
  async function summarizeUrlMessage(url: string) {
    const clean = url.trim()
    const { convId, assistantId } = startAssistantTurn(clean, '🔗')
    setIsStreaming(true)
    setResearchStatus('🔗 Leyendo el enlace…')
    const ac = new AbortController()
    abortRef.current = ac
    try {
      const page = await fetchPage(clean)
      if (!page.text || page.text.length < 40) {
        updateMessages(convId, (msgs) =>
          msgs.map((m) =>
            m.id === assistantId
              ? {
                  ...m,
                  content:
                    '⚠️ No pude leer contenido de ese enlace. Si es un video de YouTube, a veces solo puedo ver el título y la descripción.',
                }
              : m,
          ),
        )
        return
      }
      setResearchStatus('📝 Resumiendo…')
      const model =
        (settings.autoModel ? pickModelForRole('reasoning', models) || pickModelForRole('general', models) : settings.model) ||
        settings.model
      const system =
        'Resume en español el siguiente contenido de una página o video. Da un resumen claro en puntos (viñetas) con las ideas principales, y al final una frase de conclusión. Sé fiel al contenido.'
      await chat({
        model,
        systemPrompt: system,
        messages: [
          {
            id: uid(),
            role: 'user',
            content: `Título: ${page.title}\nURL: ${clean}\n\nContenido:\n${page.text.slice(0, 9000)}`,
            createdAt: Date.now(),
          },
        ],
        signal: ac.signal,
        onToken: (chunk) =>
          updateMessages(convId, (msgs) =>
            msgs.map((m) =>
              m.id === assistantId ? { ...m, content: m.content + chunk } : m,
            ),
          ),
      })
      updateMessages(convId, (msgs) =>
        msgs.map((m) =>
          m.id === assistantId
            ? { ...m, model, sources: [{ title: page.title || clean, url: clean }] }
            : m,
        ),
      )
    } catch (e: any) {
      updateMessages(convId, (msgs) =>
        msgs.map((m) =>
          m.id === assistantId
            ? { ...m, content: (m.content || '') + `\n\n⚠️ Error: ${e?.message ?? e}` }
            : m,
        ),
      )
    } finally {
      setIsStreaming(false)
      setResearchStatus(null)
      abortRef.current = null
    }
  }

  /** Genera un mapa mental (diagrama mermaid) del tema. */
  async function generateMindmapMessage(topic: string) {
    const ctx = recentContext()
    const { convId, assistantId } = startAssistantTurn(topic || '(según la conversación)', '🗺️')
    setIsStreaming(true)
    setResearchStatus('🗺️ Creando el mapa mental…')
    const ac = new AbortController()
    abortRef.current = ac
    try {
      const model =
        (settings.autoModel
          ? pickModelForRole('reasoning', models) || pickModelForRole('general', models)
          : settings.model) || settings.model
      const system = `Crea un MAPA MENTAL claro y completo del tema. Responde con 1 frase de introducción y luego SOLO un bloque \`\`\`mermaid con la sintaxis "mindmap": la primera línea es "mindmap", luego "root((Tema))" y ramas indentadas con subtemas (2 a 4 niveles, texto corto en cada nodo, en español). Ejemplo:
\`\`\`mermaid
mindmap
  root((Tema))
    Rama 1
      Subtema A
      Subtema B
    Rama 2
      Subtema C
\`\`\``
      await chat({
        model,
        systemPrompt: system,
        messages: [
          { id: uid(), role: 'user', content: topicPrompt(topic, ctx), createdAt: Date.now() },
        ],
        signal: ac.signal,
        onToken: (chunk) =>
          updateMessages(convId, (msgs) =>
            msgs.map((m) => (m.id === assistantId ? { ...m, content: m.content + chunk } : m)),
          ),
      })
      updateMessages(convId, (msgs) =>
        msgs.map((m) => (m.id === assistantId ? { ...m, model } : m)),
      )
    } catch (e: any) {
      updateMessages(convId, (msgs) =>
        msgs.map((m) =>
          m.id === assistantId
            ? { ...m, content: (m.content || '') + `\n\n⚠️ Error: ${e?.message ?? e}` }
            : m,
        ),
      )
    } finally {
      setIsStreaming(false)
      setResearchStatus(null)
      abortRef.current = null
    }
  }

  /** Resumen en markdown de un plan de estudio (con videos vetados). */
  function studyOverview(plan: StudyPlan): string {
    const lessons = plan.lessons
      .map((l, i) => `${i + 1}. **${l.title}** — ${l.summary}`)
      .join('\n')
    let md = `## 📚 Plan de estudio: ${plan.topic}\n\n${lessons}`
    if (plan.videos && plan.videos.length) {
      const vids = plan.videos
        .map((v) => `- [${v.title}](${v.url})${v.why ? ` — ${v.why}` : ''}`)
        .join('\n')
      md += `\n\n### 🎥 Videos recomendados (revisados)\n${vids}`
    }
    return md
  }

  /** Inicia una sesión de estudio: arma el plan, veta videos y empieza a enseñar. */
  async function startStudy(topic: string) {
    let convId = activeId
    const existing = conversations.find((c) => c.id === convId)
    const prevMessages = existing?.messages ?? []
    if (!convId) convId = newConversation()

    const userMsg: ChatMessage = {
      id: uid(),
      role: 'user',
      content: topic,
      createdAt: Date.now(),
    }
    const assistantMsg: ChatMessage = {
      id: uid(),
      role: 'assistant',
      content: '',
      createdAt: Date.now(),
    }
    const wasFirst = prevMessages.length === 0
    setConversations((cs) =>
      cs.map((c) => {
        if (c.id !== convId) return c
        const title =
          wasFirst && topic.trim() ? `📚 ${topic.trim().slice(0, 40)}` : c.title
        return {
          ...c,
          title,
          messages: [...c.messages, userMsg, assistantMsg],
          updatedAt: Date.now(),
        }
      }),
    )

    setIsStreaming(true)
    try {
      const model =
        (settings.autoModel ? pickModelForRole('reasoning', models) : settings.model) ||
        settings.model
      setResearchStatus('📚 Armando tu plan de estudio…')
      const plan = await makePlan(topic, model, recentContext())
      const videos = await findVideos(topic, model, setResearchStatus)
      plan.videos = videos

      // Guardar la sesión de estudio en la conversación.
      setConversations((cs) =>
        cs.map((c) => (c.id === convId ? { ...c, study: { plan, lesson: 0 } } : c)),
      )

      // Mostrar el plan + videos y empezar a enseñar la lección 1 (streaming).
      const header = studyOverview(plan) + '\n\n---\n\n'
      updateMessages(convId, (msgs) =>
        msgs.map((m) => (m.id === assistantMsg.id ? { ...m, content: header, model } : m)),
      )
      setResearchStatus('🧑‍🏫 Empezando la lección 1…')
      const system =
        tutorSystemPrompt(plan, 0) + buildMemoryBlock(memory) + buildDateBlock()
      const ac = new AbortController()
      abortRef.current = ac
      await chat({
        model,
        systemPrompt: system,
        messages: [
          {
            id: uid(),
            role: 'user',
            content: `Preséntate en 1 frase y empieza a enseñarme la lección 1 (${plan.lessons[0]?.title ?? topic}). Explica el primer concepto con un ejemplo y termina con una pregunta corta para mí.`,
            createdAt: Date.now(),
          },
        ],
        signal: ac.signal,
        onToken: (chunk) =>
          updateMessages(convId, (msgs) =>
            msgs.map((m) =>
              m.id === assistantMsg.id ? { ...m, content: m.content + chunk } : m,
            ),
          ),
      })
    } catch (e: any) {
      updateMessages(convId, (msgs) =>
        msgs.map((m) =>
          m.id === assistantMsg.id
            ? {
                ...m,
                content:
                  (m.content || '') +
                  `\n\n⚠️ No pude preparar el plan de estudio.\n\nDetalle: ${e?.message ?? e}`,
              }
            : m,
        ),
      )
    } finally {
      setIsStreaming(false)
      setResearchStatus(null)
      abortRef.current = null
    }
  }

  async function sendMessage(
    text: string,
    images: ChatImage[],
    docs: ChatDoc[],
    opts: SendOptions,
  ): Promise<string> {
    if (isStreaming) return ''

    // Rachas y logros: registrar actividad de hoy.
    if (text.trim() || images.length) {
      const { stats: ns, unlocked } = recordActivity(stats)
      setStats(ns)
      if (unlocked.length)
        showToast('🏆 ¡Logro! ' + unlocked.map((a) => `${a.emoji} ${a.name}`).join(' · '))
    }

    // Modo imagen (no requiere modelo de Ollama)
    if (opts.image?.enabled && text.trim()) {
      await generateImageMessage(text, opts.image)
      return ''
    }

    // Modo documento (Word / PDF / Excel / presentación / póster)
    if (opts.doc?.enabled && text.trim()) {
      await generateDocMessage(text, opts.doc.type, opts.doc.template)
      return ''
    }

    // Modo encuesta (formulario interactivo)
    if (opts.survey && text.trim()) {
      await generateSurveyMessage(text)
      return ''
    }

    // Modo plan de estudio (tutor interactivo)
    if (opts.study && text.trim()) {
      await startStudy(text)
      return ''
    }

    // Tarjetas de estudio
    if (opts.flashcards && text.trim()) {
      await generateFlashcardsMessage(text)
      return ''
    }

    // Examen / quiz
    if (opts.quiz && text.trim()) {
      await generateQuizMessage(text)
      return ''
    }

    // Resumir un enlace (YouTube o web)
    if (opts.summarize && text.trim()) {
      await summarizeUrlMessage(text)
      return ''
    }

    // Mapa mental
    if (opts.mindmap && text.trim()) {
      await generateMindmapMessage(text)
      return ''
    }

    if (!settings.model) {
      setConnError('No hay ningún modelo seleccionado.')
      setShowSettings(true)
      return ''
    }

    let convId = activeId
    const existing = conversations.find((c) => c.id === convId)
    const prevMessages = existing?.messages ?? []
    const personaId = existing?.personaId ?? settings.activePersonaId
    // Sesión de estudio activa: el tutor sigue enseñando en cada turno.
    const study = existing?.study
    let studyLesson = study?.lesson ?? 0
    if (study && /\b(siguiente|pr[oó]xim|avanza|contin[uú]|otra lecci[oó]n|next)\b/i.test(text)) {
      studyLesson = Math.min(studyLesson + 1, study.plan.lessons.length - 1)
      setConversations((cs) =>
        cs.map((c) =>
          c.id === convId && c.study
            ? { ...c, study: { ...c.study, lesson: studyLesson } }
            : c,
        ),
      )
    }
    if (!convId) convId = newConversation()

    const userMsg: ChatMessage = {
      id: uid(),
      role: 'user',
      content: text,
      images: images.length ? images : undefined,
      docs: docs.length ? docs : undefined,
      createdAt: Date.now(),
    }
    const assistantMsg: ChatMessage = {
      id: uid(),
      role: 'assistant',
      content: '',
      createdAt: Date.now(),
    }
    const wasFirst = prevMessages.length === 0

    setConversations((cs) =>
      cs.map((c) => {
        if (c.id !== convId) return c
        const title = wasFirst && text.trim() ? text.trim().slice(0, 48) : c.title
        return {
          ...c,
          title,
          messages: [...c.messages, userMsg, assistantMsg],
          updatedAt: Date.now(),
        }
      }),
    )

    // Sesión de estudio: inyectar el prompt del tutor con la lección actual.
    let extraContext = ''
    if (study) {
      extraContext += '\n\n' + tutorSystemPrompt(study.plan, studyLesson)
    }
    // Modo resolver-foto: leer el ejercicio de la imagen y resolverlo paso a paso.
    if (opts.solve && images.length) {
      extraContext +=
        '\n\n[Resolver ejercicio de la imagen]\nLee CON CUIDADO el ejercicio o problema que aparece en la imagen, transcríbelo, y resuélvelo PASO A PASO explicando cada paso. Usa $$...$$ para la matemática y, si ayuda, una gráfica (```plot) o un dibujo (```svg). Termina con la respuesta final clara.'
    }
    // Modo pensar: razonar dentro de <think>...</think> antes de responder.
    if (opts.think && text.trim()) {
      extraContext +=
        '\n\n[Modo pensar] Antes de responder, razona el problema paso a paso DENTRO de una sola etiqueta <think> ... </think>: piensa en voz alta, considera distintos enfoques, comprueba tu lógica y detecta posibles errores. Luego cierra con </think> y escribe debajo la respuesta final clara y bien organizada para la persona, SIN etiquetas. La respuesta final debe entenderse por sí sola.'
    }

    // Búsqueda web (si está activa)
    if (opts.web?.enabled && text.trim()) {
      setIsStreaming(true)
      setResearchStatus('🔎 Buscando en internet…')
      try {
        const { contextBlock, sources } = await runResearch({
          question: text,
          effort: opts.web.effort,
          model: settings.model,
          onStatus: setResearchStatus,
        })
        extraContext += contextBlock
        updateMessages(convId, (msgs) =>
          msgs.map((m) => (m.id === assistantMsg.id ? { ...m, sources } : m)),
        )
      } catch {
        /* si falla, se responde sin fuentes */
      }
      setResearchStatus(null)
    }

    const apiHistory = [...prevMessages, userMsg]
    let chatModel: string
    if (study) {
      chatModel =
        (settings.autoModel
          ? pickModelForRole('reasoning', models) || settings.model
          : settings.model) || settings.model
    } else if (personaId === 'programador' && images.length === 0) {
      // Modo Programador → mejor modelo de código (si Auto está activo).
      chatModel = settings.autoModel
        ? pickModelForRole('code', models) || settings.model
        : settings.model
    } else if (opts.think && images.length === 0) {
      // Modo pensar → mejor modelo de razonamiento (si Auto está activo).
      chatModel = settings.autoModel
        ? pickModelForRole('reasoning', models) || settings.model
        : settings.model
    } else {
      chatModel = settings.autoModel
        ? routeModel({
            text,
            hasImages: images.length > 0,
            docMode: false,
            models,
            fallback: settings.model,
          }).model
        : settings.model
    }
    const assistantFull = await generateInto(
      convId,
      apiHistory,
      assistantMsg.id,
      personaId,
      extraContext,
      chatModel,
    )

    runAutoMemory(text)

    if (wasFirst && text.trim() && assistantFull.trim()) {
      generateTitle(text, assistantFull, settings.model)
        .then((t) => {
          if (t)
            setConversations((cs) =>
              cs.map((c) =>
                c.id === convId ? { ...c, title: t, autoTitled: true } : c,
              ),
            )
        })
        .catch(() => {})
    }

    return assistantFull
  }

  /** Envía un mensaje normal (para las acciones rápidas bajo las respuestas). */
  function quickSend(text: string) {
    if (isStreaming || !text.trim()) return
    sendMessage(text, [], [], {
      web: { enabled: false, effort: settings.webEffort },
      image: {
        enabled: false,
        steps: settings.imageSteps,
        width: settings.imageWidth,
        height: settings.imageHeight,
      },
      doc: { enabled: false, type: 'pptx', template: 'general' },
      survey: false,
      study: false,
      flashcards: false,
      quiz: false,
      summarize: false,
      solve: false,
      mindmap: false,
      think: false,
    })
  }

  /** Sugiere 2-3 preguntas de seguimiento a partir del último intercambio. */
  async function generateFollowups(): Promise<string[]> {
    const conv = active
    if (!conv) return []
    const msgs = conv.messages
    const lastA = [...msgs].reverse().find((m) => m.role === 'assistant' && m.content)
    const lastU = [...msgs].reverse().find((m) => m.role === 'user')
    if (!lastA) return []
    const model =
      (settings.autoModel
        ? pickModelForRole('fast', models) || pickModelForRole('general', models)
        : settings.model) || settings.model
    if (!model) return []
    try {
      const raw = await complete({
        model,
        system:
          'Sugiere preguntas de seguimiento cortas y útiles que la persona podría hacer a continuación. ' +
          'Responde SOLO en JSON: {"preguntas": ["...", "...", "..."]}. En español, máximo 3, cada una de menos de 12 palabras.',
        prompt: `Pregunta: ${lastU?.content ?? ''}\n\nRespuesta: ${lastA.content.slice(0, 1500)}`,
        format: 'json',
        numPredict: 200,
      })
      const obj: any = extractJson(raw)
      const arr = Array.isArray(obj?.preguntas) ? obj.preguntas : []
      return arr.filter((x: any) => typeof x === 'string' && x.trim()).slice(0, 3)
    } catch {
      return []
    }
  }

  function regenerateLast() {
    if (isStreaming || !active) return
    const msgs = active.messages
    let ai = msgs.length - 1
    while (ai >= 0 && msgs[ai].role !== 'assistant') ai--
    if (ai < 0) return
    const assistantId = msgs[ai].id
    const apiHistory = msgs.slice(0, ai)
    updateMessages(active.id, () => [
      ...msgs.slice(0, ai),
      { ...msgs[ai], content: '', stats: undefined },
    ])
    generateInto(active.id, apiHistory, assistantId, active.personaId)
  }

  function editUserMessage(messageId: string, newText: string) {
    if (isStreaming || !active) return
    const idx = active.messages.findIndex((m) => m.id === messageId)
    if (idx < 0) return
    const editedUser: ChatMessage = { ...active.messages[idx], content: newText }
    const assistantMsg: ChatMessage = {
      id: uid(),
      role: 'assistant',
      content: '',
      createdAt: Date.now(),
    }
    const kept = active.messages.slice(0, idx)
    updateMessages(active.id, () => [...kept, editedUser, assistantMsg])
    generateInto(active.id, [...kept, editedUser], assistantMsg.id, active.personaId)
  }

  function stop() {
    abortRef.current?.abort()
  }

  // ---- Modo manos libres (voz continua) ----
  async function handsFreeTurn() {
    let blob: Blob
    try {
      blob = await recordUntilSilence({
        onState: (s) =>
          setResearchStatus(
            s === 'listening' ? '🎧 Escuchando… (habla)' : '🎙️ Grabando…',
          ),
      })
    } catch {
      setResearchStatus(null)
      stopHandsFree()
      showToast('No pude acceder al micrófono.')
      return
    }
    if (!handsFreeRef.current) {
      setResearchStatus(null)
      return
    }
    setResearchStatus('📝 Transcribiendo…')
    let text = ''
    try {
      text = await transcribeBlob(blob, 'es')
    } catch {
      /* ignore */
    }
    setResearchStatus(null)
    if (!handsFreeRef.current || !text.trim()) return

    const full = await sendMessage(text, [], [], {
      web: { enabled: false, effort: settings.webEffort },
      image: {
        enabled: false,
        steps: settings.imageSteps,
        width: settings.imageWidth,
        height: settings.imageHeight,
      },
      doc: { enabled: false, type: 'pptx', template: 'general' },
      survey: false,
      study: false,
      flashcards: false,
      quiz: false,
      summarize: false,
      solve: false,
      mindmap: false,
      think: false,
    })
    if (!handsFreeRef.current || !full.trim()) return
    await new Promise<void>((res) =>
      speak(full, {
        voice: settings.ttsVoice,
        rate: settings.ttsRate,
        lang: settings.ttsLang,
        onEnd: res,
      }),
    )
  }

  async function handsFreeLoop() {
    while (handsFreeRef.current) {
      await handsFreeTurn()
      await new Promise((r) => setTimeout(r, 200))
    }
  }

  function startHandsFree() {
    if (handsFreeRef.current) return
    handsFreeRef.current = true
    setHandsFree(true)
    showToast('🎙️ Manos libres activado. Habla cuando quieras (Esc para salir).')
    handsFreeLoop()
  }
  function stopHandsFree() {
    handsFreeRef.current = false
    setHandsFree(false)
    stopSpeaking()
    setResearchStatus(null)
  }
  function toggleHandsFree() {
    if (handsFreeRef.current) stopHandsFree()
    else startHandsFree()
  }

  // ---- Atajos de teclado (Alt+… ; Esc) ----
  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (e.key === 'Escape') {
        if (isStreaming) stop()
        stopSpeaking()
        if (handsFreeRef.current) stopHandsFree()
        return
      }
      if (!e.altKey) return
      const k = e.key.toLowerCase()
      if (k === 'n') {
        e.preventDefault()
        newConversation()
      } else if (k === 'm') {
        e.preventDefault()
        setShowMemory(true)
      } else if (k === 's') {
        e.preventDefault()
        setShowSettings(true)
      } else if (k === 'e') {
        e.preventDefault()
        if (active) exportChatMarkdown(active)
      } else if (k === 'v') {
        e.preventDefault()
        toggleHandsFree()
      } else if (k === 'f') {
        e.preventDefault()
        setFocusMode((v) => !v)
      } else if (k === 'h') {
        e.preventDefault()
        setShowHelp((v) => !v)
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isStreaming, active])

  function handleExportBackup() {
    const data = {
      app: 'mi-asistente',
      version: 3,
      exportedAt: new Date().toISOString(),
      conversations,
      memory,
      personas,
      prompts,
      settings,
    }
    const blob = new Blob([JSON.stringify(data, null, 2)], {
      type: 'application/json',
    })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `asistente-backup-${new Date().toISOString().slice(0, 10)}.json`
    document.body.appendChild(a)
    a.click()
    a.remove()
    setTimeout(() => URL.revokeObjectURL(url), 1000)
  }

  async function handleImportBackup(file: File) {
    try {
      const d = JSON.parse(await file.text())
      if (Array.isArray(d.conversations)) setConversations(d.conversations)
      if (Array.isArray(d.memory)) setMemory(d.memory)
      if (Array.isArray(d.personas) && d.personas.length) setPersonas(d.personas)
      if (Array.isArray(d.prompts) && d.prompts.length) setPrompts(d.prompts)
      if (d.settings && typeof d.settings === 'object')
        setSettings((s) => ({ ...s, ...d.settings }))
      showToast('✅ Copia importada a este perfil.')
    } catch {
      showToast('⚠️ El archivo no es un respaldo válido.')
    }
  }

  // 📱 Gestos: deslizar desde el borde izquierdo abre el menú; deslizar a la izquierda lo cierra.
  function onTouchStart(e: React.TouchEvent) {
    touchStartX.current = e.touches[0].clientX
    touchStartY.current = e.touches[0].clientY
  }
  function onTouchEnd(e: React.TouchEvent) {
    const sx = touchStartX.current
    const sy = touchStartY.current
    touchStartX.current = null
    if (sx == null) return
    const dx = e.changedTouches[0].clientX - sx
    const dy = Math.abs(e.changedTouches[0].clientY - (sy ?? 0))
    if (dy > 60) return // fue un desplazamiento vertical
    if (dx > 70 && sx < 40 && !sidebarOpen) setSidebarOpen(true)
    else if (dx < -70 && sidebarOpen) setSidebarOpen(false)
  }

  // Puerta de acceso compartido (si hay contraseña configurada).
  if (!accessChecked) {
    return (
      <div className="h-dvh flex items-center justify-center bg-zinc-50 dark:bg-zinc-950 text-zinc-400">
        <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-indigo-500 to-violet-600 animate-pulse" />
      </div>
    )
  }
  if (locked) {
    return <AccessGate verify={checkAccess} onUnlock={unlockAccess} />
  }

  if (!activeProfile) {
    if (!profilesLoaded) {
      return (
        <div className="h-dvh flex items-center justify-center bg-zinc-50 dark:bg-zinc-950 text-zinc-400">
          <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-indigo-500 to-violet-600 animate-pulse" />
        </div>
      )
    }
    return (
      <ProfileGate
        profiles={profiles}
        onSelect={enterProfile}
        onCreate={handleCreateProfile}
        onDelete={handleDeleteProfile}
        verifyPin={verifyPin}
      />
    )
  }

  return (
    <OwnerContext.Provider value={ownerValue}>
    <div
      className="flex h-dvh bg-zinc-50 dark:bg-zinc-950 text-zinc-900 dark:text-zinc-100"
      onTouchStart={device === 'phone' ? onTouchStart : undefined}
      onTouchEnd={device === 'phone' ? onTouchEnd : undefined}
    >
      <Sidebar
        conversations={conversations}
        activeId={activeId}
        collapsed={focusMode}
        profileName={activeProfile.name}
        profileAvatar={activeProfile.avatar}
        onSwitchProfile={switchProfile}
        open={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        onSelect={selectConversation}
        onNew={() => {
          newConversation()
          setSidebarOpen(false)
        }}
        onDelete={deleteConversation}
        onRename={renameConversation}
        onTogglePin={togglePinConversation}
        onSetFolder={setConversationFolder}
      />

      <main className="flex flex-col flex-1 min-w-0">
        <header className="relative z-10 flex items-center gap-2 h-14 px-3 border-b border-zinc-200 dark:border-zinc-800 bg-white/70 dark:bg-zinc-900/70 backdrop-blur">
          <button
            className="md:hidden p-2 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 shrink-0"
            onClick={() => setSidebarOpen(true)}
            title="Menú"
          >
            ☰
          </button>
          <div className="flex items-center gap-2 flex-1 min-w-0 overflow-x-auto">
            <ModelPicker
              models={models}
              value={settings.autoModel ? '__auto__' : settings.model}
              onChange={(m) =>
                m === '__auto__'
                  ? setSettings((s) => ({ ...s, autoModel: true }))
                  : setSettings((s) => ({ ...s, autoModel: false, model: m }))
              }
            />
            <PersonaPicker
              personas={personas}
              value={headerPersonaId}
              onChange={changePersona}
            />
          </div>
          {/* Acciones secundarias: en línea en escritorio */}
          <div className="hidden sm:flex items-center gap-2 shrink-0">
            {device !== 'phone' && (
              <button
                onClick={() => setFocusMode((v) => !v)}
                className={`p-2 rounded-lg transition-colors ${
                  focusMode
                    ? 'bg-indigo-600 text-white'
                    : 'hover:bg-zinc-100 dark:hover:bg-zinc-800'
                }`}
                title={focusMode ? 'Salir de modo concentración (Alt+F)' : 'Modo concentración: oculta el menú (Alt+F)'}
              >
                🎯
              </button>
            )}
            {device === 'desktop' && (
              <button
                onClick={() => setShowServers(true)}
                className="p-2 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800"
                title="Estado de los servidores y GPU"
              >
                🖥️
              </button>
            )}
            {active && active.messages.length > 0 && (
              <button
                onClick={() => exportChatMarkdown(active)}
                className="p-2 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800"
                title="Exportar este chat a Markdown"
              >
                📥
              </button>
            )}
            <button
              onClick={toggleHandsFree}
              className={`p-2 rounded-lg transition-colors ${
                handsFree
                  ? 'bg-red-500 text-white animate-pulse'
                  : 'hover:bg-zinc-100 dark:hover:bg-zinc-800'
              }`}
              title={handsFree ? 'Manos libres activo (Esc para salir)' : 'Modo manos libres (voz)'}
            >
              🎙️
            </button>
            <button
              onClick={() =>
                setSettings((s) => ({
                  ...s,
                  theme: s.theme === 'dark' ? 'light' : 'dark',
                }))
              }
              className="p-2 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800"
              title="Cambiar tema"
            >
              {settings.theme === 'dark' ? '☀️' : '🌙'}
            </button>
          </div>

          {/* Muro entre amigos */}
          <button
            onClick={() => setShowWall(true)}
            className="p-1.5 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 shrink-0"
            title="Muro de amigos"
          >
            <img src="/forum.png" alt="Muro" className="h-8 w-8 object-contain" />
          </button>

          {/* Progreso / logros: en escritorio en línea; en móvil va al menú ⋯ */}
          <button
            onClick={() => setShowAchievements(true)}
            className="relative hidden sm:block p-2 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 shrink-0"
            title="Tu progreso (rachas y logros)"
          >
            🏆
            {(stats.streak || 0) > 0 && (
              <span className="absolute -top-0.5 -right-0.5 min-w-4 h-4 px-1 rounded-full bg-orange-500 text-white text-[10px] leading-4 text-center">
                {stats.streak}
              </span>
            )}
          </button>

          {/* Memoria: en escritorio en línea; en móvil va al menú ⋯ */}
          <button
            onClick={() => setShowMemory(true)}
            className="relative hidden sm:block p-2 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 shrink-0"
            title="Memoria"
          >
            🧠
            {memory.length > 0 && (
              <span className="absolute -top-0.5 -right-0.5 min-w-4 h-4 px-1 rounded-full bg-indigo-600 text-white text-[10px] leading-4 text-center">
                {memory.length}
              </span>
            )}
          </button>

          {/* Menú "⋯": solo en móvil */}
          <div className="relative sm:hidden shrink-0">
            <button
              onClick={() => setShowHeaderMenu((v) => !v)}
              className="p-2 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800"
              title="Más opciones"
            >
              ⋯
            </button>
            {showHeaderMenu && (
              <>
                <div
                  className="fixed inset-0 z-20"
                  onClick={() => setShowHeaderMenu(false)}
                />
                <div className="absolute right-0 top-11 z-30 w-52 rounded-xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 shadow-lg py-1">
                  {active && active.messages.length > 0 && (
                    <button
                      onClick={() => {
                        exportChatMarkdown(active)
                        setShowHeaderMenu(false)
                      }}
                      className="w-full text-left px-3 py-2.5 text-sm hover:bg-zinc-100 dark:hover:bg-zinc-800"
                    >
                      📥 Exportar chat
                    </button>
                  )}
                  <button
                    onClick={() => {
                      toggleHandsFree()
                      setShowHeaderMenu(false)
                    }}
                    className="w-full text-left px-3 py-2.5 text-sm hover:bg-zinc-100 dark:hover:bg-zinc-800"
                  >
                    🎙️ Manos libres
                  </button>
                  <button
                    onClick={() => {
                      setShowAchievements(true)
                      setShowHeaderMenu(false)
                    }}
                    className="w-full text-left px-3 py-2.5 text-sm hover:bg-zinc-100 dark:hover:bg-zinc-800"
                  >
                    🏆 Tu progreso{(stats.streak || 0) > 0 ? ` · 🔥 ${stats.streak}` : ''}
                  </button>
                  <button
                    onClick={() => {
                      setShowMemory(true)
                      setShowHeaderMenu(false)
                    }}
                    className="w-full text-left px-3 py-2.5 text-sm hover:bg-zinc-100 dark:hover:bg-zinc-800"
                  >
                    🧠 Memoria{memory.length > 0 ? ` · ${memory.length}` : ''}
                  </button>
                  <button
                    onClick={() => {
                      setSettings((s) => ({
                        ...s,
                        theme: s.theme === 'dark' ? 'light' : 'dark',
                      }))
                      setShowHeaderMenu(false)
                    }}
                    className="w-full text-left px-3 py-2.5 text-sm hover:bg-zinc-100 dark:hover:bg-zinc-800"
                  >
                    {settings.theme === 'dark' ? '☀️ Tema claro' : '🌙 Tema oscuro'}
                  </button>
                  <button
                    onClick={() => {
                      setShowNotes(true)
                      setShowHeaderMenu(false)
                    }}
                    className="w-full text-left px-3 py-2.5 text-sm hover:bg-zinc-100 dark:hover:bg-zinc-800"
                  >
                    📝 Notas rápidas
                  </button>
                  <button
                    onClick={() => {
                      setShowStudio(true)
                      setShowHeaderMenu(false)
                    }}
                    className="w-full text-left px-3 py-2.5 text-sm hover:bg-zinc-100 dark:hover:bg-zinc-800"
                  >
                    🧑‍💻 Studio de código
                  </button>
                  <button
                    onClick={() => {
                      setShowHelp(true)
                      setShowHeaderMenu(false)
                    }}
                    className="w-full text-left px-3 py-2.5 text-sm hover:bg-zinc-100 dark:hover:bg-zinc-800"
                  >
                    ❓ Atajos y gestos
                  </button>
                  <button
                    onClick={() => {
                      togglePets(!showPets)
                      setShowHeaderMenu(false)
                    }}
                    className="w-full text-left px-3 py-2.5 text-sm hover:bg-zinc-100 dark:hover:bg-zinc-800"
                  >
                    🐾 Bichitos {showPets ? '· quitar' : 'de escritorio'}
                  </button>
                </div>
              </>
            )}
          </div>
          <button
            onClick={() => togglePets(!showPets)}
            className={`hidden sm:block p-2 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 shrink-0 ${showPets ? 'bg-indigo-100 dark:bg-indigo-900/40' : ''}`}
            title="Bichitos de escritorio 🐾"
          >
            🐾
          </button>
          <button
            onClick={() => setShowNotes(true)}
            className="hidden sm:block p-2 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 shrink-0"
            title="Notas rápidas"
          >
            📝
          </button>
          <button
            onClick={() => setShowStudio(true)}
            className="hidden sm:block p-2 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 shrink-0"
            title="Studio de código (Python / HTML / JS)"
          >
            🧑‍💻
          </button>
          <button
            onClick={() => setShowHelp(true)}
            className="hidden sm:block p-2 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 shrink-0"
            title="Atajos y gestos (Alt+H)"
          >
            ❓
          </button>
          <button
            onClick={() => setShowSettings(true)}
            className="p-2 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 shrink-0"
            title="Ajustes"
          >
            ⚙️
          </button>
        </header>

        {connError && (
          <div className="bg-amber-100 dark:bg-amber-900/40 text-amber-800 dark:text-amber-200 text-sm px-4 py-2 text-center">
            No se pudo conectar con Ollama. Asegúrate de que esté corriendo.{' '}
            <button onClick={refreshModels} className="underline">
              Reintentar
            </button>
          </div>
        )}

        {researchStatus && (
          <div className="bg-indigo-100 dark:bg-indigo-900/40 text-indigo-800 dark:text-indigo-200 text-sm px-4 py-2 text-center">
            {researchStatus}
          </div>
        )}

        <ChatView
          conversation={active}
          isStreaming={isStreaming}
          onSuggest={(t) => setInput(t)}
          onRegenerate={regenerateLast}
          onEditUser={editUserMessage}
          onSpeak={speakText}
          onQuick={quickSend}
          onFollowups={generateFollowups}
        />

        <Composer
          value={input}
          onChange={setInput}
          onSend={sendMessage}
          isStreaming={isStreaming}
          onStop={stop}
          disabled={!settings.model}
          prompts={prompts}
          webEffort={settings.webEffort}
          onWebEffortChange={(e) => setSettings((s) => ({ ...s, webEffort: e }))}
          imageSteps={settings.imageSteps}
          onImageStepsChange={(n) => setSettings((s) => ({ ...s, imageSteps: n }))}
          imageWidth={settings.imageWidth}
          imageHeight={settings.imageHeight}
          onImageSizeChange={(w, h) =>
            setSettings((s) => ({ ...s, imageWidth: w, imageHeight: h }))
          }
        />
      </main>

      <Suspense fallback={null}>
      {showSettings && (
        <SettingsPanel
          settings={settings}
          models={models}
          connError={connError}
          profileId={activeProfile.id}
          personas={personas}
          prompts={prompts}
          onChange={setSettings}
          onPersonasChange={setPersonas}
          onPromptsChange={setPrompts}
          onRefreshModels={refreshModels}
          onExport={handleExportBackup}
          onImport={handleImportBackup}
          canInstall={!!installEvt}
          onInstall={installApp}
          onClose={() => setShowSettings(false)}
        />
      )}

      {showAchievements && (
        <AchievementsPanel stats={stats} onClose={() => setShowAchievements(false)} />
      )}

      {showWall && activeProfile && (
        <Wall
          authorName={activeProfile.name}
          authorAvatar={activeProfile.avatar}
          model={
            (settings.autoModel ? pickModelForRole('general', models) : settings.model) ||
            settings.model
          }
          onClose={() => setShowWall(false)}
        />
      )}

      {showMemory && (
        <MemoryPanel
          memory={memory}
          autoMemory={settings.autoMemory}
          onChange={setMemory}
          onToggleAuto={(v) => setSettings((s) => ({ ...s, autoMemory: v }))}
          onClose={() => setShowMemory(false)}
        />
      )}

      {showServers && (
        <ServerStatus onClose={() => setShowServers(false)} onToast={showToast} />
      )}

      {showHelp && <HelpPanel device={device} onClose={() => setShowHelp(false)} />}

      {showNotes && (
        <NotesPanel profileId={activeProfile.id} onClose={() => setShowNotes(false)} />
      )}

      {showStudio && (
        <CodeStudio
          onClose={() => setShowStudio(false)}
          profileId={activeProfile.id}
          model={
            (settings.autoModel ? pickModelForRole('code', models) : settings.model) ||
            settings.model ||
            models[0]?.name ||
            ''
          }
        />
      )}

      {showPets && activeProfile && (
        <DesktopPets profileId={activeProfile.id} onClose={() => togglePets(false)} />
      )}
      </Suspense>

      {toast && (
        <div className="fixed bottom-24 left-1/2 -translate-x-1/2 z-50 max-w-[90vw] rounded-xl bg-zinc-900 text-white text-sm px-4 py-2 shadow-lg border border-white/10">
          {toast}
        </div>
      )}
    </div>
    </OwnerContext.Provider>
  )
}
