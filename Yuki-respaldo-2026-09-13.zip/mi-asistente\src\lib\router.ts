import type { OllamaModel } from './ollama'

export type Role = 'vision' | 'code' | 'reasoning' | 'general' | 'fast'

// Listas de preferencia por rol (nombre de modelo Ollama). Se elige el primero instalado.
const PREFS: Record<Role, string[]> = {
  vision: ['gemma3', 'llava', 'vl', 'vision', 'moondream'],
  code: ['qwen2.5-coder:14b', 'qwen2.5-coder:7b', 'qwen2.5-coder', 'deepseek-coder'],
  reasoning: ['qwen2.5:14b', 'qwen2.5:7b', 'qwen2.5', 'llama3.1:8b', 'llama3.1'],
  general: ['llama3.1:8b', 'llama3.1', 'qwen2.5:7b', 'gemma3:4b', 'gemma3'],
  fast: ['llama3.2:1b', 'llama3.2:3b', 'llama3.2', 'qwen2.5:3b', 'qwen2.5:1.5b'],
}

const CODE_RE =
  /```|\b(c[oó]digo|programa|funci[oó]n|function|clase|class|m[eé]todo|method|bug|error|script|regex|sql|python|javascript|typescript|java|css|html|api|json|compil|depur|debug|algoritmo)\b/i
const REASON_RE =
  /\b(analiza|an[aá]lisis|explica a fondo|expl[ií]came a fondo|ensayo|razona|razonamiento|compara|comparaci[oó]n|argumenta|demuestra|resuelve|plan|estrategia|profund|detalladamente|paso a paso|matem[aá]tica|filosof|teor[ií]a)\b/i

export function detectRole(opts: {
  text: string
  hasImages: boolean
  docMode: boolean
}): Role {
  if (opts.hasImages) return 'vision'
  if (opts.docMode) return 'reasoning'
  const t = (opts.text || '').trim()
  if (CODE_RE.test(t)) return 'code'
  if (REASON_RE.test(t) || t.length > 600) return 'reasoning'
  if (t.length > 0 && t.length < 40) return 'fast'
  return 'general'
}

function usable(models: OllamaModel[]): string[] {
  // excluir modelos de embeddings (no sirven para chat)
  return models.map((m) => m.name).filter((n) => !/embed/i.test(n))
}

function matchModel(pref: string[], names: string[]): string | undefined {
  for (const p of pref) {
    const m =
      names.find((n) => n === p) ||
      names.find((n) => n.startsWith(p)) ||
      names.find((n) => n.includes(p))
    if (m) return m
  }
  return undefined
}

export function pickModelForRole(
  role: Role,
  models: OllamaModel[],
): string | undefined {
  return matchModel(PREFS[role], usable(models))
}

/** Elige el mejor modelo instalado para la tarea. */
export function routeModel(opts: {
  text: string
  hasImages: boolean
  docMode: boolean
  models: OllamaModel[]
  fallback: string
}): { model: string; role: Role } {
  const role = detectRole(opts)
  const names = usable(opts.models)
  const model =
    matchModel(PREFS[role], names) ||
    matchModel([...PREFS.general, ...PREFS.fast], names) ||
    (opts.fallback && names.includes(opts.fallback) ? opts.fallback : '') ||
    names[0] ||
    opts.fallback ||
    ''
  return { model, role }
}
