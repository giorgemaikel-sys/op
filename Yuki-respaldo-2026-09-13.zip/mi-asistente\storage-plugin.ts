import type { Plugin } from 'vite'
import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'

// Guarda los perfiles y sus datos en <proyecto>/data/ (en la PC).
// Así el celular y la PC comparten los mismos datos (ambos usan este servidor).
const DATA_DIR = path.resolve(process.cwd(), 'data')
const PROFILES_FILE = path.join(DATA_DIR, 'profiles.json')
// Contraseña compartida para entrar cuando el asistente se comparte por internet.
// Si el archivo no existe o está vacío, NO hay contraseña (uso local normal).
const SHARE_FILE = path.join(DATA_DIR, 'share.txt')
// Config SMTP para enviar correos (recuperar PIN, avisos).
const SMTP_FILE = path.join(DATA_DIR, 'smtp.json')
// Muro compartido entre amigos.
const WALL_FILE = path.join(DATA_DIR, 'wall.json')
// Contraseña MAESTRA del administrador (dueño). Cámbiala aquí si quieres otra.
// Solo quien la sepa puede borrar perfiles, ver/enviar correos y configurar el correo.
const MASTER_ADMIN = '11101063520'

interface ProfileRecord {
  id: string
  name: string
  avatar?: string
  email?: string
  pinHash?: string
  salt?: string
}

function sharePassword(): string {
  try {
    return fs.readFileSync(SHARE_FILE, 'utf8').trim()
  } catch {
    return ''
  }
}

function validEmail(s: string): boolean {
  return /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(s)
}

// ---- Administrador (dueño) ----
function ownerOk(req: any): boolean {
  return String(req.headers['x-owner-pass'] || '') === MASTER_ADMIN
}
/** Puerta de acciones del dueño: exige siempre la contraseña maestra. */
function ownerGate(req: any): { ok: boolean; error?: string } {
  return ownerOk(req)
    ? { ok: true }
    : { ok: false, error: 'Contraseña de administrador incorrecta.' }
}

// ---- Envío de correo (SMTP con nodemailer) ----
interface SmtpConfig {
  host: string
  port: number
  secure: boolean
  user: string
  pass: string
  from: string
}
function loadSmtp(): SmtpConfig | null {
  return readJson<SmtpConfig | null>(SMTP_FILE, null)
}
async function sendMail(to: string, subject: string, text: string): Promise<void> {
  const cfg = loadSmtp()
  if (!cfg || !cfg.host || !cfg.user) throw new Error('correo no configurado')
  const nodemailer = (await import('nodemailer')).default
  const transport = nodemailer.createTransport({
    host: cfg.host,
    port: cfg.port || 587,
    secure: !!cfg.secure,
    auth: { user: cfg.user, pass: cfg.pass },
  })
  await transport.sendMail({
    from: cfg.from || cfg.user,
    to,
    subject,
    text,
  })
}

function ensureDir() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true })
}

function readJson<T>(file: string, fallback: T): T {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8')) as T
  } catch {
    return fallback
  }
}

function writeJson(file: string, obj: unknown) {
  ensureDir()
  fs.writeFileSync(file, JSON.stringify(obj, null, 2), 'utf8')
}

function loadProfiles(): ProfileRecord[] {
  return readJson<ProfileRecord[]>(PROFILES_FILE, [])
}
function saveProfiles(list: ProfileRecord[]) {
  writeJson(PROFILES_FILE, list)
}

function hashPin(pin: string, salt: string): string {
  return crypto.createHash('sha256').update(salt + ':' + pin).digest('hex')
}

function dataFile(id: string): string {
  // id es hex/uuid; evitar path traversal
  const safe = id.replace(/[^a-zA-Z0-9_-]/g, '')
  return path.join(DATA_DIR, `data-${safe}.json`)
}

function readBody(req: any): Promise<any> {
  return new Promise((resolve) => {
    let raw = ''
    req.on('data', (c: any) => (raw += c))
    req.on('end', () => {
      try {
        resolve(raw ? JSON.parse(raw) : {})
      } catch {
        resolve({})
      }
    })
    req.on('error', () => resolve({}))
  })
}

function sendJson(res: any, code: number, body: unknown) {
  res.statusCode = code
  res.setHeader('Content-Type', 'application/json; charset=utf-8')
  res.end(JSON.stringify(body))
}

/** Vista pública de un perfil (sin el hash del PIN). */
function publicProfile(p: ProfileRecord) {
  return { id: p.id, name: p.name, avatar: p.avatar || '', hasPin: !!p.pinHash }
}

export function storagePlugin(): Plugin {
  return {
    name: 'asistente-storage',
    configureServer(server) {
      server.middlewares.use('/store', async (req: any, res: any) => {
        try {
          const url = new URL(req.url || '', 'http://localhost')
          const p = url.pathname
          const method = (req.method || 'GET').toUpperCase()

          // ---- Perfiles ----
          if (p === '/profiles' && method === 'GET') {
            return sendJson(res, 200, { profiles: loadProfiles().map(publicProfile) })
          }
          if (p === '/profiles' && method === 'POST') {
            const body = await readBody(req)
            const name = String(body.name || '').trim() || 'Perfil'
            const avatar = String(body.avatar || '').slice(0, 8)
            const rec: ProfileRecord = { id: crypto.randomUUID(), name, avatar }
            const email = String(body.email || '').trim().slice(0, 120)
            if (email && validEmail(email)) rec.email = email
            if (body.pin) {
              rec.salt = crypto.randomBytes(8).toString('hex')
              rec.pinHash = hashPin(String(body.pin), rec.salt)
            }
            const list = loadProfiles()
            list.push(rec)
            saveProfiles(list)
            return sendJson(res, 200, { profile: publicProfile(rec) })
          }
          if (p === '/profiles/delete' && method === 'POST') {
            const gate = ownerGate(req)
            if (!gate.ok) return sendJson(res, 403, { error: gate.error })
            const body = await readBody(req)
            const id = String(body.id || '')
            saveProfiles(loadProfiles().filter((x) => x.id !== id))
            try {
              fs.unlinkSync(dataFile(id))
            } catch {
              /* sin datos */
            }
            return sendJson(res, 200, { ok: true })
          }
          if (p === '/profiles/verify' && method === 'POST') {
            const body = await readBody(req)
            const rec = loadProfiles().find((x) => x.id === String(body.id))
            if (!rec) return sendJson(res, 200, { ok: false })
            if (!rec.pinHash) return sendJson(res, 200, { ok: true })
            const ok = rec.salt
              ? hashPin(String(body.pin || ''), rec.salt) === rec.pinHash
              : false
            return sendJson(res, 200, { ok })
          }

          // ---- Acceso compartido (contraseña) ----
          if (p === '/access' && method === 'GET') {
            return sendJson(res, 200, { required: !!sharePassword() })
          }
          if (p === '/access' && method === 'POST') {
            const body = await readBody(req)
            const need = sharePassword()
            const ok = !need || String(body.password || '') === need
            return sendJson(res, 200, { ok })
          }

          // ---- Administrador (dueño) — contraseña maestra ----
          if (p === '/owner/verify' && method === 'POST') {
            const body = await readBody(req)
            return sendJson(res, 200, {
              ok: String(body.password || '') === MASTER_ADMIN,
            })
          }

          // ---- Config de correo (SMTP) — solo el dueño ----
          if (p === '/smtp' && method === 'GET') {
            const g = ownerGate(req)
            if (!g.ok) return sendJson(res, 403, { error: g.error })
            const c = loadSmtp()
            return sendJson(res, 200, {
              configured: !!(c && c.host && c.user),
              host: c?.host || '',
              port: c?.port || 587,
              secure: !!c?.secure,
              user: c?.user || '',
              from: c?.from || '',
            })
          }
          if (p === '/smtp' && method === 'POST') {
            const g = ownerGate(req)
            if (!g.ok) return sendJson(res, 403, { error: g.error })
            const body = await readBody(req)
            const cur = loadSmtp()
            const cfg: SmtpConfig = {
              host: String(body.host || '').trim(),
              port: Number(body.port) || 587,
              secure: !!body.secure,
              user: String(body.user || '').trim(),
              // si no mandan pass nueva, conservar la guardada
              pass: body.pass ? String(body.pass) : cur?.pass || '',
              from: String(body.from || '').trim(),
            }
            writeJson(SMTP_FILE, cfg)
            return sendJson(res, 200, { ok: true })
          }
          if (p === '/smtp/test' && method === 'POST') {
            const g = ownerGate(req)
            if (!g.ok) return sendJson(res, 403, { error: g.error })
            const cfg = loadSmtp()
            if (!cfg || !cfg.host || !cfg.user)
              return sendJson(res, 200, { ok: false, error: 'Configura el correo primero.' })
            try {
              await sendMail(
                cfg.user,
                'Prueba del Asistente ✅',
                'Si ves este correo, el envío funciona.\n\nRevisa si llegó a "Principal" o a "Spam". Si cayó en Spam, márcalo como "No es spam" y agrega el remitente a tus contactos.',
              )
              return sendJson(res, 200, { ok: true })
            } catch (e: any) {
              return sendJson(res, 200, { ok: false, error: String(e?.message ?? e) })
            }
          }

          // ---- Escribir a los amigos (correos de sus perfiles) ----
          if (p === '/sendmail' && method === 'POST') {
            const g = ownerGate(req)
            if (!g.ok) return sendJson(res, 403, { error: g.error })
            const body = await readBody(req)
            const to = (Array.isArray(body.to) ? body.to : [])
              .map((e: any) => String(e).trim())
              .filter((e: string) => validEmail(e))
            const subject = String(body.subject || '(sin asunto)')
            const text = String(body.text || '')
            if (!to.length) return sendJson(res, 200, { ok: false, error: 'Sin destinatarios' })
            if (!loadSmtp())
              return sendJson(res, 200, { ok: false, error: 'Configura el correo primero.' })
            let sent = 0
            let failed = 0
            for (const addr of to) {
              try {
                await sendMail(addr, subject, text)
                sent++
              } catch {
                failed++
              }
            }
            return sendJson(res, 200, { ok: true, sent, failed })
          }

          // ---- Recuperar PIN por correo ----
          if (p === '/recover' && method === 'POST') {
            const body = await readBody(req)
            const email = String(body.email || '').trim().toLowerCase()
            if (!validEmail(email))
              return sendJson(res, 200, { ok: false, error: 'correo inválido' })
            const list = loadProfiles()
            const rec = list.find((x) => (x.email || '').toLowerCase() === email)
            if (!rec || !rec.pinHash)
              return sendJson(res, 200, {
                ok: false,
                error: 'No hay un perfil con PIN para ese correo.',
              })
            if (!loadSmtp())
              return sendJson(res, 200, {
                ok: false,
                error: 'El dueño aún no configuró el envío de correos.',
              })
            // Generar un PIN nuevo y guardarlo (no se puede recuperar el viejo).
            const newPin = String(Math.floor(1000 + Math.random() * 9000))
            rec.salt = crypto.randomBytes(8).toString('hex')
            rec.pinHash = hashPin(newPin, rec.salt)
            saveProfiles(list)
            try {
              await sendMail(
                rec.email!,
                'Tu nuevo PIN del Asistente',
                `Hola ${rec.name},\n\nTu nuevo PIN para entrar al perfil "${rec.name}" es: ${newPin}\n\nEntra y cámbialo si quieres.`,
              )
              return sendJson(res, 200, { ok: true, sent: true })
            } catch (e: any) {
              return sendJson(res, 200, {
                ok: false,
                error: 'No se pudo enviar el correo: ' + String(e?.message ?? e),
              })
            }
          }

          // ---- Correos de los perfiles (solo el dueño) ----
          if (p === '/emails' && method === 'GET') {
            const g = ownerGate(req)
            if (!g.ok) return sendJson(res, 403, { error: g.error })
            const emails = loadProfiles()
              .filter((x) => x.email)
              .map((x) => ({ name: x.name, avatar: x.avatar || '', email: x.email }))
            return sendJson(res, 200, { emails })
          }

          // ---- Muro entre amigos (compartido) ----
          if (p === '/wall' && method === 'GET') {
            const posts = readJson<any[]>(WALL_FILE, [])
            return sendJson(res, 200, { posts: posts.slice(-120) })
          }
          if (p === '/wall' && method === 'POST') {
            const body = await readBody(req)
            const text = String(body.text || '').slice(0, 1000)
            const sticker = String(body.sticker || '').slice(0, 40)
            if (!text && !sticker) return sendJson(res, 400, { error: 'vacío' })
            const post = {
              id: crypto.randomUUID(),
              author: String(body.author || 'Anónimo').slice(0, 40),
              avatar: String(body.avatar || '🙂').slice(0, 8),
              text,
              sticker: sticker || undefined,
              ai: !!body.ai,
              createdAt: Date.now(),
            }
            const posts = readJson<any[]>(WALL_FILE, [])
            posts.push(post)
            writeJson(WALL_FILE, posts.slice(-500))
            return sendJson(res, 200, { post })
          }
          if (p === '/wall/react' && method === 'POST') {
            const body = await readBody(req)
            const id = String(body.id || '')
            const emoji = String(body.emoji || '').slice(0, 8)
            const who = String(body.author || 'Anónimo').slice(0, 40)
            if (!id || !emoji) return sendJson(res, 400, { error: 'faltan datos' })
            const posts = readJson<any[]>(WALL_FILE, [])
            const post = posts.find((x) => x.id === id)
            if (!post) return sendJson(res, 404, { error: 'no existe' })
            post.reactions = post.reactions || {}
            const list: string[] = post.reactions[emoji] || []
            const i = list.indexOf(who)
            if (i >= 0) list.splice(i, 1)
            else list.push(who)
            if (list.length) post.reactions[emoji] = list
            else delete post.reactions[emoji]
            writeJson(WALL_FILE, posts.slice(-500))
            return sendJson(res, 200, { post })
          }
          if (p === '/wall/reply' && method === 'POST') {
            const body = await readBody(req)
            const id = String(body.id || '')
            const text = String(body.text || '').slice(0, 500)
            if (!id || !text) return sendJson(res, 400, { error: 'faltan datos' })
            const posts = readJson<any[]>(WALL_FILE, [])
            const post = posts.find((x) => x.id === id)
            if (!post) return sendJson(res, 404, { error: 'no existe' })
            post.replies = post.replies || []
            post.replies.push({
              author: String(body.author || 'Anónimo').slice(0, 40),
              avatar: String(body.avatar || '🙂').slice(0, 8),
              text,
              createdAt: Date.now(),
            })
            writeJson(WALL_FILE, posts.slice(-500))
            return sendJson(res, 200, { post })
          }
          if (p === '/wall/clear' && method === 'POST') {
            const g = ownerGate(req)
            if (!g.ok) return sendJson(res, 403, { error: g.error })
            writeJson(WALL_FILE, [])
            return sendJson(res, 200, { ok: true })
          }

          // ---- Datos por perfil ----
          if (p === '/data' && method === 'GET') {
            const id = url.searchParams.get('id') || ''
            const data = readJson<any>(dataFile(id), {})
            return sendJson(res, 200, { data })
          }
          if (p === '/data' && method === 'POST') {
            const body = await readBody(req)
            const id = String(body.id || '')
            if (!id || !loadProfiles().some((x) => x.id === id)) {
              return sendJson(res, 400, { error: 'perfil no encontrado' })
            }
            writeJson(dataFile(id), body.data ?? {})
            return sendJson(res, 200, { ok: true })
          }

          return sendJson(res, 404, { error: 'no encontrado' })
        } catch (e: any) {
          sendJson(res, 500, { error: String(e?.message ?? e) })
        }
      })
    },
  }
}
