import type { Source } from './types'
import { complete } from './ollama'

export interface SearchResult {
  title: string
  url: string
  snippet: string
}

export interface EffortLevel {
  queries: number
  results: number
  fetch: number
  label: string
}

export const EFFORT_LEVELS: Record<number, EffortLevel> = {
  1: { queries: 0, results: 3, fetch: 0, label: 'Rápido' },
  2: { queries: 0, results: 4, fetch: 1, label: 'Ligero' },
  3: { queries: 1, results: 5, fetch: 2, label: 'Medio' },
  4: { queries: 2, results: 6, fetch: 3, label: 'Alto' },
  5: { queries: 2, results: 8, fetch: 4, label: 'Profundo' },
}

export function effortLabel(e: number): string {
  return (EFFORT_LEVELS[e] ?? EFFORT_LEVELS[3]).label
}

export async function searchWeb(query: string, n: number): Promise<SearchResult[]> {
  try {
    const res = await fetch(`/websearch?q=${encodeURIComponent(query)}&n=${n}`)
    const data = await res.json()
    return (data.results ?? []) as SearchResult[]
  } catch {
    return []
  }
}

export async function fetchPage(url: string): Promise<{ title: string; text: string }> {
  try {
    const res = await fetch(`/webfetch?url=${encodeURIComponent(url)}`)
    const data = await res.json()
    return { title: data.title ?? '', text: data.text ?? '' }
  } catch {
    return { title: '', text: '' }
  }
}

async function makeQueries(
  question: string,
  count: number,
  model: string,
): Promise<string[]> {
  if (count <= 0) return [question]
  try {
    const raw = await complete({
      model,
      system: `Eres un generador de consultas de búsqueda web. A partir de la pregunta del usuario, escribe ${count} consulta(s) efectiva(s) con palabras clave (sin comillas). Una por línea, sin numerar, sin explicaciones.`,
      prompt: question,
    })
    const qs = raw
      .split('\n')
      .map((s) => s.replace(/^[-*\d.)\s]+/, '').trim())
      .filter(Boolean)
      .slice(0, count)
    return qs.length ? qs : [question]
  } catch {
    return [question]
  }
}

export interface ResearchOutput {
  contextBlock: string
  sources: Source[]
}

/** Orquesta la investigación: consultas → búsqueda → lectura → bloque de contexto. */
export async function runResearch(opts: {
  question: string
  effort: number
  model: string
  onStatus?: (s: string) => void
}): Promise<ResearchOutput> {
  const level = EFFORT_LEVELS[opts.effort] ?? EFFORT_LEVELS[3]

  opts.onStatus?.('🔎 Buscando en internet…')
  const queries = await makeQueries(opts.question, level.queries, opts.model)

  const seen = new Set<string>()
  const results: SearchResult[] = []
  for (const q of queries) {
    const rs = await searchWeb(q, level.results)
    for (const r of rs) {
      if (r.url && !seen.has(r.url)) {
        seen.add(r.url)
        results.push(r)
      }
    }
  }
  const top = results.slice(0, level.results)

  const pages: Record<string, string> = {}
  const toFetch = top.slice(0, level.fetch)
  if (toFetch.length) {
    opts.onStatus?.(`📄 Leyendo ${toFetch.length} página(s)…`)
    const fetched = await Promise.all(toFetch.map((r) => fetchPage(r.url)))
    fetched.forEach((p, i) => {
      if (p.text) pages[toFetch[i].url] = p.text
    })
  }

  const parts: string[] = []
  const sources: Source[] = []
  top.forEach((r, i) => {
    sources.push({ title: r.title, url: r.url })
    let block = `[${i + 1}] ${r.title}\nURL: ${r.url}\n${r.snippet}`
    if (pages[r.url]) block += `\nContenido:\n${pages[r.url].slice(0, 3000)}`
    parts.push(block)
  })

  const contextBlock = top.length
    ? `\n\n[Resultados de búsqueda en internet]\n${parts.join(
        '\n\n',
      )}\n\nInstrucciones: responde la pregunta usando estas fuentes y cítalas como [n] cuando las uses. Si la información no alcanza, dilo con claridad.`
    : `\n\n[Búsqueda en internet]\nNo se obtuvieron resultados ahora mismo. Dile al usuario que no pudiste encontrar información en internet en este momento.`

  return { contextBlock, sources }
}
