@echo off
chcp 65001 >nul
title Yuki - Encender TODO
cd /d "%~dp0"

echo ============================================================
echo   ENCENDIENDO YUKI  (no cierres las ventanas que se abran)
echo ============================================================
echo.

REM --- 1) Ollama (la IA). Normalmente ya corre solo (icono en la barra). ---
powershell -NoProfile -Command "try{(Invoke-WebRequest http://localhost:11434 -UseBasicParsing -TimeoutSec 2)^|Out-Null;exit 0}catch{exit 1}" >nul 2>nul
if errorlevel 1 (
  echo  - Ollama no responde: lo intento arrancar...
  where ollama >nul 2>nul && start "Yuki - Ollama (no cerrar)" /min cmd /k "ollama serve"
) else (
  echo  - Ollama: OK
)

REM --- 2) Servidor de imagenes / voz / documentos (Python, puerto 7861) ---
if exist "sd-server\.venv\Scripts\python.exe" (
  echo  - Encendiendo servidor de imagenes/voz/documentos...
  start "Yuki - Imagenes-Voz-Docs (no cerrar)" cmd /k "cd /d "%~dp0sd-server" ^&^& .venv\Scripts\python.exe server.py"
) else (
  echo  - (Saltado: no encontre sd-server\.venv, las imagenes/voz podrian no funcionar)
)

REM --- 3) La app principal de Yuki (puerto 5173) ---
echo  - Encendiendo la app de Yuki...
start "Yuki - App (no cerrar)" cmd /k "npm run host"

REM --- 4) Esperar a que la app levante ---
echo.
echo  Esperando a que la app arranque (unos segundos)...
:wait
timeout /t 2 >nul
powershell -NoProfile -Command "try{(Invoke-WebRequest http://localhost:5173 -UseBasicParsing -TimeoutSec 2)^|Out-Null;exit 0}catch{exit 1}" >nul 2>nul
if errorlevel 1 goto wait

REM --- 5) Enlace publico (Funnel) para telefono / Chromebook SIN Tailscale ---
echo  - Publicando el enlace fijo...
set "TS=C:\Program Files\Tailscale\tailscale.exe"
"%TS%" funnel --bg 5173 >nul 2>nul

echo.
echo ============================================================
echo   LISTO. Yuki esta ENCENDIDO.
echo.
echo   En esta PC:            http://localhost:5173
echo   Desde cualquier lado:  https://maikel.tail1907d2.ts.net
echo.
echo   IMPORTANTE: deja abiertas las ventanas negras "no cerrar".
echo   Si cierras una, ese servidor se apaga.
echo   Para APAGAR todo: cierra esas ventanas.
echo ============================================================
echo.
start "" "http://localhost:5173"
echo  (Puedes cerrar SOLO esta ventana; las otras deben quedarse.)
pause
