import type { DeviceKind } from '../lib/device'

interface Props {
  device: DeviceKind
  onClose: () => void
}

const SHORTCUTS: [string, string][] = [
  ['Alt + N', 'Nuevo chat'],
  ['Alt + M', 'Abrir memoria'],
  ['Alt + S', 'Ajustes'],
  ['Alt + E', 'Exportar chat a Markdown'],
  ['Alt + V', 'Manos libres (voz)'],
  ['Alt + F', 'Modo concentración (ocultar menú)'],
  ['Esc', 'Detener respuesta / voz'],
  ['Ctrl + V', 'Pegar una imagen para analizarla'],
]

const GESTURES: [string, string][] = [
  ['👉 Desliza desde el borde izquierdo', 'Abre el menú de chats'],
  ['👈 Desliza hacia la izquierda', 'Cierra el menú'],
  ['📷 Botón cámara', 'Toma una foto de un ejercicio y te lo resuelve'],
  ['✌️ Doble toque en un chat', 'Renombrarlo'],
]

const TIPS: [string, string][] = [
  ['🧑‍💻 Studio de código', 'Escribe, ejecuta e instala Python (solo admin)'],
  ['🪟 Ver ventana', 'Programas con ventana (pygame/turtle/tkinter) en vivo en tu pantalla'],
  ['💭 Modo pensar', 'Yuki razona paso a paso antes de responder'],
  ['▶️ Ejecutar Python', 'Pide código Python y córrelo con el botón ▶️'],
  ['📌 Anclar chats', 'Pulsa el 📌 de un chat para fijarlo arriba'],
  ['🤖 Modo Auto', 'Yuki elige solo el mejor modelo para cada tarea'],
  ['🖥️ Estado de servidores', 'En PC, revisa Ollama/GPU y libera memoria'],
  ['🎨 📄 🎤 🔎', 'Imagen · Documento · Voz · Búsqueda web'],
]

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex items-start justify-between gap-3 py-1.5">
      <span className="text-sm text-zinc-600 dark:text-zinc-300">{v}</span>
      <kbd className="shrink-0 text-[11px] font-mono rounded border border-zinc-300 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-800 px-1.5 py-0.5 text-zinc-700 dark:text-zinc-200 whitespace-nowrap">
        {k}
      </kbd>
    </div>
  )
}

export default function HelpPanel({ device, onClose }: Props) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
      <div className="w-full max-w-md max-h-[85vh] overflow-y-auto rounded-2xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 shadow-xl">
        <div className="sticky top-0 flex items-center justify-between px-5 h-14 border-b border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900">
          <h2 className="font-semibold">⌨️ Atajos y gestos</h2>
          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800"
            title="Cerrar"
          >
            ✕
          </button>
        </div>

        <div className="p-5 space-y-5">
          {device === 'phone' ? (
            <section>
              <h3 className="text-xs font-semibold uppercase tracking-wide text-zinc-400 mb-1">
                📱 Gestos
              </h3>
              {GESTURES.map(([k, v]) => (
                <Row key={v} k={k} v={v} />
              ))}
            </section>
          ) : (
            <section>
              <h3 className="text-xs font-semibold uppercase tracking-wide text-zinc-400 mb-1">
                ⌨️ Atajos de teclado
              </h3>
              {SHORTCUTS.map(([k, v]) => (
                <Row key={v} k={k} v={v} />
              ))}
            </section>
          )}

          <section>
            <h3 className="text-xs font-semibold uppercase tracking-wide text-zinc-400 mb-1">
              ✨ Trucos
            </h3>
            {TIPS.map(([k, v]) => (
              <Row key={v} k={k} v={v} />
            ))}
          </section>

          <p className="text-xs text-zinc-400 text-center pt-1">
            100% local · privado · gratis
          </p>
        </div>
      </div>
    </div>
  )
}
