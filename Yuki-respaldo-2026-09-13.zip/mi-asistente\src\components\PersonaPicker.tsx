import type { Persona } from '../lib/types'

interface Props {
  personas: Persona[]
  value: string
  onChange: (id: string) => void
}

export default function PersonaPicker({ personas, value, onChange }: Props) {
  return (
    <select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className="rounded-lg border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-sm px-2 py-1.5 max-w-[38vw] md:max-w-[11rem] outline-none"
      title="Persona / rol"
    >
      {personas.map((p) => (
        <option key={p.id} value={p.id}>
          {p.emoji ? p.emoji + ' ' : ''}
          {p.name}
        </option>
      ))}
    </select>
  )
}
