import { createContext, useContext } from 'react'

/** Prefijo de la clave donde se guarda la contraseña de administrador. */
export const OWNER_KEY = 'asistente:ownerPass'

/** Clave POR PERFIL: el desbloqueo de administrador no se comparte entre perfiles. */
export function ownerKey(profileId?: string | null): string {
  return `${OWNER_KEY}:${profileId || 'default'}`
}

export interface OwnerCtx {
  /** Contraseña de administrador si este dispositivo está desbloqueado; si no, null. */
  ownerPass: string | null
  /** Guarda la contraseña (desbloquea el modo administrador en este dispositivo). */
  unlock: (pass: string) => void
  /** Olvida la contraseña (bloquea de nuevo). */
  lock: () => void
}

export const OwnerContext = createContext<OwnerCtx>({
  ownerPass: null,
  unlock: () => {},
  lock: () => {},
})

export const useOwner = () => useContext(OwnerContext)
