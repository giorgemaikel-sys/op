import type { Plugin } from 'vite'
import * as cheerio from 'cheerio'

const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36'

interface Result {
  title: string
  url: string
  snippet: string
}

async function fetchWithTimeout(
  url: string,
  init: RequestInit = {},
  ms = 12000,
): Promise<Response> {
  const ac = new AbortController()
  const t = setTimeout(() => ac.abort(), ms)
  try {
    return await fetch(url, { ...init, signal: ac.signal })
  } finally {
    clearTimeout(t)
  }
}

/** Decodifica el enlace de redirección de DuckDuckGo (?uddg=...). */
function resolveDdgHref(href: string): string {
  if (!href) return ''
  let h = href
  if (h.startsWith('//')) h = 'https:' + h
  try {
    const u = new URL(h, 'https://duckduckgo.com')
    const uddg = u.searchParams.get('uddg')
    if (uddg) return decodeURIComponent(uddg)
    if (u.protocol === 'http:' || u.protocol === 'https:') return u.toString()
  } catch {
    /* ignore */
  }
  return h.startsWith('http') ? h : ''
}

async function searchDuckDuckGo(query: string, n: number): Promise<Result[]> {
  const url =
    'https://lite.duckduckgo.com/lite/?q=' + encodeURIComponent(query)
  const res = await fetchWithTimeout(url, {
    headers: {
      'User-Agent': UA,
      'Accept-Language': 'es-ES,es;q=0.9,en;q=0.8',
      Accept: 'text/html',
    },
  })
  if (!res.ok) throw new Error('ddg ' + res.status)
  const html = await res.text()
  const $ = cheerio.load(html)

  const links = $('a.result-link')
  const snippets = $('.result-snippet')
  const results: Result[] = []
  links.each((i, el) => {
    const title = $(el).text().trim()
    const url = resolveDdgHref($(el).attr('href') || '')
    const snippet = snippets.eq(i).text().trim()
    if (title && url) results.push({ title, url, snippet })
  })
  return results.slice(0, n)
}

async function searchWikipedia(query: string, n: number): Promise<Result[]> {
  for (const lang of ['es', 'en']) {
    try {
      const api =
        `https://${lang}.wikipedia.org/w/api.php?action=query&list=search` +
        `&srsearch=${encodeURIComponent(query)}&srlimit=${n}&format=json&origin=*`
      const res = await fetchWithTimeout(api, {
        headers: { 'User-Agent': UA },
      })
      if (!res.ok) continue
      const data: any = await res.json()
      const hits = data?.query?.search ?? []
      if (!hits.length) continue
      return hits.map((h: any) => ({
        title: h.title as string,
        url: `https://${lang}.wikipedia.org/wiki/${encodeURIComponent(
          String(h.title).replace(/ /g, '_'),
        )}`,
        snippet: String(h.snippet || '').replace(/<[^>]+>/g, ''),
      }))
    } catch {
      /* siguiente idioma */
    }
  }
  return []
}

async function doSearch(query: string, n: number): Promise<Result[]> {
  // DDG con un reintento; si falla o viene vacío, Wikipedia.
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const r = await searchDuckDuckGo(query, n)
      if (r.length) return r
    } catch {
      /* reintentar */
    }
    await new Promise((r) => setTimeout(r, 400))
  }
  return searchWikipedia(query, n)
}

async function fetchPageText(
  url: string,
): Promise<{ title: string; text: string }> {
  const res = await fetchWithTimeout(
    url,
    { headers: { 'User-Agent': UA, Accept: 'text/html' } },
    12000,
  )
  const ctype = res.headers.get('content-type') || ''
  if (!res.ok || !ctype.includes('text/html')) {
    return { title: '', text: '' }
  }
  const html = await res.text()
  const $ = cheerio.load(html)
  const title = ($('title').first().text() || '').trim()
  $('script, style, noscript, nav, footer, header, aside, form, svg').remove()
  const main = $('article').text() || $('main').text() || $('body').text()
  const text = main.replace(/[ \t]+/g, ' ').replace(/\n\s*\n\s*/g, '\n\n').trim()
  return { title, text: text.slice(0, 8000) }
}

function sendJson(res: any, code: number, body: unknown) {
  res.statusCode = code
  res.setHeader('Content-Type', 'application/json; charset=utf-8')
  res.end(JSON.stringify(body))
}

/** Plugin de Vite: endpoints /websearch y /webfetch en el mismo servidor. */
export function webSearchPlugin(): Plugin {
  return {
    name: 'asistente-web-search',
    configureServer(server) {
      server.middlewares.use(
        '/websearch',
        async (req: any, res: any) => {
          try {
            const u = new URL(req.url || '', 'http://localhost')
            const q = (u.searchParams.get('q') || '').trim()
            const n = Math.min(
              10,
              Math.max(1, parseInt(u.searchParams.get('n') || '5', 10) || 5),
            )
            if (!q) return sendJson(res, 400, { error: 'falta q', results: [] })
            const results = await doSearch(q, n)
            sendJson(res, 200, { results })
          } catch (e: any) {
            sendJson(res, 200, { results: [], error: String(e?.message ?? e) })
          }
        },
      )

      server.middlewares.use(
        '/webfetch',
        async (req: any, res: any) => {
          try {
            const u = new URL(req.url || '', 'http://localhost')
            const target = u.searchParams.get('url') || ''
            if (!/^https?:\/\//i.test(target)) {
              return sendJson(res, 400, { title: '', text: '', error: 'url inválida' })
            }
            const page = await fetchPageText(target)
            sendJson(res, 200, page)
          } catch (e: any) {
            sendJson(res, 200, { title: '', text: '', error: String(e?.message ?? e) })
          }
        },
      )
    },
  }
}
