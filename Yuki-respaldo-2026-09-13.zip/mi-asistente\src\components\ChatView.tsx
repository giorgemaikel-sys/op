import { useEffect, useRef } from 'react'
import type { Conversation } from '../lib/types'
import { useDevice, deviceLabel, type DeviceKind } from '../lib/device'
import MessageBubble from './MessageBubble'

interface Props {
  conversation: Conversation | null
  isStreaming: boolean
  onSuggest: (text: string) => void
  onRegenerate: () => void
  onEditUser: (messageId: string, newText: string) => void
  onSpeak: (text: string) => void
  onQuick: (text: string) => void
  onFollowups?: () => Promise<string[]>
}

const SUGGESTIONS_BY_DEVICE: Record<DeviceKind, string[]> = {
  phone: [
    'Enséñame algo nuevo en 3 líneas',
    'Resuélveme un ejercicio (toma una foto con 📷)',
    'Ponme un mini examen rápido',
    '¿Qué puedes hacer?',
  ],
  laptop: [
    'Enséñame un tema paso a paso',
    'Hazme tarjetas de estudio de un tema',
    'Ponme un examen de un tema',
    'Explícame algo difícil con un dibujo',
  ],
  desktop: [
    'Créame una presentación completa de…',
    'Escríbeme un documento (Word/PDF) de…',
    'Enséñame un tema con gráficas y dibujos',
    'Genera una imagen de…',
  ],
}

const DEVICE_TIP: Record<DeviceKind, string> = {
  phone: '💡 Toca 📷 para tomar una foto de un ejercicio y que te lo resuelva paso a paso.',
  laptop: '💡 Atajos: Alt+N nuevo chat · Alt+M memoria · Alt+S ajustes · Alt+V voz.',
  desktop: '💡 Tu PC es donde más rinde: presentaciones, documentos e imágenes salen a tope aquí.',
}

export default function ChatView({
  conversation,
  isStreaming,
  onSuggest,
  onRegenerate,
  onEditUser,
  onSpeak,
  onQuick,
  onFollowups,
}: Props) {
  const bottomRef = useRef<HTMLDivElement>(null)
  const device = useDevice()
  const suggestions = SUGGESTIONS_BY_DEVICE[device]
  const messages = conversation?.messages ?? []
  const lastContent = messages[messages.length - 1]?.content ?? ''

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages.length, lastContent])

  if (!conversation || messages.length === 0) {
    return (
      <div className="flex-1 overflow-y-auto flex flex-col items-center justify-center text-center px-6">
        <img
          src="/icon-192.png"
          alt="Yuki"
          className="h-24 w-24 rounded-3xl object-cover mb-4 shadow-lg"
        />
        <h1 className="text-2xl font-semibold mb-2">Hola, soy Yuki 👋</h1>
        <p className="text-zinc-500 dark:text-zinc-400 max-w-md mb-2">
          Tu asistente local, privado y gratis. Escribe abajo, adjunta un PDF
          o pega una imagen (Ctrl+V) para que la analice.
        </p>
        <p className="text-xs text-zinc-400 mb-6">
          Optimizado para tu {deviceLabel[device].toLowerCase()}
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 w-full max-w-lg">
          {suggestions.map((s) => (
            <button
              key={s}
              onClick={() => onSuggest(s)}
              className="text-left text-sm rounded-xl border border-zinc-200 dark:border-zinc-800 px-4 py-3 hover:bg-zinc-100 dark:hover:bg-zinc-800/60 transition-colors"
            >
              {s}
            </button>
          ))}
        </div>
        <p className="text-xs text-zinc-400 dark:text-zinc-500 max-w-lg mt-4">
          {DEVICE_TIP[device]}
        </p>
      </div>
    )
  }

  return (
    <div className="flex-1 overflow-y-auto">
      <div className="max-w-3xl mx-auto px-4 py-6 space-y-4">
        {messages.map((m, i) => (
          <MessageBubble
            key={m.id}
            message={m}
            isLast={i === messages.length - 1}
            isStreaming={isStreaming}
            onRegenerate={onRegenerate}
            onEdit={(t) => onEditUser(m.id, t)}
            onSpeak={() => onSpeak(m.content)}
            onQuick={onQuick}
            onFollowups={i === messages.length - 1 ? onFollowups : undefined}
          />
        ))}
        <div ref={bottomRef} />
      </div>
    </div>
  )
}
