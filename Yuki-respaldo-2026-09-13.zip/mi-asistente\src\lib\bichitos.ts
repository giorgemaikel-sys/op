/**
 * bichitos.ts — motor de "bichitos de escritorio" para la web (dentro de Yuki).
 *
 * Portado fielmente de la app nativa (pet.py / characters.py / main.py):
 * los animalitos caminan por el piso de la pantalla de Yuki, se los puede
 * arrastrar, se sientan, se duermen (cada uno a su manera), hacen sus gracias
 * (el gato juega, el dino llora/ríe, el colibrí canta, el fantasma asusta, la
 * elfa dispara una flecha, el robot lanza su gancho), el perro salta y el
 * fantasma/colibrí vuelan. "Trepan" por los bordes de la pantalla.
 *
 * Funciona en cualquier dispositivo con navegador (celular, laptop, Chromebook)
 * sin instalar nada. Usa los sprites de /public/bichitos/.
 */

const BASE = '/bichitos'

// --- constantes de física (idénticas a pet.py) --------------------------------
const GRAVITY = 1.8
const WALK = 1.5
const FLOAT = 0.95
const CLIMB = 1.6
const JUMP_V = 16.0
const JUMP_VX = 3.2
const P_SEEK = 0.013
const P_JUMP = 0.006
const P_GRAPPLE = 0.004
export const TICK_MS = 40

// --- registro de personajes (de characters.py) --------------------------------
interface SpecialSpec {
  name: string
  dir: string
  frames: number
  kind?: 'sleep'
  h?: number
  cx_frac?: number
  loops?: number
  cd?: number
  weight?: number
  speed?: number
  hold?: number
  goto?: 'top' | 'floor'
  shoot?: { at: number; speed: number; arrow: string }
}
interface CharSpec {
  name: string
  flies: boolean
  image?: string
  frames?: number
  base_h?: number
  native_facing?: number
  special_rate?: number
  jump_image?: string
  jump_frames?: number
  jump_h?: number
  grapple_image?: string
  grapple_frames?: number
  grapple_h?: number
  grapple_cx_frac?: number
  draw?: 'claude'
  specials?: SpecialSpec[]
}

export const CHARACTERS: Record<string, CharSpec> = {
  gato: {
    name: 'Gato', flies: false, image: 'gato', frames: 8, base_h: 80, native_facing: 1,
    special_rate: 0.012,
    specials: [
      { name: 'play', dir: 'gato_play', frames: 4, loops: 3, cd: 220, speed: 6 },
      { name: 'dormir', dir: 'gato_dormir', frames: 6, kind: 'sleep', h: 60, loops: 6, speed: 10 },
    ],
  },
  perro: {
    name: 'Perro', flies: false, image: 'perro', frames: 6, base_h: 86, native_facing: 1,
    jump_image: 'perro_salto', jump_frames: 10, jump_h: 116,
    specials: [{ name: 'dormir', dir: 'perro_dormir', frames: 6, kind: 'sleep', h: 56, loops: 6, speed: 10 }],
  },
  conejo: {
    name: 'Conejo', flies: false, image: 'conejo', frames: 12, base_h: 84, native_facing: 1,
    specials: [{ name: 'dormir', dir: 'conejo_dormir', frames: 4, kind: 'sleep', h: 80, loops: 1, hold: 150, speed: 14 }],
  },
  elfa: {
    name: 'Elfa', flies: false, image: 'elfa', frames: 8, base_h: 104, native_facing: 1,
    special_rate: 0.010,
    specials: [
      { name: 'disparo', dir: 'elfa_shoot', frames: 6, h: 102, cx_frac: 0.42, loops: 1, cd: 450, speed: 8,
        shoot: { at: 4, speed: 12.0, arrow: 'flecha' } },
      { name: 'dormir', dir: 'elfa_dormir', frames: 4, kind: 'sleep', h: 76, loops: 1, hold: 150, speed: 14 },
    ],
  },
  dino: {
    name: 'Dinosaurio', flies: false, image: 'dino', frames: 8, base_h: 90, native_facing: 1,
    special_rate: 0.007,
    specials: [
      { name: 'llora', dir: 'dino_llora', frames: 6, loops: 1, cd: 800, weight: 1, speed: 7 },
      { name: 'feliz', dir: 'dino_feliz', frames: 3, loops: 2, cd: 800, weight: 2, speed: 8 },
      { name: 'dormir', dir: 'dino_dormir', frames: 4, kind: 'sleep', h: 82, loops: 1, hold: 150, speed: 14 },
    ],
  },
  robot: {
    name: 'Robot', flies: false, image: 'robot', frames: 3, base_h: 80, native_facing: 1,
    grapple_image: 'robot_grapple', grapple_frames: 9, grapple_h: 80, grapple_cx_frac: 0.21,
    specials: [{ name: 'dormir', dir: 'robot_dormir', frames: 4, kind: 'sleep', h: 80, loops: 1, hold: 150, speed: 14 }],
  },
  claude: { name: 'Claude', flies: false, draw: 'claude' },
  fantasma: {
    name: 'Fantasma', flies: true, image: 'fantasma', frames: 4, base_h: 96, native_facing: 1,
    special_rate: 0.006,
    specials: [
      { name: 'susto', dir: 'fantasma_susto', frames: 6, loops: 1, cd: 700, speed: 6 },
      { name: 'dormir', dir: 'fantasma_dormir', frames: 4, kind: 'sleep', h: 150, loops: 1, hold: 150, speed: 14, goto: 'top' },
    ],
  },
  colibri: {
    name: 'Colibrí', flies: true, image: 'colibri', frames: 6, base_h: 80, native_facing: 1,
    special_rate: 0.007,
    specials: [
      { name: 'canta', dir: 'colibri_canta', frames: 3, loops: 3, cd: 600, speed: 6 },
      { name: 'dormir', dir: 'colibri_dormir', frames: 3, kind: 'sleep', h: 74, loops: 1, hold: 150, speed: 14, goto: 'floor' },
    ],
  },
  pollito: {
    name: 'Pollito', flies: false, image: 'pollito', frames: 16, base_h: 96, native_facing: 1,
    specials: [{ name: 'dormir', dir: 'pollito_dormir', frames: 4, kind: 'sleep', h: 86, loops: 1, hold: 150, speed: 14 }],
  },
  esqueleto: {
    name: 'Esqueleto', flies: false, image: 'esqueleto', frames: 6, base_h: 94, native_facing: 1,
    special_rate: 0.006,
    specials: [{ name: 'dormir', dir: 'esqueleto_dormir', frames: 5, h: 94, cx_frac: 0.5, kind: 'sleep', loops: 1, speed: 12, hold: 150 }],
  },
}

export const ORDER = ['pollito', 'gato', 'perro', 'conejo', 'elfa', 'dino', 'robot', 'claude', 'fantasma', 'colibri', 'esqueleto']

export const BTN_COLORS: Record<string, string> = {
  pollito: '#ffd23f', gato: '#f4a24c', perro: '#d2a679', conejo: '#9aa6c8',
  elfa: '#b39ddb', dino: '#6cbf6c', robot: '#b8c0cc', claude: '#d97757',
  fantasma: '#c9c2ea', colibri: '#b8a9e0', esqueleto: '#d9d2c5',
}

// --- carga de sprites ---------------------------------------------------------
interface Sprite {
  name: string
  n: number
  ok: boolean
  w: number
  h: number
  imgs: HTMLImageElement[]
}
const _spriteCache = new Map<string, Sprite>()
function loadSprite(name: string, frames: number): Sprite {
  const cached = _spriteCache.get(name)
  if (cached) return cached
  const spr: Sprite = { name, n: frames, ok: false, w: 0, h: 0, imgs: [] }
  for (let i = 0; i < frames; i++) {
    const img = new Image()
    img.decoding = 'async'
    img.src = `${BASE}/${name}/${i}.png`
    if (i === 0) {
      img.onload = () => {
        spr.w = img.naturalWidth
        spr.h = img.naturalHeight
        spr.ok = true
      }
    }
    spr.imgs.push(img)
  }
  _spriteCache.set(name, spr)
  return spr
}
function sizeFor(spr: Sprite | null, targetH: number): [number, number] {
  if (!spr || !spr.ok || !spr.h) return [targetH, targetH]
  return [Math.max(1, Math.round((spr.w * targetH) / spr.h)), targetH]
}

// --- utilidades ---------------------------------------------------------------
const rand = Math.random
function randint(a: number, b: number) { return Math.floor(rand() * (b - a + 1)) + a }
function choice<T>(arr: T[]): T { return arr[Math.floor(rand() * arr.length)] }
function choices<T>(opts: T[], weights: number[]): T {
  const total = weights.reduce((s, w) => s + w, 0)
  let r = rand() * total
  for (let i = 0; i < opts.length; i++) { r -= weights[i]; if (r <= 0) return opts[i] }
  return opts[opts.length - 1]
}
const DPR = Math.max(1, Math.min(3, Math.round(window.devicePixelRatio || 1)))

// --- dibujo vectorial de Claude (de sprites.py + draw_claude) -----------------
function makeDraw(ctx: CanvasRenderingContext2D, facing: number, cx: number) {
  const fx = (x: number) => (facing < 0 ? 2 * cx - x : x)
  return {
    rrect(x1: number, y1: number, x2: number, y2: number, r: number, fill: string) {
      const a = fx(x1), b = fx(x2), L = Math.min(a, b), R = Math.max(a, b)
      const rr = Math.min(r, (R - L) / 2, (y2 - y1) / 2)
      ctx.beginPath()
      ctx.moveTo(L + rr, y1)
      ctx.arcTo(R, y1, R, y2, rr)
      ctx.arcTo(R, y2, L, y2, rr)
      ctx.arcTo(L, y2, L, y1, rr)
      ctx.arcTo(L, y1, R, y1, rr)
      ctx.closePath()
      ctx.fillStyle = fill
      ctx.fill()
    },
    line(x1: number, y1: number, x2: number, y2: number, fill: string, width = 2) {
      ctx.beginPath()
      ctx.moveTo(fx(x1), y1)
      ctx.lineTo(fx(x2), y2)
      ctx.strokeStyle = fill
      ctx.lineWidth = width
      ctx.lineCap = 'round'
      ctx.stroke()
    },
    dot(x: number, y: number, r: number, fill: string) {
      ctx.beginPath()
      ctx.ellipse(fx(x), y, r, r, 0, 0, Math.PI * 2)
      ctx.fillStyle = fill
      ctx.fill()
    },
  }
}
function drawClaude(
  ctx: CanvasRenderingContext2D, W: number, H: number, facing: number,
  state: string, phase: number, blink: boolean,
) {
  const sx = (W * DPR) / 100
  const sy = (H * DPR) / 100
  ctx.setTransform(sx, 0, 0, sy, 0, 0)
  ctx.clearRect(0, 0, 100, 100)
  const oy = state === 'sit' || state === 'sleep' ? 8 : 0
  const s = state === 'walk' ? (phase % 2 === 0 ? 3 : -3) : 0
  const body = '#d97757', dark = '#c15f3f'
  const closed = blink || state === 'sleep'
  const D = makeDraw(ctx, facing, 50)
  const eye = (x: number, y: number) => {
    if (closed) D.line(x - 3, y, x + 3, y, '#5a2c1c', 2)
    else D.dot(x, y, 2.6, '#5a2c1c')
  }
  D.rrect(41 - s, 70 + oy, 48 - s, 88, 3, dark)
  D.rrect(52 + s, 70 + oy, 59 + s, 88, 3, dark)
  D.rrect(26, 52 + oy, 33, 70 + oy, 3, body)
  D.rrect(67, 52 + oy, 74, 70 + oy, 3, body)
  D.rrect(30, 42 + oy, 70, 78 + oy, 17, body)
  const cx0 = 50, cy0 = 30 + oy
  for (let ang = 0; ang < 360; ang += 45) {
    const radn = (ang * Math.PI) / 180
    D.line(cx0, cy0, cx0 + 11 * Math.cos(radn), cy0 + 11 * Math.sin(radn), dark, 2)
  }
  D.dot(cx0, cy0, 4, '#f0a077')
  eye(43, 56 + oy)
  eye(57, 56 + oy)
  D.dot(38, 62 + oy, 3, '#ffb59a')
  D.dot(62, 62 + oy, 3, '#ffb59a')
  if (!closed) D.line(44, 64 + oy, 56, 64 + oy, '#5a2c1c', 2)
}

// --- un bichito ---------------------------------------------------------------
interface Bounds { b0: number; top0: number; b2: number; bottom0: number; floor: number }

export class Pet {
  id = ''
  key: string
  spec: CharSpec
  flies: boolean
  world: BichitosWorld
  el: HTMLDivElement
  private img: HTMLImageElement | null = null
  private canvas: HTMLCanvasElement | null = null
  private ctx: CanvasRenderingContext2D | null = null
  private zzz: HTMLSpanElement

  isImage: boolean
  nFrames: number
  baseH: number
  native: number
  sprite: Sprite | null = null
  jumpSprite: Sprite | null = null
  jumpFrames = 0
  jumpH = 0
  hasJump = false
  grappleSprite: Sprite | null = null
  grappleFrames = 0
  grappleH = 0
  grappleCxFrac = 0.5
  hasGrapple = false
  animSpecials: any[] = []
  sleepSpecial: any = null
  specialRate: number

  W = 40
  H = 40
  cx = 20
  ground = 40
  scale = 1
  facing: number
  anim = 0
  private animSub = 0
  animEvery: number
  blink = false
  private blinkLeft = 0
  vy = 0
  vx = 0
  support: number | null = 0
  state = 'walk'
  active: 'walk' | 'jump' | 'grapple' | 'special' = 'walk'
  timer = 60
  x = 0
  y = 0
  hoverY = 0
  targetY = 0

  private jumpCd = 0
  private grappleCd = 0
  private grappleIdx = 0
  private grappleSub = 0
  private climbCd = 0
  private climbDir = 0
  private climbTop = 0
  private climbHold = 0
  private climbHoldMax = 0
  private seekSide: 'L' | 'R' = 'L'
  private seekX = 0
  curSpecial: any = null
  private specialIdx = 0
  private specialSub = 0
  private specialReturn = 'walk'
  private specialShot = false
  private specialHold = 0
  private pendingSleep: any = null
  private sleepTx = 0
  private sleepTy = 0
  private needResize = false
  private dragOff = [0, 0]
  private dragId = -1

  constructor(world: BichitosWorld, key: string) {
    this.world = world
    this.key = key
    this.spec = CHARACTERS[key]
    this.flies = this.spec.flies
    this.isImage = !!this.spec.image
    this.nFrames = this.spec.frames || 1
    this.baseH = this.spec.base_h || 92
    this.native = this.spec.native_facing || 1
    this.specialRate = this.spec.special_rate ?? 0.01
    this.scale = world.scale
    this.facing = choice([-1, 1])
    this.animEvery = this.flies ? 2 : this.isImage ? 3 : 7

    if (this.isImage) {
      this.sprite = loadSprite(this.spec.image!, this.nFrames)
      if (this.spec.jump_image) {
        this.jumpSprite = loadSprite(this.spec.jump_image, this.spec.jump_frames || 0)
        this.jumpFrames = this.spec.jump_frames || 0
        this.jumpH = this.spec.jump_h || this.baseH
        this.hasJump = true
      }
      if (this.spec.grapple_image) {
        this.grappleSprite = loadSprite(this.spec.grapple_image, this.spec.grapple_frames || 0)
        this.grappleFrames = this.spec.grapple_frames || 0
        this.grappleH = this.spec.grapple_h || this.baseH
        this.grappleCxFrac = this.spec.grapple_cx_frac ?? 0.5
        this.hasGrapple = true
      }
      for (const sp of this.spec.specials || []) {
        const spr = loadSprite(sp.dir, sp.frames)
        const entry = {
          name: sp.name, sprite: spr, frames: sp.frames, h: sp.h ?? this.baseH,
          cx_frac: sp.cx_frac ?? 0.5, loops: sp.loops ?? 1, cd: sp.cd ?? 300,
          weight: sp.weight ?? 1, speed: sp.speed ?? 6, shoot: sp.shoot,
          hold: sp.hold ?? 0, goto: sp.goto, cd_left: 0,
        }
        if (sp.kind === 'sleep') this.sleepSpecial = entry
        else this.animSpecials.push(entry)
      }
    }

    // elemento (creado en el documento destino: página o ventana flotante PiP)
    const doc = world.doc
    this.el = doc.createElement('div')
    this.el.className = 'yuki-pet'
    this.el.style.cssText =
      'position:absolute;left:0;top:0;pointer-events:auto;cursor:grab;' +
      'touch-action:none;user-select:none;-webkit-user-select:none;will-change:transform;'
    if (this.isImage) {
      this.img = doc.createElement('img')
      this.img.draggable = false
      this.img.style.cssText = 'position:absolute;left:0;top:0;width:100%;height:100%;pointer-events:none;'
      this.el.appendChild(this.img)
    } else {
      this.canvas = doc.createElement('canvas')
      this.canvas.style.cssText = 'position:absolute;left:0;top:0;width:100%;height:100%;pointer-events:none;'
      this.ctx = this.canvas.getContext('2d')
      this.el.appendChild(this.canvas)
    }
    this.zzz = doc.createElement('span')
    this.zzz.textContent = '💤'
    this.zzz.style.cssText =
      'position:absolute;top:-6px;right:-6px;font-size:16px;pointer-events:none;display:none;'
    this.el.appendChild(this.zzz)

    this.recomputeMetrics()
    this.resizeEl()

    const b = world.bounds
    if (this.flies) {
      this.hoverY = Math.max(b.top0 + 10, b.floor - 150)
      this.x = rand() * Math.max(0, b.b2 - this.W)
      this.y = this.hoverY
      this.targetY = this.hoverY
      this.vx = FLOAT * this.facing
      this.state = 'float'
    } else {
      const fx = b.b0 + this.cx + 4 + rand() * Math.max(1, b.b2 - b.b0 - 2 * this.cx - 8)
      this.x = fx - this.cx
      this.y = b.floor - this.ground
      this.vx = WALK * this.facing
      this.state = 'walk'
    }
    this.timer = randint(50, 130)
    this.apply()

    this.el.addEventListener('pointerdown', this.onDown)
  }

  private activeSprite(): [Sprite | null, number] {
    if (this.active === 'jump' && this.hasJump) return [this.jumpSprite, this.jumpH]
    if (this.active === 'grapple' && this.hasGrapple) return [this.grappleSprite, this.grappleH]
    if (this.active === 'special' && this.curSpecial) return [this.curSpecial.sprite, this.curSpecial.h]
    return [this.sprite, this.baseH]
  }

  private recomputeMetrics() {
    if (this.isImage) {
      const [spr, bh] = this.activeSprite()
      const targetH = Math.max(26, Math.round(bh * this.scale))
      const [nw, nh] = sizeFor(spr, targetH)
      this.W = nw
      this.H = nh
      if (this.active === 'grapple' && this.hasGrapple) {
        let frac = this.grappleCxFrac
        if (this.facing !== this.native) frac = 1 - frac
        this.cx = frac * nw
      } else if (this.active === 'special' && this.curSpecial) {
        let frac = this.curSpecial.cx_frac
        if (this.facing !== this.native) frac = 1 - frac
        this.cx = frac * nw
      } else {
        this.cx = nw / 2
      }
      this.ground = nh
      this.needResize = !(spr && spr.ok)
    } else {
      this.W = Math.max(26, Math.round(100 * this.scale))
      this.H = this.W
      this.cx = 50 * this.scale
      this.ground = 88 * this.scale
      this.needResize = false
    }
  }

  private resizeEl() {
    this.el.style.width = this.W + 'px'
    this.el.style.height = this.H + 'px'
    if (this.canvas) {
      this.canvas.width = Math.max(1, Math.round(this.W * DPR))
      this.canvas.height = Math.max(1, Math.round(this.H * DPR))
    }
  }

  setScale(newScale: number) {
    const fx = this.x + this.cx
    const fy = this.y + this.ground
    this.scale = newScale
    this.recomputeMetrics()
    this.resizeEl()
    this.x = fx - this.cx
    this.y = fy - this.ground
    this.apply()
  }

  private switchActive(kind: 'walk' | 'jump' | 'grapple' | 'special') {
    const fx = this.x + this.cx
    const fy = this.y + this.ground
    this.active = kind
    this.recomputeMetrics()
    this.resizeEl()
    this.x = fx - this.cx
    this.y = fy - this.ground
    this.apply()
  }

  private apply() {
    this.el.style.transform = `translate(${Math.round(this.x)}px, ${Math.round(this.y)}px)`
  }

  // --- arrastre (mouse + touch unificados) ---
  private onDown = (e: PointerEvent) => {
    e.preventDefault()
    e.stopPropagation()
    this.dragId = e.pointerId
    try { this.el.setPointerCapture(e.pointerId) } catch { /* noop */ }
    this.state = 'drag'
    this.support = null
    this.dragOff = [e.clientX - this.x, e.clientY - this.y]
    this.el.style.cursor = 'grabbing'
    this.el.addEventListener('pointermove', this.onMove)
    this.el.addEventListener('pointerup', this.onUp)
    this.el.addEventListener('pointercancel', this.onUp)
  }
  private onMove = (e: PointerEvent) => {
    if (this.state !== 'drag') return
    const b = this.world.bounds
    this.x = Math.min(Math.max(e.clientX - this.dragOff[0], b.b0 - 60), b.b2 + 60 - this.W)
    this.y = Math.min(Math.max(e.clientY - this.dragOff[1], b.top0 - 60), b.bottom0 + 20)
    this.apply()
  }
  private onUp = () => {
    this.el.removeEventListener('pointermove', this.onMove)
    this.el.removeEventListener('pointerup', this.onUp)
    this.el.removeEventListener('pointercancel', this.onUp)
    this.el.style.cursor = 'grab'
    if (this.flies) {
      this.state = 'return'
    } else {
      this.vy = 0
      this.state = 'fall'
      this.support = null
    }
  }

  // --- bucle ---
  update() {
    const spd = Math.max(0.05, this.world.speed)
    this.blinkTick()
    if (this.needResize) {
      const [spr] = this.activeSprite()
      if (spr && spr.ok) this.switchActive(this.active)
    }
    if (this.state === 'drag') { this.advanceAnim(); this.redraw(); return }
    if (this.state === 'gosleep') { this.gosleepStep(); this.redraw(); return }
    if (this.state === 'special') { this.specialStep(); this.redraw(); return }
    if (this.flies) { this.updateFlyer(spd); this.advanceAnim() }
    else { this.updateWalker(spd); this.advanceAnim() }
    this.apply()
    this.redraw()
  }

  private blinkTick() {
    if (this.blinkLeft > 0) { this.blinkLeft--; this.blink = true }
    else { this.blink = false; if (this.state !== 'sleep' && rand() < 0.012) this.blinkLeft = 4 }
  }
  private advanceAnim() {
    this.animSub++
    if (this.animSub >= this.animEvery) { this.animSub = 0; this.anim++ }
  }

  // --- caminante ---
  private updateWalker(spd: number) {
    const b = this.world.bounds
    if (this.state === 'fall') {
      this.vy += GRAVITY
      this.y += this.vy
      const fy = this.y + this.ground
      if (fy >= b.floor) {
        this.support = 0
        this.y = b.floor - this.ground
        this.vy = 0
        this.state = choice(['idle', 'walk'])
        this.vx = WALK * this.facing
        this.timer = randint(40, 110)
      }
      return
    }
    if (this.state === 'climb') { this.climbStep(spd); return }
    if (this.state === 'seek') { this.seekStep(spd); return }
    if (this.state === 'jump') { this.jumpStep(spd); return }
    if (this.state === 'grapple') { this.grappleStep(); return }

    const x1 = b.b0, x2 = b.b2
    this.y = b.floor - this.ground

    if (this.climbCd > 0) this.climbCd--
    if (this.jumpCd > 0) this.jumpCd--
    if (this.grappleCd > 0) this.grappleCd--

    this.timer--
    if (this.timer <= 0) this.pickNextWalker()

    if (this.hasJump && this.support === 0 && this.jumpCd === 0 &&
      (this.state === 'walk' || this.state === 'idle') && rand() < P_JUMP) {
      this.beginJump(); return
    }
    if (this.hasGrapple && this.support === 0 && this.grappleCd === 0 &&
      (this.state === 'walk' || this.state === 'idle') && rand() < P_GRAPPLE) {
      const fx = this.x + this.cx
      this.facing = b.b2 - fx < fx - b.b0 ? 1 : -1
      this.beginGrapple(); return
    }
    if ((this.state === 'walk' || this.state === 'idle') && this.maybeSpecial('walk')) return

    if (this.world.climb && this.support === 0 && this.climbCd === 0 &&
      (this.state === 'walk' || this.state === 'idle') && rand() < P_SEEK) {
      const fx = this.x + this.cx
      this.seekSide = fx - b.b0 < b.b2 - fx ? 'L' : 'R'
      this.seekX = this.seekSide === 'L' ? b.b0 : b.b2
      this.state = 'seek'
      return
    }

    if (this.state === 'walk') {
      this.x += this.vx * spd
      const fx = this.x + this.cx
      if (fx <= x1) this.hitEdge(x1, x2, true)
      else if (fx >= x2) this.hitEdge(x1, x2, false)
    }
  }

  private hitEdge(x1: number, x2: number, left: boolean) {
    if (left) { this.x = x1 - this.cx + 0.2; this.facing = 1; this.vx = WALK }
    else { this.x = x2 - this.cx - 0.2; this.facing = -1; this.vx = -WALK }
  }

  private beginJump() {
    this.switchActive('jump')
    this.state = 'jump'
    this.support = null
    this.vy = -JUMP_V
    this.vx = JUMP_VX * this.facing
    this.jumpCd = 220
  }
  private jumpStep(spd: number) {
    const b = this.world.bounds
    this.vy += GRAVITY
    this.x += this.vx * spd
    this.y += this.vy
    const fx = this.x + this.cx
    if (fx < b.b0) { this.x = b.b0 - this.cx; this.vx = Math.abs(this.vx); this.facing = 1 }
    else if (fx > b.b2) { this.x = b.b2 - this.cx; this.vx = -Math.abs(this.vx); this.facing = -1 }
    const fy = this.y + this.ground
    if (this.vy > 0 && fy >= b.floor) {
      this.support = 0
      this.switchActive('walk')
      this.y = b.floor - this.ground
      this.vy = 0
      this.state = 'walk'
      this.vx = WALK * this.facing
      this.timer = randint(50, 120)
    }
  }

  private beginGrapple() {
    this.switchActive('grapple')
    this.state = 'grapple'
    this.grappleIdx = 0
    this.grappleSub = 0
    this.grappleCd = 500
  }
  private grappleStep() {
    this.grappleSub++
    if (this.grappleSub >= 5) { this.grappleSub = 0; this.grappleIdx++ }
    if (this.grappleIdx >= this.grappleFrames + 3) {
      this.facing = -this.facing
      this.switchActive('walk')
      this.state = 'walk'
      this.vx = WALK * this.facing
      this.grappleIdx = 0
      this.timer = randint(60, 140)
    }
  }

  // --- trepar por los bordes de la pantalla (adaptación web) ---
  private seekStep(spd: number) {
    const b = this.world.bounds
    this.y = b.floor - this.ground
    const fx = this.x + this.cx
    if (Math.abs(fx - this.seekX) <= 6) { this.beginWallClimb(); return }
    this.facing = this.seekX > fx ? 1 : -1
    this.vx = WALK * this.facing
    this.x += this.vx * spd
    const nfx = this.x + this.cx
    if (nfx < b.b0) this.x = b.b0 - this.cx
    else if (nfx > b.b2) this.x = b.b2 - this.cx
  }
  private beginWallClimb() {
    const b = this.world.bounds
    this.state = 'climb'
    this.climbDir = 1
    this.climbTop = randint(b.top0 + 10, Math.max(b.top0 + 40, Math.floor(b.floor * 0.45)))
    this.climbHold = 0
    this.climbHoldMax = randint(20, 60)
    this.facing = this.seekSide === 'L' ? 1 : -1
    this.support = null
    if (this.seekSide === 'L') this.x = b.b0
    else this.x = b.b2 - this.W
  }
  private climbStep(spd: number) {
    const b = this.world.bounds
    if (this.seekSide === 'L') this.x = b.b0
    else this.x = b.b2 - this.W
    if (this.climbDir > 0) {
      this.y -= CLIMB * spd
      if (this.y <= this.climbTop) { this.y = this.climbTop; this.climbDir = 0; this.climbHold = 0 }
    } else if (this.climbDir === 0) {
      this.climbHold++
      if (this.climbHold >= this.climbHoldMax) this.climbDir = -1
    } else {
      this.y += CLIMB * spd
      if (this.y + this.ground >= b.floor) {
        this.y = b.floor - this.ground
        this.support = 0
        this.state = 'walk'
        this.vx = WALK * this.facing
        this.climbCd = 150
        this.timer = randint(60, 140)
      }
    }
  }

  // --- acciones especiales ---
  private maybeSpecial(returnState: string): boolean {
    if (!this.animSpecials.length) return false
    for (const s of this.animSpecials) if (s.cd_left > 0) s.cd_left--
    if (rand() >= this.specialRate) return false
    const elig = this.animSpecials.filter((s) => s.cd_left === 0)
    if (!elig.length) return false
    const s = choices(elig, elig.map((e) => e.weight))
    this.curSpecial = s
    this.specialReturn = returnState
    this.specialIdx = 0
    this.specialSub = 0
    this.specialHold = 0
    this.specialShot = false
    this.switchActive('special')
    this.state = 'special'
    return true
  }
  private specialStep() {
    const s = this.curSpecial
    if (!s) { this.state = this.specialReturn; return }
    this.specialSub++
    if (this.specialSub >= s.speed) { this.specialSub = 0; this.specialIdx++ }
    if (s.shoot && !this.specialShot && this.specialIdx >= s.shoot.at) {
      this.specialShot = true
      this.world.spawnArrow(this, s.shoot.speed, s.shoot.arrow)
    }
    if (this.specialIdx >= s.loops * s.frames) {
      this.specialHold++
      if (this.specialHold >= (s.hold || 0)) {
        s.cd_left = s.cd
        this.curSpecial = null
        this.switchActive('walk')
        this.state = this.specialReturn
        if (this.state === 'walk') this.vx = WALK * this.facing
        this.specialIdx = 0
      }
    }
    this.apply()
  }

  private beginSleep() {
    const sp = this.sleepSpecial
    this.pendingSleep = sp
    const b = this.world.bounds
    if (sp.goto === 'top') this.sleepTy = b.top0
    else this.sleepTy = b.floor - this.ground
    this.sleepTx = this.x
    this.state = 'gosleep'
  }
  private gosleepStep() {
    this.y += (this.sleepTy - this.y) * 0.16
    this.x += (this.sleepTx - this.x) * 0.16
    if (Math.abs(this.sleepTy - this.y) < 3 && Math.abs(this.sleepTx - this.x) < 3) this.startSleep()
    this.advanceAnim()
    this.apply()
  }
  private startSleep() {
    const sp = this.pendingSleep
    this.curSpecial = sp
    this.specialReturn = this.flies ? 'float' : 'walk'
    this.specialIdx = 0
    this.specialSub = 0
    this.specialHold = 0
    this.specialShot = false
    this.switchActive('special')
    const b = this.world.bounds
    if (sp.goto === 'top') this.y = b.top0
    else this.y = b.floor - this.ground
    this.state = 'special'
  }

  private pickNextWalker() {
    this.state = choices(['walk', 'idle', 'sit', 'sleep'], [6, 3, 2, 2])
    if (this.state === 'sleep' && this.sleepSpecial) { this.beginSleep(); return }
    if (this.state === 'walk') {
      this.facing = choice([-1, 1])
      this.vx = WALK * this.facing
      this.timer = randint(60, 160)
    } else if (this.state === 'idle') this.timer = randint(25, 70)
    else if (this.state === 'sit') this.timer = randint(60, 140)
    else this.timer = randint(120, 260)
  }

  // --- volador ---
  private updateFlyer(spd: number) {
    const b = this.world.bounds
    const maxx = Math.max(b.b0, b.b2 - this.W)
    if (this.state === 'return') {
      this.y += (this.hoverY - this.y) * 0.12
      if (Math.abs(this.y - this.hoverY) < 1.5) {
        this.y = this.hoverY
        this.targetY = this.hoverY
        this.state = 'float'
        this.timer = randint(60, 140)
      }
      return
    }
    this.timer--
    if (this.timer <= 0) {
      this.state = choices(['float', 'sleep'], [6, 1])
      if (this.state === 'sleep' && this.sleepSpecial) { this.beginSleep(); return }
      if (this.state === 'float') {
        this.targetY = randint(b.top0 + 10, b.floor - 40)
        this.facing = choice([-1, 1])
        this.vx = FLOAT * this.facing
        this.timer = randint(80, 180)
      } else this.timer = randint(120, 240)
    }
    if (this.state === 'float') {
      if (this.maybeSpecial('float')) return
      this.x += this.vx * spd
      if (this.x <= b.b0) { this.x = b.b0; this.facing = 1; this.vx = FLOAT }
      else if (this.x >= maxx) { this.x = maxx; this.facing = -1; this.vx = -FLOAT }
      this.y += (this.targetY - this.y) * 0.05
    }
  }

  // --- dibujo ---
  private redraw() {
    const sleeping = this.state === 'sleep' ||
      (this.state === 'special' && this.curSpecial && this.curSpecial.goto !== undefined) ||
      (this.state === 'special' && this.curSpecial === this.sleepSpecial)
    this.zzz.style.display = this.state === 'sleep' ? '' : 'none'

    if (this.isImage && this.img) {
      let spr: Sprite | null
      let nfr: number
      if (this.state === 'jump' && this.hasJump) { spr = this.jumpSprite; nfr = this.jumpFrames }
      else if (this.state === 'grapple' && this.hasGrapple) { spr = this.grappleSprite; nfr = this.grappleFrames }
      else if (this.state === 'special' && this.curSpecial) { spr = this.curSpecial.sprite; nfr = this.curSpecial.frames }
      else { spr = this.sprite; nfr = this.nFrames }
      let idx: number
      if (this.state === 'grapple') idx = Math.min(this.grappleIdx, nfr - 1)
      else if (this.state === 'special') {
        idx = this.curSpecial && this.curSpecial.loops > 1
          ? this.specialIdx % nfr
          : Math.min(this.specialIdx, nfr - 1)
      } else {
        const animate = this.state !== 'idle' && this.state !== 'sit' && this.state !== 'sleep'
        idx = animate ? this.anim % nfr : 0
      }
      const flip = this.facing !== this.native
      if (spr && spr.ok) {
        const im = spr.imgs[((idx % nfr) + nfr) % nfr]
        if (im && this.img.src !== im.src) this.img.src = im.src
        this.img.style.transform = flip ? 'scaleX(-1)' : 'scaleX(1)'
        this.img.style.visibility = 'visible'
      } else {
        this.img.style.visibility = 'hidden'
      }
      void sleeping
    } else if (this.ctx) {
      const pose =
        this.state === 'drag' || this.state === 'return' || this.state === 'float' ? 'idle'
          : this.state === 'climb' || this.state === 'seek' ? 'walk'
            : this.state
      drawClaude(this.ctx, this.W, this.H, this.facing, pose, this.anim, this.blink)
    }
  }

  destroy() {
    try { this.el.removeEventListener('pointerdown', this.onDown) } catch { /* noop */ }
    this.el.remove()
  }
}

// --- proyectil (la flecha de la elfa) -----------------------------------------
class Projectile {
  world: BichitosWorld
  el: HTMLDivElement
  private img: HTMLImageElement
  x: number
  y: number
  vx: number
  W: number
  H: number
  constructor(world: BichitosWorld, name: string, cx: number, cy: number, vx: number, scale: number, height = 26) {
    this.world = world
    this.vx = vx
    const spr = loadSprite(name, 1)
    const th = Math.max(10, Math.round(height * scale))
    const [nw, nh] = sizeFor(spr, th)
    this.W = nw
    this.H = nh
    this.x = cx - nw / 2
    this.y = cy - nh / 2
    const doc = world.doc
    this.el = doc.createElement('div')
    this.el.style.cssText = `position:absolute;left:0;top:0;width:${nw}px;height:${nh}px;pointer-events:none;will-change:transform;`
    this.img = doc.createElement('img')
    this.img.draggable = false
    this.img.src = `${BASE}/${name}/0.png`
    this.img.style.cssText = `width:100%;height:100%;transform:scaleX(${vx < 0 ? -1 : 1});`
    this.el.appendChild(this.img)
    world.container.appendChild(this.el)
    this.apply()
  }
  private apply() { this.el.style.transform = `translate(${Math.round(this.x)}px, ${Math.round(this.y)}px)` }
  update(): boolean {
    this.x += this.vx
    const b = this.world.bounds
    if (this.x + this.W < b.b0 - 30 || this.x > b.b2 + 30) return false
    this.apply()
    return true
  }
  destroy() { this.el.remove() }
}

// --- gestor (de main.py PetManager) -------------------------------------------
export class BichitosWorld {
  container: HTMLElement
  win: Window
  doc: Document
  bounds: Bounds
  speed = 1
  scale = 1
  climb = true
  private pets = new Map<string, Pet>()
  private projectiles: Projectile[] = []
  private timer: number | null = null
  private idc = 0

  constructor(container: HTMLElement, win: Window = window) {
    this.container = container
    this.win = win
    this.doc = win.document
    this.bounds = this.measure()
    this.win.addEventListener('resize', this.onResize)
    // El bucle vive en la ventana destino: si es la ventana flotante (PiP),
    // sigue a 25 fps aunque la pestaña de Yuki quede en segundo plano.
    this.timer = this.win.setInterval(() => this.tick(), TICK_MS)
  }

  private measure(): Bounds {
    const w = this.win.innerWidth
    const h = this.win.innerHeight
    return { b0: 0, top0: 0, b2: w, bottom0: h, floor: h }
  }
  private onResize = () => { this.bounds = this.measure() }

  setSettings(s: { speed?: number; scale?: number; climb?: boolean }) {
    if (s.speed != null) this.speed = s.speed
    if (s.climb != null) this.climb = s.climb
    if (s.scale != null && s.scale !== this.scale) {
      this.scale = s.scale
      for (const p of this.pets.values()) p.setScale(s.scale)
    }
  }

  spawnArrow(pet: Pet, speed: number, name: string) {
    const cx = pet.x + pet.cx + pet.facing * pet.W * 0.3
    const cy = pet.y + pet.H * 0.42
    this.projectiles.push(new Projectile(this, name, cx, cy, speed * pet.facing, pet.scale))
  }

  add(key: string, id?: string): string {
    if (!CHARACTERS[key]) return ''
    const pid = id || `p${Date.now().toString(36)}${this.idc++}`
    const pet = new Pet(this, key)
    pet.id = pid
    this.pets.set(pid, pet)
    this.container.appendChild(pet.el)
    return pid
  }
  remove(id: string) {
    const p = this.pets.get(id)
    if (p) { p.destroy(); this.pets.delete(id) }
  }
  removeLast() {
    const keys = [...this.pets.keys()]
    if (keys.length) this.remove(keys[keys.length - 1])
  }
  removeAll() {
    for (const p of this.pets.values()) p.destroy()
    this.pets.clear()
    for (const pr of this.projectiles) pr.destroy()
    this.projectiles = []
  }
  count() { return this.pets.size }
  list(): { id: string; key: string }[] {
    return [...this.pets.values()].map((p) => ({ id: p.id, key: p.key }))
  }

  private tick() {
    for (const p of [...this.pets.values()]) {
      try { p.update() } catch { /* noop */ }
    }
    this.projectiles = this.projectiles.filter((pr) => {
      try { if (pr.update()) return true } catch { /* noop */ }
      pr.destroy()
      return false
    })
  }

  destroy() {
    if (this.timer != null) this.win.clearInterval(this.timer)
    this.win.removeEventListener('resize', this.onResize)
    this.removeAll()
  }
}
