// Servidor de producción para el .exe (Electron). Reemplaza al dev de Vite:
// sirve dist/ + proxies (/api,/sd,/voice,/doc) + búsqueda web + perfiles (/store).
const path = require('path')
const fs = require('fs')
const crypto = require('crypto')
const express = require('express')
const { createProxyMiddleware } = require('http-proxy-middleware')
const cheerio = require('cheerio')

const ROOT = path.resolve(__dirname, '..')
const DIST = path.join(ROOT, 'dist')
const DATA_DIR = path.join(ROOT, 'data')
const PROFILES_FILE = path.join(DATA_DIR, 'profiles.json')
const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36'

// ---------- Búsqueda web (igual que websearch-plugin.ts) ----------
async function fetchWithTimeout(url, init = {}, ms = 12000) {
  const ac = new AbortController()
  const t = setTimeout(() => ac.abort(), ms)
  try {
    return await fetch(url, { ...init, signal: ac.signal })
  } finally {
    clearTimeout(t)
  }
}
function resolveDdgHref(href) {
  if (!href) return ''
  let h = href
  if (h.startsWith('//')) h = 'https:' + h
  try {
    const u = new URL(h, 'https://duckduckgo.com')
    const uddg = u.searchParams.get('uddg')
    if (uddg) return decodeURIComponent(uddg)
    if (u.protocol === 'http:' || u.protocol === 'https:') return u.toString()
  } catch {}
  return h.startsWith('http') ? h : ''
}
async function searchDDG(query, n) {
  const url = 'https://lite.duckduckgo.com/lite/?q=' + encodeURIComponent(query)
  const res = await fetchWithTimeout(url, {
    headers: { 'User-Agent': UA, 'Accept-Language': 'es-ES,es;q=0.9,en;q=0.8', Accept: 'text/html' },
  })
  if (!res.ok) throw new Error('ddg ' + res.status)
  const $ = cheerio.load(await res.text())
  const links = $('a.result-link')
  const snippets = $('.result-snippet')
  const results = []
  links.each((i, el) => {
    const title = $(el).text().trim()
    const u = resolveDdgHref($(el).attr('href') || '')
    const snippet = snippets.eq(i).text().trim()
    if (title && u) results.push({ title, url: u, snippet })
  })
  return results.slice(0, n)
}
async function searchWiki(query, n) {
  for (const lang of ['es', 'en']) {
    try {
      const api = `https://${lang}.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(query)}&srlimit=${n}&format=json&origin=*`
      const res = await fetchWithTimeout(api, { headers: { 'User-Agent': UA } })
      if (!res.ok) continue
      const data = await res.json()
      const hits = (data && data.query && data.query.search) || []
      if (!hits.length) continue
      return hits.map((h) => ({
        title: h.title,
        url: `https://${lang}.wikipedia.org/wiki/${encodeURIComponent(String(h.title).replace(/ /g, '_'))}`,
        snippet: String(h.snippet || '').replace(/<[^>]+>/g, ''),
      }))
    } catch {}
  }
  return []
}
async function doSearch(query, n) {
  for (let a = 0; a < 2; a++) {
    try {
      const r = await searchDDG(query, n)
      if (r.length) return r
    } catch {}
    await new Promise((r) => setTimeout(r, 400))
  }
  return searchWiki(query, n)
}
async function fetchPageText(url) {
  const res = await fetchWithTimeout(url, { headers: { 'User-Agent': UA, Accept: 'text/html' } }, 12000)
  const ctype = res.headers.get('content-type') || ''
  if (!res.ok || !ctype.includes('text/html')) return { title: '', text: '' }
  const $ = cheerio.load(await res.text())
  const title = ($('title').first().text() || '').trim()
  $('script, style, noscript, nav, footer, header, aside, form, svg').remove()
  const main = $('article').text() || $('main').text() || $('body').text()
  const text = main.replace(/[ \t]+/g, ' ').replace(/\n\s*\n\s*/g, '\n\n').trim()
  return { title, text: text.slice(0, 8000) }
}

// ---------- Perfiles (igual que storage-plugin.ts) ----------
function ensureDir() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true })
}
function readJson(f, fb) {
  try {
    return JSON.parse(fs.readFileSync(f, 'utf8'))
  } catch {
    return fb
  }
}
function writeJson(f, o) {
  ensureDir()
  fs.writeFileSync(f, JSON.stringify(o, null, 2), 'utf8')
}
const loadProfiles = () => readJson(PROFILES_FILE, [])
const saveProfiles = (l) => writeJson(PROFILES_FILE, l)
const hashPin = (pin, salt) => crypto.createHash('sha256').update(salt + ':' + pin).digest('hex')
const dataFile = (id) => path.join(DATA_DIR, `data-${String(id).replace(/[^a-zA-Z0-9_-]/g, '')}.json`)
const publicProfile = (p) => ({ id: p.id, name: p.name, avatar: p.avatar || '', hasPin: !!p.pinHash })

function startServer(port = 5174) {
  const app = express()

  // Los proxies van ANTES del body-parser (necesitan el cuerpo crudo / streaming).
  // Se usa pathFilter (no montar con ruta) para que Express no recorte el prefijo.
  app.use(
    createProxyMiddleware({
      pathFilter: '/api',
      target: 'http://localhost:11434',
      changeOrigin: true,
      on: {
        proxyReq: (pr) => {
          pr.removeHeader('origin')
          pr.removeHeader('referer')
        },
      },
    }),
  )
  app.use(createProxyMiddleware({ pathFilter: '/sd', target: 'http://127.0.0.1:7861', changeOrigin: true, pathRewrite: { '^/sd': '' } }))
  app.use(createProxyMiddleware({ pathFilter: '/voice', target: 'http://127.0.0.1:7861', changeOrigin: true, pathRewrite: { '^/voice': '' } }))
  app.use(createProxyMiddleware({ pathFilter: '/doc', target: 'http://127.0.0.1:7861', changeOrigin: true }))

  app.use(express.json({ limit: '60mb' }))

  app.get('/websearch', async (req, res) => {
    try {
      const q = String(req.query.q || '').trim()
      const n = Math.min(10, Math.max(1, parseInt(req.query.n || '5', 10) || 5))
      if (!q) return res.json({ results: [] })
      res.json({ results: await doSearch(q, n) })
    } catch (e) {
      res.json({ results: [], error: String(e) })
    }
  })
  app.get('/webfetch', async (req, res) => {
    try {
      const url = String(req.query.url || '')
      if (!/^https?:\/\//i.test(url)) return res.status(400).json({ title: '', text: '' })
      res.json(await fetchPageText(url))
    } catch (e) {
      res.json({ title: '', text: '', error: String(e) })
    }
  })

  app.get('/store/profiles', (_req, res) => res.json({ profiles: loadProfiles().map(publicProfile) }))
  app.post('/store/profiles', (req, res) => {
    const b = req.body || {}
    const rec = { id: crypto.randomUUID(), name: String(b.name || 'Perfil').trim(), avatar: String(b.avatar || '').slice(0, 8) }
    if (b.pin) {
      rec.salt = crypto.randomBytes(8).toString('hex')
      rec.pinHash = hashPin(String(b.pin), rec.salt)
    }
    const list = loadProfiles()
    list.push(rec)
    saveProfiles(list)
    res.json({ profile: publicProfile(rec) })
  })
  app.post('/store/profiles/delete', (req, res) => {
    const id = String((req.body || {}).id || '')
    saveProfiles(loadProfiles().filter((x) => x.id !== id))
    try {
      fs.unlinkSync(dataFile(id))
    } catch {}
    res.json({ ok: true })
  })
  app.post('/store/profiles/verify', (req, res) => {
    const b = req.body || {}
    const rec = loadProfiles().find((x) => x.id === String(b.id))
    if (!rec) return res.json({ ok: false })
    if (!rec.pinHash) return res.json({ ok: true })
    res.json({ ok: rec.salt ? hashPin(String(b.pin || ''), rec.salt) === rec.pinHash : false })
  })
  app.get('/store/data', (req, res) => res.json({ data: readJson(dataFile(String(req.query.id || '')), {}) }))
  app.post('/store/data', (req, res) => {
    const b = req.body || {}
    const id = String(b.id || '')
    if (!id || !loadProfiles().some((x) => x.id === id)) return res.status(400).json({ error: 'perfil no encontrado' })
    writeJson(dataFile(id), b.data || {})
    res.json({ ok: true })
  })

  // Estáticos + fallback SPA
  app.use(express.static(DIST))
  app.use((_req, res) => res.sendFile(path.join(DIST, 'index.html')))

  return new Promise((resolve) => {
    app.listen(port, '127.0.0.1', () => resolve(port))
  })
}

module.exports = { startServer }

if (require.main === module) {
  startServer().then((p) => console.log('[server] http://localhost:' + p))
}
