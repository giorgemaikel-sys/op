import {
  loadConversations,
  saveConversations,
  loadSettings,
  saveSettings,
  loadMemory,
  saveMemory,
} from './storage'
import { loadPersonas, savePersonas } from './personas'

/** Descarga un JSON con todo (conversaciones, memoria, personas, ajustes). */
export function exportAll() {
  const data = {
    app: 'mi-asistente',
    version: 2,
    exportedAt: new Date().toISOString(),
    conversations: loadConversations(),
    memory: loadMemory(),
    personas: loadPersonas(),
    settings: loadSettings(),
  }
  const blob = new Blob([JSON.stringify(data, null, 2)], {
    type: 'application/json',
  })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `asistente-backup-${new Date().toISOString().slice(0, 10)}.json`
  document.body.appendChild(a)
  a.click()
  a.remove()
  setTimeout(() => URL.revokeObjectURL(url), 1000)
}

/** Restaura desde un archivo de respaldo. Lanza si el archivo no es válido. */
export async function importAll(file: File): Promise<void> {
  const text = await file.text()
  const data = JSON.parse(text)
  if (data.conversations && Array.isArray(data.conversations)) {
    saveConversations(data.conversations)
  }
  if (data.memory && Array.isArray(data.memory)) {
    saveMemory(data.memory)
  }
  if (data.personas && Array.isArray(data.personas) && data.personas.length) {
    savePersonas(data.personas)
  }
  if (data.settings && typeof data.settings === 'object') {
    saveSettings({ ...loadSettings(), ...data.settings })
  }
}
