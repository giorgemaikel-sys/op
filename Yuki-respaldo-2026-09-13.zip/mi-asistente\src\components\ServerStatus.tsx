import { useCallback, useEffect, useState } from 'react'

interface Props {
  onClose: () => void
  onToast: (msg: string) => void
}

interface LoadedModel {
  name: string
  sizeVram: number
}

interface State {
  ollama: 'ok' | 'down' | 'checking'
  ollamaModels: number
  loaded: LoadedModel[]
  sd: 'ready' | 'loading' | 'down' | 'checking'
  sdError: string | null
  whisper: boolean
}

const INITIAL: State = {
  ollama: 'checking',
  ollamaModels: 0,
  loaded: [],
  sd: 'checking',
  sdError: null,
  whisper: false,
}

function gb(bytes: number): string {
  if (!bytes) return '0 GB'
  return (bytes / 1024 / 1024 / 1024).toFixed(1) + ' GB'
}

export default function ServerStatus({ onClose, onToast }: Props) {
  const [st, setSt] = useState<State>(INITIAL)
  const [freeing, setFreeing] = useState(false)

  const refresh = useCallback(async () => {
    setSt((s) => ({ ...s, ollama: 'checking', sd: 'checking' }))

    // --- Ollama ---
    try {
      const tags = await fetch('/api/tags').then((r) => r.json())
      const count = Array.isArray(tags?.models) ? tags.models.length : 0
      let loaded: LoadedModel[] = []
      try {
        const ps = await fetch('/api/ps').then((r) => r.json())
        loaded = (ps?.models ?? []).map((m: any) => ({
          name: m.name,
          sizeVram: m.size_vram ?? m.size ?? 0,
        }))
      } catch {
        /* ps opcional */
      }
      setSt((s) => ({ ...s, ollama: 'ok', ollamaModels: count, loaded }))
    } catch {
      setSt((s) => ({ ...s, ollama: 'down', ollamaModels: 0, loaded: [] }))
    }

    // --- Servidor de imágenes / voz / documentos ---
    try {
      const h = await fetch('/sd/health').then((r) => r.json())
      setSt((s) => ({
        ...s,
        sd: h?.ready ? 'ready' : h?.loading ? 'loading' : 'ready',
        sdError: h?.error ?? null,
        whisper: !!h?.whisper_ready,
      }))
    } catch {
      setSt((s) => ({ ...s, sd: 'down', whisper: false }))
    }
  }, [])

  useEffect(() => {
    refresh()
  }, [refresh])

  async function freeGpu() {
    setFreeing(true)
    try {
      const r = await fetch('/sd/freegpu', { method: 'POST' }).then((x) => x.json())
      if (r?.ok) onToast('✅ VRAM liberada. Las imágenes deberían caber ahora.')
      else onToast('⚠️ No se pudo liberar la GPU.')
    } catch {
      onToast('⚠️ El servidor de imágenes no responde.')
    } finally {
      setFreeing(false)
      refresh()
    }
  }

  const dot = (color: string) => (
    <span className={`inline-block h-2.5 w-2.5 rounded-full ${color}`} />
  )

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
      <div className="w-full max-w-md rounded-2xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 shadow-xl">
        <div className="flex items-center justify-between px-5 h-14 border-b border-zinc-200 dark:border-zinc-800">
          <h2 className="font-semibold flex items-center gap-2">🖥️ Servidores</h2>
          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800"
            title="Cerrar"
          >
            ✕
          </button>
        </div>

        <div className="p-5 space-y-3">
          {/* Ollama */}
          <div className="rounded-xl border border-zinc-200 dark:border-zinc-800 p-3">
            <div className="flex items-center gap-2">
              {st.ollama === 'ok'
                ? dot('bg-green-500')
                : st.ollama === 'checking'
                  ? dot('bg-zinc-400 animate-pulse')
                  : dot('bg-red-500')}
              <span className="font-medium">Ollama (chat)</span>
              <span className="ml-auto text-xs text-zinc-500">
                {st.ollama === 'ok'
                  ? `${st.ollamaModels} modelos`
                  : st.ollama === 'checking'
                    ? 'comprobando…'
                    : 'apagado'}
              </span>
            </div>
            {st.loaded.length > 0 && (
              <div className="mt-2 space-y-1">
                {st.loaded.map((m) => (
                  <div
                    key={m.name}
                    className="flex items-center justify-between text-xs text-zinc-600 dark:text-zinc-400"
                  >
                    <span className="truncate">🧠 {m.name}</span>
                    <span className="shrink-0">{gb(m.sizeVram)} en GPU</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Servidor de imágenes */}
          <div className="rounded-xl border border-zinc-200 dark:border-zinc-800 p-3">
            <div className="flex items-center gap-2">
              {st.sd === 'ready'
                ? dot('bg-green-500')
                : st.sd === 'loading'
                  ? dot('bg-amber-500 animate-pulse')
                  : st.sd === 'checking'
                    ? dot('bg-zinc-400 animate-pulse')
                    : dot('bg-red-500')}
              <span className="font-medium">Imágenes · voz · documentos</span>
              <span className="ml-auto text-xs text-zinc-500">
                {st.sd === 'ready'
                  ? 'listo'
                  : st.sd === 'loading'
                    ? 'cargando…'
                    : st.sd === 'checking'
                      ? 'comprobando…'
                      : 'apagado'}
              </span>
            </div>
            <div className="mt-1 text-xs text-zinc-500">
              🎤 Voz (Whisper): {st.whisper ? 'listo' : 'se carga al usarlo'}
            </div>
            {st.sdError && (
              <div className="mt-1 text-xs text-red-500">⚠️ {st.sdError}</div>
            )}
          </div>

          <p className="text-xs text-zinc-500 leading-relaxed">
            💡 Si las imágenes fallan por falta de memoria, pulsa <b>Liberar GPU</b>:
            descarga los modelos de chat de la tarjeta para que quepa Stable Diffusion.
            El chat vuelve solo en el siguiente mensaje.
          </p>

          <div className="flex gap-2 pt-1">
            <button
              onClick={freeGpu}
              disabled={freeing}
              className="flex-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 disabled:opacity-60 text-white py-2 text-sm font-medium transition-colors"
            >
              {freeing ? 'Liberando…' : '🧹 Liberar GPU'}
            </button>
            <button
              onClick={refresh}
              className="rounded-lg border border-zinc-200 dark:border-zinc-700 hover:bg-zinc-100 dark:hover:bg-zinc-800 px-4 py-2 text-sm"
            >
              ↻ Actualizar
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
