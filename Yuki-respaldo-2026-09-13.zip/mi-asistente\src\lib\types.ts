export type Role = 'user' | 'assistant' | 'system'

export interface ChatImage {
  // base64 SIN el prefijo "data:...;base64,"
  data: string
  mime: string
}

export interface ChatDoc {
  name: string
  text: string
  truncated?: boolean
}

export interface Source {
  title: string
  url: string
}

export interface MsgStats {
  tokensPerSec: number
  totalMs: number
  evalCount: number
}

export interface DocFile {
  filename: string
  mime: string
  data: string // base64
}

// --- Encuestas / formularios interactivos ---
export type SurveyQuestionType = 'single' | 'multi' | 'text' | 'scale'

export interface SurveyQuestion {
  q: string
  type: SurveyQuestionType
  options?: string[] // para single / multi
  min?: number // para scale
  max?: number // para scale
}

export interface Survey {
  title: string
  intro?: string
  questions: SurveyQuestion[]
}

// --- Plan de estudio interactivo (tutor) ---
export interface StudyLesson {
  title: string
  objectives: string[]
  summary: string
}

export interface StudyVideo {
  title: string
  url: string
  why: string
}

export interface StudyPlan {
  topic: string
  lessons: StudyLesson[]
  videos?: StudyVideo[]
}

export interface StudyState {
  plan: StudyPlan
  lesson: number // índice de la lección actual
}

// --- Tarjetas de estudio (flashcards) ---
export interface Flashcard {
  front: string
  back: string
}
export interface FlashcardSet {
  title: string
  cards: Flashcard[]
}

// --- Examen / quiz interactivo ---
export interface QuizQuestion {
  q: string
  options: string[]
  answer: number // índice de la opción correcta
  explanation?: string
}
export interface Quiz {
  title: string
  questions: QuizQuestion[]
}

// --- Rachas y logros ---
export interface UserStats {
  streak: number // días seguidos
  bestStreak: number
  lastActive: string // YYYY-MM-DD
  days: number // total de días activos
  messages: number // total de mensajes enviados
  achievements: string[] // ids de logros desbloqueados
}

// --- Muro entre amigos ---
export interface WallReply {
  author: string
  avatar: string
  text: string
  createdAt: number
}

export interface WallPost {
  id: string
  author: string
  avatar: string
  text: string
  sticker?: string // emoji/sticker grande
  ai?: boolean // publicado por la IA
  createdAt: number
  reactions?: Record<string, string[]> // emoji -> lista de nombres que reaccionaron
  replies?: WallReply[]
}

export interface ChatMessage {
  id: string
  role: Role
  content: string
  images?: ChatImage[]
  docs?: ChatDoc[]
  sources?: Source[]
  stats?: MsgStats
  model?: string // modelo que generó la respuesta (para el modo Auto)
  file?: DocFile // documento generado (Word/PDF/pptx) para descargar
  survey?: Survey // formulario interactivo para responder en el chat
  flashcards?: FlashcardSet // tarjetas de estudio interactivas
  quiz?: Quiz // examen interactivo
  createdAt: number
}

export interface Conversation {
  id: string
  title: string
  messages: ChatMessage[]
  createdAt: number
  updatedAt: number
  personaId?: string
  autoTitled?: boolean
  pinned?: boolean // 📌 anclado arriba en la lista
  folder?: string // 🗂️ carpeta a la que pertenece (opcional)
  study?: StudyState // sesión de estudio activa (modo tutor)
}

export interface MemoryItem {
  id: string
  text: string
  createdAt: number
  auto?: boolean
}

export interface Persona {
  id: string
  name: string
  emoji?: string
  systemPrompt: string
}

export interface Settings {
  model: string
  systemPrompt: string // legado (la persona "General" ya lo cubre)
  theme: 'dark' | 'light'
  autoMemory: boolean
  activePersonaId: string
  webEffort: number // 1..5, esfuerzo por defecto de la búsqueda web
  imageSteps: number // 1..6, calidad/pasos por defecto para generar imágenes
  imageWidth: number // ancho por defecto de las imágenes
  imageHeight: number // alto por defecto de las imágenes
  autoSpeak: boolean // leer en voz alta las respuestas automáticamente
  ttsVoice: string // nombre de la voz (TTS del navegador)
  ttsRate: number // velocidad de la voz (0.5..2)
  ttsLang: string // idioma preferido para la voz
  autoModel: boolean // elegir automáticamente el mejor modelo por tarea
  accent?: string // color de acento (hex), por perfil
}

export interface PromptTemplate {
  id: string
  name: string
  text: string
}
