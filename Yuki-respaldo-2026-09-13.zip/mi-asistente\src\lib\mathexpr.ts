// Evaluador seguro de expresiones matemáticas (sin eval / new Function).
// Soporta: números, la variable x, + - * / ^, paréntesis, funciones comunes y
// constantes pi/e. Convierte "2x", "3(x+1)", "2sin(x)" en multiplicaciones.

type Token =
  | { t: 'num'; v: number }
  | { t: 'var' }
  | { t: 'op'; v: string }
  | { t: 'func'; v: string }
  | { t: 'lp' }
  | { t: 'rp' }

const FUNCS: Record<string, (x: number) => number> = {
  sin: Math.sin,
  cos: Math.cos,
  tan: Math.tan,
  asin: Math.asin,
  acos: Math.acos,
  atan: Math.atan,
  sinh: Math.sinh,
  cosh: Math.cosh,
  tanh: Math.tanh,
  sqrt: Math.sqrt,
  cbrt: Math.cbrt,
  abs: Math.abs,
  exp: Math.exp,
  ln: Math.log,
  log: Math.log10,
  log10: Math.log10,
  log2: Math.log2,
  sign: Math.sign,
  floor: Math.floor,
  ceil: Math.ceil,
  round: Math.round,
}

const CONSTS: Record<string, number> = { pi: Math.PI, e: Math.E, tau: Math.PI * 2 }

function tokenize(input: string): Token[] {
  const s = input.replace(/\s+/g, '').replace(/\*\*/g, '^')
  const raw: Token[] = []
  let i = 0
  while (i < s.length) {
    const c = s[i]
    if (/[0-9.]/.test(c)) {
      let j = i + 1
      while (j < s.length && /[0-9.]/.test(s[j])) j++
      raw.push({ t: 'num', v: parseFloat(s.slice(i, j)) })
      i = j
    } else if (/[a-zA-Z]/.test(c)) {
      let j = i + 1
      while (j < s.length && /[a-zA-Z0-9]/.test(s[j])) j++
      const name = s.slice(i, j).toLowerCase()
      if (name === 'x') raw.push({ t: 'var' })
      else if (name in CONSTS) raw.push({ t: 'num', v: CONSTS[name] })
      else if (name in FUNCS) raw.push({ t: 'func', v: name })
      else throw new Error(`desconocido: ${name}`)
      i = j
    } else if ('+-*/^'.includes(c)) {
      raw.push({ t: 'op', v: c })
      i++
    } else if (c === '(') {
      raw.push({ t: 'lp' })
      i++
    } else if (c === ')') {
      raw.push({ t: 'rp' })
      i++
    } else {
      throw new Error(`carácter inválido: ${c}`)
    }
  }
  // Multiplicación implícita a nivel de tokens (no rompe nombres de función).
  const tokens: Token[] = []
  for (let k = 0; k < raw.length; k++) {
    const a = raw[k]
    tokens.push(a)
    const b = raw[k + 1]
    if (!b) continue
    const aEnd = a.t === 'num' || a.t === 'var' || a.t === 'rp'
    const bStart = b.t === 'num' || b.t === 'var' || b.t === 'func' || b.t === 'lp'
    if (aEnd && bStart) tokens.push({ t: 'op', v: '*' })
  }
  return tokens
}

// 'u' = menos unario (prefijo, derecha). Menor precedencia que '^' para que
// -x^2 sea -(x^2), pero mayor que * y / .
const PREC: Record<string, number> = { '+': 1, '-': 1, '*': 2, '/': 2, u: 3, '^': 4 }

// Shunting-yard → RPN. Maneja el menos unario como 'u'.
function toRPN(tokens: Token[]): Token[] {
  const out: Token[] = []
  const stack: Token[] = []
  let prev: Token | null = null
  for (const tk of tokens) {
    if (tk.t === 'num' || tk.t === 'var') {
      out.push(tk)
    } else if (tk.t === 'func') {
      stack.push(tk)
    } else if (tk.t === 'op') {
      const unary =
        tk.v === '-' &&
        (prev === null || prev.t === 'op' || prev.t === 'lp')
      if (unary) {
        // prefijo: se apila sin sacar nada
        stack.push({ t: 'op', v: 'u' })
      } else {
        const right = tk.v === '^'
        const q = PREC[tk.v] ?? 0
        while (stack.length) {
          const top = stack[stack.length - 1]
          if (top.t !== 'op') break
          const p = PREC[top.v] ?? 0
          if (p > q || (p === q && !right)) out.push(stack.pop()!)
          else break
        }
        stack.push(tk)
      }
    } else if (tk.t === 'lp') {
      stack.push(tk)
    } else if (tk.t === 'rp') {
      while (stack.length && stack[stack.length - 1].t !== 'lp') out.push(stack.pop()!)
      if (!stack.length) throw new Error('paréntesis desbalanceado')
      stack.pop() // quitar '('
      if (stack.length && stack[stack.length - 1].t === 'func') out.push(stack.pop()!)
    }
    prev = tk
  }
  while (stack.length) {
    const top = stack.pop()!
    if (top.t === 'lp') throw new Error('paréntesis desbalanceado')
    out.push(top)
  }
  return out
}

/** Compila una expresión en una función x → número. Lanza si la sintaxis es inválida. */
export function compileExpr(expr: string): (x: number) => number {
  const rpn = toRPN(tokenize(expr))
  return (x: number) => {
    const st: number[] = []
    for (const tk of rpn) {
      if (tk.t === 'num') st.push(tk.v)
      else if (tk.t === 'var') st.push(x)
      else if (tk.t === 'func') {
        const a = st.pop() ?? NaN
        st.push(FUNCS[tk.v](a))
      } else if (tk.t === 'op') {
        if (tk.v === 'u') {
          st.push(-(st.pop() ?? NaN))
          continue
        }
        const b = st.pop() ?? NaN
        const a = st.pop() ?? NaN
        switch (tk.v) {
          case '+': st.push(a + b); break
          case '-': st.push(a - b); break
          case '*': st.push(a * b); break
          case '/': st.push(a / b); break
          case '^': st.push(Math.pow(a, b)); break
        }
      }
    }
    return st.length === 1 ? st[0] : NaN
  }
}
