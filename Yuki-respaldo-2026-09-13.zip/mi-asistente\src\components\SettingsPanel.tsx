import { useEffect, useRef, useState } from 'react'
import type { Persona, PromptTemplate, Settings } from '../lib/types'
import type { OllamaModel } from '../lib/ollama'
import { effortLabel } from '../lib/websearch'
import { loadVoices, speak } from '../lib/tts'
import ModelPicker from './ModelPicker'
import OwnerSettings from './OwnerSettings'

interface Props {
  settings: Settings
  models: OllamaModel[]
  connError: string | null
  profileId: string
  personas: Persona[]
  prompts: PromptTemplate[]
  onChange: (s: Settings) => void
  onPersonasChange: (p: Persona[]) => void
  onPromptsChange: (p: PromptTemplate[]) => void
  onRefreshModels: () => void
  onExport: () => void
  onImport: (file: File) => void
  canInstall?: boolean
  onInstall?: () => void
  onClose: () => void
}

function uid() {
  return Math.random().toString(36).slice(2) + Date.now().toString(36)
}

const ACCENTS = ['#4f46e5', '#2563eb', '#0ea5e9', '#10b981', '#f59e0b', '#f43f5e', '#ec4899', '#8b5cf6']

export default function SettingsPanel({
  settings,
  models,
  connError,
  profileId,
  personas,
  prompts,
  onChange,
  onPersonasChange,
  onPromptsChange,
  onRefreshModels,
  onExport,
  onImport,
  canInstall,
  onInstall,
  onClose,
}: Props) {
  const fileRef = useRef<HTMLInputElement>(null)
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([])

  useEffect(() => {
    loadVoices().then(setVoices)
  }, [])

  function updatePersona(id: string, patch: Partial<Persona>) {
    onPersonasChange(personas.map((p) => (p.id === id ? { ...p, ...patch } : p)))
  }
  function addPersona() {
    onPersonasChange([
      ...personas,
      { id: uid(), name: 'Nueva persona', emoji: '⭐', systemPrompt: '' },
    ])
  }
  function removePersona(id: string) {
    if (personas.length <= 1) return
    onPersonasChange(personas.filter((p) => p.id !== id))
  }

  function updatePrompt(id: string, patch: Partial<PromptTemplate>) {
    onPromptsChange(prompts.map((p) => (p.id === id ? { ...p, ...patch } : p)))
  }
  function addPrompt() {
    onPromptsChange([...prompts, { id: uid(), name: 'Nuevo prompt', text: '' }])
  }
  function removePrompt(id: string) {
    onPromptsChange(prompts.filter((p) => p.id !== id))
  }

  return (
    <div
      className="fixed inset-0 z-40 flex items-center justify-center p-4 bg-black/50"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 p-5 space-y-5 max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold">Ajustes</h2>
          <button
            onClick={onClose}
            className="text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200"
          >
            ✕
          </button>
        </div>

        {/* Modelo */}
        <div className="space-y-1.5">
          <label className="text-sm font-medium">Modelo</label>
          <div className="flex gap-2">
            <ModelPicker
              models={models}
              value={settings.autoModel ? '__auto__' : settings.model}
              onChange={(m) =>
                m === '__auto__'
                  ? onChange({ ...settings, autoModel: true })
                  : onChange({ ...settings, autoModel: false, model: m })
              }
            />
            <button
              onClick={onRefreshModels}
              className="text-sm px-3 py-1.5 rounded-lg border border-zinc-300 dark:border-zinc-700 hover:bg-zinc-100 dark:hover:bg-zinc-800"
              title="Recargar lista de modelos"
            >
              ↻
            </button>
          </div>
          {connError ? (
            <p className="text-xs text-red-500">{connError}</p>
          ) : (
            <p className="text-xs text-zinc-400">
              Los modelos con visión (llava, gemma3, *vl) pueden analizar imágenes.
            </p>
          )}
        </div>

        {/* Memoria */}
        <label className="flex items-center gap-2 text-sm cursor-pointer">
          <input
            type="checkbox"
            checked={settings.autoMemory}
            onChange={(e) => onChange({ ...settings, autoMemory: e.target.checked })}
            className="accent-indigo-600"
          />
          Memoria automática (detectar y guardar datos por sí solo)
        </label>

        {/* Búsqueda web */}
        <div className="space-y-1.5">
          <label className="text-sm font-medium">
            Esfuerzo de búsqueda web por defecto
          </label>
          <div className="flex items-center gap-3">
            <input
              type="range"
              min={1}
              max={5}
              step={1}
              value={settings.webEffort}
              onChange={(e) =>
                onChange({ ...settings, webEffort: parseInt(e.target.value, 10) })
              }
              className="flex-1 accent-indigo-600"
            />
            <span className="w-16 text-sm font-medium">
              {effortLabel(settings.webEffort)}
            </span>
          </div>
          <p className="text-xs text-zinc-400">
            Más esfuerzo = más resultados y páginas leídas (más lento).
          </p>
        </div>

        {/* Personas */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-sm font-medium">Personas / roles</label>
            <button
              onClick={addPersona}
              className="text-xs px-2 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white"
            >
              + Nueva
            </button>
          </div>
          <div className="space-y-3">
            {personas.map((p) => (
              <div
                key={p.id}
                className="rounded-lg border border-zinc-200 dark:border-zinc-700 p-2 space-y-2"
              >
                <div className="flex items-center gap-2">
                  <input
                    value={p.emoji ?? ''}
                    onChange={(e) => updatePersona(p.id, { emoji: e.target.value })}
                    className="w-10 text-center rounded border border-zinc-200 dark:border-zinc-700 bg-transparent text-sm p-1 outline-none"
                    title="Emoji"
                  />
                  <input
                    value={p.name}
                    onChange={(e) => updatePersona(p.id, { name: e.target.value })}
                    className="flex-1 rounded border border-zinc-200 dark:border-zinc-700 bg-transparent text-sm p-1 outline-none font-medium"
                  />
                  <button
                    onClick={() => removePersona(p.id)}
                    disabled={personas.length <= 1}
                    className="text-zinc-400 hover:text-red-500 disabled:opacity-30"
                    title="Borrar persona"
                  >
                    ✕
                  </button>
                </div>
                <textarea
                  value={p.systemPrompt}
                  onChange={(e) =>
                    updatePersona(p.id, { systemPrompt: e.target.value })
                  }
                  rows={2}
                  placeholder="Instrucciones de esta persona…"
                  className="w-full resize-y rounded border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-sm p-2 outline-none"
                />
              </div>
            ))}
          </div>
        </div>

        {/* Prompts guardados */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-sm font-medium">Prompts guardados</label>
            <button
              onClick={addPrompt}
              className="text-xs px-2 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white"
            >
              + Nuevo
            </button>
          </div>
          <div className="space-y-3">
            {prompts.map((p) => (
              <div
                key={p.id}
                className="rounded-lg border border-zinc-200 dark:border-zinc-700 p-2 space-y-2"
              >
                <div className="flex items-center gap-2">
                  <input
                    value={p.name}
                    onChange={(e) => updatePrompt(p.id, { name: e.target.value })}
                    className="flex-1 rounded border border-zinc-200 dark:border-zinc-700 bg-transparent text-sm p-1 outline-none font-medium"
                  />
                  <button
                    onClick={() => removePrompt(p.id)}
                    className="text-zinc-400 hover:text-red-500"
                    title="Borrar prompt"
                  >
                    ✕
                  </button>
                </div>
                <textarea
                  value={p.text}
                  onChange={(e) => updatePrompt(p.id, { text: e.target.value })}
                  rows={2}
                  placeholder="Texto de la plantilla…"
                  className="w-full resize-y rounded border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-sm p-2 outline-none"
                />
              </div>
            ))}
          </div>
        </div>

        {/* Voz */}
        <div className="space-y-2">
          <label className="text-sm font-medium">Voz (respuestas habladas)</label>
          <label className="flex items-center gap-2 text-sm cursor-pointer">
            <input
              type="checkbox"
              checked={settings.autoSpeak}
              onChange={(e) => onChange({ ...settings, autoSpeak: e.target.checked })}
              className="accent-indigo-600"
            />
            Leer las respuestas en voz alta automáticamente
          </label>
          <div className="flex items-center gap-2">
            <select
              value={settings.ttsVoice}
              onChange={(e) => {
                const v = voices.find((x) => x.name === e.target.value)
                onChange({
                  ...settings,
                  ttsVoice: e.target.value,
                  ttsLang: v?.lang || settings.ttsLang,
                })
              }}
              className="flex-1 min-w-0 rounded-lg border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-sm px-2 py-1.5 outline-none"
            >
              <option value="">(voz por defecto del sistema)</option>
              {voices.map((v) => (
                <option key={v.name} value={v.name}>
                  {v.name} — {v.lang}
                </option>
              ))}
            </select>
            <button
              onClick={() =>
                speak('Hola, soy tu asistente. Así es como sueno.', {
                  voice: settings.ttsVoice,
                  rate: settings.ttsRate,
                  lang: settings.ttsLang,
                })
              }
              className="text-sm px-3 py-1.5 rounded-lg border border-zinc-300 dark:border-zinc-700 hover:bg-zinc-100 dark:hover:bg-zinc-800 shrink-0"
            >
              ▶︎ Probar
            </button>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-xs text-zinc-500 shrink-0">Velocidad</span>
            <input
              type="range"
              min={0.5}
              max={2}
              step={0.1}
              value={settings.ttsRate}
              onChange={(e) =>
                onChange({ ...settings, ttsRate: parseFloat(e.target.value) })
              }
              className="flex-1 accent-indigo-600"
            />
            <span className="text-xs w-10 text-right">
              {settings.ttsRate.toFixed(1)}x
            </span>
          </div>
        </div>

        {/* Tema */}
        <div className="flex items-center justify-between">
          <label className="text-sm font-medium">Tema</label>
          <div className="flex gap-1 rounded-lg border border-zinc-300 dark:border-zinc-700 p-0.5">
            {(['dark', 'light'] as const).map((t) => (
              <button
                key={t}
                onClick={() => onChange({ ...settings, theme: t })}
                className={`px-3 py-1 rounded-md text-sm ${
                  settings.theme === t ? 'bg-indigo-600 text-white' : ''
                }`}
              >
                {t === 'dark' ? 'Oscuro' : 'Claro'}
              </button>
            ))}
          </div>
        </div>

        {/* Color de acento (por perfil) */}
        <div className="flex items-center justify-between flex-wrap gap-2">
          <label className="text-sm font-medium">Color de acento</label>
          <div className="flex items-center gap-1.5">
            {ACCENTS.map((c) => (
              <button
                key={c}
                onClick={() => onChange({ ...settings, accent: c })}
                className={`h-6 w-6 rounded-full border-2 transition-transform hover:scale-110 ${
                  (settings.accent || '#4f46e5').toLowerCase() === c
                    ? 'border-zinc-900 dark:border-white'
                    : 'border-transparent'
                }`}
                style={{ backgroundColor: c }}
                title={c}
              />
            ))}
            <input
              type="color"
              value={settings.accent || '#4f46e5'}
              onChange={(e) => onChange({ ...settings, accent: e.target.value })}
              className="h-6 w-8 rounded cursor-pointer bg-transparent"
              title="Color personalizado"
            />
          </div>
        </div>

        {/* Instalar como app (PWA) */}
        <div className="space-y-1.5 border-t border-zinc-200 dark:border-zinc-800 pt-4">
          <label className="text-sm font-medium">📱 Instalar Yuki como app</label>
          {canInstall ? (
            <div className="flex items-center gap-2">
              <button
                onClick={onInstall}
                className="text-sm px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white"
              >
                📲 Instalar ahora
              </button>
              <span className="text-xs text-zinc-400">Ícono en tu pantalla de inicio, a pantalla completa.</span>
            </div>
          ) : (
            <p className="text-xs text-zinc-400">
              En Chrome/Android: menú ⋮ → <b>Instalar app</b>. En iPhone (Safari): botón Compartir →{' '}
              <b>Añadir a pantalla de inicio</b>. (Si ya está instalada, no aparece el botón.)
            </p>
          )}
        </div>

        {/* Administrador (dueño) — correo, escribir a amigos, etc. */}
        <div className="space-y-1.5 border-t border-zinc-200 dark:border-zinc-800 pt-4">
          <label className="text-sm font-medium">🔐 Crear perfil de administrador</label>
          <OwnerSettings profileId={profileId} />
        </div>

        {/* Respaldo */}
        <div className="space-y-1.5 border-t border-zinc-200 dark:border-zinc-800 pt-4">
          <label className="text-sm font-medium">Respaldo</label>
          <div className="flex gap-2">
            <button
              onClick={onExport}
              className="text-sm px-3 py-1.5 rounded-lg border border-zinc-300 dark:border-zinc-700 hover:bg-zinc-100 dark:hover:bg-zinc-800"
            >
              ⬇️ Exportar
            </button>
            <button
              onClick={() => fileRef.current?.click()}
              className="text-sm px-3 py-1.5 rounded-lg border border-zinc-300 dark:border-zinc-700 hover:bg-zinc-100 dark:hover:bg-zinc-800"
            >
              ⬆️ Importar
            </button>
            <input
              ref={fileRef}
              type="file"
              accept="application/json,.json"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0]
                if (f) onImport(f)
                e.target.value = ''
              }}
            />
          </div>
          <p className="text-xs text-zinc-400">
            Guarda o restaura tus conversaciones, memoria, personas y ajustes.
          </p>
        </div>

        {/* Atajos */}
        <div className="border-t border-zinc-200 dark:border-zinc-800 pt-4 text-xs text-zinc-500 dark:text-zinc-400 space-y-0.5">
          <p className="font-medium text-zinc-600 dark:text-zinc-300">
            Atajos de teclado
          </p>
          <p>
            <kbd>Alt</kbd>+<kbd>N</kbd> nuevo chat · <kbd>Alt</kbd>+<kbd>M</kbd>{' '}
            memoria · <kbd>Alt</kbd>+<kbd>S</kbd> ajustes
          </p>
          <p>
            <kbd>Alt</kbd>+<kbd>E</kbd> exportar chat · <kbd>Alt</kbd>+
            <kbd>V</kbd> manos libres · <kbd>Esc</kbd> detener / callar
          </p>
        </div>
      </div>
    </div>
  )
}
