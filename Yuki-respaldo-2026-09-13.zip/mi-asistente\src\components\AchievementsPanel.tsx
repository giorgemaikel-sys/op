import type { UserStats } from '../lib/types'
import { ACHIEVEMENTS } from '../lib/gamification'

interface Props {
  stats: UserStats
  onClose: () => void
}

export default function AchievementsPanel({ stats, onClose }: Props) {
  const unlocked = new Set(stats.achievements || [])
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 px-4" onClick={onClose}>
      <div
        className="w-full max-w-md rounded-2xl bg-white dark:bg-zinc-900 p-5 max-h-[85vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold">🏆 Tu progreso</h2>
          <button onClick={onClose} className="text-zinc-400 hover:text-zinc-600 text-xl leading-none">
            ✕
          </button>
        </div>

        <div className="grid grid-cols-3 gap-2 mb-4 text-center">
          <div className="rounded-xl bg-orange-50 dark:bg-orange-950/40 p-3">
            <p className="text-2xl font-bold">🔥 {stats.streak || 0}</p>
            <p className="text-[11px] text-zinc-500">racha (días)</p>
          </div>
          <div className="rounded-xl bg-indigo-50 dark:bg-indigo-950/40 p-3">
            <p className="text-2xl font-bold">{stats.messages || 0}</p>
            <p className="text-[11px] text-zinc-500">mensajes</p>
          </div>
          <div className="rounded-xl bg-emerald-50 dark:bg-emerald-950/40 p-3">
            <p className="text-2xl font-bold">{stats.bestStreak || 0}</p>
            <p className="text-[11px] text-zinc-500">mejor racha</p>
          </div>
        </div>

        <p className="text-sm font-medium mb-2">
          Logros ({unlocked.size}/{ACHIEVEMENTS.length})
        </p>
        <div className="space-y-2">
          {ACHIEVEMENTS.map((a) => {
            const has = unlocked.has(a.id)
            return (
              <div
                key={a.id}
                className={`flex items-center gap-3 rounded-xl p-2.5 border ${
                  has
                    ? 'border-amber-300 dark:border-amber-700 bg-amber-50 dark:bg-amber-950/30'
                    : 'border-zinc-200 dark:border-zinc-800 opacity-60'
                }`}
              >
                <span className={`text-2xl ${has ? '' : 'grayscale'}`}>{a.emoji}</span>
                <div className="min-w-0">
                  <p className="text-sm font-medium">{a.name}</p>
                  <p className="text-xs text-zinc-500">{a.desc}</p>
                </div>
                {has && <span className="ml-auto text-emerald-500">✓</span>}
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
