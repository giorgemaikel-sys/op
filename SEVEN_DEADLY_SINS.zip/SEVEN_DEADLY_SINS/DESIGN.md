# Nanatsu no Taizai — Mod de WorldBox

Contrato de diseño. **Toda la nomenclatura de IDs de este documento es normativa**: cualquier
sistema que invente un id distinto rompe las referencias cruzadas y `SDSSelfCheck` lo reporta.

Objetivo de esta fase: cimientos sólidos + los sistemas que definen la identidad de la serie.
Los Cuatro Jinetes del Apocalipsis quedan fuera, pero `Eras.cs` se diseña extensible para admitirlos.

---

## 0. Entorno verificado

| Dato | Valor |
|---|---|
| Juego | WorldBox v0.51.2, build 719 (Steam buildid 19962337) |
| Unity | 2022.3.60f1, runtime Mono (no IL2CPP) |
| Perfil .NET | .NET Framework 4.x, `netstandard` 2.1 |
| Mod loader | NeoModLoader 1.2.0.1 |
| Referencia de compilación | `worldbox_Data/StreamingAssets/mods/NML/Assembly-CSharp-Publicized.dll` |
| Carpeta de mods | `steamapps/common/worldbox/Mods/` |
| Datos persistentes | `%LOCALAPPDATA%Low/mkarpenko/WorldBox/` |

NML compila los `.cs` en crudo con Roslyn al arrancar. **No entregamos DLL.** Harmony ya lo
provee el loader (`NML/Assemblies/0Harmony.dll`); no incluir copia propia.

Requisito de jugador: **Experimental Mode activado** en los ajustes del juego.

---

## 1. Convención de IDs

Prefijo global `sds_`. Sin excepciones, para que ningún id colisione con vanilla ni con otros mods.

| Tipo | Patrón | Ejemplo |
|---|---|---|
| Trait | `sds_<categoria>_<nombre>` | `sds_sin_wrath`, `sds_clan_demon` |
| Grupo de traits | `sds_group_<nombre>` | `sds_group_sins` |
| Status | `sds_status_<nombre>` | `sds_status_demon_mark` |
| Efecto | `sds_fx_<nombre>` | `sds_fx_hellblaze` |
| Proyectil | `sds_proj_<nombre>` | `sds_proj_ark` |
| Actor | `sds_<nombre>` | `sds_meliodas`, `sds_indura` |
| Poder (botón) | `sds_power_<accion>_<nombre>` | `sds_power_spawn_meliodas` |
| Reino | `sds_kingdom_<nombre>` | `sds_kingdom_liones` |
| Item | `sds_item_<nombre>` | `sds_item_lostvayne` |
| Clave de locale | `sds_<lo_que_nombre>` | `trait_sds_sin_wrath` |

Claves de localización obligatorias por trait: `trait_<id>` (nombre) y `trait_<id>_info`
(descripción). Por status: `status_title_<id>` y `status_description_<id>`.

---

## 2. Nivel de Poder — el sistema insignia

Es **la** mecánica identitaria de Nanatsu no Taizai y debe verse en la UI.

```
Nivel de Poder = Fuerza (Strength) + Espíritu (Spirit) + Magia (Magic)
```

Tres stats propios registrados en `BaseStatsLibrary` vía `PowerLevel.RegisterBaseStats()`,
siguiendo el patrón de `ChakraSystem.RegisterBaseStats` de Shinobi Legend.

- `sds_strength` — poder físico bruto
- `sds_spirit` — voluntad / presión de combate
- `sds_magic` — poder mágico

Reglas:
- Se muestra en el panel de unidad (`SDSUnitTab`) como número entero, estilo *"Nivel de Poder: 3.370"*.
- Escala con kills, edad y rango. Un aldeano ronda 5–50; un Caballero Sagrado 500–2.000;
  un Pecado Capital 3.000–5.000; un Mandamiento 20.000–60.000; el Rey Demonio ~1.000.000.
- `PowerLevel.Get(Actor)` es la única lectura pública. Nadie recalcula por su cuenta.
- Modificadores multiplicativos se registran como *contribuyentes* (`PowerLevel.AddContributor`)
  para que Sunshine, Marca del Demonio, Indura, etc. no se pisen entre sí.

**Referencias canónicas de nivel de poder** (para calibrar, no hace falta exactitud absoluta):

| Personaje | Nivel |
|---|---|
| Meliodas (sellado) | 3.370 |
| Meliodas (Assault Mode) | 56.000 |
| Escanor (mediodía, The One) | 200.000+ |
| Escanor (noche) | ~15 |
| Ban (base) | 3.220 |
| King | 4.190 |
| Diane | 3.055 |
| Gowther | 3.100 |
| Merlin | 4.710 |
| Zeldris | 55.000 |
| Estarossa | 60.000 |
| Rey Demonio | 1.000.000+ |

---

## 3. Los seis clanes

Traits del grupo `sds_group_clans`, **mutuamente excluyentes** (`SDSRegistry.Opposites`).
Cada uno tiene además un `ActorAsset` propio clonado de una plantilla vanilla.

| Trait id | ES | EN | Identidad mecánica |
|---|---|---|---|
| `sds_clan_human` | Clan de los Humanos | Human Clan | Sin bonus; acceso a rangos de Caballero Sagrado y a los Pecados |
| `sds_clan_demon` | Clan de los Demonios | Demon Clan | Regeneración, +daño, inmune a veneno, **vulnerable a Ark** |
| `sds_clan_goddess` | Clan de las Diosas | Goddess Clan | Curación en área, Ark, **daño extra a demonios** |
| `sds_clan_fairy` | Clan de las Hadas | Fairy Clan | Vuelo, vida muy larga, regeneración en bosque |
| `sds_clan_giant` | Clan de los Gigantes | Giant Clan | Escala x1.8, mucha vida, lento, manipula la tierra |
| `sds_clan_vampire` | Clan de los Vampiros | Vampire Clan | Drena vida al golpear, **se debilita de día** |

El triángulo Demonio ↔ Diosa es asimétrico y explícito: las diosas hacen daño extra a los
demonios *y* los demonios reciben daño extra de Ark. Es la Guerra Santa en dos líneas.

---

## 4. Los Siete Pecados Capitales

Grupo `sds_group_sins`, mutuamente excluyentes. Cada pecado = 1 trait + 1 actor legendario +
1 habilidad activa + 1 tesoro sagrado.

| Trait id | Pecado | Bestia | Personaje | Habilidad | Tesoro |
|---|---|---|---|---|---|
| `sds_sin_wrath` | Ira | Dragón | Meliodas | Full Counter | Lostvayne |
| `sds_sin_greed` | Avaricia | Zorro | Ban | Snatch | Courechouse |
| `sds_sin_envy` | Envidia | Serpiente | Diane | Creation | Gideon |
| `sds_sin_lust` | Lujuria | Cabra | Gowther | Invasion | Herritt |
| `sds_sin_sloth` | Pereza | Oso Gris | King | Disaster | Chastiefol |
| `sds_sin_gluttony` | Gula | Jabalí | Merlin | Infinity | Aldan |
| `sds_sin_pride` | Soberbia | León | Escanor | Sunshine | Rhitta |

### Habilidades — comportamiento exigido

- **Full Counter** (`sds_ability_full_counter`) — al recibir un ataque a distancia o mágico,
  probabilidad de reflejarlo con daño multiplicado hacia el atacante. No funciona contra
  ataques físicos directos (fidelidad al canon).
- **Snatch** (`sds_ability_snatch`) — al golpear, roba permanentemente una fracción de
  `sds_strength` del objetivo y la suma a la propia. Es la avaricia hecha stat.
- **Creation** (`sds_ability_creation`) — manipula el terreno: convierte tiles cercanos en
  roca/tierra y lanza proyectiles de piedra.
- **Invasion** (`sds_ability_invasion`) — magia mental: convierte al objetivo al reino propio,
  o le borra la memoria (pierde traits de rango).
- **Disaster** (`sds_ability_disaster`) — control de espíritu y naturaleza; invoca la lanza
  Chastiefol en sus formas y drena vida en área.
- **Infinity** (`sds_ability_infinity`) — todo efecto propio dura para siempre: los status que
  aplica no expiran. Además inmunidad a status negativos.
- **Sunshine** (`sds_ability_sunshine`) — ★ la joya. El nivel de poder **escala con la hora del
  mundo**: mínimo a medianoche, máximo a mediodía. A pleno mediodía entra en estado
  *"The One"* (`sds_status_the_one`) con multiplicador extremo. De noche queda casi inofensivo.
  Debe implementarse leyendo el reloj del mundo, no un contador propio.

### Habilidades compartidas / de clan

- **Hellblaze** (`sds_ability_hellblaze`) — llama negra demoníaca: impide la regeneración y la
  curación del objetivo. Meliodas y el Rey Demonio.
- **Ark** (`sds_ability_ark`) — luz de diosa: cura aliados, daño extra a demonios.
- **Purge** (`sds_ability_purge`) — llama blanca sagrada (Mael/Estarossa).

---

## 5. Los Diez Mandamientos

Grupo `sds_group_commandments`, mutuamente excluyentes. Cada uno impone una **maldición**:
una regla que castiga a quien la viole en presencia del portador. Ese es su encanto y hay que
implementarlo de verdad, no como texto decorativo.

| Trait id | Mandamiento | Portador | Maldición |
|---|---|---|---|
| `sds_cmd_piety` | Piedad | Zeldris | Quien juzgue al portador pierde su fuerza |
| `sds_cmd_love` | Amor | Estarossa | Quien sienta odio sin amor queda paralizado |
| `sds_cmd_truth` | Verdad | Galand | Quien mienta se convierte en piedra |
| `sds_cmd_faith` | Fe | Melascula | Quien dude pierde el alma |
| `sds_cmd_selflessness` | Altruismo | Fraudrin | Quien actúe por egoísmo pierde lo que ama |
| `sds_cmd_pacifism` | Pacifismo | Grayroad | Quien mate queda reducido a ceniza |
| `sds_cmd_repose` | Reposo | Gloxinia | Quien descanse pierde tiempo de vida |
| `sds_cmd_patience` | Paciencia | Drole | Quien huya con miedo pierde su poder |
| `sds_cmd_reticence` | Silencio | Monspeet | Quien hable del portador arde |
| `sds_cmd_purity` | Pureza | Derieri | Quien se corrompa se ahoga |

Implementación: `TenCommandments.cs` registra un manejador por mandamiento en el tick por actor.
La condición se evalúa sobre unidades **dentro de un radio** del portador vivo. Cuando se viola,
se aplica el status de castigo correspondiente (`sds_status_curse_<nombre>`).

Un solo portador vivo por mandamiento a la vez: es un puesto, no un rasgo común.

---

## 6. Tipos de magia

Grupo `sds_group_magic`, mutuamente excluyentes. Todo usuario de magia tiene exactamente uno.

| Trait id | ES | EN | Efecto |
|---|---|---|---|
| `sds_magic_strengthener` | Reforzador | Strengthener | Multiplica stats físicos propios |
| `sds_magic_enchanter` | Encantador | Enchanter | Encanta a aliados cercanos (buff en área) |
| `sds_magic_incantation` | Hechicero | Incantation | Proyectiles mágicos de largo alcance |
| `sds_magic_healer` | Sanador | Healer | Cura a aliados cercanos |
| `sds_magic_special` | Especial | Special | Habilidad única e irrepetible; requisito para los Pecados |

---

## 7. Rangos de Caballero Sagrado

Grupo `sds_group_ranks`, excluyentes, progresión ascendente ganada por combate.

`sds_rank_apprentice` (Aprendiz) → `sds_rank_holy_knight` (Caballero Sagrado) →
`sds_rank_great_holy_knight` (Gran Caballero Sagrado) → `sds_rank_grand_master` (Gran Maestro)

Ascenso por kills + edad, gestionado en `HolyKnights.cs`. Cada rango sube el Nivel de Poder.

---

## 8. Tesoros Sagrados (items)

Registrados como `ItemAsset` en `SacredTreasures.cs`. Solo el Pecado correspondiente puede
empuñarlos con su efecto completo.

| Item id | Tesoro | Dueño | Tipo |
|---|---|---|---|
| `sds_item_lostvayne` | Lostvayne | Meliodas | Espada demoníaca; clones físicos |
| `sds_item_courechouse` | Courechouse | Ban | Bastón sagrado de cuatro secciones |
| `sds_item_chastiefol` | Chastiefol | King | Lanza espiritual |
| `sds_item_gideon` | Gideon | Diane | Martillo de guerra |
| `sds_item_herritt` | Herritt | Gowther | Arco gemelo |
| `sds_item_aldan` | Aldan | Merlin | Orbe |
| `sds_item_rhitta` | Rhitta | Escanor | Hacha divina |

---

## 9. Transformaciones

- **Marca del Demonio** (`sds_status_demon_mark`) — se activa en combate a baja vida.
  Multiplica poder, tiñe al actor. Base de Assault Mode.
- **Assault Mode** (`sds_status_assault_mode`) — el escalón siguiente, solo Meliodas.
- **Indura** (`sds_actor_indura`) — un demonio que agota su poder mágico degenera en una
  bestia Indura descontrolada, hostil a todos. Transformación irreversible.
- **The One** (`sds_status_the_one`) — Escanor a mediodía.

---

## 10. Reinos

`sds_kingdom_liones` (humanos), `sds_kingdom_camelot`, `sds_kingdom_danafor`,
`sds_kingdom_fairy_forest`, `sds_kingdom_giant_dungeon`, `sds_kingdom_purgatory` (demonios),
`sds_kingdom_heaven` (diosas).

---

## 11. Arquitectura del código

Espejo de Shinobi Legend, que ya está probado contra esta versión del juego.

```
SEVEN_DEADLY_SINS/
├── mod.json
├── icon.png
├── Code/
│   ├── Main.cs                 BasicMod<Main> + Step() aislado por sistema
│   ├── SDSConfig.cs
│   ├── Core/
│   │   ├── SDSRegistry.cs      ★ puerta única a AssetManager
│   │   ├── SDSLocale.cs        ES + tabla base
│   │   ├── SDSLocaleEN.cs      mapa EN
│   │   ├── SDSTick.cs          tick round-robin en rodajas
│   │   ├── SDSUnit.cs          helpers de consulta sobre Actor
│   │   ├── SDSLog.cs / SDSFx.cs
│   │   ├── PowerLevel.cs       ★ el stat insignia
│   │   └── SDSSelfCheck.cs     valida iconos, locales e ids al arrancar
│   ├── Content/
│   │   ├── TraitGroups.cs  Effects.cs  Statuses.cs  Projectiles.cs
│   │   ├── Traits.cs  Actors.cs  TraitLore.cs
│   ├── Systems/
│   │   ├── Clans.cs  SevenSins.cs  TenCommandments.cs  MagicTypes.cs
│   │   ├── HolyKnights.cs  SacredTreasures.cs  DemonMark.cs  Indura.cs
│   │   ├── Abilities.cs  Sunshine.cs  FullCounter.cs  Snatch.cs
│   │   ├── HolyWar.cs  Kingdoms.cs  Legends.cs  Eras.cs
│   └── UI/
│       ├── SDSTab.cs  SDSUnitTab.cs  SDSGuide.cs
├── GameResources/
│   ├── actors/<id>/Main/walk_0..3.png
│   ├── ui/icons/…
│   └── effects/…
└── Locales/ en.json, es.json
```

### Invariantes no negociables

Estas cuatro reglas están verificadas contra el juego (documentadas en `SLRegistry.cs` y
`XiaRace.cs` del ecosistema existente). Violarlas produce bugs silenciosos:

1. **`SDSRegistry.ApplyOpposites()` debe ejecutarse después del último trait registrado.**
   El juego construye los `HashSet` de opuestos al arrancar la librería, antes de que el mod
   registre nada. Sin la llamada final, las exclusiones son inertes y una unidad puede portar
   los 7 pecados y los 10 mandamientos a la vez.
2. **`Actor.addTrait(id)` tiene `pRemoveOpposites = false` por defecto.** Hay que llamar
   `addTrait(id, true)` o pasar siempre por `SDSTraits.Give`.
3. **`rate_birth` se deja en 0 siempre.** El pool de nacimiento del juego es ciego a la especie:
   un trait ahí acaba en osos y dragones. El contenido se reparte por sistemas, no por el pool.
4. **Nunca precargar `SpriteTextureLoader.getSpriteList` dentro de `OnModLoad`.** Envenena la
   caché de sprites permanentemente con arrays vacíos. Cargar en el primer uso real.

Además: `check_flip` nunca nulo en un `ActorAsset` (`linkAssets` corre antes que `OnModLoad`
y lanza `NullReferenceException`), y `birth_rate` explícito o `BabyMaker` lo trunca a 0.

---

## 12. Sprites

16×16 RGBA, **alfa binario** (0 o 255), sin semitransparencias. Carpeta `Main` obligatoria:
`ActorTextureSubAsset` compone `texture_path_main = ruta + "main"` y si no existe cae a `male_1`.

Ciclo de caminado por altura, fotogramas contiguos: `walk_0` y `walk_3` con los pies en la fila 15,
`walk_1` levantado 2 px, `walk_2` levantado 1 px. Si falta un fotograma la animación se corta.

Criaturas grandes (Indura, gigantes) escapan del 16×16 y se escalan con `base_stats["scale"]`.

Paletas por personaje: Meliodas (rubio #F2D16B + negro), Ban (blanco #E8E8E8 + rojo #C0392B),
King (rosa #E8A0C0 + verde), Diane (castaño + naranja), Gowther (rosa pálido + armadura),
Merlin (negro azulado + morado), Escanor (naranja #E67E22 + dorado).
