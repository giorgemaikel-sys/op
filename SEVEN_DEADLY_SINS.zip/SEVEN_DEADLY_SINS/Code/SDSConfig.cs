namespace SevenDeadlySins
{
    /// Player-facing switches. Every system reads these rather than hard-coding behaviour, so a
    /// player who only wants the clans can turn the rest off.
    ///
    /// The setters below are called BY NAME from default_config.json, in the form
    /// "SevenDeadlySins.SDSConfig:SetSunshineCycle". Renaming one without editing that file breaks
    /// the link silently — the toggle appears in the settings screen and does nothing.
    ///
    /// default_config.json must be a JSON ARRAY of ModConfigItem per group key, not an object keyed
    /// by name. Getting that wrong throws inside BasicMod.LoadConfig before OnModLoad ever runs, and
    /// NeoModLoader disables the whole mod with a Newtonsoft deserialisation error.
    public static class SDSConfig
    {
        /// Sunshine scales Escanor with the world clock. Off = fixed power, for players who find the
        /// night-time collapse frustrating.
        public static bool SunshineCycle = true;

        /// Commandment curses punish units that break them. Off = the commandments are just strong
        /// traits with no world-wide rules.
        public static bool CommandmentCurses = true;

        /// Demons whose magic runs out degenerate into Indura.
        public static bool InduraTransformation = true;

        /// Holy Knights get promoted by kills and age.
        public static bool HolyKnightPromotion = true;

        /// The Demon Mark triggers automatically at low health.
        public static bool AutoDemonMark = true;

        /// Ability cooldowns. Off makes everything fire whenever it can, which is chaotic and fun.
        public static bool AbilityCooldowns = true;

        /// Cruce entre razas. Con esto, cualquier raza puede enamorarse y tener hijos con otra —
        /// una diosa con un demonio, un gigante con un hada. El hijo hereda la sangre de los dos
        /// (ver Offspring), que es de donde salen los Cuatro Jinetes del Apocalipsis: Tristan es
        /// hijo de Meliodas y Elizabeth, demonio y diosa. Es opcional porque cambia la simulacion
        /// entera del juego, no solo el mod, y no todo el mundo lo quiere.
        public static bool CrossRaceBreeding = true;

        // ---------------------------------------------------------------- config callbacks

        public static void SetSunshineCycle(bool v) { SunshineCycle = v; }
        public static void SetCommandmentCurses(bool v) { CommandmentCurses = v; }
        public static void SetInduraTransformation(bool v) { InduraTransformation = v; }
        public static void SetHolyKnightPromotion(bool v) { HolyKnightPromotion = v; }
        public static void SetAutoDemonMark(bool v) { AutoDemonMark = v; }
        public static void SetAbilityCooldowns(bool v) { AbilityCooldowns = v; }
        public static void SetCrossRaceBreeding(bool v) { CrossRaceBreeding = v; }

        public static void Init()
        {
            // The settings screen reads each item's Id as a localisation key.
            SDSLocale.Add("config_sds_sunshine", "Ciclo de Sunshine");
            SDSLocale.Add("config_sds_curses", "Maldiciones de los Mandamientos");
            SDSLocale.Add("config_sds_indura", "Transformacion Indura");
            SDSLocale.Add("config_sds_promotion", "Ascenso de Caballeros Sagrados");
            SDSLocale.Add("config_sds_demon_mark", "Marca del Demonio automatica");
            SDSLocale.Add("config_sds_cooldowns", "Enfriamiento de habilidades");
            SDSLocale.Add("config_sds_crossbreed", "Hijos entre razas distintas");
        }
    }
}
