using UnityEngine;

namespace SevenDeadlySins
{
    /// Convierte un mapa recien generado en el Purgatorio.
    ///
    /// El Purgatorio de la serie es una extension enorme de roca quemada bajo un cielo rojo, con
    /// venas de lava y agujas de piedra negra, y SIN UNA GOTA DE MAR. Un mundo aleatorio de WorldBox
    /// es justo lo contrario: verde y medio oceano. Asi que hay que rehacerlo casilla a casilla.
    ///
    /// QUE SE HACE CON EL AGUA. Los oceanos se convierten en TIERRA, no en lava. Es tentador
    /// volverlos mares de lava — queda espectacular y es muy de la serie — pero un mapa tipico es
    /// mas de medio oceano, y eso dejaria un Purgatorio donde todo lo que entra muere en diez
    /// segundos. La lava va en lagos sueltos sobre lo que era fondo marino: se ve, se teme, y se
    /// rodea. El paisaje de la serie es roca, con la lava como amenaza, no como suelo.
    ///
    /// POR QUE DE UNA SOLA VEZ, Y NO EN RODAJAS. La primera version repartia el trabajo entre
    /// frames para no dar un tiron. Fue un error: mientras se reparte, la simulacion corre sobre un
    /// mapa a medio rehacer — media isla ya es roca y la otra media todavia es oceano — y el gestor
    /// de chunks recalcula enlaces sobre ese disparate. Se hace todo en una pasada, sin ensuciar
    /// casilla a casilla, y con un unico repintado al final. Ver Repaint(), donde estuvo el peor
    /// error de todo esto.
    ///
    /// CUANDO SE PUEDE LLAMAR. Solo con el mundo del todo generado. `generateNewMap()` no ha
    /// terminado cuando devuelve el control: encola una veintena de pasos, y los de vegetacion,
    /// biomas y limpieza corren DESPUES. Moldear antes de tiempo no da ningun error, simplemente el
    /// generador te pisa el trabajo. La señal buena es `SmoothLoader.isLoading()`, no "¿ya hay
    /// tierra?" — eso se cumple a mitad de la cola.
    public static class PurgatoryLand
    {
        /// Moldea el mapa entero. Devuelve false si el mundo todavia no esta listo.
        public static bool ShapeAll()
        {
            WorldTile[] tiles = null;
            try { tiles = MapBox.instance != null ? MapBox.instance.tiles_list : null; }
            catch { }

            if (tiles == null || tiles.Length == 0) return false;

            _soil = AssetManager.tiles.get("soil_low");
            _lava = AssetManager.tiles.get("lava1");
            if (_soil == null) { SDSLog.Error("purgatorio: no existe soil_low"); return false; }

            _seaFloor = _soil.height_min;

            _infernalLow = AssetManager.top_tiles.get("infernal_low");
            _infernalHigh = AssetManager.top_tiles.get("infernal_high");
            _wasteland = AssetManager.top_tiles.get("wasteland_low");
            _corruptedLow = AssetManager.top_tiles.get("corrupted_low");
            _corruptedHigh = AssetManager.top_tiles.get("corrupted_high");

            SDSLog.Info("purgatorio: moldeando el terreno (nivel de tierra=" + _seaFloor + ")...");

            for (int i = 0; i < tiles.Length; i++) Shape(tiles[i], i);

            Repaint();

            SDSLog.Info("purgatorio: terreno listo (" + tiles.Length + " casillas)");
            return true;
        }

        /// Repinta el mapa SIN borrarlo.
        ///
        /// Aqui estaba el peor error de todo esto: antes se llamaba `MapBox.resetTiles()` creyendo
        /// que refrescaba el render. No refresca — DESTRUYE. Recorre las casillas llamando
        /// `WorldTile.clear()`, que las deja en `deep_ocean` con altura 0 y ademas desvincula
        /// unidades y edificios. En todo el juego se usa en un unico sitio: dentro de
        /// `MapBox.clearWorld()`. O sea que cada vez que terminaba de esculpir el Purgatorio, lo
        /// borraba entero acto seguido y me quedaba mirando un oceano vacio.
        ///
        /// Lo correcto es marcar sucio y forzar el recalculo de chunks, que es exactamente lo que
        /// hace el generador del juego despues de terraformar. Marcar los chunks es ademas lo que
        /// faltaba para que `MapChunkManager.calc_links()` no recalculara enlaces sobre regiones
        /// obsoletas.
        private static void Repaint()
        {
            try
            {
                MapBox.instance.allTilesDirty();
                World.world.map_chunk_manager.allDirty();
                World.world.map_chunk_manager.update(0f, pForce: true);
                World.world.resetRedrawTimer();
                MapBox.instance.redrawTiles();
            }
            catch (System.Exception e)
            {
                SDSLog.Error("purgatorio/repintado: " + e.Message);
            }
        }

        /// La altura minima a la que una casilla deja de ser mar. La dice el propio juego.
        private static int _seaFloor;

        // Resueltos una vez por moldeado, no por casilla: son 65536 busquedas evitadas.
        private static TileType _soil, _lava;
        private static TopTileType _infernalLow, _infernalHigh, _wasteland, _corruptedLow, _corruptedHigh;

        /// El aspecto de una sola casilla.
        ///
        /// El tipo se ASIGNA, no se deriva. Llegue a creer que WorldBox sacaba el terreno de la
        /// altura y que por eso no me cuajaban los cambios; es falso — `setTileType` guarda lo que
        /// le des. Lo que me pisaba el trabajo era el generador, que seguia corriendo por detras.
        /// La altura se toca solo para que el mar deje de serlo de cara al resto del juego.
        ///
        /// El indice hace de semilla en vez de un random puro: asi el mismo mapa da siempre el mismo
        /// Purgatorio, y los lagos de lava salen repartidos en lugar de amontonarse. Un `Randy` por
        /// casilla daria ruido blanco, que se ve como suciedad.
        private static void Shape(WorldTile t, int index)
        {
            if (t == null) return;

            try
            {
                TileType main = t.main_type;
                if (main == null) return;

                if (main.ocean || main.liquid)
                {
                    // El mar del Purgatorio no existe: donde habia fondo marino ahora hay llanura.
                    // Se sube apenas por encima del limite para que quede llano — el relieve de la
                    // serie es una meseta rota, no un continente con colinas.
                    t.Height = _seaFloor + (index % 7 == 0 ? 1 : 0);

                    // Los lagos de lava van justo aqui, sobre lo que era fondo marino. Sueltos y
                    // repartidos: en la serie la lava es una amenaza que se rodea, no el suelo. Un
                    // Purgatorio de lava mataria a todo lo que entra en diez segundos.
                    if (_lava != null && index % 337 == 0) Paint(t, _lava, null);
                    else Paint(t, _soil, index % 3 == 0 ? _wasteland : _infernalLow);
                    return;
                }

                // La roca alta se queda como esta: las agujas y las cumbres ya son el paisaje. Solo
                // se le quita lo que tenga encima, porque la piedra negra va pelada.
                if (main.id == "mountains" || main.id == "summit" || main.id == "hills")
                {
                    Paint(t, main, null);
                    return;
                }

                // Tierra firme: suelo infernal. La franja alta lleva la version _high, mas oscura,
                // para que el relieve se siga leyendo. Alguna mancha corrompida de vez en cuando,
                // porque en la serie el Purgatorio no es uniforme.
                bool high = main.id == "soil_high";
                if (index % 211 == 0) Paint(t, main, high ? _corruptedHigh : _corruptedLow);
                else Paint(t, main, high ? _infernalHigh : _infernalLow);
            }
            catch { }
        }

        /// UNA sola escritura por casilla, y por una razon concreta.
        ///
        /// `setTileTypes` pone el top y despues el main, y es este ultimo el que llama a
        /// `updateStats()`. Haciendolo por separado con `setTopTileType(top, false)` se saltaba esa
        /// actualizacion y `cur_tile_type` se quedaba apuntando al terreno ANTERIOR — que es
        /// justo lo que leen el render, la comparacion de capas y el calculo de chunks. El mapa
        /// acababa mintiendo sobre si mismo.
        ///
        /// `pSetDirty` va en false porque ensuciar 65536 casillas de una en una es lo que hacia
        /// recalcular enlaces a mitad del moldeado. El repintado va una sola vez, en Repaint().
        private static void Paint(WorldTile t, TileType main, TopTileType top)
        {
            try { t.setTileTypes(main, top, pSetDirty: false); }
            catch { }
        }
    }
}
