using UnityEngine;

namespace SevenDeadlySins
{
    /// The Demon Mark, and the thing above it.
    ///
    /// The mark surfaces when a demon fights at the edge of death. Assault Mode is the next rung and
    /// belongs to the Sin of Wrath alone — it is Meliodas with every seal broken, and the series is
    /// clear that nobody else gets there.
    ///
    /// Both are registered as PowerLevel CONTRIBUTORS. That is what lets a marked Escanor at noon be
    /// both things at once instead of one of them silently winning: Sunshine and the mark multiply
    /// together rather than overwriting each other.
    public static class DemonMark
    {
        public const string StatusMark = "sds_status_demon_mark";
        public const string StatusAssault = "sds_status_assault_mode";
        public const string FxMark = "sds_fx_demon_mark";
        public const string FxAssault = "sds_fx_assault_mode";

        /// Health fraction below which the darkness surfaces.
        private const float MarkThreshold = 0.45f;

        /// Assault Mode needs him genuinely cornered.
        private const float AssaultThreshold = 0.2f;

        private const float MarkMultiplier = 2.6f;

        /// Meliodas sellado ronda 3.370; en Modo Asalto (despierto, contra Escanor) la serie lo cita
        /// en 142.000, unas 42 veces mas. La marca ya multiplica por 2,6 por debajo, asi que este es
        /// el RESTO del salto, no el salto entero: 2,6 x 16,2 = 42,1, y 3.370 x 42,1 ~ 142.000.
        private const float AssaultMultiplier = 16.2f;

        public static void Init()
        {
            PowerLevel.AddContributor("demon_mark", Multiplier);
            SDSTick.Register(Tick);
        }

        public static float Multiplier(Actor a)
        {
            if (a == null) return 1f;

            float m = 1f;
            if (a.hasStatus(StatusMark)) m *= MarkMultiplier;
            if (a.hasStatus(StatusAssault)) m *= AssaultMultiplier;
            return m;
        }

        /// True for anyone the darkness answers: demons by blood, and whoever carries the Wrath.
        private static bool CanMark(Actor a)
        {
            return a.hasTrait(Clans.Demon)
                   || a.hasTrait(SevenDeadlySins.Traits.DemonBlood)
                   || a.hasTrait(SevenSins.Wrath);
        }

        private static void Tick(Actor a, float dt)
        {
            if (a == null || !a.isAlive() || a.data == null) return;
            if (!SDSConfig.AutoDemonMark) return;
            if (!CanMark(a)) return;

            // It surfaces in a FIGHT. A demon bleeding out alone in a field does not transform —
            // the mark answers danger, not injury.
            if (!a.has_attack_target) return;

            float max = a.getMaxHealth();
            if (max <= 0f) return;
            float ratio = a.data.health / max;

            if (ratio > MarkThreshold) return;

            // Short duration, renewed while the conditions hold. There is no verified way to remove
            // a status on this build, so everything transient here has to lapse on its own.
            bool wasMarked = a.hasStatus(StatusMark);
            try { a.addStatusEffect(StatusMark, 6f); }
            catch { return; }

            if (!wasMarked)
            {
                SDSFx.At(a, FxMark, 0.5f);
                SDSData.SetLong(a, SDSData.DemonMarkTime, SDSData.WorldSeconds());
            }

            // --- Assault Mode: Wrath only, cornered, and EARNED -----------------------
            if (ratio > AssaultThreshold) return;
            if (!a.hasTrait(SevenSins.Wrath)) return;

            // A freshly summoned Meliodas cannot break his seals. He has to have fought for it —
            // see Progression, which owns every unlock gate in the mod.
            if (!Progression.Has(a, Progression.Mastered)) return;

            bool wasAssault = a.hasStatus(StatusAssault);
            try { a.addStatusEffect(StatusAssault, 6f); }
            catch { return; }

            if (wasAssault) return;

            SDSFx.At(a, FxAssault, 0.8f);
            SDSFx.Wave(a, 3f, 2f);
            SDSLog.Chronicle(SDSLocale.T(
                a.getName() + " ha roto sus sellos. Lo que queda ya no pelea por ganar.",
                a.getName() + " has broken every seal. What is left is not fighting to win."));
        }
    }
}
