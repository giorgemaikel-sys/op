using System.Collections.Generic;
using UnityEngine;

namespace SevenDeadlySins
{
    /// Ban. Greed as a stat.
    ///
    /// Snatch takes strength off whatever it touches and KEEPS it. The keeping is the point: this is
    /// the one ability in the mod that permanently changes both parties, it is stored in Actor.data
    /// so it survives the save, and a Ban left alone in a violent world slowly becomes the strongest
    /// thing on the map without ever levelling up.
    ///
    /// The stolen total feeds back through a PowerLevel contributor rather than being written into
    /// the base stat, so it composes with the Demon Mark and Sunshine instead of fighting them, and
    /// so a single number in Actor.data is the whole truth about how much he has taken.
    public static class Snatch
    {
        public const string Ability = "sds_ability_snatch";
        public const string Fx = "sds_fx_snatch";

        /// Fraction of the victim's strength taken per bite.
        private const float StealFraction = 0.06f;

        /// Never take less than this, or robbing a peasant does literally nothing.
        private const float MinSteal = 1.5f;

        /// A victim cannot be drained below this much of their original strength. Without a floor a
        /// long-lived Ban reduces every neighbour to a statue and the world stops fighting back.
        private const float VictimFloor = 0.35f;

        private const float Radius = 2.5f;
        private const float Cooldown = 2f;

        private const string KeyOriginalStrength = "sds_snatch_orig";

        public static void Init()
        {
            // What he has taken is added on top of what he was born with.
            PowerLevel.AddContributor("snatch", Multiplier);
            SDSTick.Register(Tick);
        }

        /// Stolen strength expressed as a multiplier on total power.
        ///
        /// A multiplier rather than a flat addition because PowerLevel composes multiplicatively;
        /// the divisor keeps early thefts meaningful without letting a century of robbery run away
        /// into the millions.
        public static float Multiplier(Actor a)
        {
            if (a == null || !a.hasTrait(Ability)) return 1f;

            float stolen = SDSData.GetFloat(a, SDSData.StolenStrength, 0f);
            if (stolen <= 0f) return 1f;

            return 1f + stolen / 400f;
        }

        /// How much this unit has stolen over its life. Read by the unit panel.
        public static float Stolen(Actor a)
        {
            return SDSData.GetFloat(a, SDSData.StolenStrength, 0f);
        }

        private static void Tick(Actor a, float dt)
        {
            if (a == null || !a.isAlive() || a.data == null) return;
            if (!a.hasTrait(Ability)) return;
            if (!a.has_attack_target) return;
            if (!SDSData.TryUse(a, "snatch", SDSConfig.AbilityCooldowns ? Cooldown : 0.2f)) return;

            List<Actor> nearby = SDSUnit.Around(a, Radius);
            for (int i = 0; i < nearby.Count; i++)
            {
                Actor prey = nearby[i];
                if (prey == null || !prey.isAlive() || prey.data == null) continue;
                if (prey.kingdom == a.kingdom) continue;

                if (!Rob(a, prey)) continue;

                SDSFx.At(prey, Fx, 0.35f);
                return;      // one victim per bite
            }
        }

        /// Returns true when strength actually changed hands.
        private static bool Rob(Actor thief, Actor prey)
        {
            float current = PowerLevel.Strength(prey);
            if (current <= 0f) return false;

            // Remember what they started with, once, so the floor is measured against their original
            // self rather than against whatever is left after the last theft.
            float original = SDSData.GetFloat(prey, KeyOriginalStrength, -1f);
            if (original < 0f)
            {
                original = current;
                SDSData.SetFloat(prey, KeyOriginalStrength, original);
            }

            float floor = original * VictimFloor;
            if (current <= floor) return false;

            float take = Mathf.Max(MinSteal, current * StealFraction);
            if (current - take < floor) take = current - floor;
            if (take <= 0f) return false;

            // The victim's loss is written into their base stat; the thief's gain is accumulated in
            // Actor.data and surfaces through the contributor above.
            try { prey.stats[PowerLevel.StatStrength] = current - take; }
            catch { return false; }

            SDSData.SetFloat(thief, SDSData.StolenStrength, Stolen(thief) + take);
            return true;
        }
    }
}
