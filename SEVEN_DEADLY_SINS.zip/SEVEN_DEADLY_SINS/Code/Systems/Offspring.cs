using HarmonyLib;
using UnityEngine;

namespace SevenDeadlySins
{
    /// Los hijos heredan la sangre de sus padres.
    ///
    /// Esto es puro Four Knights of the Apocalypse. Tristan es hijo de Meliodas y Elizabeth — mitad
    /// demonio, mitad diosa — y Lancelot es hijo de Ban y Elaine — mitad humano, mitad hada. La
    /// serie que sigue el usuario ES la de los hijos de los Pecados, asi que un mod de los Pecados
    /// sin herencia se queda a medias.
    ///
    /// COMO. Se engancha al nacimiento (`ActorManager.createBabyActorFromData`) y se mira la sangre
    /// de los dos padres. El clan de cada padre se traduce a su rasgo de SANGRE — que no es
    /// exclusivo, al reves que el rasgo de clan — asi que un bebe puede llevar las dos a la vez.
    /// Un demonio con una diosa da un hijo con sangre de demonio Y de diosa. Eso es Tristan.
    ///
    /// Ademas, si alguno de los padres es un Pecado con nombre, el hijo lleva la marca de su linaje:
    /// mas poder del que le tocaria, porque la sangre de un Pecado no es la de cualquiera.
    public static class Offspring
    {
        public const string TraitScion = "sds_scion";
        public const string TraitHybrid = "sds_hybrid";

        /// El PRODIGIO. Superar a un padre legendario es casi imposible a proposito: un hijo normal
        /// hereda poco y, aunque pelee toda su vida, se queda por debajo. Solo un prodigio — que sale
        /// con probabilidad casi nula — hereda lo bastante como para PODER superarlo, y aun asi le
        /// cuesta. Los Cuatro Jinetes del Apocalipsis (Tristan, Lancelot) son prodigios siempre: la
        /// profecia dice que superan a sus padres.
        public const string TraitProdigy = "sds_prodigy";

        /// Probabilidad de que un hijo cualquiera nazca prodigio. Casi nula, como pidio el usuario.
        private const float ProdigyChance = 0.02f;

        /// La mitad de poder de cada padre que hereda un hibrido, guardada en su ficha y sumada a
        /// sus estadisticas en PowerScaling. Se guarda el numero y no un rasgo fijo porque cada
        /// hibrido hereda una cantidad distinta — la de SUS padres.
        public const string KeyHybStr = "sds_hyb_str";
        public const string KeyHybSpi = "sds_hyb_spi";
        public const string KeyHybMag = "sds_hyb_mag";

        /// Las formas heredadas de padres Pecado (solo hijos NO hibridos), hasta dos.
        private const string KeyForm1 = "sds_inherit_form1";
        private const string KeyForm2 = "sds_inherit_form2";

        /// Un hibrido tiene su propia forma, que se gana con kills. KeyHybFormPending dice que la
        /// tiene pendiente; KeyHybFormId guarda CUAL — la forma con nombre de su tipo de hibrido.
        /// Publicas para que el Purgatorio las conserve al cruzar una unidad (ver Purgatory).
        public const string KeyHybFormPending = "sds_hyb_form_pending";
        public const string KeyHybFormId = "sds_hyb_form_id";
        public const string KeyHybClan = "sds_hyb_clan";      // id del clan hibrido, para sus formas
        public const string KeyHybStage = "sds_hyb_stage";    // ultima etapa de forma despertada

        /// Kills de cada una de las TRES transformaciones de un hibrido. Se ganan, no se regalan —
        /// pero alcanzables: si costaran cientos de kills nadie las veria nunca.
        private const int HybridFormKills = 15;    // fase 1: forma con nombre + habilidades
        private const int HybStage2Kills = 50;     // fase 2: mas fuerte
        private const int HybStage3Kills = 120;    // fase 3: forma verdadera

        /// Cuanto del poder de un padre pasa al hijo, ANTES de escalar por prodigio. Un padre puro
        /// pasa 0.6; uno que ya es hibrido, 0.3 — la sangre se diluye con cada generacion.
        private static float BaseRate(Actor parent)
        {
            return (parent != null && parent.hasTrait(TraitHybrid)) ? 0.3f : 0.6f;
        }

        /// El factor final: un hijo normal solo se queda con poco mas de la mitad de lo que heredaria
        /// (0.55), asi que arranca MUY por debajo de sus padres y, aun con muchas kills, casi nunca
        /// los alcanza. Un prodigio se queda con todo (1.0) y, con esfuerzo, puede superarlos.
        private static float ChildScale(bool prodigy)
        {
            return prodigy ? 1.0f : 0.55f;
        }

        public static void Init()
        {
            Scion();
            Hybrid();
            Prodigy();
            Main.harmony.PatchAll(typeof(BirthPatch));
            Main.harmony.PatchAll(typeof(CrossRacePatch));
            SDSTick.Register(TickBreeding);
            SDSTick.Register(TickForms);
        }

        /// Concede las formas, cada una a su manera:
        ///   - Hijo de Pecado NO hibrido: la forma del pecado del padre, de adulto y fuerte.
        ///   - Hibrido: su forma PROPIA, que se gana con kills (no la de ningun padre).
        private static void TickForms(Actor a, float dt)
        {
            if (a == null || !a.isAlive() || a.data == null) return;

            bool hasInherited = !string.IsNullOrEmpty(SDSData.GetString(a, KeyForm1, ""));
            bool hybFormPending = SDSData.GetBool(a, KeyHybFormPending);
            if (!hasInherited && !hybFormPending) return;   // nada que conceder: fuera

            // Barato: solo de vez en cuando, no cada barrido.
            if (!SDSData.TryUse(a, "inherit_form", 5f)) return;
            if (!a.isAdult()) return;

            // La forma PROPIA del hibrido, a golpe de kills. Es lo que pediste: no la de sus padres,
            // y ganada peleando.
            if (hybFormPending)
            {
                int kills = 0;
                try { kills = a.data.kills; } catch { }

                string hclan = SDSData.GetString(a, KeyHybClan, "");
                if (string.IsNullOrEmpty(hclan)) return;

                int stage = SDSData.GetInt(a, KeyHybStage, 0);

                // TRES transformaciones, cada una a mas kills. La primera trae su forma con nombre y
                // las HABILIDADES de sus dos razas; las otras dos son mas fuertes y apilan.
                int want = kills >= HybStage3Kills ? 3
                         : kills >= HybStage2Kills ? 2
                         : kills >= HybridFormKills ? 1 : 0;

                for (int s = stage + 1; s <= want; s++)
                {
                    HybridForms.Awaken(a, hclan, s);
                    SDSData.SetInt(a, KeyHybStage, s);
                    SDSLog.Chronicle(SDSLocale.T(
                        a.getName() + " ha despertado su forma hibrida (fase " + s + ").",
                        a.getName() + " has awakened their hybrid form (stage " + s + ")."));
                }
                return;     // un hibrido no lleva formas heredadas: aqui acaba
            }

            // Hijo de Pecado no hibrido: la forma del padre, cuando su poder esta a la altura.
            if (PowerLevel.Get(a) < 1500f) return;
            GrantForm(a, SDSData.GetString(a, KeyForm1, ""));
            string f2 = SDSData.GetString(a, KeyForm2, "");
            if (!string.IsNullOrEmpty(f2)) GrantForm(a, f2);
        }

        private static void GrantForm(Actor a, string form)
        {
            if (string.IsNullOrEmpty(form) || a.hasStatus(form)) return;
            if (!SDSStatus.Inflict(a, form, 9999f)) return;
            SDSFx.At(a, "sds_fx_demon_king", 0.7f);
        }

        /// EL EMBARAZO ENTRE RAZAS, que es lo que faltaba.
        ///
        /// El usuario lo vio exacto: las unidades se enamoran "pero hasta ahi". El amor lo abre mi
        /// parche de canFallInLoveWith, pero el paso siguiente — quedarse embarazada — lo maneja una
        /// tarea de IA definida en DATOS del juego, no en codigo, y esa sigue bloqueando entre
        /// especies distintas. No hay forma limpia de parchear una tarea que no esta en el ensamblado.
        ///
        /// Asi que se hace por el otro lado: para una pareja de razas DISTINTAS, se aplica el
        /// embarazo a mano. `makeBabyFromPregnancy` usa `pActor.lover` como el otro padre y NO mira
        /// especie, asi que la tuberia normal (gestacion -> parto -> mi BirthPatch) hace el resto y
        /// sale un hibrido. Solo toca a parejas mixtas: las de la misma raza las lleva el juego.
        private static int _loggedPreg;
        private static int _diagBirth;   // diagnostico temporal de nacimientos

        private static void TickBreeding(Actor a, float dt)
        {
            if (!SDSConfig.CrossRaceBreeding) return;
            if (a == null || !a.isAlive() || a.data == null) return;

            // La hembra vivipara es la que lleva el embarazo. Una lectura de sexo antes de nada.
            if (!a.isSexFemale()) return;
            if (!a.hasLover()) return;

            Actor lover = a.lover;
            if (lover == null || !lover.isAlive()) return;

            // Cruce de verdad: dos razas del mod distintas. RaceKeyOf (no ClanOf) para que un padre
            // hibrido — sin clan base — cuente por su sangre y pueda engendrar la siguiente generacion.
            string ca = SDSUnit.RaceKeyOf(a);
            string cl = SDSUnit.RaceKeyOf(lover);
            if (ca == null || cl == null || ca == cl) return;

            // Ritmo lento a proposito: un intento cada rato, con poca probabilidad. El cruce entre
            // razas es raro en la serie, no una cadena de montaje.
            if (!SDSData.TryUse(a, "cross_breed", 15f)) return;
            if (!Randy.randomChance(0.15f)) return;

            try
            {
                if (a.hasStatus("pregnant")) return;

                // No se exige "sitio privado" (pide una casa; dos razas sueltas en el campo no la
                // tienen). Pero SI todos los limites de poblacion del juego — sin ellos el cruce
                // reventaba en sobrepoblacion. `canMakeBabies` mira el limite de hijos y la comida;
                // `isMetaLimitsReached` mira el tope de poblacion del mundo y las leyes.
                if (!a.isBreedingAge()) return;
                if (a.hasStatus("afterglow")) return;
                if (!BabyHelper.canMakeBabies(a)) return;
                if (BabyHelper.isMetaLimitsReached(a)) return;

                a.addStatusEffect("pregnant", a.getMaturationTimeSeconds());

                if (_loggedPreg < 8)
                {
                    _loggedPreg++;
                    SDSLog.Info("embarazo entre razas aplicado: " + ca + " x " + cl);
                }
            }
            catch (System.Exception e)
            {
                if (_loggedPreg < 8) { _loggedPreg++; SDSLog.Error("embarazo cruce fallo: " + e.Message); }
            }
        }

        private static void Hybrid()
        {
            if (AssetManager.traits.dict.ContainsKey(TraitHybrid)) return;

            ActorTrait t = SDSRegistry.Trait(TraitHybrid, TraitGroups.Bloodline, "ui/icons/" + TraitHybrid);
            t.type = TraitType.Positive;

            // El rasgo en si es modesto: la fuerza de un hibrido viene del 50% que hereda de cada
            // padre (KeyHyb*), no de este bloque. Aqui solo va lo que lo hace mas que un mestizo
            // cualquiera: aguanta mas y vive mas, como los Jinetes del Apocalipsis.
            PowerLevel.Grant(t, 40f, 40f, 40f);
            t.base_stats["health"] = 80f;
            t.base_stats["multiplier_lifespan"] = 3f;

            SDSRegistry.AddTrait(t);
            SDSLocale.Trait(TraitHybrid, "Hibrido",
                "Nacido del cruce de dos razas. Lleva la sangre y los poderes de las dos.");
        }

        private static void Prodigy()
        {
            if (AssetManager.traits.dict.ContainsKey(TraitProdigy)) return;

            ActorTrait t = SDSRegistry.Trait(TraitProdigy, TraitGroups.Bloodline, "ui/icons/" + TraitProdigy);
            t.type = TraitType.Positive;

            // El rasgo en si es modesto: lo que hace grande a un prodigio es que hereda el poder de
            // sus padres CASI ENTERO (ver ChildScale), no este bloque. Aqui solo va el brillo que lo
            // separa de sus hermanos: crece un poco mas rapido y vive mas.
            PowerLevel.Grant(t, 60f, 60f, 60f);
            t.base_stats["health"] = 120f;
            t.base_stats["multiplier_lifespan"] = 4f;

            SDSRegistry.AddTrait(t);
            SDSLocale.Trait(TraitProdigy, "Prodigio",
                "Uno entre mil. Nacio con el don raro de poder superar a sus padres — si logra "
                + "sobrevivir lo bastante como para intentarlo.");
            SDSLocale.TraitLore(TraitProdigy, "Sale al nacer, con probabilidad casi nula (2%). Solo "
                + "un prodigio hereda bastante poder como para superar a sus padres. Los Jinetes "
                + "canonicos (Tristan, Lancelot) lo son siempre.");
        }

        /// Deja que dos razas distintas se enamoren, si la config lo permite.
        ///
        /// El juego bloquea el amor entre especies distintas en `canFallInLoveWith` con un
        /// `isSameSpecies`. Un postfix que solo diga "true" saltaria TODAS las demas condiciones —
        /// dejaria emparejarse a un nino, a un pariente, a alguien que ya tiene pareja. Asi que
        /// cuando el original dice que no, se vuelven a comprobar a mano todas las razones MENOS la
        /// de la especie. Si la unica pega era que son de razas distintas, se permite; si habia
        /// cualquier otra, se respeta.
        ///
        /// Solo entre unidades del mod: no se toca el emparejamiento de las criaturas del juego base.
        [HarmonyPatch(typeof(Actor), nameof(Actor.canFallInLoveWith))]
        internal static class CrossRacePatch
        {
            private static int _loggedCross;

            [HarmonyPostfix]
            public static void Postfix(Actor __instance, Actor pTarget, ref bool __result)
            {
                if (__result) return;                       // ya se permitia: nada que hacer
                if (!SDSConfig.CrossRaceBreeding) return;

                Actor a = __instance;
                if (a == null || pTarget == null || a == pTarget) return;

                // Ambos tienen que ser de un pueblo del mod (RaceKeyOf incluye a los hibridos, que ya
                // no llevan clan base pero si sangre). Si no, es cosa del juego base.
                if (SDSUnit.RaceKeyOf(a) == null || SDSUnit.RaceKeyOf(pTarget) == null) return;

                try
                {
                    // La MISMA lista de condiciones del original, sin la de especie.
                    if (a.hasLover() || pTarget.hasLover()) return;
                    if (!a.isAdult() || !pTarget.isAdult()) return;
                    if (!a.isBreedingAge() || !pTarget.isBreedingAge()) return;
                    if (a.subspecies == null || !a.subspecies.needs_mate) return;
                    if (pTarget.subspecies == null || !pTarget.subspecies.needs_mate) return;
                    if (a.isRelatedTo(pTarget)) return;

                    // Todo lo demas encaja: lo unico que sobraba era que fueran de razas distintas.
                    __result = true;

                    // Diagnostico acotado: confirma que el cruce se esta permitiendo de verdad, sin
                    // llenar el log. Se apaga solo tras unas cuantas veces.
                    if (_loggedCross < 8)
                    {
                        _loggedCross++;
                        SDSLog.Info("cruce permitido: " + SDSUnit.ClanOf(a) + " + " + SDSUnit.ClanOf(pTarget));
                    }
                }
                catch { }
            }
        }

        private static void Scion()
        {
            if (AssetManager.traits.dict.ContainsKey(TraitScion)) return;

            ActorTrait t = SDSRegistry.Trait(TraitScion, TraitGroups.Bloodline, "ui/icons/" + TraitScion);
            t.type = TraitType.Positive;

            // Un descendiente de los Pecados nace por encima de la media, pero MUY por debajo de sus
            // padres: la herencia es una ventaja de salida, no un atajo al poder de Meliodas.
            PowerLevel.Grant(t, 120f, 90f, 90f);
            t.base_stats["health"] = 60f;
            t.base_stats["multiplier_lifespan"] = 2f;

            SDSRegistry.AddTrait(t);
            SDSLocale.Trait(TraitScion, "Heredero de un Pecado",
                "Por sus venas corre la sangre de los Siete Pecados Capitales.");
        }

        /// clan de un padre -> el rasgo de sangre que le pasa al hijo.
        private static string BloodOf(Actor parent)
        {
            if (parent == null) return null;
            if (parent.hasTrait(Clans.Demon)) return SevenDeadlySins.Traits.DemonBlood;
            if (parent.hasTrait(Clans.Goddess)) return SevenDeadlySins.Traits.GoddessBlood;
            if (parent.hasTrait(Clans.Fairy)) return SevenDeadlySins.Traits.FairyWings;
            if (parent.hasTrait(Clans.Giant)) return SevenDeadlySins.Traits.GiantStrength;
            if (parent.hasTrait(Clans.Vampire)) return SevenDeadlySins.Traits.VampireThirst;
            return null;
        }

        /// Reune TODAS las sangres que un padre transmite: la de su clan base (si es puro) MAS las que
        /// ya lleva encima (si es un hibrido de una generacion anterior). Asi la herencia no se pierde
        /// al cruzar hibridos — es lo que permite que la 3a generacion (Caballeros del Grial) siga
        /// llevando el linaje entero de los Pecados.
        private static void CollectBloods(Actor parent, System.Collections.Generic.HashSet<string> into)
        {
            if (parent == null || into == null) return;
            string fromClan = BloodOf(parent);
            if (fromClan != null) into.Add(fromClan);
            if (parent.hasTrait(SevenDeadlySins.Traits.DemonBlood)) into.Add(SevenDeadlySins.Traits.DemonBlood);
            if (parent.hasTrait(SevenDeadlySins.Traits.GoddessBlood)) into.Add(SevenDeadlySins.Traits.GoddessBlood);
            if (parent.hasTrait(SevenDeadlySins.Traits.FairyWings)) into.Add(SevenDeadlySins.Traits.FairyWings);
            if (parent.hasTrait(SevenDeadlySins.Traits.GiantStrength)) into.Add(SevenDeadlySins.Traits.GiantStrength);
            if (parent.hasTrait(SevenDeadlySins.Traits.VampireThirst)) into.Add(SevenDeadlySins.Traits.VampireThirst);
        }

        /// Reune las CLAVES DE RAZA que representa un padre: su clan base (si es puro) MAS la raza de
        /// cada sangre que lleva. Con esto se detecta el hibridismo por el conjunto real de razas del
        /// hijo, no por una sola raza representativa (que colapsaba con padres ya hibridos).
        /// Diagnostico temporal: describe que aporta un padre (clan base, sangres, si es Pecado).
        private static string Describe(Actor a)
        {
            if (a == null) return "null";
            string c = SDSUnit.ClanOf(a);
            string b = "";
            if (a.hasTrait(SevenDeadlySins.Traits.DemonBlood)) b += "D";
            if (a.hasTrait(SevenDeadlySins.Traits.GoddessBlood)) b += "G";
            if (a.hasTrait(SevenDeadlySins.Traits.FairyWings)) b += "F";
            if (a.hasTrait(SevenDeadlySins.Traits.GiantStrength)) b += "Gi";
            if (a.hasTrait(SevenDeadlySins.Traits.VampireThirst)) b += "V";
            string sin = SDSUnit.SinOf(a);
            string nm;
            try { nm = a.getName(); } catch { nm = "?"; }
            return nm + "(clan=" + (c ?? "-") + ",sangre=" + (b == "" ? "-" : b) + ",pecado=" + (sin != null ? "si" : "-") + ")";
        }

        private static void CollectRaces(Actor parent, System.Collections.Generic.HashSet<string> into)
        {
            if (parent == null || into == null) return;
            string c = SDSUnit.ClanOf(parent);
            if (c == Clans.Human) into.Add("human");
            else if (c == Clans.Demon) into.Add("demon");
            else if (c == Clans.Goddess) into.Add("goddess");
            else if (c == Clans.Fairy) into.Add("fairy");
            else if (c == Clans.Giant) into.Add("giant");
            else if (c == Clans.Vampire) into.Add("vampire");
            if (parent.hasTrait(SevenDeadlySins.Traits.DemonBlood)) into.Add("demon");
            if (parent.hasTrait(SevenDeadlySins.Traits.GoddessBlood)) into.Add("goddess");
            if (parent.hasTrait(SevenDeadlySins.Traits.FairyWings)) into.Add("fairy");
            if (parent.hasTrait(SevenDeadlySins.Traits.GiantStrength)) into.Add("giant");
            if (parent.hasTrait(SevenDeadlySins.Traits.VampireThirst)) into.Add("vampire");
        }

        /// EL PARCHE VA EN makeBaby, NO EN createBabyActorFromData, y esto es LA correccion.
        ///
        /// `makeBaby` hace: crea el bebe con createBabyActorFromData, y SOLO DESPUES le asigna los
        /// padres con setParent1/setParent2. Mi parche estaba en createBabyActorFromData, asi que
        /// corria ANTES de que el bebe tuviera padres — `parent_id_1/2` valian -1 y no heredaba
        /// nada. Por eso "no eredan nada". Aqui los padres llegan como argumentos, ya completos.
        [HarmonyPatch(typeof(BabyMaker), nameof(BabyMaker.makeBaby))]
        internal static class BirthPatch
        {
            [HarmonyPostfix]
            public static void Postfix(Actor __result, Actor pParent1, Actor pParent2)
            {
                Actor baby = __result;
                if (baby == null || baby.data == null) return;

                try
                {
                    Actor p1 = pParent1 != null && pParent1.data != null ? pParent1 : null;
                    Actor p2 = pParent2 != null && pParent2.data != null ? pParent2 : null;
                    if (p1 == null && p2 == null) return;

                    // Que al menos uno de los padres sea del mod. RaceKeyOf (no ClanOf) para que un
                    // padre HIBRIDO cuente: no tiene clan base, pero si sangre. Sin esto, dos hibridos
                    // cruzandose salian por aqui sin heredar NADA (y el hijo quedaba sin identidad).
                    bool anyMod = (p1 != null && SDSUnit.RaceKeyOf(p1) != null)
                               || (p2 != null && SDSUnit.RaceKeyOf(p2) != null);
                    if (!anyMod) return;

                    // LA SANGRE ES LA UNION de las dos herencias, sin exclusividad. Esto ES la herencia
                    // canonica — Tristan lleva sangre de demonio Y de diosa a la vez. Y CRUCIAL para la
                    // tercera generacion (los Caballeros del Grial): un padre que YA es hibrido propaga
                    // TODAS sus sangres, no solo la de su clan, asi que el nieto de los Pecados hereda
                    // el linaje entero (el hijo de Tristan y una humana sigue llevando demonio+diosa).
                    var bloods = new System.Collections.Generic.HashSet<string>();
                    CollectBloods(p1, bloods);
                    CollectBloods(p2, bloods);
                    foreach (string bl in bloods) SDSTraits.Give(baby, bl);

                    // LA MAGIA NO SE HEREDA EN BLOQUE. En la serie un hijo desarrolla su PROPIA magia;
                    // no sale con el repertorio entero de sus dos padres. Antes se copiaban TODAS las
                    // habilidades de firma de ambos, y eso no es canon. Ahora, a lo sumo, hereda UNA
                    // sola tecnica de un padre, y con poca probabilidad. Su poder de SANGRE (llama de
                    // demonio, luz de diosa, alas de hada...) le llega por su clan y su forma hibrida,
                    // no por copiar la habilidad personal de nadie. (Se aplica AL FINAL, y SOLO si el
                    // hijo no recibe una firma propia — ver mas abajo.)

                    // ¿HIJO CANONICO? Meliodas x Elizabeth = Tristan; Ban x Elaine = Lancelot. Los
                    // hijos reales de la serie, con su nombre y su magia propia.
                    string canon = CanonChild(p1, p2);

                    // SUPERAR A UN PADRE ES CASI IMPOSIBLE, a proposito. Un hijo normal hereda poco
                    // (ChildScale 0.55) y se queda por debajo de sus padres de por vida, por muchas
                    // kills que junte. Solo un PRODIGIO — que sale con probabilidad casi nula — hereda
                    // el poder casi entero y PUEDE superarlos, y aun asi le cuesta. Los Jinetes
                    // canonicos son prodigios siempre: la profecia dice que superan a sus padres.
                    bool prodigy = canon != null || Randy.randomChance(ProdigyChance);
                    float scale = ChildScale(prodigy);

                    // PODER HEREDADO, escalado. El decaimiento por generacion (BaseRate) y el factor de
                    // prodigio (scale) juntos son lo que hace que un hijo normal casi nunca alcance a
                    // sus padres, mientras un prodigio si puede con esfuerzo.
                    SDSData.SetFloat(baby, KeyHybStr, scale * (BaseRate(p1) * PowerLevel.Strength(p1) + BaseRate(p2) * PowerLevel.Strength(p2)));
                    SDSData.SetFloat(baby, KeyHybSpi, scale * (BaseRate(p1) * PowerLevel.Spirit(p1) + BaseRate(p2) * PowerLevel.Spirit(p2)));
                    SDSData.SetFloat(baby, KeyHybMag, scale * (BaseRate(p1) * PowerLevel.Magic(p1) + BaseRate(p2) * PowerLevel.Magic(p2)));

                    // HIBRIDO: se mira el CONJUNTO de razas del hijo — el clan base MAS todas las
                    // sangres de sus dos padres. Es hibrido si ese conjunto tiene 2+ razas distintas.
                    // Antes se comparaba UNA sola raza representativa (RaceKeyOf) por padre, y eso fallaba
                    // con padres hibridos: dos medio-demonios distintos daban "demon"=="demon" -> se
                    // trataba al hijo como NO hibrido y conservaba un clan base pese a su sangre mezclada.
                    // Ese era el bug de "clanes hibridos como no hibridos".
                    var races = new System.Collections.Generic.HashSet<string>();
                    CollectRaces(p1, races);
                    CollectRaces(p2, races);
                    bool hybrid = races.Count >= 2;

                    // Las DOS razas representativas para su clan hibrido: las de mayor prioridad tematica
                    // presentes (demonio/diosa por delante — un demonio-diosa-hada es "Crepusculo").
                    string ra = null, rb = null;
                    string[] prio = { "demon", "goddess", "fairy", "giant", "vampire", "human" };
                    for (int pi = 0; pi < prio.Length; pi++)
                    {
                        if (!races.Contains(prio[pi])) continue;
                        if (ra == null) ra = prio[pi];
                        else { rb = prio[pi]; break; }
                    }

                    // ¿HIJO DE DOS PECADOS? Si lo es, NO hereda NINGUNA forma de sus padres ni la
                    // hibrida generica: su unica transformacion es la SUYA de legado (SinLegacy). El
                    // usuario lo pidio claro — un hijo de dos Pecados no lleva la forma de nadie mas.
                    bool legacy = SinLegacy.IsPair(p1, p2);

                    if (hybrid)
                    {
                        SDSTraits.Give(baby, TraitHybrid);

                        // UN HIBRIDO NO TIENE CLAN. Se supone que es su propia mezcla, no "un demonio
                        // con algo" — el usuario lo pidio y es el canon. Se le marca el clan como
                        // asignado (para que Clans.Assign NO le ponga uno por raza) y se le quita
                        // cualquier clan base que arrastrase. Su identidad es el clan HIBRIDO, no uno de
                        // los seis.
                        SDSData.SetBool(baby, SDSData.ClanAssigned, true);
                        for (int ci = 0; ci < Clans.All.Length; ci++) SDSTraits.Remove(baby, Clans.All[ci]);

                        // Su CLAN HIBRIDO propio (identidad, no uno de los seis clanes base).
                        string hclan = HybridClans.ForKeys(ra, rb);
                        if (hclan != null)
                        {
                            SDSTraits.Give(baby, hclan);
                            SDSData.SetString(baby, KeyHybClan, hclan);   // para conceder sus formas
                        }

                        if (!legacy)
                        {
                            // Un hibrido normal NO hereda las formas de sus padres — tiene la SUYA
                            // propia con NOMBRE segun sus dos razas (Crepusculo, Titan Oscuro...) y tres
                            // fases. TickForms la concede cuando se la gana.
                            SDSData.SetBool(baby, KeyHybFormPending, true);
                            string formId = hclan != null ? HybridForms.FormForHybridClan(hclan) : null;
                            if (formId != null) SDSData.SetString(baby, KeyHybFormId, formId);
                        }
                    }
                    else if (!legacy)
                    {
                        // NO hibrido y NO hijo de dos Pecados: si un padre es un Pecado, hereda su forma
                        // (la del pecado de su sangre), concedida de adulto y fuerte.
                        InheritSinForm(baby, p1);
                        InheritSinForm(baby, p2);
                    }

                    bool sinBlood = (p1 != null && SDSUnit.IsSin(p1)) || (p2 != null && SDSUnit.IsSin(p2));
                    if (sinBlood) SDSTraits.Give(baby, TraitScion);

                    if (prodigy) SDSTraits.Give(baby, TraitProdigy);

                    // LA FIRMA UNICA DEL HIJO, por prioridad (SOLO UNA — la mas especifica gana). Esto
                    // es el arbol de herencia entero, de la 1a a la 3a generacion:
                    //   1) Caballero del Grial: hijo de un Jinete del Apocalipsis (3a gen — nietos de los
                    //      Pecados; en el canon los trae Cath Palug del futuro).
                    //   2) Jinete canonico de 2a gen: Tristan (Meliodas x Elizabeth), Lancelot (Ban x Elaine).
                    //   3) Hijo de DOS Pecados: SinLegacy (21 pares).
                    //   4) MEDIO-Pecado: un solo padre Pecado y el otro no (HalfSinLegacy) — lo que pidio
                    //      el usuario: "no solo los hijos puros de pecados, tambien los mitad si mitad no".
                    //   5) Hibrido de raza: dos razas distintas sin Pecado (HybridLegacy).
                    string firma = "ninguna";
                    bool signed = GrailKnights.TryApply(baby, p1, p2);
                    if (signed) firma = "grial";
                    if (!signed && canon != null) { DressCanonChild(baby, canon); signed = true; firma = "canon:" + canon; }
                    if (!signed && SinLegacy.TryApply(baby, p1, p2)) { signed = true; firma = "dos-pecados"; }
                    if (!signed && HalfSinLegacy.TryApply(baby, p1, p2)) { signed = true; firma = "medio-pecado"; }
                    if (!signed && hybrid && HybridLegacy.TryApply(baby, SDSData.GetString(baby, KeyHybClan, ""))) { signed = true; firma = "hibrido"; }

                    // SOLO un hijo SIN firma propia hereda, a lo sumo, UNA tecnica suelta de un padre.
                    // Antes corria SIEMPRE y se apilaba encima de la firma del hijo -> "habilidades
                    // equivocadas" (un Crepusculo con, ademas, el Full Counter de su abuelo).
                    if (!signed) InheritSomeAbility(baby, p1, p2);

                    // DIAGNOSTICO TEMPORAL: como se resolvio cada nacimiento del mod (primeras veces).
                    if (_diagBirth < 30)
                    {
                        _diagBirth++;
                        string rr = "";
                        foreach (string k in races) rr += k + ",";
                        SDSLog.Info("nacimiento: " + baby.getName()
                            + " | p1=" + Describe(p1) + " p2=" + Describe(p2)
                            + " | razas=[" + rr + "] hibrido=" + hybrid
                            + " hclan=" + SDSData.GetString(baby, KeyHybClan, "-") + " firma=" + firma);
                    }

                    // EL HIJO PELEA DEL LADO DE SUS PADRES. Comun a TODOS los hijos del mod (hibrido de
                    // raza, hijo de dos Pecados, Jinete canonico): que comparta el reino/ciudad de un
                    // padre. Sin esto un bebe cae en el reino SALVAJE de su (sub)especie, distinto al de
                    // sus aliados, y sus curas — que buscaban "o.kingdom == a.kingdom" — no encontraban a
                    // NADIE y fallaban en silencio. Es la causa raiz de "la llama que cura no cura". Si
                    // los padres son sueltos sin reino (invocados a mano), esto no hace nada — pero
                    // entonces SDSUnit.IsAlly reconoce al aliado por PARENTESCO, que nunca falla.
                    try
                    {
                        Actor kin = (p1 != null && p1.kingdom != null) ? p1
                                  : (p2 != null && p2.kingdom != null) ? p2 : null;
                        if (kin != null && baby.kingdom != kin.kingdom)
                        {
                            if (kin.city != null) baby.joinCity(kin.city);
                            else baby.setKingdom(kin.kingdom);
                        }
                    }
                    catch { }

                    // NADA de carteles por cada nacimiento normal (el jugador no los quiere). La unica
                    // excepcion es un Jinete canonico: eso SI se anuncia, en DressCanonChild.
                }
                catch { }
            }
        }

        /// Copia las habilidades de FIRMA del padre, no su magia de clase.
        ///
        /// Un hijo aprende a pelear como su padre — el Full Counter de Meliodas, el Rayo de
        /// Gilthunder, la luz de una diosa. Lo que NO hereda es la magia de clase (Piel de Hierro,
        /// Chispa...) ni la clase en si (Reforzador, Hechicero): eso no es sangre, es oficio, y se
        /// aprende con una profesion. Por eso se excluye ClassAbilities.All.
        /// Probabilidad de que un hijo herede UNA tecnica de un padre. La mayoria NO hereda ninguna —
        /// desarrollan la suya, como en la serie.
        private const float InheritAbilityChance = 0.25f;

        /// Hereda COMO MUCHO una habilidad de firma, del conjunto de los dos padres, y solo a veces.
        /// Ni todas, ni una por padre: una, al azar, con poca probabilidad. Nunca la magia de CLASE
        /// (eso es oficio, se aprende con una profesion).
        private static void InheritSomeAbility(Actor baby, Actor p1, Actor p2)
        {
            if (baby == null) return;
            if (!Randy.randomChance(InheritAbilityChance)) return;
            try
            {
                var pool = new System.Collections.Generic.List<string>();
                AddSignatureAbilities(pool, p1);
                AddSignatureAbilities(pool, p2);
                if (pool.Count == 0) return;

                string one = pool.GetRandom();
                if (!string.IsNullOrEmpty(one))
                {
                    SDSTraits.Give(baby, one);
                    // CLAVE: sin esto el hijo tiene el rasgo pero el comportamiento no corre (gateado
                    // en IsNamed). Lo marcamos como usuario de habilidad para que SI funcione.
                    SDSUnit.MarkAbilityUser(baby);
                }
            }
            catch { }
        }

        private static void AddSignatureAbilities(System.Collections.Generic.List<string> pool, Actor parent)
        {
            if (pool == null || parent == null) return;
            var ids = SDSRegistry.TraitIds;
            for (int i = 0; i < ids.Count; i++)
            {
                string id = ids[i];
                if (id == null || !id.StartsWith("sds_ability_")) continue;
                if (System.Array.IndexOf(ClassAbilities.All, id) >= 0) continue;   // magia de clase: NO
                if (parent.hasTrait(id) && !pool.Contains(id)) pool.Add(id);
            }
        }

        /// Si el padre es un Pecado, apunta en la ficha del hijo la FORMA de ese pecado. La forma se
        /// concede cuando el hijo crece y es fuerte, no de bebe — ver TickForms.
        private static void InheritSinForm(Actor baby, Actor parent)
        {
            if (baby == null || parent == null) return;
            try
            {
                string sin = SDSUnit.SinOf(parent);
                if (sin == null) return;
                string form = SinForms.FormOf(sin);
                if (form == null) return;

                // Se guardan hasta dos formas (una por padre Pecado). Un hijo de dos Pecados —
                // improbable pero posible — puede acabar con las dos.
                if (string.IsNullOrEmpty(SDSData.GetString(baby, KeyForm1, "")))
                    SDSData.SetString(baby, KeyForm1, form);
                else
                    SDSData.SetString(baby, KeyForm2, form);
            }
            catch { }
        }

        // ---------------------------------------------------------------- hijos canonicos

        /// El hijo real de esta pareja en la serie, o null. Meliodas (Ira) + Elizabeth = Tristan;
        /// Ban (Avaricia) + Elaine = Lancelot. Se mira en los dos ordenes de padre.
        private static string CanonChild(Actor p1, Actor p2)
        {
            if ((IsMeliodas(p1) && IsElizabeth(p2)) || (IsMeliodas(p2) && IsElizabeth(p1))) return "Tristan";
            if ((IsBan(p1) && IsElaine(p2)) || (IsBan(p2) && IsElaine(p1))) return "Lancelot";
            return null;
        }

        // Meliodas y Ban se reconocen por su Pecado, que es un titulo unico que solo lleva su leyenda
        // (los hijos heredan la HABILIDAD, no el rasgo de Pecado). Elizabeth y Elaine, por su nombre.
        private static bool IsMeliodas(Actor a) { return a != null && a.hasTrait(SevenSins.Wrath); }
        private static bool IsBan(Actor a) { return a != null && a.hasTrait(SevenSins.Greed); }
        private static bool IsElizabeth(Actor a) { return NameIs(a, "Elizabeth"); }
        private static bool IsElaine(Actor a) { return NameIs(a, "Elaine"); }

        private static bool NameIs(Actor a, string name)
        {
            if (a == null) return false;
            try { return a.getName() == name; }
            catch { return false; }
        }

        /// Viste al bebe como el Jinete que le toca: su nombre, su magia de la secuela y la marca de
        /// unidad con NOMBRE (sin ella su habilidad de firma no correria — ver LegendMagic).
        private static void DressCanonChild(Actor baby, string who)
        {
            if (baby == null) return;
            try
            {
                SDSData.SetBool(baby, SDSData.Named, true);

                if (who == "Tristan")
                {
                    baby.setName("Tristan");
                    SDSTraits.Give(baby, LegendMagic.Compassion);
                    SDSTraits.Give(baby, Abilities.Ark);
                    SDSTraits.Give(baby, SevenDeadlySins.Traits.DemonBlood);
                    SDSTraits.Give(baby, SevenDeadlySins.Traits.GoddessBlood);
                }
                else if (who == "Lancelot")
                {
                    baby.setName("Lancelot");
                    SDSTraits.Give(baby, LegendMagic.Perception);
                    SDSTraits.Give(baby, SevenDeadlySins.Traits.FairyWings);
                }

                SDSFx.At(baby, "sds_fx_sunshine", 0.8f);
                SDSLog.Chronicle(SDSLocale.T(
                    "Ha nacido " + baby.getName() + ", uno de los Cuatro Jinetes del Apocalipsis.",
                    baby.getName() + " is born — one of the Four Knights of the Apocalypse."));
            }
            catch { }
        }

        private static Actor Parent(long id)
        {
            if (id <= 0L) return null;
            try
            {
                Actor a = World.world.units.get(id);
                return a != null && a.data != null ? a : null;
            }
            catch { return null; }
        }
    }
}
