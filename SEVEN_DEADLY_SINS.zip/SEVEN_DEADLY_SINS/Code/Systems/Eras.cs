using UnityEngine;

namespace SevenDeadlySins
{
    /// The ages of Britannia, registered into the GAME'S OWN era wheel.
    ///
    /// These used to be buttons on a mod tab that the player had to press. That was wrong twice
    /// over: it put a world-scale event behind a click, and it duplicated a system the game already
    /// has and does better. WorldBox rotates through its ages on its own — Age of Darkness, Age of
    /// the Sun — and now Britannia's three sit in that rotation and arrive on their own.
    ///
    /// The API is AssetManager.era_library.add(WorldAgeAsset), taken from a mod on this machine that
    /// registers an age and works. Every field here exists on that asset; nothing is guessed.
    public static class Eras
    {
        public const string HolyWarAge = "sds_age_holy_war";
        public const string SevenSinsAge = "sds_age_seven_sins";
        public const string CommandmentsAge = "sds_age_commandments";

        public static void Init()
        {
            // --- La Antigua Guerra Santa -----------------------------------------
            // Hace tres mil anos. El cielo se oscurece y la tierra deja de dar.
            Age(HolyWarAge, "La Antigua Guerra Santa", "The Ancient Holy War",
                "#C0392B", rate: 2, darkness: true, alpha: 0.45f, growth: -2, clouds: 1.2f);

            // --- La Era de los Siete Pecados --------------------------------------
            // La epoca luminosa: Liones en pie y siete criminales sueltos.
            Age(SevenSinsAge, "La Era de los Siete Pecados", "The Age of the Seven Deadly Sins",
                "#2ECC71", rate: 3, darkness: false, alpha: 0f, growth: 2, clouds: 3f);

            // --- El Regreso de los Diez Mandamientos ------------------------------
            // Se rompe el sello. Oscuridad otra vez, y con leyes.
            Age(CommandmentsAge, "El Regreso de los Diez Mandamientos", "The Return of the Ten Commandments",
                "#8E44AD", rate: 2, darkness: true, alpha: 0.5f, growth: -1, clouds: 1f);
        }

        private static void Age(string id, string nameEs, string nameEn, string colorHex,
                                int rate, bool darkness, float alpha, int growth, float clouds)
        {
            try
            {
                if (AssetManager.era_library.get(id) != null) return;

                WorldAgeAsset age = new WorldAgeAsset();
                age.id = id;
                age.path_icon = "otherAssets/iconAge_" + id;
                age.path_background = "otherAssets/" + id + "_background";
                age.title_color = Toolbox.makeColor(colorHex);

                // How often the wheel lands on this age relative to the others. Kept comparable to
                // the vanilla ages so Britannia does not take over the rotation.
                age.rate = rate;

                age.overlay_darkness = darkness;
                age.era_effect_overlay_alpha = alpha;
                age.bonus_biomes_growth = growth;
                age.cloud_interval = clouds;

                AssetManager.era_library.add(age);

                // The wheel reads the id as a localisation key.
                SDSLocale.Add(id, nameEs);
                SDSLocale.Add(id + "_description", DescriptionEs(id));
            }
            catch (System.Exception e)
            {
                SDSLog.Error("no se pudo registrar la era '" + id + "': " + e.Message);
            }
        }

        private static string DescriptionEs(string id)
        {
            if (id == HolyWarAge)
                return "Demonios, Diosas, Hadas y Gigantes se reparten Britannia a mordiscos.";
            if (id == SevenSinsAge)
                return "Liones en pie, los Caballeros Sagrados en su sitio, y siete criminales sueltos por el reino.";
            return "El sello se rompe. Los Mandamientos vuelven y sus leyes vuelven con ellos.";
        }

        // NOTA: aqui habia consultas del tipo "en que era estamos" (CurrentId, SinsAllowed,
        // CommandmentsAllowed). Se han quitado, no simplificado: WorldAgeManager no expone en este
        // build ningun miembro de era que se pudiera verificar — `current_era` existe en el codigo
        // de otro mod pero llega por reflexion, no como campo. Nadie las usaba todavia, asi que
        // adivinar una firma para dejarlas bonitas habria sido deuda disfrazada de funcionalidad.
        //
        // Si algun sistema necesita mas adelante saber la era actual, el sitio es este, y el primer
        // paso es confirmar el miembro contra la DLL publicizada.
    }
}
