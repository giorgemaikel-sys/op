using System.Collections.Generic;
using UnityEngine;

namespace SevenDeadlySins
{
    /// How a Sin earns their forms.
    ///
    /// Handing every transformation out with the trait made the Sins static: a freshly summoned
    /// Meliodas was already everything Meliodas would ever be. Here the modes are EARNED. A Sin
    /// climbs three rungs by fighting, and each rung is a real step: more power, a new name, and the
    /// key to a transformation that simply will not trigger before it.
    ///
    /// The gates live here rather than inside DemonMark and Sunshine so that "what does this unlock"
    /// is answerable by reading one file.
    public static class Progression
    {
        public const int Latent = 0;
        public const int Awakened = 1;
        public const int Mastered = 2;
        public const int TrueForm = 3;

        /// Kills needed for each rung. Deliberately reachable — a Sin dropped into a war should get
        /// somewhere in a session, not in a week.
        private static readonly int[] Thresholds = { 0, 8, 30, 90 };

        /// Multiplicador de poder por peldano. NEUTRO a proposito (todo 1).
        ///
        /// Antes era {1, 1,3, 1,75, 2,5}: un empujon invisible que se multiplicaba encima de TODO lo
        /// demas. El problema es que ahora cada Pecado tiene una forma VISIBLE calibrada a su clase de
        /// combate del canon — SinForms carga el pico plano de los cinco (Diane 50.000, King 41.600,
        /// Gowther 35.400...), la Marca del Demonio lleva a Meliodas a 142.000 y Sunshine a Escanor a
        /// 114.000 — y esos multiplicadores tambien son contribuyentes. Un x2,5 de progresion encima
        /// los duplicaba: Diane se iba a 123.000, Escanor a 182.000. La forma ES el salto; la
        /// progresion solo decide CUANDO se desbloquea y anuncia su nombre. El crecimiento gradual,
        /// mientras tanto, lo da el bono por bajas de PowerLevel.Get (un veterano supera su base).
        private static readonly float[] Multiplier = { 1f, 1f, 1f, 1f };

        private const string KeyStage = "sds_prog_stage";

        public static void Init()
        {
            PowerLevel.AddContributor("progression", a => Multiplier[Stage(a)]);
            SDSTick.Register(Tick);
            RegisterNames();
        }

        // ---------------------------------------------------------------- reading

        public static int Stage(Actor a)
        {
            if (a == null || a.data == null) return Latent;
            return Mathf.Clamp(SDSData.GetInt(a, KeyStage, Latent), Latent, TrueForm);
        }

        /// The gate every transformation asks. Anyone without a Sin is unrestricted — this system
        /// governs the Seven, not the world.
        public static bool Has(Actor a, int stage)
        {
            if (a == null) return false;
            if (SDSUnit.SinOf(a) == null) return true;
            return Stage(a) >= stage;
        }

        /// Kills still needed for the next rung, or 0 at the top.
        public static int ToNext(Actor a)
        {
            int s = Stage(a);
            if (s >= TrueForm || a == null || a.data == null) return 0;
            return Mathf.Max(0, Thresholds[s + 1] - a.data.kills);
        }

        // ---------------------------------------------------------------- advancing

        private static void Tick(Actor a, float dt)
        {
            // Same fast gate as TreasureArts: only the named bodies reach SinOf, which is seven
            // string lookups and far too expensive to run on the whole population every sweep.
            if (!SDSUnit.IsNamed(a)) return;
            if (!a.isAlive() || a.data == null) return;

            string sin = SDSUnit.SinOf(a);
            if (sin == null) return;

            int stage = Stage(a);
            if (stage >= TrueForm) return;

            if (a.data.kills < Thresholds[stage + 1]) return;

            stage++;
            SDSData.SetInt(a, KeyStage, stage);
            Announce(a, sin, stage);
        }

        private static void Announce(Actor a, string sin, int stage)
        {
            SDSFx.At(a, "sds_fx_the_one", 0.6f);
            SDSFx.Wave(a, 2.5f, 1.5f);

            string form = FormName(sin, stage);
            SDSLog.Chronicle(SDSLocale.T(
                a.getName() + " alcanza " + form + ".",
                a.getName() + " reaches " + form + "."));
        }

        // ---------------------------------------------------------------- the ladder, per sin

        private class Ladder
        {
            public readonly string[] es, en;
            public Ladder(string[] es, string[] en) { this.es = es; this.en = en; }
        }

        /// Three rungs per sin, named for what the character actually unlocks in the story.
        private static readonly Dictionary<string, Ladder> _ladders = new Dictionary<string, Ladder>();

        private static void RegisterNames()
        {
            L(SevenSins.Wrath,
                new[] { "la Marca del Demonio", "el Modo Asalto", "el poder del Rey Demonio" },
                new[] { "the Demon Mark", "Assault Mode", "the Demon King's power" });

            L(SevenSins.Greed,
                new[] { "el instinto del cazador", "el Snatch perfecto", "la inmortalidad absoluta" },
                new[] { "the hunter's instinct", "perfected Snatch", "absolute immortality" });

            L(SevenSins.Envy,
                new[] { "la Danza de Drole", "la Creacion", "la forma de guerra gigante" },
                new[] { "Drole's Dance", "Creation", "the giant war form" });

            L(SevenSins.Lust,
                new[] { "la Invasion", "la lectura total", "el muneco perfecto" },
                new[] { "Invasion", "total reading", "the perfect doll" });

            L(SevenSins.Sloth,
                new[] { "la segunda forma de Chastiefol", "la cuarta forma", "el Desastre" },
                new[] { "Chastiefol's second form", "the fourth form", "Disaster" });

            L(SevenSins.Gluttony,
                new[] { "el Infinito", "el saber absoluto", "el Cubo Perfecto" },
                new[] { "Infinity", "absolute knowledge", "the Perfect Cube" });

            L(SevenSins.Pride,
                new[] { "el Sunshine", "The One", "el Unico" },
                new[] { "Sunshine", "The One", "The One and Only" });
        }

        private static void L(string sin, string[] es, string[] en)
        {
            _ladders[sin] = new Ladder(es, en);
        }

        /// The name of the rung a Sin has just reached. Falls back to a plain label so a sin added
        /// later without a ladder still announces something sensible.
        public static string FormName(string sin, int stage)
        {
            Ladder l;
            if (sin != null && _ladders.TryGetValue(sin, out l) && stage >= 1 && stage <= 3)
                return SDSLocale.English ? l.en[stage - 1] : l.es[stage - 1];

            return SDSLocale.T("un nuevo grado de poder", "a new degree of power");
        }

        /// The rung this unit currently stands on, for the unit panel. Null when they have no Sin or
        /// have not woken up yet.
        public static string CurrentForm(Actor a)
        {
            string sin = SDSUnit.SinOf(a);
            int s = Stage(a);
            if (sin == null || s < Awakened) return null;
            return FormName(sin, s);
        }
    }
}
