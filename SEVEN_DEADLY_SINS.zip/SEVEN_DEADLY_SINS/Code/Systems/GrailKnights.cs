using System.Collections.Generic;
using UnityEngine;

namespace SevenDeadlySins
{
    /// LOS CABALLEROS DEL GRIAL — la TERCERA generacion, y el techo del arbol de herencia.
    ///
    /// El usuario lo pidio exacto: "sigue tan fiel al canon que hasta anadas el sistema de herencias
    /// hasta los Caballeros del Grial". Y el canon encaja perfecto: los Knights of the Holy Grail son
    /// los HIJOS de los Cuatro Jinetes del Apocalipsis, traidos del futuro por Cath Palug con la
    /// esperanza de que sus descendientes tuvieran la fuerza de matarlos. Es decir: NIETOS de los
    /// Siete Pecados. Si en el mod cruzas a un Jinete (Tristan, Lancelot, Percival, Gawain), su hijo
    /// nace Caballero del Grial — con nombre, rango y habilidad propia, y como PRODIGIO (en la serie
    /// Galahad hiere a Lancelot y la flecha de Kardeiz tumba a Percival: superan a sus padres).
    ///
    /// Parentescos (los establecidos; el resto se asigna por Jinete, tematico):
    ///   - Galahad   <- Lancelot (nieto de Ban).
    ///   - Kardeiz   <- Tristan.
    ///   - Lohengrin <- Percival.
    ///   - Ysaye     <- Gawain.
    ///   - Llywarch  <- Escanor o Merlin (nieta adoptiva de ambos, canon).
    public static class GrailKnights
    {
        /// El RANGO de Caballero del Grial (identidad + poder de nieto de los Pecados).
        public const string Rank = "sds_grail_knight";

        private sealed class Grail
        {
            public string key, name;
            public string abilityTrait, ability;
            public string nameEs, nameEn, desc, fx, icon;
        }

        private static readonly Dictionary<string, Grail> _table = new Dictionary<string, Grail>();
        private const string KeyGrail = "sds_grail_key";
        private const float AbilityDuration = 25f;
        private const float AbilityCooldown = 30f;

        /// No CADA hijo de un Jinete nace Caballero del Grial: seria un ejercito de clones con el mismo
        /// nombre. Solo una parte; el resto cae a hibrido/medio-Pecado normal por la cadena de firma.
        private const float GrailChance = 0.5f;

        // key, nombre, nombre-habilidad ES, EN, que hace, FX reutilizado
        private static readonly (string key, string name, string es, string en, string desc, string fx)[] Defs =
        {
            ("galahad",   "Galahad",   "Espada Sagrada del Grial", "Sacred Grail Blade",
                "ve venir el golpe y clava una hoja de luz sin fallo en el enemigo mas lejano, mientras cubre y cura a los suyos", "sds_fx_flash"),
            ("kardeiz",   "Kardeiz",   "Flecha Envenenada",        "Poisoned Arrow",
                "dispara una flecha certera al enemigo mas lejano y siembra un veneno que paraliza a todo el area", "sds_fx_snatch"),
            ("lohengrin", "Lohengrin", "Luz del Grial",            "Grail Light",
                "un martillo de luz sagrada sobre todos los enemigos del area, y cura a los aliados", "sds_fx_ark"),
            ("ysaye",     "Ysaye",     "Filo del Alba",            "Dawnedge",
                "una hoja de sol que arrasa a un objetivo y prende en llamas a los enemigos de alrededor", "sds_fx_sunshine"),
            ("llywarch",  "Llywarch",  "Saber Infinito",           "Infinite Lore",
                "el saber de Merlin y el sol de Escanor: arcano en area, un golpe de sol, y cura a los suyos", "sds_fx_infinity"),
        };

        public static void Init()
        {
            RegisterRank();

            for (int i = 0; i < Defs.Length; i++)
            {
                var d = Defs[i];
                Grail g = new Grail
                {
                    key = d.key, name = d.name,
                    abilityTrait = "sds_ability_grail_" + d.key,
                    ability = "sds_status_grail_ab_" + d.key,
                    nameEs = d.es, nameEn = d.en, desc = d.desc, fx = d.fx,
                    icon = "ui/icons/sds_grail_" + d.key,
                };
                _table[d.key] = g;

                RegisterTrait(g);
                RegisterStatus(g);

                string info = "Habilidad de " + g.name + ", Caballero del Grial: " + g.desc + ". Dura 25s, se relanza cada 30s.";
                SDSLocale.Trait(g.abilityTrait, g.nameEs, info);
                SDSLocale.Status(g.ability, g.nameEs, info);
                SDSLocale.TraitLore(g.abilityTrait,
                    "La lleva " + g.name + " al nacer del cruce de un Cuatro Jinetes del Apocalipsis. "
                    + "Es la tercera generacion — nieto de los Siete Pecados — y nace prodigio.");
            }

            SDSTick.Register(Tick);
        }

        private static void RegisterRank()
        {
            if (AssetManager.traits.dict.ContainsKey(Rank)) return;
            ActorTrait t = SDSRegistry.Trait(Rank, TraitGroups.Bloodline, "ui/icons/sds_grail_knight");
            t.type = TraitType.Positive;
            // Nietos de los Pecados y prodigios: fuertes, a la altura de un Jinete, sin pasarse.
            PowerLevel.Grant(t, 2000f, 2000f, 2000f);
            t.base_stats["health"] = 400f;
            t.base_stats["damage"] = 35f;
            t.base_stats["armor"] = 18f;
            t.base_stats["multiplier_lifespan"] = 6f;
            SDSRegistry.AddTrait(t);
            SDSLocale.Trait(Rank, "Caballero del Grial",
                "Uno de los Caballeros del Grial: hijos de los Cuatro Jinetes, nietos de los Siete "
                + "Pecados. Servidores de Camelot, criados para superar a sus padres.");
            SDSLocale.TraitLore(Rank, "Nace del cruce de un Cuatro Jinetes del Apocalipsis (Tristan, "
                + "Lancelot, Percival, Gawain) o de Escanor/Merlin. La tercera generacion del linaje.");
        }

        private static void RegisterTrait(Grail g)
        {
            if (AssetManager.traits.dict.ContainsKey(g.abilityTrait)) return;
            ActorTrait t = SDSRegistry.Trait(g.abilityTrait, TraitGroups.Grace, g.icon);
            t.type = TraitType.Positive;
            PowerLevel.Grant(t, 700f, 700f, 700f);
            t.base_stats["damage"] = 24f;
            SDSRegistry.AddTrait(t);
        }

        private static void RegisterStatus(Grail g)
        {
            if (AssetManager.status.dict.ContainsKey(g.ability)) return;
            StatusAsset s = SDSRegistry.Status(g.ability, g.icon, AbilityDuration);
            PowerLevel.Grant(s, 3000f, 3000f, 3000f);   // prodigios: fuertes, sin el pico absurdo de 15k
            s.base_stats["damage"] = 30f;
            s.base_stats["armor"] = 18f;
            s.base_stats["critical_chance"] = 0.2f;
            s.removed_on_damage = false;
            SDSRegistry.AddStatus(s);
        }

        // ---------------------------------------------------------------- deteccion del padre Jinete

        private static bool NameIs(Actor a, string n) { try { return a != null && a.getName() == n; } catch { return false; } }

        // SOLO por NOMBRE de la leyenda real (y que sea Named). NADA de detectar por el rasgo de
        // habilidad (Compassion/Perception/Hope): InheritSomeAbility se lo pasa al 25% a hijos
        // NORMALES, y un hijo-legado — que ES Named — que herede Compassion disparaba un Grial FALSO.
        // El nombre exacto solo lo llevan Tristan/Lancelot (hijos canonicos) y Percival/Gawain
        // (leyendas). Escanor/Merlin NO son Jinetes: sus hijos ya no son Caballeros del Grial.
        private static bool IsLancelot(Actor a) { return SDSUnit.IsNamed(a) && NameIs(a, "Lancelot"); }
        private static bool IsTristan(Actor a)  { return SDSUnit.IsNamed(a) && NameIs(a, "Tristan"); }
        private static bool IsPercival(Actor a) { return SDSUnit.IsNamed(a) && NameIs(a, "Percival"); }
        private static bool IsGawain(Actor a)   { return SDSUnit.IsNamed(a) && NameIs(a, "Gawain"); }

        /// La clave del Caballero del Grial que le toca a este cruce, o null si ningun padre es uno de
        /// los CUATRO Jinetes. (Llywarch queda registrada pero sin disparador: en el canon es nieta
        /// ADOPTIVA de Escanor/Merlin, no hija de un Jinete, asi que no encaja en la regla.)
        private static string GrailFor(Actor p1, Actor p2)
        {
            if (IsLancelot(p1) || IsLancelot(p2)) return "galahad";
            if (IsTristan(p1)  || IsTristan(p2))  return "kardeiz";
            if (IsPercival(p1) || IsPercival(p2)) return "lohengrin";
            if (IsGawain(p1)   || IsGawain(p2))   return "ysaye";
            return null;
        }

        /// Viste al bebe como el Caballero del Grial que le toca. Devuelve true si se aplico — Offspring
        /// lo usa como la firma de MAXIMA prioridad (por encima de SinLegacy, medio-Pecado e hibrido).
        public static bool TryApply(Actor baby, Actor p1, Actor p2)
        {
            if (baby == null) return false;
            string key = GrailFor(p1, p2);
            if (key == null) return false;
            if (!Randy.randomChance(GrailChance)) return false;   // solo algunos; el resto, hibrido normal

            Grail g;
            if (!_table.TryGetValue(key, out g)) return false;

            try
            {
                baby.setName(g.name);
                SDSData.SetBool(baby, SDSData.Named, true);
                SDSTraits.Give(baby, Rank);
                SDSTraits.Give(baby, g.abilityTrait);
                SDSTraits.Give(baby, Offspring.TraitProdigy);   // prodigios: superan a sus padres
                SDSData.SetString(baby, KeyGrail, key);
                SDSUnit.MarkAbilityUser(baby);

                SDSFx.At(baby, "sds_fx_sunshine", 0.9f);
                SDSLog.Chronicle(SDSLocale.T(
                    "Ha nacido " + g.name + ", uno de los Caballeros del Grial — nieto de los Pecados.",
                    g.name + " is born, one of the Knights of the Holy Grail."));
            }
            catch { }
            return true;
        }

        private static float CD(float s) { return SDSConfig.AbilityCooldowns ? s : 0.3f; }

        private static void Tick(Actor a, float dt)
        {
            if (a == null || !a.isAlive() || a.data == null) return;
            if (!SDSUnit.RunsAbilities(a)) return;
            if (!a.isAdult()) return;

            string key = SDSData.GetString(a, KeyGrail, "");
            if (string.IsNullOrEmpty(key)) return;

            Grail g;
            if (!_table.TryGetValue(key, out g)) return;

            if (Curses.Incapacitated(a)) return;

            bool foe = AbilityOps.NearestEnemy(a, 14f) != null;
            bool wounded = HasWoundedAlly(a, 12f);
            if (!foe && !wounded) return;

            if (a.hasStatus(g.ability)) return;
            if (!SDSData.TryUse(a, "grail_cast", CD(AbilityCooldown))) return;

            if (!SDSStatus.Inflict(a, g.ability, AbilityDuration)) return;
            SDSFx.At(a, g.fx, 0.9f);

            CastAbility(a, key);
        }

        private static bool HasWoundedAlly(Actor a, float radius)
        {
            List<Actor> near = SDSUnit.Around(a, radius);
            for (int i = 0; i < near.Count; i++)
            {
                Actor o = near[i];
                if (!SDSUnit.IsAlly(a, o)) continue;
                if (o.data != null && o.data.health < o.getMaxHealth()) return true;
            }
            return false;
        }

        private static void CastAbility(Actor a, string key)
        {
            try
            {
                float m = PowerLevel.Magic(a);
                float s = PowerLevel.Strength(a);
                switch (key)
                {
                    case "galahad":   // Espada Sagrada: golpe certero al mas lejano + cubre y cura
                        AbilityOps.Hit(a, AbilityOps.FarthestEnemy(a, 16f), 26f + s * 0.06f, AttackType.Other, "sds_fx_flash");
                        AbilityOps.HealAllies(a, 11f, 14f + m * 0.05f);
                        AbilityOps.BuffAllies(a, 10f, "sds_status_ark_blessing", 12f, "sds_fx_ark");
                        break;
                    case "kardeiz":   // Flecha Envenenada: golpe al mas lejano + veneno que paraliza
                        AbilityOps.Hit(a, AbilityOps.FarthestEnemy(a, 17f), 24f + s * 0.06f, AttackType.Other, "sds_fx_snatch");
                        AbilityOps.AoE(a, 7f, 10f + m * 0.04f, AttackType.Other, "sds_fx_snatch", Curses.Paralyzed, 4f);
                        break;
                    case "lohengrin": // Luz del Grial: martillo de luz en area + cura
                        AbilityOps.AoE(a, 7f, 18f + m * 0.06f, AttackType.Other, "sds_fx_ark", null, 0f);
                        AbilityOps.HealAllies(a, 11f, 14f + m * 0.05f);
                        break;
                    case "ysaye":     // Filo del Alba: sol a uno + fuego en area
                        AbilityOps.Hit(a, AbilityOps.NearestEnemy(a, 12f), 26f + m * 0.07f, AttackType.Fire, "sds_fx_sunshine");
                        AbilityOps.AoE(a, 6f, 14f + m * 0.05f, AttackType.Fire, "sds_fx_sunshine", null, 0f);
                        break;
                    case "llywarch":  // Saber Infinito: arcano en area + sol a uno + cura
                        AbilityOps.AoE(a, 7f, 14f + m * 0.06f, AttackType.Other, "sds_fx_infinity", null, 0f);
                        AbilityOps.Hit(a, AbilityOps.NearestEnemy(a, 12f), 18f + m * 0.05f, AttackType.Fire, "sds_fx_sunshine");
                        AbilityOps.HealAllies(a, 11f, 12f + m * 0.05f);
                        break;
                }
            }
            catch { }
        }
    }
}
