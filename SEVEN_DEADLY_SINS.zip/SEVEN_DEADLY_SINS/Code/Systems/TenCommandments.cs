using System;
using System.Collections.Generic;
using UnityEngine;

namespace SevenDeadlySins
{
    /// The Ten Commandments — DESIGN.md section 5.
    ///
    /// What makes them worth building is not the stat block: it is that each one imposes a LAW on the
    /// world around its bearer. Stand near Grayroad and kill someone, and you are reduced to ash. That
    /// is the whole appeal, so it is implemented for real: one global tick sweeps the living bearers,
    /// asks every unit inside their radius whether it broke the rule, and brands the guilty with
    /// sds_status_curse_<name>.
    ///
    /// The curses are deliberately SHORT-LIVED and re-applied every second. That is what makes the law
    /// feel local: walk out of the bearer's presence and the punishment lapses on its own, with no
    /// bookkeeping and nothing to clean up if a bearer dies mid-sweep.
    ///
    /// A commandment is a post, not a common trait: exactly one living bearer at a time.
    public static class TenCommandments
    {
        // ---------------------------------------------------------------- contract

        public const string Piety = "sds_cmd_piety", Love = "sds_cmd_love", Truth = "sds_cmd_truth",
            Faith = "sds_cmd_faith", Selflessness = "sds_cmd_selflessness", Pacifism = "sds_cmd_pacifism",
            Repose = "sds_cmd_repose", Patience = "sds_cmd_patience", Reticence = "sds_cmd_reticence",
            Purity = "sds_cmd_purity";

        public static readonly string[] All = { Piety, Love, Truth, Faith, Selflessness, Pacifism,
                                                Repose, Patience, Reticence, Purity };

        public const string Group = "sds_group_commandments";

        // ---------------------------------------------------------------- internals

        /// The game's own task ids for running away, read out of Assembly-CSharp. Kept as constants
        /// because isTask is a string compare and a typo here would fail silently forever.
        private const string TaskFlee = "task_unit_flee";
        private const string TaskRunAway = "run_away";

        /// Per-unit bookkeeping for the two laws that punish KILLING. The game gives us a running kill
        /// total and no kill event, so a violation is "the total went up since we last looked".
        private const string DataSeenKills = "sds_cmd_seen_kills";

        /// A full world scan to find a bearer is expensive; only do it when a post is actually vacant,
        /// and never more often than this.


        /// The bearers, by commandment id. A CACHE, never the source of truth: the trait on the actor is,
        /// and it is what survives a save/load. RefreshBearers rebuilds this from the world.
        private static readonly Dictionary<string, Actor> _bearers = new Dictionary<string, Actor>();

        /// Units whose kill total was read this sweep, flushed once at the end so that Selflessness and
        /// Pacifism both see the SAME delta instead of the first one to run eating it.
        private static readonly HashSet<Actor> _killScanned = new HashSet<Actor>();

        /// One commandment: the trait, the punishment, and the rule that triggers it.
        private sealed class Law
        {
            public string id;
            public string curse;
            public string bearer;        // the canonical holder, for the chronicle and the lore line
            public float radius;
            public float dps;            // continuous damage while in violation, 0 for none
            public Func<Actor, Actor, bool> broken;   // (subject, bearer) -> did they break it?
            public Action<Actor, float> toll;         // extra price beyond damage, may be null
        }

        private static Law[] _laws;

        // ---------------------------------------------------------------- public API

        /// True when a living unit currently holds this commandment.
        public static bool IsHeld(string cmdId)
        {
            return HolderOf(cmdId) != null;
        }

        /// The living bearer of a commandment, or null. Revalidated on read: the cached actor may have
        /// died, or lost the trait to an opposite, since the last sweep.
        public static Actor HolderOf(string cmdId)
        {
            if (string.IsNullOrEmpty(cmdId)) return null;

            Actor a;
            if (!_bearers.TryGetValue(cmdId, out a)) return null;

            if (a == null || !a.isAlive() || !a.hasTrait(cmdId))
            {
                _bearers.Remove(cmdId);
                return null;
            }
            return a;
        }

        /// Appoints a unit to a commandment. Strips the previous bearer, because the post is unique,
        /// and strips any other commandment from the newcomer, because a demon holds only one.
        public static void Bestow(Actor a, string cmdId)
        {
            if (a == null || !a.isAlive() || string.IsNullOrEmpty(cmdId)) return;
            if (Array.IndexOf(All, cmdId) < 0)
            {
                SDSLog.Warn("Bestow con un mandamiento desconocido: " + cmdId);
                return;
            }

            Actor previous = HolderOf(cmdId);
            if (previous == a) return;

            if (previous != null)
            {
                // Demoted, not killed: the trait goes and the old bearer keeps living.
                SDSTraits.Remove(previous, cmdId);
                SDSLog.Chronicle(SDSLocale.T(
                    previous.getName() + " pierde su mandamiento",
                    previous.getName() + " loses their commandment"));
            }

            SDSTraits.GiveExclusive(a, cmdId, All);
            if (!a.hasTrait(cmdId)) return;      // did not stick: do not claim the post or announce it

            _bearers[cmdId] = a;

            SDSLog.Chronicle(SDSLocale.T(
                a.getName() + " recibe el mandamiento de " + NameOf(cmdId),
                a.getName() + " receives the commandment of " + NameEnOf(cmdId)));
        }

        /// The canonical bearer from the series. Used by Legends/Actors to hand each commandment to the
        /// demon it belongs to, and by the lore line under the trait.
        public static string CanonicalBearer(string cmdId)
        {
            Law law = LawOf(cmdId);
            return law == null ? "" : law.bearer;
        }

        // ---------------------------------------------------------------- init

        public static void Init()
        {
            RegisterCurses();
            RegisterTraits();
            BuildLaws();

            // A unit holds exactly one commandment. Inert without SDSRegistry.ApplyOpposites, which
            // Main runs after the last trait in the mod is registered.
            SDSRegistry.Opposites(All);

            // The sweep is per-BEARER, not per-actor: at most ten Around() queries a second no matter
            // how big the world gets. Registering it per-actor would mean every unit hunting for a
            // nearby bearer, which is the same work multiplied by the population.
            SDSTick.RegisterGlobal(Tick);

            // Adoption of existing bearers rides the sliced tick so it never spikes. See SeeActor.
            SDSTick.Register(SeeActor);
        }

        // ---------------------------------------------------------------- content

        private static void RegisterTraits()
        {
            // Clases de combate canonicas de la serie: un Mandamiento va de 27.000 (Galand) a 61.000
            // (Zeldris), con Estarossa 60.000 y la pareja Monspeet/Derieri en 52.000. Las stats sds_* son lo
            // que lee el Nivel de Poder; health/damage/armor son lo que lee el combate del juego, y un
            // Mandamiento necesita las dos o canta como un dios y muere ante una milicia.
            Commandment(Piety, "Piedad", "Zeldris",
                "Quien alce su arma contra el portador ve su fuerza desangrarse.",
                22000f, 20000f, 19000f, 2700f, 195f, 130f);   // Zeldris ~61.000

            Commandment(Love, "Amor", "Estarossa",
                "Quien ataque al portador sin compartir su reino queda paralizado donde esta.",
                22000f, 20000f, 18000f, 2800f, 200f, 135f);   // Estarossa 60.000

            Commandment(Truth, "Verdad", "Galand",
                "Quien huya del combate en su presencia se convierte en piedra.",
                11000f, 8000f, 8000f, 1700f, 200f, 150f);     // Galand 27.000

            Commandment(Faith, "Fe", "Melascula",
                "Quien agonice sin levantar el arma pierde el alma poco a poco.",
                7000f, 9000f, 18000f, 1500f, 130f, 80f);      // Melascula ~34.000

            Commandment(Selflessness, "Altruismo", "Fraudrin",
                "Quien mate a un aliado del portador pierde todo lo que amaba.",
                11000f, 9000f, 10000f, 1700f, 150f, 110f);    // Fraudrin ~30.000

            Commandment(Pacifism, "Pacifismo", "Grayroad",
                "Quien mate cerca del portador queda reducido a ceniza.",
                7000f, 7000f, 14000f, 1400f, 135f, 90f);      // Grayroad ~28.000

            Commandment(Repose, "Reposo", "Gloxinia",
                "Quien se quede ocioso en su presencia pierde tiempo de vida.",
                10000f, 12000f, 12000f, 1800f, 165f, 120f);   // Gloxinia ~34.000

            Commandment(Patience, "Paciencia", "Drole",
                "Quien huya con miedo pierde su poder.",
                15000f, 11000f, 8000f, 2000f, 185f, 165f);    // Drole ~34.000

            Commandment(Reticence, "Silencio", "Monspeet",
                "Quien ataque a distancia en su presencia arde.",
                18000f, 16000f, 18000f, 2300f, 180f, 115f);   // Monspeet 52.000

            Commandment(Purity, "Pureza", "Derieri",
                "Quien use magia cerca del portador se ahoga.",
                18000f, 17000f, 17000f, 2300f, 185f, 125f);   // Derieri 52.000
        }

        private static void Commandment(string id, string name, string bearer, string rule,
                                        float str, float spr, float mag,
                                        float health, float damage, float armor)
        {
            ActorTrait t = SDSRegistry.Trait(id, Group, "ui/icons/" + id);
            PowerLevel.Grant(t, str, spr, mag);
            t.base_stats.set("health", health);
            t.base_stats.set("damage", damage);
            t.base_stats.set("armor", armor);
            SDSRegistry.AddTrait(t);

            SDSLocale.Trait(id, "Mandamiento: " + name,
                "Uno de los Diez Mandamientos del Rey Demonio, portado por " + bearer + ". " + rule);
            SDSLocale.TraitLore(id, "Solo un portador vivo a la vez. Se otorga a un demonio elegido; "
                                    + "el portador anterior lo pierde.");
        }

        /// Every curse is registered here rather than in Content/Statuses.cs, because a curse is
        /// meaningless without the law that applies it and the two should not drift apart.
        /// AddStatus is idempotent, so nothing breaks if Statuses.cs ever claims one of these ids too.
        private static void RegisterCurses()
        {
            // Piety: the strength bleeds out of anyone who raises a hand to the bearer.
            Curse(Piety, "Maldicion: Piedad", "Alzo su arma contra un Mandamiento. Su fuerza se desangra.",
                delegate (StatusAsset s)
                {
                    PowerLevel.Grant(s, -6000f, 0f, 0f);
                    s.base_stats.set("multiplier_damage", -0.65f);
                    s.base_stats.set("damage", -120f);
                });

            // Love: struck from outside the fold, and held fast for it.
            Curse(Love, "Maldicion: Amor", "Ataco sin amor a un Mandamiento. Sus miembros no responden.",
                delegate (StatusAsset s)
                {
                    s.base_stats.set("multiplier_speed", -0.95f);
                    s.base_stats.set("multiplier_attack_speed", -0.90f);
                    s.base_stats.set("accuracy", -0.50f);
                });

            // Truth: a coward's flight is a lie told with the feet. Stone is heavy and hard: the
            // armor bonus is not mercy, it is what being a statue feels like from the outside.
            Curse(Truth, "Maldicion: Verdad", "Huyo del combate. Su cuerpo se convierte en piedra.",
                delegate (StatusAsset s)
                {
                    s.base_stats.set("multiplier_speed", -0.98f);
                    s.base_stats.set("multiplier_attack_speed", -0.95f);
                    s.base_stats.set("multiplier_damage", -0.80f);
                    s.base_stats.set("armor", 120f);
                });

            // Faith: doubt at death's door. The soul goes first, the body follows.
            Curse(Faith, "Maldicion: Fe", "Dudo en el umbral de la muerte. Su alma se apaga.",
                delegate (StatusAsset s)
                {
                    PowerLevel.Grant(s, 0f, -8000f, 0f);
                    s.base_stats.set("multiplier_health", -0.35f);
                    s.base_stats.set("multiplier_speed", -0.30f);
                });

            // Selflessness: they took what the bearer loved, so they lose what they loved — every
            // scrap of the power they were so proud of.
            Curse(Selflessness, "Maldicion: Altruismo", "Mato por egoismo. Pierde todo lo que amaba.",
                delegate (StatusAsset s)
                {
                    PowerLevel.Grant(s, -7000f, -7000f, -7000f);
                    s.base_stats.set("multiplier_damage", -0.60f);
                    s.base_stats.set("multiplier_health", -0.40f);
                });

            // Pacifism: killing is the one unforgivable act. This is the harshest curse in the set.
            Curse(Pacifism, "Maldicion: Pacifismo", "Mato ante un Mandamiento. Se deshace en ceniza.",
                delegate (StatusAsset s)
                {
                    s.base_stats.set("multiplier_health", -0.60f);
                    s.base_stats.set("multiplier_speed", -0.45f);
                    s.base_stats.set("armor", -80f);
                });

            // Repose: no stat can express "you are older now". The real price is charged in Age().
            Curse(Repose, "Maldicion: Reposo", "Se quedo ocioso. Los anos se le echan encima.",
                delegate (StatusAsset s)
                {
                    s.base_stats.set("multiplier_speed", -0.40f);
                    s.base_stats.set("multiplier_health", -0.20f);
                });

            // Patience: fear costs power, which is exactly what the Nivel de Poder measures.
            Curse(Patience, "Maldicion: Paciencia", "Huyo con miedo. Su poder lo abandona.",
                delegate (StatusAsset s)
                {
                    PowerLevel.Grant(s, -5000f, -5000f, -5000f);
                    s.base_stats.set("multiplier_damage", -0.55f);
                });

            // Reticence: strike from afar and burn for it.
            Curse(Reticence, "Maldicion: Silencio", "Ataco a distancia. Arde en llamas.",
                delegate (StatusAsset s)
                {
                    s.base_stats.set("multiplier_health", -0.25f);
                    s.base_stats.set("multiplier_speed", -0.20f);
                    s.base_stats.set("armor", -40f);
                });

            // Purity: magic is a corruption, and the corrupt drown on dry land.
            Curse(Purity, "Maldicion: Pureza", "Uso magia ante un Mandamiento. Se ahoga en tierra firme.",
                delegate (StatusAsset s)
                {
                    PowerLevel.Grant(s, 0f, 0f, -6000f);
                    s.base_stats.set("multiplier_speed", -0.55f);
                    s.base_stats.set("multiplier_attack_speed", -0.50f);
                });
        }

        private static void Curse(string cmdId, string title, string description, Action<StatusAsset> tune)
        {
            string id = CurseIdOf(cmdId);

            // 7s against a 1s re-application: comfortably long enough that the curse never flickers
            // while the victim stays in range, short enough that it lapses soon after they leave.
            StatusAsset s = SDSRegistry.Status(id, "ui/icons/" + id, 7f);

            // A curse that fell off the moment its victim was struck would never survive the fight it
            // was handed out in — which is the only place most of these are ever earned.
            s.removed_on_damage = false;

            if (tune != null) tune(s);
            SDSRegistry.AddStatus(s);
            SDSLocale.Status(id, title, description);
        }

        /// sds_cmd_piety -> sds_status_curse_piety
        private static string CurseIdOf(string cmdId)
        {
            return "sds_status_curse_" + cmdId.Substring("sds_cmd_".Length);
        }

        // ---------------------------------------------------------------- the laws

        private static void BuildLaws()
        {
            _laws = new[]
            {
                new Law { id = Piety, curse = CurseIdOf(Piety), bearer = "Zeldris",
                          radius = 8f, dps = 0f, broken = BrokePiety },

                new Law { id = Love, curse = CurseIdOf(Love), bearer = "Estarossa",
                          radius = 8f, dps = 0f, broken = BrokeLove },

                new Law { id = Truth, curse = CurseIdOf(Truth), bearer = "Galand",
                          radius = 10f, dps = 0f, broken = BrokeTruth },

                new Law { id = Faith, curse = CurseIdOf(Faith), bearer = "Melascula",
                          radius = 9f, dps = 14f, broken = BrokeFaith },

                new Law { id = Selflessness, curse = CurseIdOf(Selflessness), bearer = "Fraudrin",
                          radius = 11f, dps = 10f, broken = BrokeSelflessness },

                // The widest reach and the heaviest toll in the set: Grayroad's law is the one that
                // turns a battlefield into a graveyard, and it should be felt from across it.
                new Law { id = Pacifism, curse = CurseIdOf(Pacifism), bearer = "Grayroad",
                          radius = 13f, dps = 34f, broken = BrokePacifism },

                new Law { id = Repose, curse = CurseIdOf(Repose), bearer = "Gloxinia",
                          radius = 10f, dps = 0f, broken = BrokeRepose, toll = TollRepose },

                new Law { id = Patience, curse = CurseIdOf(Patience), bearer = "Drole",
                          radius = 10f, dps = 0f, broken = BrokePatience },

                new Law { id = Reticence, curse = CurseIdOf(Reticence), bearer = "Monspeet",
                          radius = 12f, dps = 18f, broken = BrokeReticence },

                new Law { id = Purity, curse = CurseIdOf(Purity), bearer = "Derieri",
                          radius = 9f, dps = 12f, broken = BrokePurity },
            };
        }

        /// Piedad — raise a weapon against the bearer and your strength drains away.
        private static bool BrokePiety(Actor subject, Actor bearer)
        {
            return TargetsBearer(subject, bearer);
        }

        /// Amor — striking a Commandment is only forgiven to their own people.
        private static bool BrokeLove(Actor subject, Actor bearer)
        {
            if (!TargetsBearer(subject, bearer)) return false;
            try { return !bearer.isSameKingdom(subject); }
            catch { return true; }
        }

        /// Verdad — running from a fight is the lie the body tells.
        private static bool BrokeTruth(Actor subject, Actor bearer)
        {
            return IsFleeing(subject);
        }

        /// Fe — dying without fighting back is doubt, and doubt costs the soul.
        private static bool BrokeFaith(Actor subject, Actor bearer)
        {
            if (Attacking(subject)) return false;

            float max = subject.getMaxHealth();
            if (max <= 0f) return false;
            return subject.data.health / max < 0.35f;
        }

        /// Altruismo — killing one of the bearer's own is the selfish act this law punishes.
        private static bool BrokeSelflessness(Actor subject, Actor bearer)
        {
            if (!HasKilledSinceLastCheck(subject)) return false;
            try { return !bearer.isSameKingdom(subject); }
            catch { return true; }
        }

        /// Pacifismo — no exceptions, no kingdoms, no excuses. Kill anyone and you burn to ash.
        private static bool BrokePacifism(Actor subject, Actor bearer)
        {
            return HasKilledSinceLastCheck(subject);
        }

        /// Reposo — standing about with nothing to do.
        private static bool BrokeRepose(Actor subject, Actor bearer)
        {
            return IsIdle(subject);
        }

        /// Paciencia — not merely fleeing (that is Galand's law) but fleeing BROKEN, which is what
        /// tells the two apart when both bearers happen to be alive.
        private static bool BrokePatience(Actor subject, Actor bearer)
        {
            if (!IsFleeing(subject)) return false;

            float max = subject.getMaxHealth();
            if (max <= 0f) return false;
            return subject.data.health / max < 0.5f;
        }

        /// Silencio — fighting at range instead of face to face.
        private static bool BrokeReticence(Actor subject, Actor bearer)
        {
            if (!Attacking(subject)) return false;
            try { return subject.hasRangeAttack(); }
            catch { return false; }
        }

        /// Pureza — magic is the corruption. Carrying a magic type and actually fighting with it.
        private static bool BrokePurity(Actor subject, Actor bearer)
        {
            if (!Attacking(subject)) return false;

            for (int i = 0; i < MagicTypes.All.Length; i++)
                if (subject.hasTrait(MagicTypes.All[i])) return true;

            return false;
        }

        /// Reposo's real price. No stat in the game means "you are older now", so the toll is charged
        /// against created_time, which is what the game computes an actor's age from.
        ///
        /// The bite is a FRACTION of the life already lived rather than a flat number of seconds: world
        /// time has no fixed relation to a year, so a flat figure would be meaningless on one map and
        /// lethal on the next. It also reads better — idling barely touches a child and crumbles an
        /// elder, which is exactly what Gloxinia's law should feel like.
        private static void TollRepose(Actor subject, float dt)
        {
            if (subject.data == null || World.world == null) return;

            try
            {
                double now = World.world.getCurWorldTime();
                double lived = now - subject.data.created_time;
                if (lived <= 0d) return;

                // Clamped so a long frame (or a paused-then-resumed world) cannot age someone to dust
                // in a single step.
                double steal = lived * 0.02d * Mathf.Clamp(dt, 0f, 2f);
                subject.data.created_time -= steal;

                try { subject.updateAge(); } catch { }
            }
            catch { }
        }

        // ---------------------------------------------------------------- condition helpers

        /// Is this unit swinging at the bearer right now? Read from both ends, because the attacker's
        /// target clears the instant the blow lands while the victim's attackedBy still remembers it.
        private static bool TargetsBearer(Actor subject, Actor bearer)
        {
            try
            {
                if (subject.attack_target == bearer && subject.has_attack_target) return true;
                return bearer.attackedBy == subject;
            }
            catch { return false; }
        }

        private static bool Attacking(Actor a)
        {
            try { return a.has_attack_target; }
            catch { return false; }
        }

        /// Running away. The game's own task ids come first; the fallback is behavioural, because
        /// task ids are the one thing here that a game update could quietly rename, and "was just hit
        /// and is not hitting back" is what fleeing looks like from the outside either way.
        private static bool IsFleeing(Actor a)
        {
            try
            {
                if (a.isTask(TaskFlee) || a.isTask(TaskRunAway)) return true;
            }
            catch { }

            try { return a.attackedBy != null && !a.has_attack_target; }
            catch { return false; }
        }

        private static bool IsIdle(Actor a)
        {
            try { return !a.has_attack_target && !a.hasTask(); }
            catch { return false; }
        }

        /// The game exposes a running kill total and no kill event, so a fresh kill is "the total is
        /// higher than when we last looked at this unit".
        ///
        /// A unit seen for the FIRST time gets a baseline and no verdict: without that, every veteran
        /// who ever wandered near Grayroad would be executed for kills made a hundred years earlier.
        private static bool HasKilledSinceLastCheck(Actor a)
        {
            if (a.data == null) return false;

            _killScanned.Add(a);

            int seen = SDSData.GetInt(a, DataSeenKills, -1);
            if (seen < 0) return false;
            return a.data.kills > seen;
        }

        /// Flushed once per sweep, after every law has read the delta, so two commandments judging the
        /// same killer both see the same kill.
        private static void FlushKillBaselines()
        {
            foreach (Actor a in _killScanned)
            {
                if (a == null || a.data == null) continue;
                SDSData.SetInt(a, DataSeenKills, a.data.kills);
            }
            _killScanned.Clear();
        }

        // ---------------------------------------------------------------- the sweep

        private static void Tick(float dt)
        {
            if (!SDSConfig.CommandmentCurses) return;
            if (World.world == null || _laws == null) return;

            RefreshBearers(dt);

            for (int i = 0; i < _laws.Length; i++)
            {
                Law law = _laws[i];
                Actor bearer = HolderOf(law.id);
                if (bearer == null) continue;

                Judge(law, bearer, dt);
            }

            FlushKillBaselines();
        }

        private static void Judge(Law law, Actor bearer, float dt)
        {
            List<Actor> nearby = SDSUnit.Around(bearer, law.radius);

            for (int i = 0; i < nearby.Count; i++)
            {
                Actor subject = nearby[i];
                if (subject == null || !subject.isAlive() || subject.data == null) continue;

                // A Commandment answers to no other Commandment. Without this the ten of them would
                // stand in a circle cursing each other into paste the moment two shared a battlefield.
                if (SDSUnit.IsCommandment(subject)) continue;

                bool guilty;
                try { guilty = law.broken(subject, bearer); }
                catch (Exception e)
                {
                    SDSLog.Error("maldicion '" + law.id + "': " + e.Message);
                    continue;
                }

                if (!guilty) continue;
                Punish(law, subject, dt);
            }
        }

        private static void Punish(Law law, Actor subject, float dt)
        {
            // Routed through SDSStatus so a bearer of Infinity is refused outright. Returning here
            // rather than merely skipping the status is deliberate: if the curse cannot take hold,
            // its damage and its bond marker must not apply either, or Merlin would still be ground
            // down by a law that never touched her.
            if (!SDSStatus.Inflict(subject, law.curse, 7f)) return;

            // The visible half: stone, ash, a soul coming loose. Five of the ten laws have one.
            Curses.Deliver(subject, law.id);

            // Which law is judging this unit — read by the unit panel.
            SDSData.SetString(subject, SDSData.CommandmentBond, law.id);

            if (law.dps > 0f)
            {
                // Attacker is deliberately NULL. The curse is a law of the world, not a personal blow:
                // crediting the bearer would drag their whole kingdom into a war over a passive aura,
                // and would re-enter the damage hooks from inside a tick.
                try { subject.getHit(law.dps * dt, true, AttackType.Other, null, true); }
                catch { }
            }

            if (law.toll != null)
            {
                try { law.toll(subject, dt); }
                catch { }
            }
        }

        // ---------------------------------------------------------------- bearer bookkeeping

        /// Keeps the cache honest. Bearers die, and a save loaded from disk brings back units wearing
        /// commandments that this cache has never heard of — so a vacant post triggers a world scan
        /// that adopts whoever is already carrying the trait.
        private static void RefreshBearers(float dt)
        {
            bool vacancy = false;

            for (int i = 0; i < All.Length; i++)
            {
                string id = All[i];

                Actor cached;
                if (!_bearers.TryGetValue(id, out cached)) { vacancy = true; continue; }

                if (cached != null && cached.isAlive() && cached.hasTrait(id)) continue;

                _bearers.Remove(id);
                vacancy = true;

                if (cached != null)
                {
                    SDSLog.Chronicle(SDSLocale.T(
                        "El mandamiento de " + NameOf(id) + " queda sin portador",
                        "The commandment of " + NameEnOf(id) + " is left without a bearer"));
                }
            }

            // NO full-population rescan here any more.
            //
            // It used to call Rescan() whenever a post was vacant, and in an ordinary world all ten
            // posts are vacant forever — so every ten seconds it walked the entire unit list doing
            // ten hasTrait lookups per unit. At a couple of thousand units that is twenty thousand
            // string lookups landing inside a single frame, which is exactly the stutter players
            // reported. Adoption now happens in SeeActor, riding the sliced tick that already visits
            // everyone, so the same work is spread across a whole sweep instead of spiking.
            _vacancy = vacancy;
        }

        private static bool _vacancy = true;

        /// Rides the sliced per-actor tick: claims a vacant post for whoever is already carrying the
        /// trait, and strips latecomers from a post that is already filled.
        ///
        /// Cheap-exits on the common case. Only units that actually hold one of the ten traits cost
        /// anything beyond the initial check, and that check is skipped entirely while every post is
        /// already occupied.
        private static void SeeActor(Actor a, float dt)
        {
            if (!_vacancy) return;
            if (a == null || !a.isAlive()) return;

            // Un mandamiento solo lo lleva un personaje con nombre, y SDSUnit.CommandmentOf son diez
            // busquedas por cadena. Esta lectura de un bool saca a toda la poblacion normal antes.
            if (!SDSUnit.IsNamed(a)) return;

            string cmd = SDSUnit.CommandmentOf(a);
            if (cmd == null) return;

            Actor current = HolderOf(cmd);
            if (current == null)
            {
                _bearers[cmd] = a;
                return;
            }

            // A post is unique. The latecomer loses the trait rather than sharing the law.
            if (current != a) SDSTraits.Remove(a, cmd);
        }


        // ---------------------------------------------------------------- names

        private static Law LawOf(string cmdId)
        {
            if (_laws == null || string.IsNullOrEmpty(cmdId)) return null;
            for (int i = 0; i < _laws.Length; i++)
                if (_laws[i].id == cmdId) return _laws[i];
            return null;
        }

        /// The Spanish display name of a commandment, for chronicles and tips.
        public static string NameOf(string cmdId)
        {
            switch (cmdId)
            {
                case Piety: return "la Piedad";
                case Love: return "el Amor";
                case Truth: return "la Verdad";
                case Faith: return "la Fe";
                case Selflessness: return "el Altruismo";
                case Pacifism: return "el Pacifismo";
                case Repose: return "el Reposo";
                case Patience: return "la Paciencia";
                case Reticence: return "el Silencio";
                case Purity: return "la Pureza";
                default: return cmdId;
            }
        }

        private static string NameEnOf(string cmdId)
        {
            switch (cmdId)
            {
                case Piety: return "Piety";
                case Love: return "Love";
                case Truth: return "Truth";
                case Faith: return "Faith";
                case Selflessness: return "Selflessness";
                case Pacifism: return "Pacifism";
                case Repose: return "Repose";
                case Patience: return "Patience";
                case Reticence: return "Reticence";
                case Purity: return "Purity";
                default: return cmdId;
            }
        }
    }
}
