using UnityEngine;

namespace SevenDeadlySins
{
    /// The seven Sacred Treasures.
    ///
    /// Each is cloned from a vanilla weapon rather than constructed: AssetManager.items.clone is the
    /// only registration path that works on this build, and cloning means every field we do not set
    /// keeps a value the game already knows how to handle.
    ///
    /// They are NOT pool weapons. No blacksmith in Britannia makes a Lostvayne — the treasures are
    /// handed out by Bestow to the Sin they belong to, and to nobody else.
    public static class SacredTreasures
    {
        public const string Lostvayne = "sds_item_lostvayne";
        public const string Courechouse = "sds_item_courechouse";
        public const string Chastiefol = "sds_item_chastiefol";
        public const string Gideon = "sds_item_gideon";
        public const string Herritt = "sds_item_herritt";
        public const string Aldan = "sds_item_aldan";
        public const string Rhitta = "sds_item_rhitta";

        // Las armas de los Cuatro Jinetes del Apocalipsis (la secuela).
        public const string PercivalStaff = "sds_item_percival";
        public const string TristanSword = "sds_item_tristan";
        public const string LancelotBow = "sds_item_lancelot";
        public const string GawainSword = "sds_item_gawain";

        private const string Group = "sds_treasures";

        public static void Init()
        {
            MakeGroup();
            PatchHeldSprites();

            // damage, template, name, description
            W(Lostvayne, 46f, "sword_steel", "Lostvayne",
                "La espada demoniaca de Meliodas. Crea clones fisicos de quien la empuna.");
            W(Courechouse, 40f, "spear_steel", "Courechouse",
                "El baston sagrado de cuatro secciones de Ban.");
            W(Chastiefol, 52f, "spear_steel", "Chastiefol",
                "La lanza espiritual del Rey Hada. Cambia de forma segun lo que haga falta.");
            W(Gideon, 58f, "mace_steel", "Gideon",
                "El martillo de guerra de Diane. Pesa lo que pesa una montana pequena.");
            W(Herritt, 34f, "bow_steel", "Herritt",
                "El arco gemelo de Gowther. Dispara dos veces por cada tension de cuerda.");
            W(Aldan, 30f, "sword_steel", "Aldan",
                "El orbe de Merlin. No corta: piensa.");
            W(Rhitta, 70f, "axe_steel", "Rhitta",
                "El hacha divina de Escanor. De noche pesa tanto que nadie puede levantarla.");

            // --- Los Cuatro Jinetes del Apocalipsis --------------------------------
            W(PercivalStaff, 38f, "spear_steel", "Baston de Percival",
                "El baston de Percival, el vaso del Caos.");
            W(TristanSword, 54f, "sword_steel", "Espada de Tristan",
                "La espada de Tristan, hijo de Meliodas y Elizabeth. Corta y cura.");
            W(LancelotBow, 44f, "bow_steel", "Arco de Lancelot",
                "El arco de Lancelot, hijo de Ban y Elaine. No falla un tiro.");
            W(GawainSword, 66f, "sword_steel", "Espada de Gawain",
                "La gran espada de Gawain, la Caballero Sagrado del Sol.");
        }

        // ---------------------------------------------------------------- the sprite in the hand

        /// THIS IS THE FIX FOR THE FREEZE.
        ///
        /// ItemLibrary.loadSprites runs AFTER every mod's init and rebuilds each item's sprite list
        /// from scratch, so anything assigned during Init is thrown away before a single unit is
        /// drawn. Our treasures were left with an EMPTY gameplay_sprites array — and the renderer
        /// indexes that array every frame for every unit holding the weapon. One armed unit was
        /// enough to bring the frame rate down; a battle full of them locked the game.
        ///
        /// So the sprites are filled in a postfix, after the game has finished, and — the part that
        /// actually matters — the array is NEVER left empty. If our own art cannot be found for any
        /// reason, the weapon falls back to the sprites of the vanilla item it was cloned from. A
        /// treasure that looks like a steel sword is a cosmetic bug. A treasure with no sprites at
        /// all is a frozen game.
        private static void PatchHeldSprites()
        {
            try
            {
                System.Reflection.MethodInfo m =
                    HarmonyLib.AccessTools.DeclaredMethod(typeof(ItemLibrary), "loadSprites");

                if (m == null)
                {
                    SDSLog.Warn("no existe ItemLibrary.loadSprites; los tesoros usaran el sprite de su plantilla.");
                    return;
                }

                Main.harmony.Patch(m, postfix: new HarmonyLib.HarmonyMethod(
                    typeof(SacredTreasures).GetMethod(nameof(LoadHeldSprites),
                        System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.NonPublic)));
            }
            catch (System.Exception e)
            {
                SDSLog.Error("no se pudo parchear loadSprites: " + e.Message);
            }
        }

        /// Called by Harmony after the game has rebuilt every item's sprites.
        internal static void LoadHeldSprites()
        {
            int ours = 0, fallback = 0;

            for (int i = 0; i < SDSRegistry.ItemIds.Count; i++)
            {
                ItemAsset item = null;
                try { item = AssetManager.items.get(SDSRegistry.ItemIds[i]); }
                catch { }
                if (item == null) continue;

                Sprite[] mine = Fetch(item.path_gameplay_sprite);
                if (mine != null && mine.Length > 0)
                {
                    item.gameplay_sprites = mine;
                    ours++;
                    continue;
                }

                // Never leave it empty. Borrow from the template we cloned.
                if (item.gameplay_sprites == null || item.gameplay_sprites.Length == 0)
                {
                    Sprite[] borrowed = Fetch("weapons/weapon_sword_steel");
                    if (borrowed == null || borrowed.Length == 0)
                    {
                        ItemAsset steel = null;
                        try { steel = AssetManager.items.get("sword_steel"); }
                        catch { }
                        if (steel != null) borrowed = steel.gameplay_sprites;
                    }

                    if (borrowed != null && borrowed.Length > 0)
                    {
                        item.gameplay_sprites = borrowed;
                        fallback++;
                    }
                }
            }

            SDSLog.Info("sprites de tesoro en mano: " + ours + " propios, " + fallback + " prestados");
        }

        /// The game's own loader first — it knows about sprites.json pivots, which a raw
        /// Resources.Load does not — then the plain load as a fallback.
        private static Sprite[] Fetch(string path)
        {
            if (string.IsNullOrEmpty(path)) return null;

            // getSpriteList first: it understands sprites.json pivots and multi-frame folders.
            try
            {
                Sprite[] list = SpriteTextureLoader.getSpriteList(path);
                if (list != null && list.Length > 0) return list;
            }
            catch { }

            // Then the SINGULAR loader. This is the one that actually works for a flat file, and it
            // is what every icon in this mod already resolves through — getSpriteList kept coming
            // back empty for weapons/<id>.png, which is why the treasures were all borrowing a steel
            // sword's sprite despite their own art sitting right there on disk.
            try
            {
                Sprite one = SpriteTextureLoader.getSprite(path);
                if (one != null) return new Sprite[] { one };
            }
            catch { }

            try
            {
                Sprite one = Resources.Load<Sprite>("GameResources/" + path);
                if (one != null) return new Sprite[] { one };
            }
            catch { }

            return null;
        }

        /// Our own section in the weapon list, so the treasures do not vanish among the game's swords.
        private static void MakeGroup()
        {
            try
            {
                if (AssetManager.item_groups.get(Group) != null) return;
                ItemGroupAsset g = AssetManager.item_groups.clone(Group, "sword");
                if (g == null) return;
                g.id = Group;
                AssetManager.item_groups.add(g);
                SDSLocale.Add(Group, "Tesoros Sagrados");
            }
            catch { }
        }

        private static void W(string id, float damage, string template, string name, string info)
        {
            ItemAsset item = null;
            try { item = AssetManager.items.clone(id, template); }
            catch { }

            // Falling back to a plain steel sword rather than giving up: a treasure with the wrong
            // silhouette is still a treasure, a missing one breaks Legends' kit assignment.
            if (item == null)
            {
                try { item = AssetManager.items.clone(id, "sword_steel"); }
                catch { return; }
            }
            if (item == null) return;

            item.id = id;
            item.equipment_type = EquipmentType.Weapon;
            item.group_id = Group;
            item.material = "steel";
            item.path_icon = "ui/weapons/" + id;
            item.path_gameplay_sprite = "weapons/" + id;

            // The id is not the name. Without translation_key the weapon is called whatever the sword
            // we cloned is called, and every treasure reads "Steel Sword".
            item.translation_key = id;

            // Never mass-produced. These are named weapons with a history.
            item.is_pool_weapon = false;
            try { item.unlock(true); }
            catch { }

            item.base_stats["damage"] = damage;

            SDSRegistry.TrackItem(id);
            SDSLocale.Add(id, name);
            SDSLocale.Add(id + "_info", info);
        }

        /// Marks a unit as the rightful bearer of a treasure and grants its power.
        ///
        /// It does NOT force the weapon into their hands. No equip signature was verifiable against
        /// this build — `giveItem` and `generateItem` exist in the assembly but their parameters
        /// could not be confirmed, and the reference mod on this machine never equips a unit
        /// programmatically either. Rather than guess and have it fail silently, the treasure's
        /// POWER is granted directly and the weapon itself remains a real, registered item that
        /// exists in the world.
        ///
        /// Replace the body with a real equip call if a signature is ever confirmed; every caller
        /// already goes through here.
        public static void Bestow(Actor a, string itemId)
        {
            if (a == null || !a.isAlive() || string.IsNullOrEmpty(itemId)) return;

            ItemAsset asset = null;
            try { asset = AssetManager.items.get(itemId); }
            catch { }
            if (asset == null) return;

            // The treasure's bite, applied to the bearer directly.
            float damage = 0f;
            try { damage = asset.base_stats["damage"]; }
            catch { }

            try { a.stats[PowerLevel.StatStrength] = PowerLevel.Strength(a) + damage * 4f; }
            catch { }

            SDSData.SetString(a, "sds_treasure", itemId);
        }

        /// The treasure this unit has been granted, or an empty string.
        public static string Held(Actor a)
        {
            return SDSData.GetString(a, "sds_treasure", "");
        }

        /// The treasure this unit is entitled to, or null. Only the matching Sin gets one.
        public static string For(Actor a)
        {
            string sin = SDSUnit.SinOf(a);
            return sin == null ? null : SevenSins.TreasureOf(sin);
        }
    }
}
