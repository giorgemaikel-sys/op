using UnityEngine;

namespace SevenDeadlySins
{
    /// El tiempo del Purgatorio: un minuto fuera son sesenta anos dentro.
    ///
    /// Es de lo mas conocido de la serie. Ban entro a buscar a Meliodas y se paso SESENTA ANOS ahi
    /// dentro cazando; fuera habian pasado unos dias. El sitio no es solo peligroso, es que la vida
    /// se te va mientras estas dentro. Sin esto, el Purgatorio era un mapa con bichos.
    ///
    /// COMO SE MIDE, Y POR QUE ESE NUMERO. El reloj del juego se lleva en `MapStats.world_time`, y
    /// un ano son 60 unidades — se ve en el propio codigo del juego, en el asignador de `year`:
    /// `world_time += value * 60f`. Asi que 60 anos son 3600 unidades. Repartidas en un minuto real
    /// salen 60 unidades por segundo, que es lo que se anade aqui.
    ///
    /// LO QUE ARRASTRA. Una unidad de WorldBox no guarda su edad: la deduce de `created_time`
    /// contra el reloj del mundo. O sea que acelerar el reloj ENVEJECE a todo el mundo de verdad,
    /// sin tocar una sola unidad. Un mortal que entre al Purgatorio y se quede sale viejo, o no
    /// sale. Un inmortal como Ban aguanta. Eso no lo he programado: sale solo, y es exactamente lo
    /// que pasa en la serie.
    public static class PurgatoryTime
    {
        /// Unidades de reloj que vale un ano. Constante del juego, no elegida por mi.
        public const float YearInWorldTime = 60f;

        /// Los sesenta anos por minuto de la serie.
        public const float YearsPerMinute = 60f;

        /// Cuanto reloj hay que anadir por segundo real para conseguirlo.
        private const float PerSecond = (YearsPerMinute / 60f) * YearInWorldTime;

        /// Anos transcurridos dentro desde que se entro, solo para poder contarlo.
        private static float _yearsInside;

        /// Segundos reales que se lleva el jugador FUERA. El Purgatorio no se para por eso.
        private static float _secondsOutside;

        /// Tope de lo que se APLICA de una sola ausencia. Ojo: solo del efecto, no de la cuenta.
        ///
        /// Con medio millon de anos por ano de Britannia, aplicar el numero entero al reloj del
        /// mundo no seria "el Purgatorio siguio": seria convertirlo en un cementerio. Todo lo que
        /// tenga edad muere mil veces, y al cruzar te encuentras un desierto.
        ///
        /// Asi que la CUENTA es real y sin tope — se te dicen los 525.600 anos que han pasado, y el
        /// contador del Purgatorio los guarda todos — pero lo que cae sobre el mapa esta acotado a
        /// dos mil anos. Es la diferencia entre un sitio donde el tiempo no significa nada y un
        /// sitio muerto. Lo digo aqui porque es una mentira piadosa deliberada, no un descuido.
        private const float MaxApplied = 2000f;

        public static float YearsInside { get { return _yearsInside; } }

        /// Lo que ha pasado de verdad ahi dentro durante la ausencia. Sin tope: es lo que se cuenta.
        public static double OwedYears
        {
            get { return _owedBritanniaYears * YearsPerBritanniaYear; }
        }

        /// Lo que se le aplica al mapa. Acotado para que el reino sobreviva a la cuenta.
        public static float OwedYearsApplied
        {
            get { return Mathf.Min(MaxApplied, (float)OwedYears); }
        }

        public static void Init()
        {
            SDSTick.RegisterGlobal(Tick);
            SDSTick.RegisterGlobal(TickOutside);
        }

        /// Al entrar o salir se reinicia la cuenta de dentro.
        public static void Reset()
        {
            _yearsInside = 0f;
        }

        /// Se llama al entrar, una vez cobrada la deuda.
        public static void ClearOwed()
        {
            _secondsOutside = 0f;
            _owedBritanniaYears = 0.0;
            _lastWorldTime = -1.0;
        }

        /// Borron y cuenta nueva: para cuando empieza una partida distinta. El Purgatorio de la
        /// anterior no existe, y su reloj tampoco.
        public static void HardReset()
        {
            _yearsInside = 0f;
            _secondsOutside = 0f;
            _owedBritanniaYears = 0.0;
            _lastWorldTime = -1.0;
            _purgatoryYear = 0.0;
        }

        /// LA PROPORCION, y es entre anos DE JUEGO, no de reloj de pared.
        ///
        /// Un ano en Britannia son 525.600 anos en el Purgatorio. El numero es del jugador y tiene
        /// su gracia: 525.600 son los minutos que tiene un ano, asi que cada minuto de Britannia
        /// vale un ano ahi dentro.
        ///
        /// POR QUE SE MIDE ASI Y NO EN SEGUNDOS REALES. La primera version contaba segundos de
        /// reloj, y por eso "no pasaba nada": si juegas Britannia a velocidad rapida, un ano de
        /// juego se te va en unos pocos segundos reales, y el Purgatorio apenas se movia. Atado al
        /// reloj del juego, el tiempo del Purgatorio depende de lo que vive Britannia — que es lo
        /// que se pedia — y ademas respeta la pausa y la velocidad sin tener que enterarse de ellas.
        public const double YearsPerBritanniaYear = 525600.0;

        /// Anos totales que lleva corridos el Purgatorio desde que existe. NO se reinicia.
        private static double _purgatoryYear;

        /// Ultimo valor visto del reloj de Britannia, para sacar el avance por diferencia.
        private static double _lastWorldTime = -1.0;

        public static double PurgatoryYear { get { return _purgatoryYear; } }


        /// EL RELOJ DEL PURGATORIO NO PARA NUNCA.
        ///
        /// Aqui esta lo que faltaba. WorldBox corre UN solo mundo, asi que el mapa del Purgatorio no
        /// puede simularse casilla a casilla mientras estas en Britannia — eso no es un ajuste, es
        /// otro motor, y no te voy a decir que lo hace. Lo que si corre de verdad en segundo plano
        /// es esto: el reloj sigue, los anos se acumulan, y de vez en cuando llega noticia de lo que
        /// esta pasando alli. Cuando cruzas, todo ese tiempo se cobra de golpe sobre el mapa.
        ///
        /// Antes el tiempo fuera se contaba en silencio y solo te enterabas al entrar. Ahora se ve
        /// correr, que es la diferencia entre "hay un contador" y "aquello sigue vivo sin ti".
        private static void TickOutside(float dt)
        {
            if (Purgatory.Inside) { _lastWorldTime = -1.0; return; }
            if (World.world == null || MapBox.instance == null) return;

            double now;
            try { now = MapBox.instance.map_stats.world_time; }
            catch { return; }

            // Primera lectura tras cruzar o cargar: solo se toma referencia. Sin esto el primer
            // salto seria el reloj entero de la partida multiplicado por medio millon.
            if (_lastWorldTime < 0.0) { _lastWorldTime = now; return; }

            double advanced = now - _lastWorldTime;
            _lastWorldTime = now;

            // Cargar otra partida puede mover el reloj hacia atras o dar un salto absurdo.
            if (advanced <= 0.0 || advanced > 600.0) return;

            double britanniaYears = advanced / YearInWorldTime;

            _secondsOutside += dt;
            _purgatoryYear += britanniaYears * YearsPerBritanniaYear;
            _owedBritanniaYears += britanniaYears;

            // Antes aqui salia una noticia del Purgatorio cada cuarto de ano de Britannia. El
            // jugador la quiere fuera: el reloj sigue corriendo igual, pero en silencio. La cuenta
            // no depende de que se anuncie.
        }

        /// Anos de BRITANNIA acumulados desde la ultima visita. Es la moneda con la que se cobra.
        private static double _owedBritanniaYears;


        private static void Tick(float dt)
        {
            if (!Purgatory.Inside) return;
            if (World.world == null || MapBox.instance == null) return;

            // Mientras se carga o se moldea el mundo el reloj no corre: acelerar el tiempo sobre un
            // mapa a medio hacer es la clase de cosa que ya salio cara una vez en este sistema.
            try { if (SmoothLoader.isLoading()) return; }
            catch { return; }

            float add = PerSecond * dt;

            try { MapBox.instance.map_stats.updateWorldTime(add); }
            catch { return; }

            _yearsInside += add / YearInWorldTime;

            // El mismo contador continuo que corre estando fuera: el Purgatorio tiene UN reloj, y
            // no se entera de si el jugador esta mirando.
            _purgatoryYear += add / YearInWorldTime;

        }

        /// Ya no hay avisos de anos que reiniciar — el jugador los quiere fuera. Se mantiene el
        /// metodo porque Purgatory lo llama al cruzar en las dos direcciones, y quitarlo solo
        /// serviria para tener que volver a ponerlo si algun dia se quiere un aviso distinto.
        public static void ResetAnnounce()
        {
        }
    }
}
