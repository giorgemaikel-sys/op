using System.Collections.Generic;
using UnityEngine;

namespace SevenDeadlySins
{
    /// Primitivas de efecto compartidas por TODAS las habilidades de legado del mod.
    ///
    /// SinLegacy (hijos de dos Pecados) las tenia privadas; ahora viven aqui para que las reutilicen
    /// tambien las nuevas familias de herencia — hibridos de raza, medio-Pecados y los Caballeros del
    /// Grial — sin duplicar la logica de "a quien golpeo" y "a quien curo". Todas pasan por el detector
    /// de aliados robusto (SDSUnit.IsAlly/IsEnemy), asi que funcionan aunque el usuario los invoque a
    /// mano sin reino — que es justo el bug que arreglamos antes.
    public static class AbilityOps
    {
        public static Actor NearestEnemy(Actor a, float radius)
        {
            List<Actor> near = SDSUnit.Around(a, radius);
            for (int i = 0; i < near.Count; i++)
                if (SDSUnit.IsEnemy(a, near[i])) return near[i];
            return null;
        }

        public static Actor FarthestEnemy(Actor a, float radius)
        {
            Actor far = null;
            List<Actor> near = SDSUnit.Around(a, radius);
            for (int i = 0; i < near.Count; i++)
                if (SDSUnit.IsEnemy(a, near[i])) far = near[i];   // el ultimo del barrido: el mas lejano-ish
            return far;
        }

        /// Un golpe a un objetivo, con su FX opcional encima.
        public static void Hit(Actor a, Actor t, float dmg, AttackType type, string fx)
        {
            if (t == null || !t.isAlive()) return;
            try { t.getHit(dmg, true, type, a, true); } catch { return; }
            if (!string.IsNullOrEmpty(fx)) SDSFx.At(t, fx, 0.5f);
        }

        /// Golpe en area a todos los ENEMIGOS del radio, con estado opcional (paralisis, etc.).
        public static void AoE(Actor a, float radius, float dmg, AttackType type, string fx, string status, float statusTime)
        {
            List<Actor> near = SDSUnit.Around(a, radius);
            for (int i = 0; i < near.Count; i++)
            {
                Actor o = near[i];
                if (!SDSUnit.IsEnemy(a, o)) continue;
                try { o.getHit(dmg, true, type, a, true); } catch { continue; }
                if (!string.IsNullOrEmpty(status)) SDSStatus.Inflict(o, status, statusTime);
            }
            if (!string.IsNullOrEmpty(fx)) SDSFx.At(a, fx, 0.6f);
        }

        /// Drena a un objetivo y se cura con ello (contra/hurto de vida).
        public static void Drain(Actor a, Actor t, float dmg)
        {
            if (t == null || !t.isAlive()) return;
            try
            {
                t.getHit(dmg, true, AttackType.Other, a, true);
                a.restoreHealth(Mathf.Max(1, Mathf.RoundToInt(dmg * 0.7f)));
            }
            catch { }
            SDSFx.At(t, "sds_fx_snatch", 0.5f);
        }

        /// Drena a TODOS los enemigos del radio y se cura con la suma.
        public static void DrainAll(Actor a, float radius, float dmg)
        {
            List<Actor> near = SDSUnit.Around(a, radius);
            float healed = 0f;
            for (int i = 0; i < near.Count; i++)
            {
                Actor o = near[i];
                if (!SDSUnit.IsEnemy(a, o)) continue;
                try { o.getHit(dmg, true, AttackType.Other, a, true); healed += dmg * 0.5f; } catch { }
            }
            if (healed > 0f)
            {
                try { a.restoreHealth(Mathf.Max(1, Mathf.RoundToInt(healed))); } catch { }
                SDSFx.At(a, "sds_fx_snatch", 0.6f);
            }
        }

        /// Cura a los aliados heridos del radio.
        public static void HealAllies(Actor a, float radius, float amount)
        {
            List<Actor> near = SDSUnit.Around(a, radius);
            bool used = false;
            for (int i = 0; i < near.Count; i++)
            {
                Actor o = near[i];
                if (!SDSUnit.IsAlly(a, o)) continue;
                if (o.data == null || o.data.health >= o.getMaxHealth()) continue;
                try { o.restoreHealth(Mathf.Max(1, Mathf.RoundToInt(amount))); used = true; } catch { }
            }
            if (used) SDSFx.At(a, "sds_fx_heal", 0.5f);
        }

        /// Pone un estado POSITIVO sobre los aliados del radio (bendicion, furor...).
        public static void BuffAllies(Actor a, float radius, string statusId, float seconds, string fx)
        {
            if (string.IsNullOrEmpty(statusId)) return;
            List<Actor> near = SDSUnit.Around(a, radius);
            bool used = false;
            for (int i = 0; i < near.Count; i++)
            {
                Actor o = near[i];
                if (!SDSUnit.IsAlly(a, o)) continue;
                if (o.hasStatus(statusId)) continue;
                SDSStatus.Inflict(o, statusId, seconds); used = true;
            }
            if (used && !string.IsNullOrEmpty(fx)) SDSFx.At(a, fx, 0.5f);
        }
    }
}
