using System.Collections.Generic;
using UnityEngine;

namespace SevenDeadlySins
{
    /// How an ordinary person of Britannia comes into their power.
    ///
    /// Until now the only ladder in the mod was the Holy Knight ranks, and only humans could climb
    /// it. That left every Fairy, Giant, Demon and Goddess in the world permanently ordinary — and
    /// it is not how the series works either. Power in Nanatsu no Taizai comes from the KIND of
    /// magic you were born with, not from a commission signed by a kingdom.
    ///
    /// So: every magic user grows on their own. What they unlock depends on which of the five magic
    /// types they have, and their pool is fixed by that type — a Healer will never learn Hellblaze
    /// no matter how long they live, and a Special can eventually reach things nobody else can.
    ///
    /// Nothing here touches the Holy Knight ranks. The two ladders are independent on purpose: a
    /// Grand Master with Healer magic and a hermit Healer of the same age know the same spells.
    public static class MagicProgression
    {
        private const string KeyTier = "sds_magic_tier";

        /// Kills needed for tier 1, 2 and 3. Lower than the Sins' ladder — these are villagers, and
        /// the point is that a world left running fills up with people who can do things.
        private static readonly int[] Thresholds = { 0, 4, 16, 45 };

        /// What each magic type can ever learn, in the order it learns it.
        private static readonly Dictionary<string, string[]> _pools = new Dictionary<string, string[]>();

        public static void Init()
        {
            // NINGUNA de estas es la habilidad emblematica de un personaje.
            //
            // La primera version repartia Full Counter, Snatch, Hellblaze, Ark y Flash — es decir,
            // los poderes de Meliodas, Ban, el Rey Demonio, el Clan de las Diosas y Ludociel. Un
            // aldeano con suficientes batallas acababa teniendo el contraataque de Meliodas, lo que
            // deja a los Siete Pecados sin nada que los haga especiales.
            //
            // Ahora cada clase saca de su propio repertorio (ClassAbilities), y lo de los Pecados
            // sigue siendo solo suyo.
            Pool(MagicTypes.Strengthener, new[]
            {
                ClassAbilities.IronSkin,
                ClassAbilities.HeavyBlow,
                ClassAbilities.Berserk,
            });

            Pool(MagicTypes.Enchanter, new[]
            {
                ClassAbilities.BlessWeapon,
                ClassAbilities.Ward,
                ClassAbilities.BattleHymn,
            });

            Pool(MagicTypes.Incantation, new[]
            {
                ClassAbilities.Spark,
                ClassAbilities.FrostLance,
                ClassAbilities.Meteor,
            });

            Pool(MagicTypes.Healer, new[]
            {
                ClassAbilities.Mend,
                ClassAbilities.Cleanse,
                ClassAbilities.Vigor,
            });

            Pool(MagicTypes.Special, new[]
            {
                ClassAbilities.Mimic,
                ClassAbilities.Displace,
                ClassAbilities.Unravel,
            });

            SDSTick.Register(Tick);
        }

        private static void Pool(string magicType, string[] abilities)
        {
            _pools[magicType] = abilities;
        }

        // ---------------------------------------------------------------- reading

        public static int Tier(Actor a)
        {
            if (a == null || a.data == null) return 0;
            return Mathf.Clamp(SDSData.GetInt(a, KeyTier, 0), 0, Thresholds.Length - 1);
        }

        /// Kills still needed for the next unlock, or 0 when there is nothing left to learn.
        public static int ToNext(Actor a)
        {
            int t = Tier(a);
            if (a == null || a.data == null || t >= Thresholds.Length - 1) return 0;
            return Mathf.Max(0, Thresholds[t + 1] - a.data.kills);
        }

        /// The ability this unit would learn next, or null.
        public static string NextAbility(Actor a)
        {
            string magic = MagicTypes.TypeOf(a);
            if (magic == null) return null;

            string[] pool;
            if (!_pools.TryGetValue(magic, out pool)) return null;

            int t = Tier(a);
            return t < pool.Length ? pool[t] : null;
        }

        // ---------------------------------------------------------------- advancing

        private static void Tick(Actor a, float dt)
        {
            if (a == null || !a.isAlive() || a.data == null) return;

            // Cheap exit for the whole population: only someone who has already been given a magic
            // type can climb, and that flag is one data read rather than five hasTrait lookups.
            if (!SDSData.GetBool(a, "sds_magic_rolled")) return;

            // A NAMED CHARACTER NEVER LEARNS ANYTHING HERE.
            //
            // Meliodas has Full Counter, Ludociel has Flash, and that is the entire list. Letting
            // them climb the common ladder meant Escanor picking up Frost Lance because he happened
            // to be an Incantation user, which is nonsense twice over: it is not his, and it makes
            // the ladder look like the way anyone becomes anyone.
            if (SDSUnit.IsNamed(a)) return;

            int tier = Tier(a);
            if (tier >= Thresholds.Length - 1) return;
            if (a.data.kills < Thresholds[tier + 1]) return;

            string next = NextAbility(a);

            tier++;
            SDSData.SetInt(a, KeyTier, tier);

            if (string.IsNullOrEmpty(next)) return;
            if (a.hasTrait(next)) return;

            SDSTraits.Give(a, next);
            SDSFx.At(a, "sds_fx_enchant", 0.45f);

            // Only the last rung is worth announcing to the world; the first two happen constantly.
            if (tier >= Thresholds.Length - 1)
            {
                string label = Name(next);
                SDSLog.Chronicle(SDSLocale.T(
                    a.getName() + " domina " + label + ".",
                    a.getName() + " has mastered " + label + "."));
            }
        }

        private static string Name(string traitId)
        {
            try
            {
                string v = LocalizedTextManager.getText("trait_" + traitId, null, false);
                if (!string.IsNullOrEmpty(v) && v != "trait_" + traitId) return v;
            }
            catch { }
            return traitId;
        }
    }
}
