using System.Collections.Generic;
using UnityEngine;

namespace SevenDeadlySins
{
    /// Las magias con NOMBRE del resto del elenco: los compañeros de Percival, los Caballeros del
    /// Caos de Camelot, los grupos de Caballeros Sagrados (Dawn Roar, Pleiades, Colmillos Raros) y
    /// las magias propias de los Cuatro Jinetes que no son la Onda del Caos.
    ///
    /// Sigue el mismo patron que Liones.cs: cada magia es un trait con su Nivel de Poder y un
    /// comportamiento propio que corre SOLO en los personajes con nombre (los genericos usan
    /// KnightPowers o la magia racial). Asi Lancelot pelea como Lancelot y no como un humano con una
    /// espada mas cara. Los numeros son la clase de combate de Caballero Sagrado de la serie
    /// (~1.000-4.400): el rango y el clan suman encima.
    public static class LegendMagic
    {
        // --- Cuatro Jinetes del Apocalipsis ------------------------------------
        public const string Hope = "sds_ability_hope";               // Percival
        public const string Perception = "sds_ability_perception";   // Lancelot
        public const string Compassion = "sds_ability_compassion";   // Tristan

        // --- Caballeros del Caos de Camelot ------------------------------------
        public const string PurgatoryFlame = "sds_ability_purgatory_flame"; // Ironside
        public const string Salamander = "sds_ability_salamander";          // Pellegarde

        // --- Compañeros de Percival --------------------------------------------
        public const string Venom = "sds_ability_venom";             // Nasiens
        public const string Telekinesis = "sds_ability_telekinesis"; // Donny
        public const string Insight = "sds_ability_insight";         // Anne (ve la verdad)

        // --- Caballeros Sagrados de Liones (grupos) ----------------------------
        public const string Overpower = "sds_ability_overpower";     // Slader (Dawn Roar)
        public const string Snipe = "sds_ability_snipe";             // Weinheidt (Dawn Roar)
        public const string Melody = "sds_ability_melody";           // Deathpierce (Pleiades)
        public const string Judgement = "sds_ability_judgement";     // Denzel (Pleiades)
        public const string Vanish = "sds_ability_vanish";           // Golgius (Colmillos Raros)
        public const string Swarm = "sds_ability_swarm";             // Friesia (Colmillos Raros)
        public const string Hex = "sds_ability_hex";                 // Vivian (maga de Liones)

        private const string Group = TraitGroups.KnightMagic;

        public static void Init()
        {
            A(Hope, "Esperanza",
                "La magia heroica de Percival. Crece con la fe de quienes lo rodean: cuantos mas "
                + "aliados cerca, mas fuerte pega y mas los cura.",
                spi: 500f, mag: 1400f);

            A(Perception, "Percepcion",
                "La magia de Lancelot, el mas fuerte de los Cuatro Jinetes. Lee la mente y ve el "
                + "instante siguiente: sus flechas de luz no fallan y esquiva lo que aun no ha pasado.",
                str: 1800f, spi: 1400f, mag: 1200f);

            A(Compassion, "Compasion",
                "La magia de Tristan, hijo de Meliodas y Elizabeth. Cura a los suyos con luz de diosa; "
                + "cuando la sangre de demonio despierta, esa misma mano quema.",
                spi: 1500f, mag: 1600f);

            A(PurgatoryFlame, "Llama del Purgatorio",
                "La magia del Caballero del Caos Ironside. Fuego negro amplificado por su Baculo del "
                + "Caos: lo que prende no se cierra.",
                spi: 600f, mag: 1400f);

            A(Salamander, "Salamandra",
                "La magia del Caballero del Caos Pellegarde. Invoca una bestia de fuego que arrasa "
                + "todo lo que tiene delante.",
                str: 1200f, spi: 800f, mag: 1000f);

            A(Venom, "Veneno",
                "La magia de Nasiens, aprendiz de herborista. Su toxina ahoga por dentro y no deja "
                + "de obrar mientras el cuerpo aguante.",
                spi: 400f, mag: 900f);

            A(Telekinesis, "Levitacion",
                "La magia de Donny. Levanta lo que hay alrededor y lo lanza, y se aparta a si mismo "
                + "del suelo cuando conviene.",
                spi: 500f, mag: 800f);

            A(Insight, "Discernimiento",
                "El don de Anne: ve la mentira en cuanto se dice. En el fragor, la verdad de su bando "
                + "los sostiene — cura y bendice a los suyos.",
                spi: 700f, mag: 500f);

            A(Overpower, "Dominio",
                "La magia de Slader, capitan de Rugido del Alba. Aplasta la voluntad del enemigo y lo "
                + "deja clavado donde esta.",
                str: 1200f, spi: 900f, mag: 500f);

            A(Snipe, "Puntería",
                "La magia de Weinheidt, de Rugido del Alba. Su flecha alcanza al mas lejano y "
                + "atraviesa lo que se cruce.",
                str: 900f, spi: 500f, mag: 700f);

            A(Melody, "Melodia",
                "La magia de Deathpierce, de las Pleyades. Interfiere en el ritmo de los movimientos "
                + "del enemigo y lo desbarata.",
                spi: 700f, mag: 1200f);

            A(Judgement, "Juicio",
                "La magia de Denzel, de las Pleyades. Llama a las almas de los muertos para que "
                + "atormenten a quien las mando alli.",
                spi: 900f, mag: 1300f);

            A(Vanish, "Invisibilidad",
                "La magia de Golgius, de los Colmillos Raros. Desaparece de la vista y golpea desde "
                + "donde nadie lo espera.",
                str: 700f, mag: 500f);

            A(Swarm, "Enjambre",
                "La magia de Friesia, de los Colmillos Raros. Un enjambre de insectos que cubre y "
                + "devora todo un frente.",
                spi: 400f, mag: 800f);

            A(Hex, "Maleficio",
                "La magia de Vivian, la maga de Liones. Encadena, petrifica y encierra a quien se le "
                + "antoja en una jaula de la que no se sale.",
                spi: 600f, mag: 1600f);

            SDSTick.Register(Tick);
        }

        private static void A(string id, string nameEs, string infoEs,
                              float str = 0f, float spi = 0f, float mag = 0f,
                              float damage = 0f, float armor = 0f)
        {
            if (AssetManager.traits.dict.ContainsKey(id)) return;

            ActorTrait t = SDSRegistry.Trait(id, Group, "ui/icons/" + id);
            t.type = TraitType.Positive;
            PowerLevel.Grant(t, str, spi, mag);
            if (damage != 0f) t.base_stats["damage"] = damage;
            if (armor != 0f) t.base_stats["armor"] = armor;

            SDSRegistry.AddTrait(t);
            SDSLocale.Trait(id, nameEs, infoEs);

            // Letra gris: como se consigue. Es la magia de firma de un personaje de leyenda; se
            // consigue invocando a ese personaje, y a veces la hereda un hijo suyo.
            SDSLocale.TraitLore(id, "Magia de firma de un personaje de leyenda. La trae su portador "
                + "cuando lo invocas, y un hijo suyo puede heredarla con suerte.");
        }

        // ---------------------------------------------------------------- comportamiento

        private static float CD(float s)
        {
            return SDSConfig.AbilityCooldowns ? s : 0.2f;
        }

        private static Actor NearestEnemy(Actor a, float radius)
        {
            List<Actor> near = SDSUnit.Around(a, radius);
            for (int i = 0; i < near.Count; i++)
            {
                Actor o = near[i];
                if (o != null && o.isAlive() && o.kingdom != a.kingdom) return o;
            }
            return null;
        }

        private static Actor FarthestEnemy(Actor a, float radius)
        {
            List<Actor> near = SDSUnit.Around(a, radius);
            Actor far = null;
            for (int i = 0; i < near.Count; i++)
            {
                Actor o = near[i];
                if (o != null && o.isAlive() && o.kingdom != a.kingdom) far = o;
            }
            return far;
        }

        private static void Tick(Actor a, float dt)
        {
            if (a == null || !a.isAlive() || a.data == null) return;

            // Solo los personajes con nombre. La marca saca a la poblacion antes de nada.
            if (!SDSUnit.RunsAbilities(a)) return;
            if (Curses.Incapacitated(a)) return;

            // Las de apoyo obran aunque no haya objetivo (curan, bendicen).
            if (a.hasTrait(Hope)) TickHope(a);
            if (a.hasTrait(Compassion)) TickCompassion(a);
            if (a.hasTrait(Insight)) TickInsight(a);

            if (!a.has_attack_target) return;

            if (a.hasTrait(Perception)) TickPerception(a);
            if (a.hasTrait(PurgatoryFlame)) TickPurgatoryFlame(a);
            if (a.hasTrait(Salamander)) TickSalamander(a);
            if (a.hasTrait(Venom)) TickVenom(a);
            if (a.hasTrait(Telekinesis)) TickTelekinesis(a);
            if (a.hasTrait(Overpower)) TickOverpower(a);
            if (a.hasTrait(Snipe)) TickSnipe(a);
            if (a.hasTrait(Melody)) TickMelody(a);
            if (a.hasTrait(Judgement)) TickJudgement(a);
            if (a.hasTrait(Vanish)) TickVanish(a);
            if (a.hasTrait(Swarm)) TickSwarm(a);
            if (a.hasTrait(Hex)) TickHex(a);
        }

        /// Percival. Cuenta a los aliados cerca: cura a todos y pega mas fuerte cuantos mas haya.
        private static void TickHope(Actor a)
        {
            if (!SDSData.TryUse(a, "hope", CD(5f))) return;

            List<Actor> near = SDSUnit.Around(a, 11f);
            int allies = 0;
            bool used = false;
            for (int i = 0; i < near.Count; i++)
            {
                Actor o = near[i];
                if (o == null || !o.isAlive() || o == a) continue;
                if (SDSUnit.IsAlly(a, o))
                {
                    allies++;
                    if (o.data != null && o.data.health < o.getMaxHealth())
                    {
                        try { o.restoreHealth(Mathf.Max(1, Mathf.RoundToInt(6f + PowerLevel.Magic(a) * 0.03f))); used = true; }
                        catch { }
                    }
                }
            }

            // La fe de los que lo rodean se convierte en golpe.
            Actor enemy = NearestEnemy(a, 12f);
            if (enemy != null)
            {
                float power = 10f + PowerLevel.Magic(a) * 0.05f + allies * 6f;
                try { enemy.getHit(power, true, AttackType.Other, a, true); used = true; }
                catch { }
                SDSFx.At(enemy, "sds_fx_sunshine", 0.4f);
            }

            if (used) SDSFx.At(a, "sds_fx_heal", 0.4f);
        }

        /// Lancelot. Flecha de luz al enemigo mas lejano, sin fallo, y se cubre de una guardia que
        /// ve venir el golpe.
        private static void TickPerception(Actor a)
        {
            if (!SDSData.TryUse(a, "perception", CD(5f))) return;

            Actor target = FarthestEnemy(a, 17f);
            if (target == null) return;

            SDSFx.Projectile(a, target, Projectiles.Ark);
            try { target.getHit(20f + PowerLevel.Strength(a) * 0.05f + PowerLevel.Magic(a) * 0.04f, true, AttackType.Other, a, true); }
            catch { return; }
            SDSFx.At(target, "sds_fx_flash", 0.5f);
        }

        /// Tristan. Cura a los suyos con luz; si hay enemigo cerca, la sangre de demonio quema.
        private static void TickCompassion(Actor a)
        {
            if (!SDSData.TryUse(a, "compassion", CD(4f))) return;

            float mag = PowerLevel.Magic(a);
            bool used = false;
            List<Actor> near = SDSUnit.Around(a, 12f);
            for (int i = 0; i < near.Count; i++)
            {
                Actor o = near[i];
                if (o == null || !o.isAlive() || o == a) continue;
                if (SDSUnit.IsAlly(a, o) && o.data != null && o.data.health < o.getMaxHealth())
                {
                    try { o.restoreHealth(Mathf.Max(1, Mathf.RoundToInt(10f + mag * 0.05f))); used = true; }
                    catch { }
                    SDSStatus.Inflict(o, "sds_status_ark_blessing", 10f);
                }
            }
            if (used) SDSFx.At(a, "sds_fx_ark", 0.6f);

            Actor enemy = NearestEnemy(a, 10f);
            if (enemy != null)
            {
                SDSFx.Projectile(a, enemy, Projectiles.Hellblaze);
                try { enemy.getHit(12f + mag * 0.05f, true, AttackType.Fire, a, true); }
                catch { return; }
                SDSStatus.Inflict(enemy, "sds_status_hellblaze", 8f);
            }
        }

        /// Ironside. Fuego negro que no deja cerrar la herida, como la llama del Rey Demonio.
        private static void TickPurgatoryFlame(Actor a)
        {
            if (!SDSData.TryUse(a, "purgatory_flame", CD(6f))) return;

            Actor target = NearestEnemy(a, 12f);
            if (target == null) return;

            SDSFx.Projectile(a, target, Projectiles.Hellblaze);
            try { target.getHit(15f + PowerLevel.Magic(a) * 0.06f, true, AttackType.Fire, a, true); }
            catch { return; }
            SDSStatus.Inflict(target, "sds_status_hellblaze", 10f);
            SDSFx.At(target, "sds_fx_hellblaze", 0.5f);
        }

        /// Pellegarde. Una bestia de fuego que revienta en area.
        private static void TickSalamander(Actor a)
        {
            if (!SDSData.TryUse(a, "salamander", CD(7f))) return;

            Actor target = NearestEnemy(a, 12f);
            if (target == null) return;

            float power = 14f + PowerLevel.Magic(a) * 0.05f + PowerLevel.Strength(a) * 0.03f;
            List<Actor> blast = SDSUnit.Around(target, 4.5f);
            try { target.getHit(power, true, AttackType.Fire, a, true); }
            catch { return; }
            for (int i = 0; i < blast.Count; i++)
            {
                Actor o = blast[i];
                if (o == null || !o.isAlive() || o.kingdom == a.kingdom) continue;
                try { o.getHit(power * 0.6f, true, AttackType.Fire, a, true); }
                catch { }
            }
            SDSFx.At(target, "sds_fx_hellblaze", 0.6f);
            SDSFx.Wave(target, 2.5f, 1.5f);
        }

        /// Nasiens. Toxina que ahoga por dentro.
        private static void TickVenom(Actor a)
        {
            if (!SDSData.TryUse(a, "venom", CD(6f))) return;

            Actor target = NearestEnemy(a, 10f);
            if (target == null) return;

            SDSFx.Projectile(a, target, Projectiles.Magic);
            try { target.getHit(8f + PowerLevel.Magic(a) * 0.04f, true, AttackType.Other, a, true); }
            catch { return; }
            SDSStatus.Inflict(target, Curses.Drowning, 8f);
            SDSFx.At(target, "sds_fx_soul", 0.4f);
        }

        /// Donny. Levanta y lanza lo que hay alrededor: empuje en area.
        private static void TickTelekinesis(Actor a)
        {
            if (!SDSData.TryUse(a, "telekinesis", CD(7f))) return;

            float power = 9f + PowerLevel.Magic(a) * 0.04f;
            List<Actor> near = SDSUnit.Around(a, 8f);
            bool used = false;
            for (int i = 0; i < near.Count; i++)
            {
                Actor o = near[i];
                if (o == null || !o.isAlive() || o.kingdom == a.kingdom) continue;
                try { o.getHit(power, true, AttackType.Other, a, true); used = true; }
                catch { }
            }
            if (used) SDSFx.At(a, "sds_fx_creation", 0.5f);
        }

        /// Anne. Bendice y cura a los suyos: la verdad que sostiene al bando.
        private static void TickInsight(Actor a)
        {
            if (!SDSData.TryUse(a, "insight", CD(6f))) return;

            bool used = false;
            List<Actor> near = SDSUnit.Around(a, 10f);
            for (int i = 0; i < near.Count; i++)
            {
                Actor o = near[i];
                if (o == null || !o.isAlive()) continue;
                if (!SDSUnit.IsAlly(a, o)) continue;
                if (o.data != null && o.data.health < o.getMaxHealth())
                {
                    try { o.restoreHealth(Mathf.Max(1, Mathf.RoundToInt(6f + PowerLevel.Spirit(a) * 0.03f))); used = true; }
                    catch { }
                }
                SDSStatus.Inflict(o, "sds_status_ark_blessing", 8f);
            }
            if (used) SDSFx.At(a, "sds_fx_heal", 0.4f);
        }

        /// Slader. Aplasta y clava al enemigo donde esta.
        private static void TickOverpower(Actor a)
        {
            if (!SDSData.TryUse(a, "overpower", CD(6f))) return;

            Actor target = NearestEnemy(a, 9f);
            if (target == null) return;

            try { target.getHit(18f + PowerLevel.Strength(a) * 0.05f, true, AttackType.Other, a, true); }
            catch { return; }
            SDSStatus.Inflict(target, Curses.Paralyzed, 4f);
            SDSFx.At(target, "sds_fx_creation", 0.5f);
        }

        /// Weinheidt. Flecha al mas lejano, que atraviesa.
        private static void TickSnipe(Actor a)
        {
            if (!SDSData.TryUse(a, "snipe", CD(5f))) return;

            Actor target = FarthestEnemy(a, 18f);
            if (target == null) return;

            SDSFx.Projectile(a, target, Projectiles.Magic);
            try { target.getHit(16f + PowerLevel.Strength(a) * 0.05f, true, AttackType.Other, a, true); }
            catch { return; }
            SDSFx.At(target, "sds_fx_flash", 0.35f);
        }

        /// Deathpierce. Rompe el ritmo del enemigo: lo debilita y lo traba.
        private static void TickMelody(Actor a)
        {
            if (!SDSData.TryUse(a, "melody", CD(6f))) return;

            Actor target = NearestEnemy(a, 11f);
            if (target == null) return;

            try { target.getHit(11f + PowerLevel.Magic(a) * 0.05f, true, AttackType.Other, a, true); }
            catch { return; }
            SDSStatus.Inflict(target, Curses.Ash, 6f);
            SDSStatus.Inflict(target, Curses.Paralyzed, 2f);
            SDSFx.At(target, "sds_fx_ash", 0.4f);
        }

        /// Denzel. Las almas de los muertos atormentan al enemigo.
        private static void TickJudgement(Actor a)
        {
            if (!SDSData.TryUse(a, "judgement", CD(7f))) return;

            Actor target = NearestEnemy(a, 12f);
            if (target == null) return;

            SDSFx.Projectile(a, target, Projectiles.Ark);
            try { target.getHit(13f + PowerLevel.Magic(a) * 0.05f, true, AttackType.Other, a, true); }
            catch { return; }
            SDSStatus.Inflict(target, Curses.SoulStolen, 7f);
            SDSFx.At(target, "sds_fx_soul", 0.5f);
        }

        /// Golgius. Desaparece y golpea por la espalda: un solo tajo brutal.
        private static void TickVanish(Actor a)
        {
            if (!SDSData.TryUse(a, "vanish", CD(6f))) return;

            Actor target = NearestEnemy(a, 8f);
            if (target == null) return;

            try { target.getHit(24f + PowerLevel.Strength(a) * 0.06f, true, AttackType.Other, a, true); }
            catch { return; }
            SDSFx.At(target, "sds_fx_snatch", 0.5f);
        }

        /// Friesia. Un enjambre que cubre el frente y ahoga.
        private static void TickSwarm(Actor a)
        {
            if (!SDSData.TryUse(a, "swarm", CD(7f))) return;

            float power = 7f + PowerLevel.Magic(a) * 0.04f;
            List<Actor> near = SDSUnit.Around(a, 9f);
            bool used = false;
            for (int i = 0; i < near.Count; i++)
            {
                Actor o = near[i];
                if (o == null || !o.isAlive() || o.kingdom == a.kingdom) continue;
                try { o.getHit(power, true, AttackType.Other, a, true); used = true; }
                catch { }
                SDSStatus.Inflict(o, Curses.Drowning, 5f);
            }
            if (used) SDSFx.At(a, "sds_fx_curse", 0.5f);
        }

        /// Vivian. Encadena y petrifica: una jaula de la que no se sale.
        private static void TickHex(Actor a)
        {
            if (!SDSData.TryUse(a, "hex", CD(7f))) return;

            Actor target = NearestEnemy(a, 12f);
            if (target == null) return;

            SDSFx.Projectile(a, target, Projectiles.Magic);
            try { target.getHit(10f + PowerLevel.Magic(a) * 0.05f, true, AttackType.Other, a, true); }
            catch { return; }
            SDSStatus.Inflict(target, Curses.Petrified, 4f);
            SDSFx.At(target, "sds_fx_petrify", 0.5f);
        }
    }
}
