using System.Collections.Generic;
using UnityEngine;

namespace SevenDeadlySins
{
    /// The Four Archangels and their graces.
    ///
    /// Ludociel, Sariel and Tarmiel get an ability each; Mael's is Sunshine, which already exists —
    /// he is the one the grace was TAKEN from, and giving him a second copy would be wrong twice
    /// over. So this file registers three traits, not four.
    ///
    /// Their graces are deliberately area-shaped rather than single-target. The Archangels are the
    /// Goddess Clan's answer to an army of demons, and each one reads as a weather event.
    public static class Archangels
    {
        public const string Flash = "sds_ability_flash";        // Ludociel
        public const string Tornado = "sds_ability_tornado";    // Sariel
        public const string Ocean = "sds_ability_ocean";        // Tarmiel

        /// El poder de la Diosa Suprema. Es el espejo del Rey Demonio y hasta ahora no existia:
        /// invocarla daba una diosa cualquiera con un nombre grande.
        public const string SupremeLight = "sds_supreme_light";

        /// El rango de Arcangel en si, aparte de la Gracia. Las Gracias (Flash, Torbellino, Oceano)
        /// son HABILIDADES y se heredan; el poder canonico de un Arcangel (~180.000: Ludociel se cita
        /// en 201.000) no debe heredarse suelto, igual que el rasgo de Pecado no se hereda. Por eso
        /// vive en su propio rasgo de identidad y no en la Gracia. Mael NO lo lleva: su poder es
        /// Sunshine, que fluctua con el sol como el de Escanor.
        public const string Archangel = "sds_archangel";

        public static readonly string[] All = { Flash, Tornado, Ocean };

        private const string Group = TraitGroups.Grace;

        public static void Init()
        {
            Grace(Flash, "Flash",
                "Gracia de Ludociel. Cae como un rayo sobre varios enemigos a la vez y no se puede esquivar.",
                60f, 120f, 260f);

            Grace(Tornado, "Torbellino",
                "Gracia de Sariel. Levanta un viento que arrastra y despedaza a todo lo que rodea.",
                90f, 90f, 220f);

            Grace(Ocean, "Oceano",
                "Gracia de Tarmiel. El agua envuelve a los enemigos y cura a los suyos al mismo tiempo.",
                40f, 150f, 240f);

            Rank();
            Supreme();
            SDSTick.Register(Tick);
        }

        /// El rango de Arcangel. Los Cuatro Arcangeles son la respuesta del Clan de las Diosas a un
        /// ejercito de demonios: en la serie rivalizan con los Demonios Originales (Chandler 173.000,
        /// Cusack 168.000) y con el Meliodas de Modo Asalto (142.000), y a Ludociel se le cita en
        /// 201.000. 40+70+70 = 180.000, con la magia y el espiritu por delante: son luz.
        private static void Rank()
        {
            if (AssetManager.traits.dict.ContainsKey(Archangel)) return;

            ActorTrait t = SDSRegistry.Trait(Archangel, TraitGroups.Grace, "ui/icons/sds_archangel");
            t.type = TraitType.Positive;
            PowerLevel.Grant(t, 40000f, 70000f, 70000f);
            t.base_stats["health"] = 3200f;
            t.base_stats["damage"] = 170f;
            t.base_stats["armor"] = 90f;
            t.base_stats["multiplier_lifespan"] = 15f;

            SDSRegistry.AddTrait(t);
            SDSLocale.Trait(Archangel, "Arcangel",
                "Uno de los Cuatro Arcangeles, generales del Clan de las Diosas en la Guerra Santa.");
            SDSLocale.TraitLore(Archangel, "Lo llevan Ludociel, Sariel y Tarmiel cuando los invocas. "
                + "Rango de general de las diosas: clase de combate de unos 180.000, a la altura de "
                + "los Demonios Originales.");
        }

        /// La Diosa Suprema. Mismos ordenes de magnitud que el Rey Demonio, y su aura hace justo lo
        /// contrario que la de el: cura a los suyos y quema a los demonios en vez de al reves.
        private static void Supreme()
        {
            if (AssetManager.traits.dict.ContainsKey(SupremeLight)) return;

            ActorTrait t = SDSRegistry.Trait(SupremeLight, TraitGroups.Grace, "ui/icons/sds_supreme_light");
            t.type = TraitType.Positive;
            // El espejo exacto del Rey Demonio: un millon, los dos supremos hechos el uno del otro.
            // 260+350+390 = 1.000.000, con la magia por delante porque su fuerza es la luz.
            PowerLevel.Grant(t, 260000f, 350000f, 390000f);
            t.base_stats["health"] = 5000f;
            t.base_stats["damage"] = 250f;
            t.base_stats["armor"] = 120f;
            t.base_stats["multiplier_lifespan"] = 20f;

            SDSRegistry.AddTrait(t);
            SDSLocale.Trait(SupremeLight, "Luz Suprema",
                "El poder de la Diosa Suprema. Su luz cierra las heridas de los suyos y consume a los demonios.");
        }

        private static void Grace(string id, string nameEs, string infoEs, float str, float spi, float mag)
        {
            if (AssetManager.traits.dict.ContainsKey(id)) return;

            ActorTrait t = SDSRegistry.Trait(id, Group, "ui/icons/" + id);
            t.type = TraitType.Positive;
            PowerLevel.Grant(t, str, spi, mag);
            SDSRegistry.AddTrait(t);
            SDSLocale.Trait(id, nameEs, infoEs);
        }

        // ---------------------------------------------------------------- behaviour

        private const float FlashRadius = 13f;
        private const float TornadoRadius = 8f;
        private const float OceanRadius = 11f;

        private static void Tick(Actor a, float dt)
        {
            if (!SDSUnit.RunsAbilities(a)) return;
            if (!a.isAlive() || a.data == null) return;

            // A petrified archangel does not call down lightning. Every active ability in the mod
            // should be asking this.
            if (Curses.Incapacitated(a)) return;

            if (a.hasTrait(SupremeLight)) TickSupreme(a);
            if (a.hasTrait(Flash)) TickFlash(a);
            if (a.hasTrait(Tornado)) TickTornado(a);
            if (a.hasTrait(Ocean)) TickOcean(a);
        }

        private static float CD(float s)
        {
            return SDSConfig.AbilityCooldowns ? s : 0.2f;
        }

        /// La Diosa Suprema. Aura constante, no un ataque: cura a todo aliado a la vista y consume a
        /// todo demonio, este o no en guerra con ella. Es la Guerra Santa hecha presencia.
        private static void TickSupreme(Actor a)
        {
            if (!SDSData.TryUse(a, "supreme", CD(2.5f))) return;

            float magic = PowerLevel.Magic(a);
            List<Actor> near = SDSUnit.Around(a, 14f);
            bool used = false;

            for (int i = 0; i < near.Count; i++)
            {
                Actor o = near[i];
                if (o == null || !o.isAlive() || o == a) continue;

                if (o.hasTrait(Clans.Demon))
                {
                    try { o.getHit(18f + magic * 0.05f, true, AttackType.Fire, a, true); used = true; }
                    catch { }
                    continue;
                }

                if (!SDSUnit.IsAlly(a, o)) continue;
                if (o.data == null || o.data.health >= o.getMaxHealth()) continue;

                try { o.restoreHealth(Mathf.Max(1, Mathf.RoundToInt(14f + magic * 0.05f))); used = true; }
                catch { }
                SDSStatus.Inflict(o, "sds_status_ark_blessing", 14f);
            }

            if (used) SDSFx.At(a, "sds_fx_ark", 0.8f);
        }

        /// Ludociel. Strikes SEVERAL enemies at once — that is what makes it Flash rather than a
        /// bolt, and it is why it hits hardest against a crowd.
        private static void TickFlash(Actor a)
        {
            if (!a.has_attack_target) return;
            if (!SDSData.TryUse(a, "flash", CD(6f))) return;

            float power = 14f + PowerLevel.Magic(a) * 0.05f;
            int struck = 0;

            List<Actor> nearby = SDSUnit.Around(a, FlashRadius);
            for (int i = 0; i < nearby.Count && struck < 4; i++)
            {
                Actor o = nearby[i];
                if (o == null || !o.isAlive() || o.kingdom == a.kingdom) continue;

                try { o.getHit(power, true, AttackType.Other, a, true); }
                catch { continue; }

                SDSFx.At(o, "sds_fx_flash", 0.45f);
                struck++;
            }
        }

        /// Sariel. Tight radius, heavy knockback, hits everything hostile inside it.
        private static void TickTornado(Actor a)
        {
            if (!a.has_attack_target) return;
            if (!SDSData.TryUse(a, "tornado", CD(7f))) return;

            float power = 9f + PowerLevel.Magic(a) * 0.04f;
            bool used = false;

            List<Actor> nearby = SDSUnit.Around(a, TornadoRadius);
            for (int i = 0; i < nearby.Count; i++)
            {
                Actor o = nearby[i];
                if (o == null || !o.isAlive() || o.kingdom == a.kingdom) continue;

                try { o.getHit(power, true, AttackType.Other, a, true); used = true; }
                catch { }
            }

            if (used) SDSFx.At(a, "sds_fx_tornado", 0.7f);
        }

        /// Tarmiel. The only grace that does both jobs in one pass: drowns the enemy, mends the ally.
        private static void TickOcean(Actor a)
        {
            if (!SDSData.TryUse(a, "ocean", CD(6f))) return;

            float magic = PowerLevel.Magic(a);
            bool used = false;

            List<Actor> nearby = SDSUnit.Around(a, OceanRadius);
            for (int i = 0; i < nearby.Count; i++)
            {
                Actor o = nearby[i];
                if (o == null || !o.isAlive()) continue;

                if (SDSUnit.IsAlly(a, o))
                {
                    if (o.data == null || o.data.health >= o.getMaxHealth()) continue;
                    try { o.restoreHealth(Mathf.Max(1, Mathf.RoundToInt(9f + magic * 0.04f))); used = true; }
                    catch { }
                }
                else
                {
                    try { o.getHit(8f + magic * 0.035f, true, AttackType.Other, a, true); }
                    catch { continue; }

                    // Drowning on dry land, exactly like the Commandment of Purity's toll.
                    SDSStatus.Inflict(o, Curses.Drowning, 6f);
                    used = true;
                }
            }

            if (used) SDSFx.At(a, "sds_fx_ocean", 0.6f);
        }
    }
}
