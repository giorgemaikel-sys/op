using System.Collections.Generic;

namespace SevenDeadlySins
{
    /// Quien reina sobre su pueblo toma el rasgo de rey de su raza.
    ///
    /// El usuario lo pidio: el que se convierta en rey del pueblo de los demonios toma el rasgo del
    /// Rey Demonio, y lo mismo para gigantes, hadas, diosas, humanos y vampiros. Un rey no es un
    /// aldeano con corona: lleva el poder de su pueblo entero.
    ///
    /// Se detecta con `Actor.isKing()` (el rey de un reino) y se mira su clan. No hace falta mirar la
    /// raza del reino: el rey de un reino de demonios es un demonio. La comprobacion es barata —
    /// `isKing()` saca a casi toda la poblacion antes de tocar nada.
    ///
    /// Estos NO son el rasgo-jefe del Rey Demonio (que anda por el millon de poder): son rasgos
    /// de rey dedicados, fuertes pero sin romper el juego, porque puede haber varios reinos por raza.
    public static class RacialKings
    {
        public const string DemonKingTrait = "sds_king_demon";
        public const string GoddessKing = "sds_king_goddess";
        public const string FairyKing = "sds_king_fairy";
        public const string GiantKing = "sds_king_giant";
        public const string VampireKing = "sds_king_vampire";
        public const string HumanKing = "sds_king_human";

        /// clan -> rasgo de rey de ese clan.
        private static readonly Dictionary<string, string> _kingFor = new Dictionary<string, string>();

        public static void Init()
        {
            King(DemonKingTrait, Clans.Demon, "Rey del Clan de los Demonios",
                "Reina sobre los demonios. Lleva en si el poder del Rey Demonio.",
                2200f, 1400f, 1800f, 900f, 70f, 30f, "sds_clan_demon");
            King(GoddessKing, Clans.Goddess, "Reina del Clan de las Diosas",
                "Reina sobre las diosas, bajo la luz de la Diosa Suprema.",
                1200f, 2200f, 2400f, 800f, 40f, 20f, "sds_clan_goddess");
            King(FairyKing, Clans.Fairy, "Rey del Bosque de las Hadas",
                "El senor del Bosque del Rey Hada.",
                1000f, 1800f, 1900f, 700f, 40f, 15f, "sds_clan_fairy");
            King(GiantKing, Clans.Giant, "Rey del Clan de los Gigantes",
                "El mayor de los gigantes, senor del Calabozo.",
                2800f, 900f, 700f, 1400f, 90f, 45f, "sds_clan_giant");
            King(VampireKing, Clans.Vampire, "Rey de los Vampiros",
                "El senor de Edimburgo, el mas viejo de la sangre.",
                1800f, 1000f, 1100f, 800f, 60f, 25f, "sds_clan_vampire");
            King(HumanKing, Clans.Human, "Gran Rey de Britannia",
                "El rey de un pueblo humano. Los humanos gobiernan cuando saben mandar.",
                1000f, 1000f, 1000f, 700f, 45f, 20f, "sds_clan_human");

            SDSTick.Register(Tick);
        }

        private static void King(string id, string clan, string nameEs, string infoEs,
                                 float str, float spi, float mag, float health, float damage, float armor,
                                 string iconClan)
        {
            if (!AssetManager.traits.dict.ContainsKey(id))
            {
                ActorTrait t = SDSRegistry.Trait(id, TraitGroups.Bloodline, "ui/icons/" + id);
                t.type = TraitType.Positive;
                PowerLevel.Grant(t, str, spi, mag);
                t.base_stats["health"] = health;
                t.base_stats["damage"] = damage;
                t.base_stats["armor"] = armor;
                t.base_stats["multiplier_lifespan"] = 10f;      // un rey vive lo suyo

                SDSRegistry.AddTrait(t);
                SDSLocale.Trait(id, nameEs, infoEs);
            }
            _kingFor[clan] = id;
        }

        private static void Tick(Actor a, float dt)
        {
            if (a == null || !a.isAlive() || a.data == null) return;

            // La puerta barata: casi nadie es rey. Solo despues se mira el clan.
            bool king;
            try { king = a.isKing(); }
            catch { return; }
            if (!king) return;

            string clan = SDSUnit.ClanOf(a);
            if (clan == null) return;

            string kingTrait;
            if (!_kingFor.TryGetValue(clan, out kingTrait)) return;
            if (a.hasTrait(kingTrait)) return;      // ya lo tiene

            SDSTraits.Give(a, kingTrait);
            SDSFx.At(a, "sds_fx_demon_king", 0.7f);
            SDSLog.Chronicle(SDSLocale.T(
                a.getName() + " se ha alzado como rey de su pueblo.",
                a.getName() + " has risen as king of their people."));
        }
    }
}
