using System.Collections.Generic;

namespace SevenDeadlySins
{
    /// The Seven Deadly Sins themselves: seven exclusive traits, seven active abilities, and the
    /// canon table that ties each sin to its beast, its bearer, its ability and its sacred treasure.
    ///
    /// This file OWNS the mapping. FullCounter, Snatch, Sunshine, SacredTreasures and Legends all ask
    /// here rather than keeping their own copy, so the canon lives in exactly one place and a typo in
    /// a treasure id cannot silently split the mod's idea of who owns Lostvayne.
    ///
    /// Only the traits and the data are here. The BEHAVIOUR of each ability belongs to its own file.
    public static class SevenSins
    {
        public const string Wrath = "sds_sin_wrath";
        public const string Greed = "sds_sin_greed";
        public const string Envy = "sds_sin_envy";
        public const string Lust = "sds_sin_lust";
        public const string Sloth = "sds_sin_sloth";
        public const string Gluttony = "sds_sin_gluttony";
        public const string Pride = "sds_sin_pride";

        public static readonly string[] All = { Wrath, Greed, Envy, Lust, Sloth, Gluttony, Pride };

        // ---- the seven signature abilities (behaviour lives elsewhere; these are the traits) ----

        public const string AbilityFullCounter = "sds_ability_full_counter";
        public const string AbilitySnatch = "sds_ability_snatch";
        public const string AbilityCreation = "sds_ability_creation";
        public const string AbilityInvasion = "sds_ability_invasion";
        public const string AbilityDisaster = "sds_ability_disaster";
        public const string AbilityInfinity = "sds_ability_infinity";
        public const string AbilitySunshine = "sds_ability_sunshine";

        public static readonly string[] AllAbilities =
        {
            AbilityFullCounter, AbilitySnatch, AbilityCreation, AbilityInvasion,
            AbilityDisaster, AbilityInfinity, AbilitySunshine
        };

        /// Meliodas' black flame. Registered by Abilities.cs (it is shared with the Demon King), but
        /// Bestow hands it out with Wrath, so the id is named here too.
        private const string AbilityHellblaze = "sds_ability_hellblaze";

        // Group ids are written out rather than read from TraitGroups so this file compiles even
        // while the content files are still being filled in. They are fixed by DESIGN.md section 1.
        private const string GroupSins = "sds_group_sins";
        private const string GroupAbilities = TraitGroups.SinPowers;

        // ---------------------------------------------------------------- canon table

        private sealed class SinDef
        {
            public string TitleEs;      // "Ira, el Pecado del Dragon"
            public string TitleEn;
            public string BeastEs;
            public string BeastEn;
            public string Bearer;       // proper noun: identical in both languages
            public string Ability;      // trait id
            public string Treasure;     // item id
            public string Clan;         // the blood the bearer is born of
        }

        private static readonly Dictionary<string, SinDef> Table = new Dictionary<string, SinDef>();

        public static void Init()
        {
            BuildTable();
            RegisterSins();
            RegisterAbilities();

            // One sin per bearer. This only takes effect because Main calls
            // SDSRegistry.ApplyOpposites() after the last trait in the mod is registered.
            SDSRegistry.Opposites(All);
        }

        private static void BuildTable()
        {
            Define(Wrath, "Ira, el Pecado del Dragon", "Wrath, the Dragon's Sin", "Dragon", "Dragon",
                   "Meliodas", AbilityFullCounter, "sds_item_lostvayne", Clans.Demon);

            Define(Greed, "Avaricia, el Pecado del Zorro", "Greed, the Fox's Sin", "Zorro", "Fox",
                   "Ban", AbilitySnatch, "sds_item_courechouse", Clans.Human);

            Define(Envy, "Envidia, el Pecado de la Serpiente", "Envy, the Serpent's Sin", "Serpiente", "Serpent",
                   "Diane", AbilityCreation, "sds_item_gideon", Clans.Giant);

            // Gowther is a doll built by a demon in his own image. Of the six clans the demon blood
            // is the only honest fit; "doll" is not a clan the series ever fields as one.
            Define(Lust, "Lujuria, el Pecado de la Cabra", "Lust, the Goat's Sin", "Cabra", "Goat",
                   "Gowther", AbilityInvasion, "sds_item_herritt", Clans.Demon);

            Define(Sloth, "Pereza, el Pecado del Oso Gris", "Sloth, the Grizzly's Sin", "Oso Gris", "Grizzly Bear",
                   "King", AbilityDisaster, "sds_item_chastiefol", Clans.Fairy);

            Define(Gluttony, "Gula, el Pecado del Jabali", "Gluttony, the Boar's Sin", "Jabali", "Boar",
                   "Merlin", AbilityInfinity, "sds_item_aldan", Clans.Human);

            Define(Pride, "Soberbia, el Pecado del Leon", "Pride, the Lion's Sin", "Leon", "Lion",
                   "Escanor", AbilitySunshine, "sds_item_rhitta", Clans.Human);
        }

        private static void Define(string id, string titleEs, string titleEn, string beastEs, string beastEn,
                                   string bearer, string ability, string treasure, string clan)
        {
            SinDef d = new SinDef();
            d.TitleEs = titleEs;
            d.TitleEn = titleEn;
            d.BeastEs = beastEs;
            d.BeastEn = beastEn;
            d.Bearer = bearer;
            d.Ability = ability;
            d.Treasure = treasure;
            d.Clan = clan;
            Table[id] = d;
        }

        // ---------------------------------------------------------------- the sins

        /// The three numbers on each line are the canon breakdown of that character's power level
        /// (strength / spirit / magic) as printed in the series, and they add up to the totals in
        /// DESIGN.md section 2. They are the whole point of the mod's signature stat, so they are
        /// written literally instead of being derived from a curve.
        private static void RegisterSins()
        {
            Sin(Wrath, 960f, 2010f, 400f,          // 3.370 (960 fuerza / 2.010 espiritu / 400 magia, el desglose exacto de la serie)
                1600f, 190f, 45f, 14f, 0.30f,
                "El Pecado del Dragon de la Ira. Meliodas, capitan de los Siete Pecados Capitales e "
                + "hijo del Rey Demonio. Cargo con la destruccion de Danafor y aun sonrie. Su Full "
                + "Counter devuelve la magia enemiga multiplicada.");

            Sin(Greed, 930f, 910f, 1380f,          // 3.220 (930 fuerza / 910 espiritu / 1.380 magia; Ban es mas magico de lo que parece)
                2200f, 150f, 35f, 12f, 0.25f,
                "El Pecado del Zorro de la Avaricia. Ban el Inmortal, el bandido que bebio de la "
                + "Fuente de la Juventud: la muerte no le retiene, y lo que codicia acaba siendo suyo.");

            Sin(Envy, 1500f, 1000f, 750f,          // 3.250 (Diane a tamano de giganta; la fuerza por delante)
                2400f, 170f, 70f, 4f, 0.10f,
                "El Pecado de la Serpiente de la Envidia. Diane, giganta del Clan de los Gigantes, "
                + "que moldea la tierra con Creation y envidia lo que nunca podra ser: pequena.");

            Sin(Lust, 500f, 1300f, 1300f,          // 3.100 (500 fuerza / 1.300 espiritu / 1.300 magia, el desglose de la serie)
                1300f, 140f, 40f, 10f, 0.35f,
                "El Pecado de la Cabra de la Lujuria. Gowther, la muneca sin corazon creada a imagen "
                + "de un demonio. Invade la mente ajena y reescribe lo que encuentra dentro.");

            Sin(Sloth, 1070f, 1620f, 1500f,        // 4.190
                1500f, 175f, 40f, 12f, 0.20f,
                "El Pecado del Oso Gris de la Pereza. King, el Rey Hada Harlequin, que abandono su "
                + "bosque durante setecientos anos. Su lanza Chastiefol cambia de forma a su antojo.");

            Sin(Gluttony, 1000f, 1710f, 2000f,     // 4.710
                1400f, 200f, 55f, 8f, 0.20f,
                "El Pecado del Jabali de la Gula. Merlin, la maga de Belialuin, insaciable de todo "
                + "saber y de toda magia. Su Infinity hace eterno cuanto conjura.");

            // Escanor's trait carries his MIDNIGHT numbers on purpose: 5 + 5 + 5 = 15, exactly the
            // figure the series gives him at his weakest. Everything above that is daylight, and
            // daylight is Sunshine.cs's job through PowerLevel.AddContributor — baking a flat bonus
            // in here would quietly erase the night-time collapse that defines the character.
            // The combat stats below are the body he still has: enough to survive until dawn.
            Sin(Pride, 5f, 5f, 5f,                 // 15 at night; Sunshine multiplies it to 200.000+
                1200f, 60f, 30f, 6f, 0.15f,
                "El Pecado del Leon de la Soberbia. Escanor, el hombre mas fuerte del mundo a "
                + "mediodia y el mas debil a medianoche. Su poder sigue al sol, sin excepcion.");
        }

        private static void Sin(string id, float strength, float spirit, float magic,
                                float health, float damage, float armor, float speed, float crit,
                                string info)
        {
            // rate_inherit stays 0: a sin is a title granted by a king, never something a child is
            // born holding. SDSRegistry keeps rate_birth at 0 for the same reason.
            ActorTrait t = SDSRegistry.Trait(id, GroupSins, "ui/icons/" + id);

            PowerLevel.Grant(t, strength, spirit, magic);

            // The power level is the mod's headline number, but the game fights with these. Without
            // them a Sin would read as 3.370 in the panel and die to a wolf.
            t.base_stats.set("health", health);
            t.base_stats.set("damage", damage);
            t.base_stats.set("armor", armor);
            t.base_stats.set("speed", speed);
            t.base_stats.set("critical_chance", crit);

            // A Sin does not miss. Shared floor rather than a per-sin number.
            t.base_stats.set("accuracy", 0.45f);

            SDSRegistry.AddTrait(t);

            SinDef d;
            string name = Table.TryGetValue(id, out d) ? d.TitleEs : id;
            SDSLocale.Trait(id, name, info);
        }

        // ---------------------------------------------------------------- the abilities

        private static void RegisterAbilities()
        {
            // Las habilidades NO cargan poder: el Nivel de Poder canonico de cada Pecado vive en su
            // rasgo de Pecado (RegisterSins, Fuerza+Espiritu+Magia = la "clase de combate" de la
            // serie), que es donde estan las cifras del canon y el unico sitio que las cuenta. Aqui
            // la habilidad aporta solo su SABOR de combate (dano/armadura/critico), no numero de
            // poder — si tambien sumara poder, un Pecado leeria el DOBLE de su clase de combate y,
            // como la habilidad SI se hereda (Offspring) y el rasgo de Pecado no, los hijos la
            // heredarian inflada. El poder que hereda un hijo llega por KeyHyb (50% de cada padre),
            // no por esta via.
            Ability(AbilityFullCounter, 0f, 0f, 0f, 0f, 0f, 20f, 0.20f,   // Meliodas: poder en Wrath (~3.370)
                "Contraataque Total",
                "Devuelve multiplicado el ataque magico o a distancia que recibe. Contra un golpe "
                + "fisico directo no sirve de nada: hay que poder tocar la magia para devolverla.");

            Ability(AbilitySnatch, 0f, 0f, 0f, 0f, 25f, 0f, 0.15f,   // Ban: poder en Greed (~3.220)
                "Arrebatar",
                "Cada golpe roba para siempre una parte de la fuerza de la victima y la suma a la "
                + "propia. La avaricia convertida en un numero que solo sube.");

            Ability(AbilityCreation, 0f, 0f, 0f, 0f, 0f, 45f, 0f,   // Diane: poder en Envy (~3.055)
                "Creacion",
                "Moldea la tierra y la roca a voluntad: levanta el suelo bajo sus pies y lo lanza "
                + "hecho proyectil. La magia del Clan de los Gigantes.");

            Ability(AbilityInvasion, 0f, 0f, 0f, 30f, 0f, 0f, 0f,   // Gowther: poder en Lust (~3.100)
                "Invasion",
                "Magia mental: entra en la mente ajena, la vuelve a su bando o le borra los "
                + "recuerdos. Quien la sufre olvida hasta lo que era.");

            Ability(AbilityDisaster, 0f, 0f, 0f, 0f, 30f, 0f, 0f,   // King: poder en Sloth (~4.190)
                "Desastre",
                "Dominio sobre el espiritu y la naturaleza. Invoca la lanza sagrada Chastiefol en "
                + "todas sus formas y drena la vida de cuanto le rodea.");

            Ability(AbilityInfinity, 0f, 0f, 0f, 20f, 0f, 30f, 0f,   // Merlin: poder en Gluttony (~4.710)
                "Infinito",
                "Todo efecto que crea dura para siempre: sus hechizos no expiran nunca y ningun "
                + "estado negativo llega a prender en ella.");

            // Deliberately statless. Sunshine's entire contribution is a function of the world clock,
            // computed in Sunshine.cs; a flat bonus here would show up at midnight too and break the
            // one thing the ability is for. See DESIGN.md section 4.
            Ability(AbilitySunshine, 0f, 0f, 0f, 0f, 0f, 0f, 0f,
                "Sol Naciente",
                "La gracia que el Supremo Deidad concedio al Leon: su poder sigue al sol. Nulo a "
                + "medianoche, absoluto a mediodia, cuando se alza como The One.");
        }

        private static void Ability(string id, float strength, float spirit, float magic,
                                    float intelligence, float damage, float armor, float crit,
                                    string name, string info)
        {
            ActorTrait t = SDSRegistry.Trait(id, GroupAbilities, "ui/icons/" + id);

            PowerLevel.Grant(t, strength, spirit, magic);

            if (intelligence != 0f) t.base_stats.set("intelligence", intelligence);
            if (damage != 0f) t.base_stats.set("damage", damage);
            if (armor != 0f) t.base_stats.set("armor", armor);
            if (crit != 0f) t.base_stats.set("critical_chance", crit);

            SDSRegistry.AddTrait(t);
            SDSLocale.Trait(id, name, info);
        }

        // ---------------------------------------------------------------- the canon, as data

        /// The beast on the sin's crest, ready to print. Empty string for an unknown id.
        public static string BeastOf(string sinId)
        {
            SinDef d = Def(sinId);
            return d == null ? "" : SDSLocale.T(d.BeastEs, d.BeastEn);
        }

        /// The character who holds the sin in the series. A proper noun, so it is not translated.
        public static string BearerOf(string sinId)
        {
            SinDef d = Def(sinId);
            return d == null ? "" : d.Bearer;
        }

        /// The trait id of the sin's signature ability. Null for an unknown id.
        public static string AbilityOf(string sinId)
        {
            SinDef d = Def(sinId);
            return d == null ? null : d.Ability;
        }

        /// The item id of the sin's sacred treasure. SacredTreasures.cs reads this to decide who may
        /// wield what; nothing else should hard-code the pairing.
        public static string TreasureOf(string sinId)
        {
            SinDef d = Def(sinId);
            return d == null ? null : d.Treasure;
        }

        /// The clan the bearer is born of.
        public static string ClanOf(string sinId)
        {
            SinDef d = Def(sinId);
            return d == null ? null : d.Clan;
        }

        /// The full display title, e.g. "Ira, el Pecado del Dragon".
        public static string TitleOf(string sinId)
        {
            SinDef d = Def(sinId);
            return d == null ? "" : SDSLocale.T(d.TitleEs, d.TitleEn);
        }

        /// The sin whose signature ability this is, or null. Lets an ability handler find its owner
        /// without a second table.
        public static string SinOfAbility(string abilityId)
        {
            if (string.IsNullOrEmpty(abilityId)) return null;
            for (int i = 0; i < All.Length; i++)
            {
                SinDef d = Def(All[i]);
                if (d != null && d.Ability == abilityId) return All[i];
            }
            return null;
        }

        private static SinDef Def(string sinId)
        {
            if (string.IsNullOrEmpty(sinId)) return null;
            SinDef d;
            return Table.TryGetValue(sinId, out d) ? d : null;
        }

        // ---------------------------------------------------------------- granting a sin

        /// Makes a unit one of the Seven: the sin itself, its signature ability, the blood its bearer
        /// is born of, and the Special magic that DESIGN.md section 6 makes a prerequisite.
        ///
        /// This is the ONLY supported way to hand out a sin. Legends.cs uses it for the seven
        /// legendary spawns and the god-power button uses it for the player; both then get identical
        /// treatment, which is why the linked traits are not duplicated at either call site.
        public static void Bestow(Actor a, string sinId)
        {
            if (a == null || !a.isAlive()) return;

            SinDef d = Def(sinId);
            if (d == null)
            {
                SDSLog.Warn("Bestow: pecado desconocido '" + (sinId ?? "null") + "'");
                return;
            }

            // A sin is a title among thinking people. The birth pool is species-blind, which is why
            // nothing here is left to it — and why a bear must be refused out loud rather than
            // silently ignored. If a legendary spawn lands here, its race is missing from
            // SDSUnit.AllowRace in Actors.Init.
            if (!SDSUnit.IsSentient(a))
            {
                string race = a.asset != null ? a.asset.id : "?";
                SDSLog.Warn("Bestow: '" + race + "' no puede portar un Pecado Capital");
                SDSLog.Tip(SDSLocale.T("Solo un ser pensante puede portar un Pecado Capital",
                                       "Only a thinking being may bear a Deadly Sin"));
                return;
            }

            // GiveExclusive on top of the opposite lists: the sins are the most visible axis in the
            // mod, and a unit wearing two crests at once would be noticed immediately.
            SDSTraits.GiveExclusive(a, sinId, All);

            GiveLinked(a, d.Ability);
            GiveLinked(a, d.Clan);
            GiveLinked(a, MagicTypes.Special);

            // Meliodas' black flame is not a sin ability, but it is inseparable from him.
            if (sinId == Wrath) GiveLinked(a, AbilityHellblaze);

            SDSData.SetBool(a, SDSData.SinAssigned, true);

            SDSLog.Chronicle(SDSLocale.T(a.getName() + " ha despertado como " + d.TitleEs,
                                         a.getName() + " has awakened as " + d.TitleEn));
        }

        /// Gives a trait only if it actually exists.
        ///
        /// The linked traits come from files that load after this one (Abilities.cs) or that a player
        /// may have stripped out of the folder. Asking the dictionary first — rather than
        /// AssetManager.traits.get, which complains about ids it does not know — keeps a missing
        /// optional file from filling the log with errors on every spawn.
        private static void GiveLinked(Actor a, string traitId)
        {
            if (a == null || string.IsNullOrEmpty(traitId)) return;
            if (!AssetManager.traits.dict.ContainsKey(traitId)) return;
            SDSTraits.Give(a, traitId);
        }
    }
}
