using System.Collections.Generic;

namespace SevenDeadlySins
{
    /// La Guerra Santa: demonios contra diosas, PERO SOLO CUANDO SUS REINOS ESTAN EN GUERRA.
    ///
    /// El usuario lo pidio muchas veces: demonios y diosas no se pelean solos, solo durante la
    /// guerra. Antes esto se auto-declaraba en cuanto coexistian los dos clanes y los hacia chocar
    /// para siempre — "siempre en guerra". Ya no.
    ///
    /// Ahora el choque solo ocurre entre dos unidades cuyos reinos estan HOSTILES de verdad
    /// (`Clans.Hostile`, que mira la diplomacia y la guerra real). Como ademas se quito la enemistad
    /// permanente demonio-diosa del Feud, en paz `Hostile` es falso y no pasa nada; en una guerra de
    /// reinos, los dos bandos chocan con este dano extra por encima del combate normal. La Guerra
    /// Santa deja de ser una ley de la naturaleza y pasa a ser lo que es: una guerra.
    public static class HolyWar
    {
        /// Dano extra que los dos clanes se hacen cuando SUS REINOS estan en guerra.
        private const float ClashDamage = 3f;
        private const float ClashRadius = 6f;

        /// La FURIA DE LA GUERRA SANTA: cuando demonios y diosas chocan de verdad, la guerra milenaria
        /// se reaviva en ellos y pelean mas fuerte. Es un buff, no una obligacion — solo lo recibe
        /// quien YA esta chocando en una guerra real, asi que no rompe la paz.
        public const string StatusFrenzy = "sds_status_holy_war";

        /// Se anuncia la Guerra Santa una sola vez, cuando estalla el primer choque de verdad.
        private static bool _announced;

        public static void Init()
        {
            Frenzy();
            SDSTick.Register(TickActor);
        }

        private static void Frenzy()
        {
            if (AssetManager.status.dict.ContainsKey(StatusFrenzy)) return;
            StatusAsset s = SDSRegistry.Status(StatusFrenzy, "ui/icons/" + StatusFrenzy, 10f);
            PowerLevel.Grant(s, 1500f, 1500f, 1500f);
            s.base_stats["damage"] = 40f;
            s.base_stats["speed"] = 10f;
            s.removed_on_damage = false;
            SDSRegistry.AddStatus(s);
            SDSLocale.Status(StatusFrenzy, "Furia de la Guerra Santa",
                "La guerra milenaria entre demonios y diosas se reaviva. Pelea mas fuerte y mas rapido.");
        }

        private static void TickActor(Actor a, float dt)
        {
            if (a == null || !a.isAlive()) return;

            bool demon = a.hasTrait(Clans.Demon);
            bool goddess = !demon && a.hasTrait(Clans.Goddess);
            if (!demon && !goddess) return;

            if (!SDSData.TryUse(a, "holy_war", 3f)) return;

            List<Actor> nearby = SDSUnit.Around(a, ClashRadius);
            for (int i = 0; i < nearby.Count; i++)
            {
                Actor o = nearby[i];
                if (o == null || !o.isAlive()) continue;
                if (!SDSUnit.AreEnemyClans(a, o)) continue;

                // SOLO si sus reinos estan hostiles de verdad. En paz, un demonio y una diosa se
                // cruzan sin tocarse.
                if (!Clans.Hostile(a, o)) continue;

                try { o.getHit(ClashDamage, true, AttackType.Other, a, true); }
                catch { }

                // La guerra santa arde: los dos que chocan entran en furia.
                SDSStatus.Inflict(a, StatusFrenzy, 10f);
                SDSStatus.Inflict(o, StatusFrenzy, 10f);

                if (!_announced)
                {
                    _announced = true;
                    SDSLog.Chronicle(SDSLocale.T(
                        "Ha estallado la Guerra Santa: demonios y diosas se enfrentan de nuevo.",
                        "The Holy War has broken out: demons and goddesses clash once more."));
                }
                return;      // un choque por intervalo
            }
        }
    }
}
