using System.Collections.Generic;
using UnityEngine;

namespace SevenDeadlySins
{
    /// Meliodas. Reflects magic and ranged attacks back at their source, multiplied — and does
    /// nothing at all against a fist. That last part is not a limitation, it is the character: every
    /// fight Meliodas loses, he loses to someone who walked up and hit him.
    ///
    /// IMPLEMENTATION NOTE, because it is not the obvious one.
    ///
    /// The obvious build is a Harmony prefix on the damage path that cancels the hit and redirects it.
    /// This mod does not do that, deliberately. No damage-method signature was verifiable against this
    /// build, and the reference mod on this machine — sixty-plus systems, jutsu, tailed beasts —
    /// patches ONLY user-interface methods and never once touches combat. That is a strong signal
    /// from someone who has shipped against this game: a wrong prefix on a combat path corrupts
    /// worlds, and it corrupts them in saves.
    ///
    /// So instead this watches health. Each sweep it compares the bearer's health to what it was, and
    /// when it has dropped it looks for who could have done it. An attacker standing next to him is
    /// treated as a physical blow and ignored — exactly as in the manga. An enemy hurting him from
    /// beyond arm's reach can only be doing it with a spell or a projectile, and THAT is what comes
    /// back multiplied.
    ///
    /// The trade-off is honest: the reflection lands a fraction of a second after the hit rather than
    /// instead of it, and Meliodas takes the original damage before returning it. In exchange nothing
    /// here can corrupt a save.
    public static class FullCounter
    {
        public const string Ability = "sds_ability_full_counter";
        public const string StatusReady = "sds_status_full_counter_ready";
        public const string Fx = "sds_fx_full_counter";

        private const string KeyLastHealth = "sds_fc_hp";

        /// Anything inside this is a punch, and Full Counter does not answer punches.
        private const float MeleeRadius = 2.5f;

        /// How far out we will look for the caster who is hurting him.
        private const float ReflectRadius = 16f;

        /// Damage below this is ambient — poison, burning, a scratch — and is not worth answering.
        private const float MinDamageToReflect = 4f;

        /// The multiplier the series is built on. Full Counter does not return what it received; it
        /// returns considerably more, which is why nobody throws magic at him twice.
        private const float ReflectMultiplier = 3.2f;

        private const float Cooldown = 1.2f;

        public static void Init()
        {
            SDSTick.Register(Tick);
        }

        private static void Tick(Actor a, float dt)
        {
            if (a == null || !a.isAlive() || a.data == null) return;
            if (!a.hasTrait(Ability)) return;

            float current = a.data.health;
            float previous = SDSData.GetFloat(a, KeyLastHealth, -1f);
            SDSData.SetFloat(a, KeyLastHealth, current);

            // First sighting of this unit: nothing to compare against yet.
            if (previous < 0f) return;

            // Healed or unchanged. Keep the "ready" marker up so the player can see he is armed.
            if (current >= previous)
            {
                if (!a.hasStatus(StatusReady) && SDSData.TryUse(a, "fc_ready", 8f))
                {
                    try { a.addStatusEffect(StatusReady, 12f); }
                    catch { }
                }
                return;
            }

            float taken = previous - current;
            if (taken < MinDamageToReflect) return;
            if (!SDSData.TryUse(a, "full_counter", CooldownFor())) return;

            Actor source = FindRangedAttacker(a);
            if (source == null) return;      // it was a fist, or nobody is there: no counter

            float back = taken * ReflectMultiplier + PowerLevel.Spirit(a) * 0.05f;

            try { source.getHit(back, true, AttackType.Other, a, true); }
            catch { return; }

            SDSFx.At(source, Fx, 0.45f);
            SDSFx.At(a, Fx, 0.3f);
        }

        private static float CooldownFor()
        {
            return SDSConfig.AbilityCooldowns ? Cooldown : 0.1f;
        }

        /// The enemy hurting him from outside arm's reach.
        ///
        /// Anyone standing adjacent is excluded rather than merely deprioritised: if a hostile is in
        /// melee range at all, we assume the damage was theirs and let it stand. Being wrong in that
        /// direction costs a counter; being wrong the other way would let Full Counter answer swords,
        /// which is the one thing it must never do.
        private static Actor FindRangedAttacker(Actor a)
        {
            List<Actor> melee = SDSUnit.Around(a, MeleeRadius);
            for (int i = 0; i < melee.Count; i++)
            {
                Actor m = melee[i];
                if (m != null && m.isAlive() && m.kingdom != a.kingdom) return null;
            }

            Actor best = null;
            float bestPower = 0f;

            List<Actor> nearby = SDSUnit.Around(a, ReflectRadius);
            for (int i = 0; i < nearby.Count; i++)
            {
                Actor other = nearby[i];
                if (other == null || !other.isAlive()) continue;
                if (other.kingdom == a.kingdom) continue;

                // The strongest hostile caster in range is the likeliest source of a spell.
                float power = PowerLevel.Magic(other) + PowerLevel.Strength(other) * 0.25f;
                if (power <= bestPower) continue;

                bestPower = power;
                best = other;
            }

            return best;
        }
    }
}
