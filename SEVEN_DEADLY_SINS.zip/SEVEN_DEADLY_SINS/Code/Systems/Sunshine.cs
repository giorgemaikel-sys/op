using UnityEngine;

namespace SevenDeadlySins
{
    /// Escanor. The reason this mod has a clock.
    ///
    /// Sunshine multiplies its bearer's power by the height of the sun: nothing at midnight, absolute
    /// at noon. That curve is the character — a man who apologises for existing at night and looks
    /// down on gods at midday — so it is implemented as a real multiplier on the real stat, not as a
    /// cosmetic status.
    ///
    /// It is registered as a PowerLevel CONTRIBUTOR rather than written into the stats directly. That
    /// matters: it means Sunshine composes with the Demon Mark and with Indura instead of one of them
    /// overwriting the other, and it means the number the unit panel shows is always current without
    /// anything having to remember to recalculate it.
    public static class Sunshine
    {
        public const string Ability = "sds_ability_sunshine";
        public const string StatusTheOne = "sds_status_the_one";
        public const string Fx = "sds_fx_sunshine";

        /// At the very bottom of the night he is weaker than a villager. That is canon and it is the
        /// whole joke.
        private const float NightFloor = 0.06f;

        /// El ramp de la manana, justo antes del mediodia. La base de Escanor es diminuta a proposito
        /// (su rasgo Soberbia carga sus numeros de MEDIANOCHE, 5+5+5=15, mas el clan Humano: ~33 en
        /// total), asi que el multiplicador tiene que ser grande para que el numero del panel llegue
        /// al canon. A pleno sol, antes del instante de mediodia, ronda las decenas de miles
        /// (~33 x 1050 ~ 35.000): ya a la altura de un Mandamiento y de las formas verdaderas de los
        /// Pecados.
        private const float NoonPeak = 1050f;

        /// The One. La clase de combate de Escanor a mediodia se cita en 114.000 en la serie (de un
        /// minimo de 15 por la noche). Contra su base de ~33 eso pide un multiplicador de ~3.450:
        /// ~33 x 3450 ~ 114.000, justo la cifra de la fuente. Es un pico que solo existe en el
        /// instante EXACTO del mediodia y solo dura, como en el manga, un momento.
        private const float TheOneMultiplier = 3450f;

        public static void Init()
        {
            PowerLevel.AddContributor("sunshine", Multiplier);
            SDSTick.Register(Tick);
        }

        /// The curve every other system sees.
        public static float Multiplier(Actor a)
        {
            if (a == null || !a.hasTrait(Ability)) return 1f;

            // Config off: park him at a flat, unremarkable strength rather than removing the ability.
            if (!SDSConfig.SunshineCycle) return 12f;

            float sun = DayCycle.SunHeight();

            // Cubed on purpose. A linear ramp made him merely "a bit weaker in the evening"; cubing
            // keeps him genuinely harmless through most of the night and makes the last hour before
            // noon feel like something arriving.
            float curve = sun * sun * sun;

            float m = Mathf.Lerp(NightFloor, NoonPeak, curve);
            if (DayCycle.IsNoon) m *= TheOneMultiplier / NoonPeak;

            return Mathf.Max(NightFloor, m);
        }

        // ---------------------------------------------------------------- behaviour

        private static bool _announced;

        private static void Tick(Actor a, float dt)
        {
            if (a == null || !a.isAlive() || !a.hasTrait(Ability)) return;

            // The One is the second rung of the Lion's ladder, not a free gift with the trait.
            // Below it Escanor still swells at midday — he simply does not become THAT.
            bool noon = SDSConfig.SunshineCycle && DayCycle.IsNoon
                        && Progression.Has(a, Progression.Mastered);

            if (noon)
            {
                bool wasMarked = a.hasStatus(StatusTheOne);

                // SHORT duration, re-applied every sweep while noon lasts. There is no verified way
                // to remove a status on this build, so the status has to expire on its own — the
                // moment noon ends we simply stop renewing it and it lapses within seconds.
                try { a.addStatusEffect(StatusTheOne, 4f); }
                catch { }

                if (!wasMarked)
                {
                    SDSFx.At(a, Fx, 0.6f);

                    if (!_announced)
                    {
                        _announced = true;
                        SDSLog.Chronicle(SDSLocale.T(
                            a.getName() + " se alza al mediodia. No queda nada en Britannia que pueda plantarle cara.",
                            a.getName() + " rises at noon. There is nothing left in Britannia that can stand before him."));
                    }
                }
                return;
            }

            // A little light while the sun is up, so you can see who he is without opening a panel.
            if (SDSConfig.SunshineCycle && DayCycle.SunHeight() > 0.55f
                && SDSData.TryUse(a, "sunshine_glow", 6f))
            {
                SDSFx.At(a, Fx, 0.3f);
            }
        }
    }
}
