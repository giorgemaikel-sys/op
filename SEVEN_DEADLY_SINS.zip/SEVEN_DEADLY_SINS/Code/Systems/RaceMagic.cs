using System.Collections.Generic;
using UnityEngine;

namespace SevenDeadlySins
{
    /// La magia propia de cada raza, UNA POR CADA CLASE.
    ///
    /// El usuario lo pidio con un ejemplo y luego lo preciso: no es una magia por raza, es una por
    /// cada combinacion de raza Y clase. Un gigante potenciador no hace lo mismo que un gigante
    /// hechicero, y ninguno de los dos hace lo que un demonio de su misma clase.
    ///
    /// Se cruzan dos ejes:
    ///   - La CLASE decide la FORMA del hechizo:
    ///       Potenciador -> se refuerza a si mismo
    ///       Encantador  -> castiga a un enemigo con un estado
    ///       Hechicero   -> lanza un proyectil a distancia
    ///       Sanador     -> cura a los aliados alrededor
    ///       Especial    -> el golpe de firma de su pueblo, en area
    ///   - La RAZA decide el SABOR: su elemento, su color, su estado, si roba vida.
    ///
    /// Asi salen veinticinco hechizos distintos de dos ejes cortos, en vez de veinticinco funciones
    /// sueltas. Los personajes con nombre quedan fuera: conservan solo lo suyo, como en todo el mod.
    /// Los humanos tampoco tienen rama — su magia ya son las cinco clases base, sin apellido.
    public static class RaceMagic
    {
        public const string StatusHaste = "sds_status_haste";
        public const string StatusMight = "sds_status_might";

        public static void Init()
        {
            Buffs();
            SDSTick.Register(Tick);
        }

        /// Dos refuerzos que las clases potenciadoras necesitan y que el mod no tenia: uno de
        /// velocidad y uno de pura fuerza bruta. El de armadura ya existe (StatusReinforced).
        private static void Buffs()
        {
            if (!AssetManager.status.dict.ContainsKey(StatusHaste))
            {
                StatusAsset s = SDSRegistry.Status(StatusHaste, "ui/icons/sds_status_haste", 8f);
                s.base_stats.set("speed", 55f);
                s.base_stats.set("attack_speed", 0.4f);
                s.removed_on_damage = false;
                SDSRegistry.AddStatus(s);
                SDSLocale.Status(StatusHaste, "Celeridad",
                    "Mas rapido de lo que el ojo sigue. Un instante dura poco, pero cunde.");
            }

            if (!AssetManager.status.dict.ContainsKey(StatusMight))
            {
                StatusAsset s = SDSRegistry.Status(StatusMight, "ui/icons/sds_status_might", 8f);
                s.base_stats.set("damage", 35f);
                s.base_stats.set("knockback", 4f);
                s.base_stats.set("multiplier_damage", 0.5f);
                s.removed_on_damage = false;
                SDSRegistry.AddStatus(s);
                SDSLocale.Status(StatusMight, "Poderio",
                    "La fuerza desbordada de una raza que no mide su golpe.");
            }
        }

        // ---------------------------------------------------------------- perfil de raza

        /// El sabor de una raza: lo que las cinco clases usan para tenirse.
        private class Profile
        {
            public string element;        // FX del elemento
            public string debuff;         // estado que castiga
            public float debuffTime;
            public AttackType damageType;
            public float lifesteal;       // 0..1 de lo que roba
            public bool burnsDemons;      // la luz de la diosa
        }

        private static readonly Dictionary<string, Profile> _profiles = new Dictionary<string, Profile>();

        private static Profile Prof(Actor a)
        {
            string clan = null;
            if (SDSUnit.IsGiant(a)) clan = Clans.Giant;
            else if (SDSUnit.IsFairy(a)) clan = Clans.Fairy;
            else if (SDSUnit.IsGoddess(a)) clan = Clans.Goddess;
            else if (SDSUnit.IsDemon(a)) clan = Clans.Demon;
            else if (SDSUnit.IsVampire(a)) clan = Clans.Vampire;
            if (clan == null) return null;

            Profile p;
            if (_profiles.TryGetValue(clan, out p)) return p;

            p = new Profile();
            switch (clan)
            {
                case Clans.Giant:
                    p.element = Effects.Creation; p.debuff = Curses.Ash; p.debuffTime = 6f;
                    p.damageType = AttackType.Other; break;
                case Clans.Fairy:
                    p.element = Effects.Chastiefol; p.debuff = Curses.Paralyzed; p.debuffTime = 3f;
                    p.damageType = AttackType.Other; break;
                case Clans.Goddess:
                    p.element = Effects.Ark; p.debuff = Curses.Ash; p.debuffTime = 4f;
                    p.damageType = AttackType.Fire; p.burnsDemons = true; break;
                case Clans.Demon:
                    p.element = Effects.Hellblaze; p.debuff = Statuses.Hellblaze; p.debuffTime = 8f;
                    p.damageType = AttackType.Other; break;
                case Clans.Vampire:
                    p.element = Effects.Snatch; p.debuff = Curses.Paralyzed; p.debuffTime = 2.5f;
                    p.damageType = AttackType.Other; p.lifesteal = 0.6f; break;
            }
            _profiles[clan] = p;
            return p;
        }

        // ---------------------------------------------------------------- bucle

        private static float CD(float s) { return SDSConfig.AbilityCooldowns ? s : 0.3f; }

        private static void Tick(Actor a, float dt)
        {
            if (a == null || !a.isAlive() || a.data == null) return;
            if (SDSUnit.IsNamed(a)) return;      // los nombrados conservan solo lo suyo
            if (!a.has_attack_target) return;

            Profile p = Prof(a);
            if (p == null) return;               // humano u otra cosa: sin rama racial

            // La clase decide la forma. Se elige la mas "magica" si lleva varias.
            if (a.hasTrait(MagicTypes.Special)) Special(a, p);
            else if (a.hasTrait(MagicTypes.Incantation)) Incantation(a, p);
            else if (a.hasTrait(MagicTypes.Enchanter)) Enchanter(a, p);
            else if (a.hasTrait(MagicTypes.Healer)) Healer(a, p);
            else if (a.hasTrait(MagicTypes.Strengthener)) Strengthener(a, p);
        }

        private static Actor Enemy(Actor a, float radius)
        {
            List<Actor> near = SDSUnit.Around(a, radius);
            for (int i = 0; i < near.Count; i++)
            {
                Actor o = near[i];
                if (o != null && o.isAlive() && Clans.Hostile(a, o)) return o;
            }
            return null;
        }

        // ---------------------------------------------------------------- las cinco clases

        /// Potenciador: se refuerza a si mismo. La raza decide QUE refuerzo.
        ///
        /// El gigante crece de poderio; el hada gana celeridad (el ejemplo del usuario, invertido:
        /// no encoge, se agiliza); la diosa se blinda; el demonio entra en frenesi con su regen; el
        /// vampiro enciende su sed y roba con cada golpe.
        private static void Strengthener(Actor a, Profile p)
        {
            if (!SDSData.TryUse(a, "race_str", CD(9f))) return;

            if (SDSUnit.IsFairy(a)) SDSStatus.Inflict(a, StatusHaste, 8f);
            else if (SDSUnit.IsGoddess(a)) SDSStatus.Inflict(a, MagicTypes.StatusReinforced, 8f);
            else SDSStatus.Inflict(a, StatusMight, 8f);

            if (SDSUnit.IsDemon(a) || SDSUnit.IsVampire(a))
            {
                try { a.restoreHealth(Mathf.Max(1, Mathf.RoundToInt(a.getMaxHealth() * 0.15f))); }
                catch { }
            }

            SDSFx.At(a, p.element, 0.5f);
        }

        /// Encantador: castiga a un enemigo con el estado de su raza.
        private static void Enchanter(Actor a, Profile p)
        {
            if (!SDSData.TryUse(a, "race_ench", CD(6f))) return;

            Actor target = Enemy(a, 9f);
            if (target == null) return;

            try { target.getHit(6f + PowerLevel.Magic(a) * 0.03f, true, p.damageType, a, true); }
            catch { return; }

            SDSStatus.Inflict(target, p.debuff, p.debuffTime);
            SDSFx.At(target, p.element, 0.45f);
        }

        /// Hechicero: proyectil a distancia con el elemento de la raza.
        private static void Incantation(Actor a, Profile p)
        {
            if (!SDSData.TryUse(a, "race_inc", CD(5f))) return;

            Actor target = Enemy(a, 12f);
            if (target == null) return;

            float dmg = 12f + PowerLevel.Magic(a) * 0.05f;
            if (p.burnsDemons && target.hasTrait(Clans.Demon)) dmg *= 1.6f;

            SDSFx.Projectile(a, target, Projectiles.Magic);
            try { target.getHit(dmg, true, p.damageType, a, true); }
            catch { return; }

            if (p.lifesteal > 0f)
            {
                try { a.restoreHealth(Mathf.Max(1, Mathf.RoundToInt(dmg * p.lifesteal))); }
                catch { }
            }
            SDSFx.At(target, p.element, 0.45f);
        }

        /// Sanador: cura a los aliados alrededor. La diosa y el hada curan mas — es lo suyo.
        private static void Healer(Actor a, Profile p)
        {
            if (!SDSData.TryUse(a, "race_heal", CD(5f))) return;

            float power = 8f + PowerLevel.Magic(a) * 0.04f;
            if (SDSUnit.IsGoddess(a) || SDSUnit.IsFairy(a)) power *= 1.6f;

            List<Actor> near = SDSUnit.Around(a, 7f);
            bool used = false;

            for (int i = 0; i < near.Count; i++)
            {
                Actor o = near[i];
                if (o == null || !o.isAlive()) continue;
                if (!SDSUnit.IsAlly(a, o)) continue;
                if (o.data == null || o.data.health >= o.getMaxHealth()) continue;

                try { o.restoreHealth(Mathf.Max(1, Mathf.RoundToInt(power))); used = true; }
                catch { }
            }

            if (used) SDSFx.At(a, p.burnsDemons ? Effects.Ark : Effects.Wings, 0.5f);
        }

        /// Especial: el golpe de firma del pueblo, en area sobre todos los enemigos cercanos.
        private static void Special(Actor a, Profile p)
        {
            if (!SDSData.TryUse(a, "race_special", CD(8f))) return;

            float power = 14f + (PowerLevel.Magic(a) + PowerLevel.Strength(a)) * 0.04f;
            List<Actor> near = SDSUnit.Around(a, 6f);
            bool used = false;
            float healed = 0f;

            for (int i = 0; i < near.Count; i++)
            {
                Actor o = near[i];
                if (o == null || !o.isAlive() || o == a) continue;

                if (Clans.Hostile(a, o))
                {
                    float dmg = power;
                    if (p.burnsDemons && o.hasTrait(Clans.Demon)) dmg *= 1.6f;
                    try { o.getHit(dmg, true, p.damageType, a, true); used = true; }
                    catch { continue; }

                    if (p.debuff != null) SDSStatus.Inflict(o, p.debuff, p.debuffTime);
                    if (p.lifesteal > 0f) healed += dmg * p.lifesteal;
                }
            }

            if (healed > 0f)
            {
                try { a.restoreHealth(Mathf.Max(1, Mathf.RoundToInt(healed))); }
                catch { }
            }

            if (used)
            {
                SDSFx.At(a, p.element, 0.7f);
                SDSFx.Wave(a, 3f, 2f);
            }
        }
    }
}
