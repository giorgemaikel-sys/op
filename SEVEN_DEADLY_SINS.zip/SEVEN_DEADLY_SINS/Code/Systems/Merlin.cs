using System.Collections.Generic;
using UnityEngine;

namespace SevenDeadlySins
{
    /// El libro de hechizos de Merlin.
    ///
    /// Infinity por si sola no hacia nada. Su poder no es un ataque: es que TODO lo que ella lanza
    /// dura para siempre. Sin hechizos que lanzar, la mejor maga de Britannia se quedaba en una
    /// aldeana con un rasgo bonito y un orbe que no servia de nada.
    ///
    /// Aqui estan los tres que la definen en la serie, y los tres se apoyan en Infinity en vez de
    /// ignorarla: el Cubo no expira, la Cancelacion no se levanta sola, y Aldan amplifica lo que
    /// venga despues. Ese es el sentido de su magia — no pega mas fuerte, pega para siempre.
    public static class Merlin
    {
        public const string PerfectCube = "sds_ability_perfect_cube";
        public const string AbsoluteCancel = "sds_ability_absolute_cancel";
        public const string EndlessWhirl = "sds_ability_endless_whirl";

        public const string StatusCube = "sds_status_perfect_cube";
        public const string StatusCancelled = "sds_status_cancelled";
        public const string StatusAldan = "sds_status_aldan";

        private const string Group = TraitGroups.Arcane;

        /// Cuanto dura un hechizo suyo cuando lo lanza ALGUIEN CON INFINITY.
        /// No es "para siempre" literal porque no hay forma verificable de retirar un estado en este
        /// build: nueve mil segundos de mundo son, a efectos practicos, lo mismo.
        private const float Forever = 9999f;

        public static void Init()
        {
            Spell(PerfectCube, "Cubo Perfecto",
                "Encierra lo que hay dentro. Nada entra y nada sale, y con Infinity no se abre nunca.",
                spi: 220f, mag: 380f);

            Spell(AbsoluteCancel, "Cancelacion Absoluta",
                "Apaga la magia ajena. Un hechicero alcanzado deja de serlo.",
                spi: 180f, mag: 320f);

            Spell(EndlessWhirl, "Torbellino Sin Fin",
                "Un vendaval que no amaina mientras ella quiera que siga.",
                spi: 140f, mag: 300f);

            Statuses();
            SDSTick.Register(Tick);
        }

        private static void Spell(string id, string nameEs, string infoEs, float spi, float mag)
        {
            if (AssetManager.traits.dict.ContainsKey(id)) return;

            ActorTrait t = SDSRegistry.Trait(id, Group, "ui/icons/" + id);
            t.type = TraitType.Positive;
            PowerLevel.Grant(t, 0f, spi, mag);
            SDSRegistry.AddTrait(t);
            SDSLocale.Trait(id, nameEs, infoEs);
        }

        private static void Statuses()
        {
            Status(StatusCube, "Cubo Perfecto",
                "Atrapado dentro de un cubo que no se puede romper desde ningun lado.",
                speed: -500f, damage: -300f, armor: 200f);

            Status(StatusCancelled, "Magia Cancelada",
                "Su magia no responde. Nada de lo que sabe le sirve ahora mismo.",
                speed: -20f, damage: -40f, armor: 0f, magic: -800f);

            Status(StatusAldan, "Aldan",
                "El orbe de Merlin amplifica todo lo que lanza mientras lo sostiene.",
                speed: 0f, damage: 0f, armor: 0f, magic: 600f, positive: true);
        }

        private static void Status(string id, string nameEs, string infoEs,
                                   float speed, float damage, float armor,
                                   float magic = 0f, bool positive = false)
        {
            if (AssetManager.status.dict.ContainsKey(id)) return;

            StatusAsset s = SDSRegistry.Status(id, "ui/icons/" + id, 12f);
            if (speed != 0f) s.base_stats["speed"] = speed;
            if (damage != 0f) s.base_stats["damage"] = damage;
            if (armor != 0f) s.base_stats["armor"] = armor;
            if (magic != 0f) s.base_stats[PowerLevel.StatMagic] = magic;

            s.removed_on_damage = false;

            SDSRegistry.AddStatus(s);
            if (!positive) SDSStatus.MarkNegative(id);
            SDSLocale.Status(id, nameEs, infoEs);
        }

        // ---------------------------------------------------------------- comportamiento

        /// Lo que dura un hechizo de este lanzador. Con Infinity, para siempre.
        ///
        /// Esta es la unica funcion del archivo que de verdad importa: es donde el rasgo de Merlin
        /// deja de ser decorativo. El mismo hechizo lanzado por otra persona se le pasa en unos
        /// segundos.
        private static float Duration(Actor a, float normal)
        {
            return a.hasTrait(Abilities.Infinity) ? Forever : normal;
        }

        private static float CD(float s)
        {
            return SDSConfig.AbilityCooldowns ? s : 0.2f;
        }

        private static void Tick(Actor a, float dt)
        {
            if (a == null || !a.isAlive() || a.data == null) return;

            // Estos hechizos son de una sola persona en todo el mundo. Una lectura de bool saca a
            // la poblacion entera antes de tocar un solo hasTrait.
            if (!SDSUnit.RunsAbilities(a)) return;
            if (Curses.Incapacitated(a)) return;

            if (a.hasTrait(PerfectCube)) TickCube(a);
            if (a.hasTrait(AbsoluteCancel)) TickCancel(a);
            if (a.hasTrait(EndlessWhirl)) TickWhirl(a);
        }

        /// Cubo Perfecto: encierra a los enemigos cercanos. No hace dano — los saca del combate.
        private static void TickCube(Actor a)
        {
            if (!a.has_attack_target) return;
            if (!SDSData.TryUse(a, "perfect_cube", CD(16f))) return;

            List<Actor> near = SDSUnit.Around(a, 8f);
            int caught = 0;

            for (int i = 0; i < near.Count && caught < 3; i++)
            {
                Actor o = near[i];
                if (o == null || !o.isAlive() || o.kingdom == a.kingdom) continue;
                if (o.hasStatus(StatusCube)) continue;

                if (!SDSStatus.Inflict(o, StatusCube, Duration(a, 14f))) continue;

                SDSFx.At(o, "sds_fx_infinity", 0.5f);
                caught++;
            }

            if (caught > 0)
                SDSLog.Tip(a.getName() + ": " + SDSLocale.T("Cubo Perfecto", "Perfect Cube"));
        }

        /// Cancelacion Absoluta: apaga la magia del objetivo. Contra alguien sin magia no hace nada,
        /// que es exactamente como funciona en la serie.
        private static void TickCancel(Actor a)
        {
            if (!a.has_attack_target) return;
            if (!SDSData.TryUse(a, "absolute_cancel", CD(12f))) return;

            List<Actor> near = SDSUnit.Around(a, 12f);
            Actor best = null;
            float bestMagic = 0f;

            for (int i = 0; i < near.Count; i++)
            {
                Actor o = near[i];
                if (o == null || !o.isAlive() || o.kingdom == a.kingdom) continue;

                float m = PowerLevel.Magic(o);
                if (m <= bestMagic) continue;
                bestMagic = m;
                best = o;
            }

            // Nadie a quien cancelarle nada.
            if (best == null || bestMagic < 20f) return;

            if (!SDSStatus.Inflict(best, StatusCancelled, Duration(a, 10f))) return;

            SDSFx.At(best, "sds_fx_soul", 0.5f);
            SDSLog.Tip(a.getName() + ": " + SDSLocale.T("Cancelacion Absoluta", "Absolute Cancel"));
        }

        /// Torbellino Sin Fin: dano en area, y con Infinity deja a los alcanzados dentro del viento.
        private static void TickWhirl(Actor a)
        {
            if (!a.has_attack_target) return;
            if (!SDSData.TryUse(a, "endless_whirl", CD(9f))) return;

            float power = 16f + PowerLevel.Magic(a) * 0.07f;
            List<Actor> near = SDSUnit.Around(a, 10f);
            bool used = false;

            for (int i = 0; i < near.Count; i++)
            {
                Actor o = near[i];
                if (o == null || !o.isAlive() || o.kingdom == a.kingdom) continue;

                try { o.getHit(power, true, AttackType.Other, a, true); }
                catch { continue; }

                // La paralisis NO se hace eterna aunque la lance Merlin. Un enemigo congelado para
                // siempre no es un hechizo, es borrarlo del mundo; Infinity solo la alarga.
                SDSStatus.Inflict(o, Curses.Paralyzed, a.hasTrait(Abilities.Infinity) ? 20f : 4f);
                used = true;
            }

            if (used) SDSFx.At(a, "sds_fx_tornado", 0.7f);
        }

        /// Aldan. Lo llama TreasureArts: el orbe amplifica su magia, y con Infinity no se le pasa.
        public static void Aldan(Actor a)
        {
            if (a == null || a.hasStatus(StatusAldan)) return;
            if (!SDSData.TryUse(a, "aldan", CD(10f))) return;

            SDSStatus.Inflict(a, StatusAldan, Duration(a, 20f));
            SDSFx.At(a, "sds_fx_aldan", 0.6f);
        }
    }
}
