using System.Collections.Generic;
using UnityEngine;

namespace SevenDeadlySins
{
    /// The Demon King, and Purgatory around him.
    ///
    /// He is the only unit in the mod built as a BOSS: he does not simply have big numbers, he
    /// changes as he is worn down. Three phases, each announced, each stronger than the last, and
    /// the last one is what a million-power-level creature is supposed to feel like.
    ///
    /// The phases are keyed off health rather than time, so the escalation is something the player
    /// causes rather than something they wait for.
    public static class DemonKing
    {
        public const string TraitKing = "sds_demon_king_power";
        public const string TraitMaster = "sds_demon_master";     // Chandler and Cusack

        private const string KeyPhase = "sds_dk_phase";

        /// Health fractions at which he escalates.
        private static readonly float[] PhaseAt = { 1f, 0.6f, 0.3f };

        /// Power multiplier per phase.
        private static readonly float[] PhasePower = { 1f, 1.6f, 2.6f };

        private const float AuraRadius = 10f;

        public static void Init()
        {
            King();
            Master();

            PowerLevel.AddContributor("demon_king", a =>
            {
                if (a == null || !a.hasTrait(TraitKing)) return 1f;
                return PhasePower[Mathf.Clamp(Phase(a), 0, PhasePower.Length - 1)];
            });

            SDSTick.Register(Tick);
        }

        private static void King()
        {
            if (AssetManager.traits.dict.ContainsKey(TraitKing)) return;

            ActorTrait t = SDSRegistry.Trait(TraitKing, TraitGroups.Demonic, "ui/icons/sds_demon_king");
            t.type = TraitType.Positive;

            // La cifra del canon es un millon, y ahora se pone tal cual: el usuario quiere los
            // numeros de la serie, y PowerScaling ya evita que un millon vuelva la pelea imposible
            // (el factor de combate va a la raiz y tiene techo, asi que el panel canta el millon
            // pero el golpe sigue siendo un golpe). 280+330+390 = 1.000.000.
            PowerLevel.Grant(t, 280000f, 330000f, 390000f);
            t.base_stats["health"] = 5000f;
            t.base_stats["damage"] = 250f;
            t.base_stats["armor"] = 120f;
            t.base_stats["multiplier_lifespan"] = 20f;

            SDSRegistry.AddTrait(t);
            SDSLocale.Trait(TraitKing, "Poder del Rey Demonio",
                "El origen de toda la oscuridad. Cuanto mas dano recibe, mas terrible se vuelve.");
        }

        private static void Master()
        {
            if (AssetManager.traits.dict.ContainsKey(TraitMaster)) return;

            ActorTrait t = SDSRegistry.Trait(TraitMaster, TraitGroups.Demonic, "ui/icons/sds_chandler");
            t.type = TraitType.Positive;
            // Los Demonios Originales. La databook los cita en ~170.000 (Chandler 173.000, Cusack
            // 168.000): por encima de cualquier Mandamiento y del Escanor de mediodia, por debajo de
            // los dioses. 55+58+57 = 170.000.
            PowerLevel.Grant(t, 55000f, 58000f, 57000f);
            t.base_stats["health"] = 2000f;
            t.base_stats["damage"] = 120f;
            t.base_stats["armor"] = 60f;
            t.base_stats["multiplier_lifespan"] = 15f;

            SDSRegistry.AddTrait(t);
            SDSLocale.Trait(TraitMaster, "Maestro del Rey Demonio",
                "Chandler y Cusack. Entrenaron a Meliodas y a Zeldris, y no han olvidado como se hace.");
        }

        // ---------------------------------------------------------------- phases

        public static int Phase(Actor a)
        {
            if (a == null || a.data == null) return 0;
            return Mathf.Clamp(SDSData.GetInt(a, KeyPhase, 0), 0, PhaseAt.Length - 1);
        }

        private static void Tick(Actor a, float dt)
        {
            if (!SDSUnit.IsNamed(a)) return;
            if (!a.isAlive() || a.data == null) return;

            bool king = a.hasTrait(TraitKing);
            if (!king && !a.hasTrait(TraitMaster)) return;

            if (king) Escalate(a);

            if (Curses.Incapacitated(a)) return;

            Aura(a, king);
        }

        /// Moves him up a phase when his health crosses the next threshold. Never goes back down:
        /// the Demon King does not calm off.
        private static void Escalate(Actor a)
        {
            float max = a.getMaxHealth();
            if (max <= 0f) return;

            float ratio = a.data.health / max;
            int phase = Phase(a);

            while (phase + 1 < PhaseAt.Length && ratio <= PhaseAt[phase + 1])
            {
                phase++;
                SDSData.SetInt(a, KeyPhase, phase);

                SDSFx.At(a, "sds_fx_demon_king", 0.9f);
                SDSFx.Wave(a, 4.5f, 3f);

                SDSLog.Chronicle(SDSLocale.T(
                    PhaseTextEs(phase, a.getName()),
                    PhaseTextEn(phase, a.getName())));
            }
        }

        private static string PhaseTextEs(int phase, string name)
        {
            if (phase == 1) return name + " se despoja de su contencion. La oscuridad se espesa.";
            return name + " deja de fingir que esto era un combate.";
        }

        private static string PhaseTextEn(int phase, string name)
        {
            if (phase == 1) return name + " sheds his restraint. The darkness thickens.";
            return name + " stops pretending this was a fight.";
        }

        /// Darkness that eats at everything not of the Demon Clan, and mends the demons standing in
        /// it. Wider and hungrier the further he has been pushed.
        private static void Aura(Actor a, bool king)
        {
            if (!SDSData.TryUse(a, "dk_aura", SDSConfig.AbilityCooldowns ? 2.5f : 0.3f)) return;

            int phase = king ? Phase(a) : 0;
            float radius = AuraRadius * (king ? 1f + phase * 0.25f : 0.7f);
            float bite = (king ? 12f : 7f) * (1f + phase * 0.6f);

            List<Actor> nearby = SDSUnit.Around(a, radius);
            bool used = false;

            for (int i = 0; i < nearby.Count; i++)
            {
                Actor o = nearby[i];
                if (o == null || !o.isAlive() || o == a) continue;

                if (SDSUnit.IsDemon(o))
                {
                    if (o.data.health >= o.getMaxHealth()) continue;
                    try { o.restoreHealth(Mathf.Max(1, Mathf.RoundToInt(bite * 0.5f))); used = true; }
                    catch { }
                    continue;
                }

                if (SDSUnit.IsAlly(a, o)) continue;   // no quema a los suyos aunque el Rey sea salvaje

                try { o.getHit(bite, true, AttackType.Fire, a, true); }
                catch { continue; }

                // His black flame is the reason wounds from the Demon King do not close.
                SDSStatus.Inflict(o, "sds_status_hellblaze", 12f);
                used = true;
            }

            if (used) SDSFx.At(a, "sds_fx_hellblaze", king ? 0.7f : 0.45f);
        }

        /// Abre una grieta al Purgatorio donde el jugador pinche.
        ///
        /// El Purgatorio es un SITIO en la serie, no un reino politico: la carcel donde el Rey
        /// Demonio encerro a Meliodas. Como lugar no cabe en el mapa de WorldBox, asi que se
        /// implementa como lo que hace: se abre, y sale lo que hay dentro.
        ///
        /// La proporcion no es aleatoria — salen muchos demonios grises, algunos rojos, pocos azules
        /// y un Albion de vez en cuando. Es la jerarquia del Clan de los Demonios, de abajo arriba.
        public static bool OpenRift(WorldTile tile)
        {
            if (tile == null || World.world == null) return false;

            int spawned = 0;
            for (int i = 0; i < 9; i++)
            {
                string what = Actors.GrayDemon;
                if (i >= 7) what = Actors.BlueDemon;
                else if (i >= 4) what = Actors.RedDemon;

                if (AssetManager.actor_library.get(what) == null) continue;

                try
                {
                    Actor born = World.world.units.spawnNewUnit(what, tile,
                        pSpawnSound: false, pMiracleSpawn: true, pSpawnHeight: 4f);
                    if (born != null)
                    {
                        Actors.NameUnit(born, what);
                        spawned++;
                    }
                }
                catch { }
            }

            // Un Albion no sale siempre: si saliera con cada grieta dejaria de dar miedo.
            if (Randy.randomChance(0.35f) && AssetManager.actor_library.get(Actors.Albion) != null)
            {
                try
                {
                    Actor albion = World.world.units.spawnNewUnit(Actors.Albion, tile,
                        pSpawnSound: true, pMiracleSpawn: true, pSpawnHeight: 4f);
                    if (albion != null) Actors.NameUnit(albion, Actors.Albion);
                }
                catch { }
            }

            if (spawned == 0) return false;

            SDSFx.At(tile, "sds_fx_demon_king", 1f);
            SDSLog.Chronicle(SDSLocale.T(
                "Se ha abierto una grieta al Purgatorio.",
                "A rift to Purgatory has opened."));
            return true;
        }

        /// Hands a unit the Demon King's power. Used by Legends.
        public static void Crown(Actor a)
        {
            if (a == null) return;
            Clans.Give(a, Clans.Demon);
            SDSTraits.Give(a, TraitKing);
            SDSTraits.Give(a, Abilities.Hellblaze);
            SDSTraits.Give(a, SevenDeadlySins.Traits.Immortal);   // el Rey Demonio no muere de nada
            SDSData.SetInt(a, KeyPhase, 0);
        }
    }
}
