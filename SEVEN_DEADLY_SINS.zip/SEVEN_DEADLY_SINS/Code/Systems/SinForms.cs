using System.Collections.Generic;
using UnityEngine;

namespace SevenDeadlySins
{
    /// La forma final de cada Pecado, y el estado que la hace visible.
    ///
    /// Progression ya subia tres peldanos y anunciaba el nombre de cada uno, pero lo unico que
    /// cambiaba de verdad era un multiplicador invisible. Dos de los siete tenian forma real —
    /// el Modo Asalto de Meliodas y The One de Escanor — y los otros cinco no tenian NADA: subian
    /// de grado y seguian exactamente igual en pantalla.
    ///
    /// Aqui estan las cinco que faltaban. Cada una es un estado permanente que se aplica al llegar
    /// al ultimo peldano, con los numeros de su personaje y un efecto al transformarse, para que
    /// alcanzar la forma verdadera se VEA.
    public static class SinForms
    {
        public const string Undead = "sds_status_form_undead";        // Ban
        public const string WarGiant = "sds_status_form_war_giant";   // Diane
        public const string PerfectDoll = "sds_status_form_doll";     // Gowther
        public const string TrueFairyKing = "sds_status_form_king";   // King
        public const string AbsoluteLore = "sds_status_form_lore";    // Merlin

        /// pecado -> (estado de forma, nombre, efecto al transformarse)
        private class Form
        {
            public readonly string status, es, fx;
            public Form(string status, string es, string fx) { this.status = status; this.es = es; this.fx = fx; }
        }

        private static readonly Dictionary<string, Form> _forms = new Dictionary<string, Form>();

        public static void Init()
        {
            // La forma verdadera lleva a cada Pecado a su PICO canonico, el de despues del
            // entrenamiento, cuando pelean de tu a tu con los Mandamientos: se suma sobre su base
            // (3.000-4.700) hasta la clase de combate que la serie le da a esa forma. Diane a tamano
            // de giganta llega a 50.000, King (Verdadero Rey Hada) a 41.600, Gowther (memorias
            // restauradas) a 35.400, Merlin a un Mandamiento alto, Ban a ~30.000 con el Bosque.

            // --- Ban: ~30.000 ------------------------------------------------------
            Status(Undead, "Inmortal Absoluto",
                "La muerte dejo de tener opinion. Las heridas se cierran solas y la fuerza robada no se va.",
                str: 14000f, spi: 7000f, mag: 6000f, health: 900f, armor: 60f);

            // --- Diane: ~50.000 (tope de giganta) ----------------------------------
            Status(WarGiant, "Forma de Guerra Gigante",
                "La Danza de Drole despierta del todo. La tierra se mueve con ella.",
                str: 26000f, spi: 12000f, mag: 8000f, health: 1600f, damage: 90f, knockback: 6f);

            // --- Gowther: ~35.400 (memorias restauradas) ---------------------------
            Status(PerfectDoll, "Muneco Perfecto",
                "Sin limitador. Lee y reescribe sin resistencia, y ya no finge sentir.",
                str: 6000f, spi: 8000f, mag: 18000f, health: 700f);

            // --- King: ~41.600 (Verdadero Rey Hada) --------------------------------
            Status(TrueFairyKing, "Verdadero Rey Hada",
                "Le vuelven las alas. Chastiefol despierta con el y el bosque entero le responde.",
                str: 9000f, spi: 16000f, mag: 12000f, health: 1000f, speed: 20f);

            // --- Merlin: ~40.000 (Saber Absoluto) ----------------------------------
            Status(AbsoluteLore, "Saber Absoluto",
                "Toda la magia de Britannia cabe en su cabeza, y con Infinity no se le olvida ninguna.",
                str: 3000f, spi: 12000f, mag: 20000f, health: 800f);

            Link(SevenSins.Greed, Undead, "sds_fx_snatch");
            Link(SevenSins.Envy, WarGiant, "sds_fx_creation");
            Link(SevenSins.Lust, PerfectDoll, "sds_fx_infinity");
            Link(SevenSins.Sloth, TrueFairyKing, "sds_fx_chastiefol");
            Link(SevenSins.Gluttony, AbsoluteLore, "sds_fx_aldan");

            // La Ira y la Soberbia YA tienen forma propia (Modo Asalto y The One), con sus reglas de
            // activacion en DemonMark y Sunshine. Meterlas aqui las duplicaria.

            SDSTick.Register(Tick);
        }

        private static void Status(string id, string nameEs, string infoEs,
                                   float str, float spi, float mag,
                                   float health = 0f, float damage = 0f,
                                   float armor = 0f, float speed = 0f, float knockback = 0f)
        {
            if (AssetManager.status.dict.ContainsKey(id)) return;

            StatusAsset s = SDSRegistry.Status(id, "ui/icons/" + id, 9999f);
            PowerLevel.Grant(s, str, spi, mag);

            if (health != 0f) s.base_stats["health"] = health;
            if (damage != 0f) s.base_stats["damage"] = damage;
            if (armor != 0f) s.base_stats["armor"] = armor;
            if (speed != 0f) s.base_stats["speed"] = speed;
            if (knockback != 0f) s.base_stats["knockback"] = knockback;

            s.removed_on_damage = false;

            SDSRegistry.AddStatus(s);
            SDSLocale.Status(id, nameEs, infoEs);
        }

        private static void Link(string sin, string status, string fx)
        {
            _forms[sin] = new Form(status, "", fx);
        }

        /// La forma final de este pecado, o null si no tiene una propia.
        public static string FormOf(string sinId)
        {
            Form f;
            return sinId != null && _forms.TryGetValue(sinId, out f) ? f.status : null;
        }

        // ---------------------------------------------------------------- comportamiento

        private static void Tick(Actor a, float dt)
        {
            // Solo los siete. Una lectura de bool antes de nada.
            if (!SDSUnit.IsNamed(a)) return;
            if (a == null || !a.isAlive() || a.data == null) return;

            // La forma verdadera es el ULTIMO peldano. Antes de eso el pecado sigue creciendo.
            if (Progression.Stage(a) < Progression.TrueForm) return;

            string sin = SDSUnit.SinOf(a);
            if (sin == null) return;

            Form f;
            if (!_forms.TryGetValue(sin, out f)) return;
            if (a.hasStatus(f.status)) return;

            // Duracion enorme y reaplicada: no hay forma verificable de retirar un estado en este
            // build, asi que "permanente" se consigue renovandolo, no marcandolo.
            if (!SDSStatus.Inflict(a, f.status, 9999f)) return;

            SDSFx.At(a, f.fx, 0.8f);
            SDSFx.Wave(a, 3.5f, 2.5f);

            SDSLog.Chronicle(SDSLocale.T(
                a.getName() + " alcanza su forma verdadera.",
                a.getName() + " reaches their true form."));
        }
    }
}
