using UnityEngine;

namespace SevenDeadlySins
{
    /// A demon that spends everything it has stops being a demon.
    ///
    /// Indura is not a buff and not a transformation status — it REPLACES the unit with a different
    /// creature. That is the whole horror of it in the series: there is no changing back, and what
    /// walks away is not the person who went in. Implementing it as a spawn-and-remove rather than a
    /// stat boost is what makes "irreversible" true rather than merely stated.
    ///
    /// The Indura asset is cloned from the game's hostile-creature template, so it inherits mob
    /// behaviour and attacks everyone without this file having to manufacture hostility.
    public static class Indura
    {
        public const string Status = "sds_status_indura";
        public const string Fx = "sds_fx_indura";

        /// Seconds of sustained, losing combat before a demon burns out.
        private const float ExhaustionSeconds = 45f;

        /// It only degenerates when it is genuinely spent.
        private const float HealthThreshold = 0.25f;

        public static void Init()
        {
            SDSTick.Register(Tick);
        }

        private static void Tick(Actor a, float dt)
        {
            if (!SDSConfig.InduraTransformation) return;
            if (a == null || !a.isAlive() || a.data == null || a.asset == null) return;

            // Only true demons, and never one that already is an Indura.
            if (a.asset.id == Actors.Indura) return;
            if (!a.hasTrait(Clans.Demon)) return;

            // The Ten Commandments do not degenerate. They are what the Demon King made them, and a
            // Commandment collapsing into a beast would quietly delete the mod's antagonists.
            if (SDSUnit.IsCommandment(a)) return;

            float max = a.getMaxHealth();
            if (max <= 0f) return;

            bool spending = a.has_attack_target && a.data.health / max <= HealthThreshold;

            float timer = SDSData.GetFloat(a, SDSData.InduraTimer, 0f);

            if (!spending)
            {
                // Recovers, but slower than it burns: a demon that keeps getting into losing fights
                // eventually runs out even with breaks in between.
                if (timer > 0f) SDSData.SetFloat(a, SDSData.InduraTimer, Mathf.Max(0f, timer - dt * 0.5f));
                return;
            }

            timer += dt;
            SDSData.SetFloat(a, SDSData.InduraTimer, timer);

            if (timer < ExhaustionSeconds) return;

            Degenerate(a);
        }

        /// Replaces the demon with an Indura on the same tile.
        public static void Degenerate(Actor a)
        {
            if (a == null || !a.isAlive() || a.current_tile == null) return;
            if (AssetManager.actor_library.get(Actors.Indura) == null) return;

            WorldTile tile = a.current_tile;
            string who = a.getName();

            SDSFx.At(a, Fx, 0.9f);
            SDSFx.Wave(a, 4f, 2.5f);

            Actor beast = null;
            try
            {
                beast = World.world.units.spawnNewUnit(Actors.Indura, tile,
                    pSpawnSound: true, pMiracleSpawn: false, pSpawnHeight: 0f);
            }
            catch { }

            // If the beast could not be created, leave the demon alive. Removing it first and failing
            // to replace it would silently delete units, which is far worse than a missed transformation.
            if (beast == null) return;

            try { beast.addStatusEffect(Status, 9999f); }
            catch { }

            Actors.NameUnit(beast, Actors.Indura);

            // The demon does not survive the change. die() is the verified removal path; the flags
            // are (pDropLoot, type, pDeathFx, pKillFinalizer) as used by the reference mod.
            try { a.die(true, AttackType.Other, true, false); }
            catch { }

            SDSLog.Chronicle(SDSLocale.T(
                who + " lo ha gastado todo. Lo que se ha levantado en su lugar es una Indura.",
                who + " spent everything. What stood up in its place is an Indura."));
        }
    }
}
