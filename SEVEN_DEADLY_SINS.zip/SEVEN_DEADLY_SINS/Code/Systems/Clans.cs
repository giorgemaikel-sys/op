using System.Collections.Generic;
using UnityEngine;

namespace SevenDeadlySins
{
    /// The six clans of Britannia. Exactly one per person: they are a species, not a hobby.
    ///
    /// The Demon/Goddess pair is the spine of the whole setting, so it is the only asymmetry
    /// implemented in both directions — Ark sears demons AND demons are written as vulnerable to it.
    /// Everything else is stat shaping plus one signature behaviour per clan.
    public static class Clans
    {
        public const string Human = "sds_clan_human";
        public const string Demon = "sds_clan_demon";
        public const string Goddess = "sds_clan_goddess";
        public const string Fairy = "sds_clan_fairy";
        public const string Giant = "sds_clan_giant";
        public const string Vampire = "sds_clan_vampire";

        public static readonly string[] All = { Human, Demon, Goddess, Fairy, Giant, Vampire };

        private const string Group = "sds_group_clans";

        // Radii are in tiles. Kept modest: every one of these is a proximity scan on a sliced tick.
        private const float ArkRadius = 9f;
        private const float DrainRadius = 2.5f;

        public static void Init()
        {
            Human_();
            Demon_();
            Goddess_();
            Fairy_();
            Giant_();
            Vampire_();

            // Exactly one clan per unit. Inert until SDSRegistry.ApplyOpposites runs at the end of
            // the load — see the invariant in DESIGN.md.
            SDSRegistry.Opposites(All);

            SDSTick.Register(Tick);
        }

        // ---------------------------------------------------------------- the six

        private static ActorTrait New(string id, string icon)
        {
            ActorTrait t = SDSRegistry.Trait(id, Group, "ui/icons/" + id);
            t.type = TraitType.Other;
            return t;
        }

        private static void Human_()
        {
            ActorTrait t = New(Human, Human);
            // Deliberately flat. Humans are the baseline every other clan is measured against, and
            // the only people who may hold a Sin or climb the Holy Knight ranks.
            PowerLevel.Grant(t, 8f, 6f, 4f);
            SDSRegistry.AddTrait(t);
            SDSLocale.Trait(Human, "Clan de los Humanos",
                "El pueblo mas corto de vida y mas numeroso de Britannia. Solo los humanos pueden "
                + "ascender como Caballeros Sagrados y portar uno de los Siete Pecados Capitales.");
        }

        private static void Demon_()
        {
            ActorTrait t = New(Demon, Demon);
            PowerLevel.Grant(t, 90f, 70f, 110f);
            t.base_stats["damage"] = 14f;
            t.base_stats["armor"] = 6f;
            t.base_stats["health"] = 120f;
            t.base_stats["multiplier_lifespan"] = 2.5f;
            SDSRegistry.AddTrait(t);
            SDSLocale.Trait(Demon, "Clan de los Demonios",
                "Hijos del Rey Demonio. Regeneran, golpean mas fuerte de lo que la carne permite y el "
                + "veneno no les hace nada. Pero la luz del Ark los quema.");
        }

        private static void Goddess_()
        {
            ActorTrait t = New(Goddess, Goddess);
            PowerLevel.Grant(t, 70f, 110f, 120f);
            t.base_stats["damage"] = 9f;
            t.base_stats["armor"] = 5f;
            t.base_stats["health"] = 90f;
            t.base_stats["multiplier_lifespan"] = 3f;
            SDSRegistry.AddTrait(t);
            SDSLocale.Trait(Goddess, "Clan de las Diosas",
                "Siervas de la Diosa Suprema. Su Ark cierra las heridas de los suyos y abrasa a los demonios.");
        }

        private static void Fairy_()
        {
            ActorTrait t = New(Fairy, Fairy);
            PowerLevel.Grant(t, 40f, 60f, 80f);
            t.base_stats["speed"] = 12f;
            t.base_stats["health"] = 45f;
            t.base_stats["multiplier_lifespan"] = 6f;
            SDSRegistry.AddTrait(t);
            SDSLocale.Trait(Fairy, "Clan de las Hadas",
                "El pueblo alado del Bosque del Rey Hada. Vuelan, viven siglos, y el bosque los cura.");
        }

        private static void Giant_()
        {
            ActorTrait t = New(Giant, Giant);
            PowerLevel.Grant(t, 130f, 60f, 30f);
            t.base_stats["damage"] = 16f;
            t.base_stats["health"] = 260f;
            t.base_stats["armor"] = 10f;
            t.base_stats["knockback"] = 4f;
            t.base_stats["speed"] = -8f;      // heavy and slow: that is the trade

            // No scale bump. Giants used to be blown up to nearly double, which at sixteen pixels
            // deformed the sprite instead of enlarging it. Their size now lives in the numbers —
            // health, damage, knockback — not in a stretched body.
            t.base_stats["multiplier_lifespan"] = 3f;
            SDSRegistry.AddTrait(t);
            SDSLocale.Trait(Giant, "Clan de los Gigantes",
                "Guerreros del Calabozo de los Gigantes. Enormes, durisimos y lentos de mover.");
        }

        private static void Vampire_()
        {
            ActorTrait t = New(Vampire, Vampire);
            PowerLevel.Grant(t, 75f, 55f, 65f);
            t.base_stats["damage"] = 11f;
            t.base_stats["health"] = 80f;
            t.base_stats["multiplier_lifespan"] = 5f;
            SDSRegistry.AddTrait(t);
            SDSLocale.Trait(Vampire, "Clan de los Vampiros",
                "Sellados por Meliodas hace mucho. Drenan la vida de lo que hieren, y la luz del dia los debilita.");
        }

        // ---------------------------------------------------------------- behaviour

        /// Per-actor, on the sliced tick. dt is seconds since THIS actor was last visited.
        private static void Tick(Actor a, float dt)
        {
            if (a == null || !a.isAlive() || a.data == null) return;

            // Newborns and freshly spawned units arrive with no clan. This is where they get one —
            // guarded by SDSData.ClanAssigned so it costs one dictionary read per unit per sweep
            // after the first, not a trait scan.
            if (!SDSData.GetBool(a, SDSData.ClanAssigned)) Assign(a);

            if (a.hasTrait(Demon)) TickDemon(a, dt);
            else if (a.hasTrait(Goddess)) TickGoddess(a, dt);
            else if (a.hasTrait(Fairy)) TickFairy(a, dt);
            else if (a.hasTrait(Vampire)) TickVampire(a, dt);
        }

        /// Demons close their own wounds. Slower in a fight, so regeneration flavours a duel instead
        /// of deciding it.
        private static void TickDemon(Actor a, float dt)
        {
            Regenerate(a, a.has_attack_target ? 1.5f : 4f, dt);
        }

        /// Ark: mends the faithful, sears the demonic. One pass, both effects — this IS the Holy War
        /// in mechanical form, so it is worth the proximity scan.
        private static void TickGoddess(Actor a, float dt)
        {
            Regenerate(a, 1f, dt);

            // El halo SIEMPRE encima. El usuario se quejaba de que las diosas casi nunca muestran
            // sus efectos: aqui se garantiza que se vea que lo son, este o no combatiendo. Barato,
            // con su propia cadencia para no dibujar un halo por frame.
            if (SDSData.TryUse(a, "goddess_halo", 3f)) SDSFx.At(a, Effects.Halo, 0.4f);

            if (!SDSData.TryUse(a, "clan_ark", 2f)) return;

            List<Actor> nearby = SDSUnit.Around(a, ArkRadius);
            float magic = PowerLevel.Magic(a);

            for (int i = 0; i < nearby.Count; i++)
            {
                Actor other = nearby[i];
                if (other == null || !other.isAlive()) continue;

                // La luz solo quema a un demonio si es ENEMIGO de verdad. Antes quemaba a todo
                // demonio "hubiera guerra o no", y eso rompia dos cosas del canon a la vez:
                //
                //  - Elizabeth (diosa) quemaba a Meliodas y a Gowther, que llevan el clan Demonio
                //    por sus Pecados, y ellos CONTRAATACABAN. De ahi el "Meliodas y Gowther atacan
                //    a Elizabeth" — no la atacaban, se defendian de su aura.
                //  - Demonios y diosas del mismo reino, o en paz, se mataban solos. En la serie no
                //    estan siempre en guerra: hay treguas, alianzas, y hasta amor entre los dos
                //    bandos. La Guerra Santa es un estado, no una ley de la naturaleza.
                //
                // SOLO contra un demonio ENEMIGO DE VERDAD (reinos en guerra). Fuera de la guerra,
                // demonios y diosas no se hacen dano por verse. Como se quito la enemistad permanente
                // demonio-diosa, `Hostile` es falso en paz y esto no dispara.
                if (other.hasTrait(Demon) && Hostile(a, other))
                {
                    try { other.getHit(4f + magic * 0.03f, true, AttackType.Fire, a, true); }
                    catch { }
                }
                else if (other.kingdom == a.kingdom)
                {
                    Heal(other, 3f + magic * 0.02f);
                }
            }
        }

        /// True cuando `a` de verdad pelearia contra `b`: distinto reino y diplomacia hostil.
        ///
        /// Es la unica puerta por la que un aura de clan puede hacer dano a otro. Un companero
        /// (mismo reino) nunca es hostil, asi que los Siete Pecados no se tocan entre si aunque
        /// mezclen clanes — Meliodas es Demonio, King es Hada, y son aliados.
        public static bool Hostile(Actor a, Actor b)
        {
            if (a == null || b == null || a == b) return false;
            if (a.kingdom != null && a.kingdom == b.kingdom) return false;
            try { return a.canAttackTarget(b, true, false); }
            catch { return false; }
        }

        /// The forest heals its own. Tile-type inspection is not verifiable on this build, so this is
        /// a flat gentle regeneration rather than a wrong guess about terrain.
        private static void TickFairy(Actor a, float dt)
        {
            Regenerate(a, 1.2f, dt);

            // Las alas, aleteando encima. En la serie las hadas vuelan, y el mod las tenia sin nada
            // que las distinguiera de un humano verde. Ahora se les ve el aleteo constante.
            if (SDSData.TryUse(a, "fairy_wings", 2.5f)) SDSFx.At(a, Effects.Wings, 0.4f);
        }

        /// Drains what it wounds, and the sun hurts. Both halves are what makes a vampire a vampire,
        /// so neither is decorative.
        private static void TickVampire(Actor a, float dt)
        {
            if (DayCycle.IsDay)
            {
                // Daylight: steady attrition, worse the higher the sun. Never lethal on its own —
                // a vampire caught at noon should be in trouble, not deleted.
                float burn = DayCycle.SunHeight() * 2.5f * dt;
                if (burn > 0.05f && a.data.health > a.getMaxHealth() * 0.15f)
                {
                    try { a.getHit(burn, false, AttackType.Fire, null, false); }
                    catch { }
                }
                return;
            }

            if (!a.has_attack_target) return;
            if (!SDSData.TryUse(a, "clan_drain", 1.5f)) return;

            List<Actor> nearby = SDSUnit.Around(a, DrainRadius);
            for (int i = 0; i < nearby.Count; i++)
            {
                Actor prey = nearby[i];
                if (prey == null || !prey.isAlive()) continue;
                if (prey.kingdom == a.kingdom) continue;
                if (prey.hasTrait(Vampire)) continue;

                float bite = 5f + PowerLevel.Strength(a) * 0.02f;
                try { prey.getHit(bite, true, AttackType.Other, a, true); }
                catch { continue; }

                Heal(a, bite * 0.6f);
                break;   // one victim per bite
            }
        }

        // ---------------------------------------------------------------- helpers

        private static void Regenerate(Actor a, float perSecond, float dt)
        {
            float max = a.getMaxHealth();
            if (max <= 0f || a.data.health >= max) return;
            Heal(a, perSecond * dt);
        }

        /// restoreHealth takes an int, so anything under 1 truncates to nothing. Sub-1 amounts are
        /// promoted to 1 rather than silently discarded — otherwise a slow regeneration on a short
        /// tick never heals at all.
        private static void Heal(Actor a, float amount)
        {
            if (a == null || amount <= 0f) return;
            try { a.restoreHealth(Mathf.Max(1, Mathf.RoundToInt(amount))); }
            catch { }
        }

        // ---------------------------------------------------------------- assignment

        /// Gives a clan to someone who has none, matching the race they were born as. Anyone whose
        /// race the mod does not own — vanilla humans, above all — becomes Human, so the world reads
        /// as mostly human with the other clans as the exception that matters.
        public static void Assign(Actor a)
        {
            if (a == null || !SDSUnit.IsSentient(a)) return;
            if (SDSUnit.ClanOf(a) != null) return;
            if (SDSData.GetBool(a, SDSData.ClanAssigned)) return;

            SDSData.SetBool(a, SDSData.ClanAssigned, true);

            // A newborn takes the clan of its people. Anyone born as a plain vanilla human — which
            // is everyone the mod did not place, plus every named character — becomes a Human, and
            // Legends overwrites that a sweep later for the ones who are not.
            string clan = a.asset != null ? Actors.ClanOfRace(a.asset.id) : null;
            SDSTraits.Give(a, clan ?? Human);
        }

        public static void Give(Actor a, string clanId)
        {
            if (a == null || string.IsNullOrEmpty(clanId)) return;
            SDSData.SetBool(a, SDSData.ClanAssigned, true);
            SDSTraits.GiveExclusive(a, clanId, All);
        }

        /// Only humans carry the Sins. Every other clan has its own place in the story.
        public static bool CanBearSin(Actor a)
        {
            return a != null && a.hasTrait(Human);
        }
    }
}
