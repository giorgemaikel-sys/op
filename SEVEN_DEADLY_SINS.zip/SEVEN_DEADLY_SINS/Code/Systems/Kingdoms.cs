namespace SevenDeadlySins
{
    /// A wild kingdom and a civilised kingdom for every people of Britannia.
    ///
    /// THIS IS WHAT WAS CRASHING THE GAME. Each race actor points at kingdom_id_wild and
    /// kingdom_id_civilization by id. Those ids have to resolve to real KingdomAssets — when they
    /// did not, ActorManager.prepareForMetaChecks dereferenced null on EVERY FRAME of the
    /// simulation. The units existed, walked around, and took the whole meta layer down with them,
    /// which is also why they could not be selected: the meta pass that builds selection never
    /// finished.
    ///
    /// The clone chain is the game's own: nomads_human -> nomads_&lt;race&gt;, then
    /// nomads_&lt;race&gt; -> &lt;race&gt; with civ enabled. Registered BEFORE the architecture and
    /// the actors, because both of those store references to what is built here.
    ///
    /// The Holy War lives here too, as tags: Demons and Goddesses are enemies at the KINGDOM level,
    /// so their wars start the way the game starts every other war instead of being simulated by a
    /// tick handler nudging health.
    public static class Kingdoms
    {
        private const string Tag = "sds";

        public static void Init()
        {
            Race(Actors.Goddess, "#F2E3B0", "goddess");
            Race(Actors.Fairy, "#3FA96B", "fairy");
            Race(Actors.Giant, "#B5651D", "giant");
            Race(Actors.Demon, "#8E1F2B", "demon");
            Race(Actors.Vampire, "#6B3A8A", "vampire");

            Horde();
            Feud();
        }

        /// El reino al que pertenece todo lo que sale del Purgatorio.
        public const string PurgatoryHorde = "nomads_sds_horde";

        /// La horda: bestias que atacan a todo lo que no sea de los suyos.
        ///
        /// La hostilidad en WorldBox NO va por `ActorAsset.aggression` — ese campo esta declarado y
        /// no se lee en ningun sitio del juego, es codigo muerto. Va por el REINO, con las mismas
        /// dos banderas que usa el juego para sus propios monstruos rabiosos (el reino `mad`).
        ///
        /// `always_attack_each_other` se queda en false a proposito, aunque el Purgatorio de la
        /// serie sea una carniceria constante: con esa bandera la horda se mata a si misma y el
        /// mapa se vacia solo. Atacan a todo lo de fuera, que es lo que hace falta para que entrar
        /// alli sea peligroso.
        private static void Horde()
        {
            try
            {
                if (AssetManager.kingdoms.get(PurgatoryHorde) != null) return;

                KingdomAsset horde = AssetManager.kingdoms.clone(PurgatoryHorde, "nomads_human");
                if (horde == null) return;

                horde.group_main = true;
                horde.default_kingdom_color = ColorAsset.tryMakeNewColorAsset("#5A1020");
                horde.units_always_looking_for_enemies = true;
                horde.always_attack_each_other = false;
                horde.neutral = false;
                horde.civ = false;
                horde.mobs = true;
                horde.addTag(Tag);
                horde.addTag("sds_horde");
                horde.addFriendlyTag("sds_horde");
            }
            catch { }
        }

        /// Builds the pair of kingdoms a race needs to exist.
        private static void Race(string raceId, string colorHex, string tag)
        {
            try
            {
                // --- the wild / nomad kingdom -------------------------------------
                string wildId = "nomads_" + raceId;
                if (AssetManager.kingdoms.get(wildId) == null)
                {
                    KingdomAsset nomads = AssetManager.kingdoms.clone(wildId, "nomads_human");
                    if (nomads == null) return;

                    nomads.group_main = true;
                    nomads.default_kingdom_color = ColorAsset.tryMakeNewColorAsset(colorHex);
                    nomads.addTag(Tag);
                    nomads.addTag(tag);
                    nomads.addTag("sliceable");
                    nomads.addFriendlyTag(tag);
                }

                // --- the civilised kingdom ----------------------------------------
                if (AssetManager.kingdoms.get(raceId) == null)
                {
                    KingdomAsset civ = AssetManager.kingdoms.clone(raceId, wildId);
                    if (civ == null) return;

                    civ.group_main = true;
                    civ.clearKingdomColor();
                    civ.civ = true;
                    civ.mobs = false;
                    civ.addTag("civ");
                    civ.addTag(Tag);
                    civ.addTag(tag);
                    civ.addFriendlyTag(tag);
                    civ.addEnemyTag("bandit");
                }

                SDSLocale.Kingdom(raceId, Name(tag));
            }
            catch (System.Exception e)
            {
                SDSLog.Error("reino de '" + raceId + "': " + e.Message);
            }
        }

        /// La diplomacia entre pueblos. DEMONIOS Y DIOSAS YA NO SON ENEMIGOS PERMANENTES.
        ///
        /// El usuario lo repitio: no quiere que demonios y diosas se peleen solos, solo durante la
        /// Guerra Santa. Antes esto ponia enemistad de reino permanente (`Enemy(Demon, "goddess")`),
        /// y la IA del juego los hacia pelear pasara lo que pasara — por encima de cualquier arreglo
        /// en las habilidades. Se ha QUITADO esa enemistad: los dos bandos son neutrales por
        /// defecto, y solo chocan cuando la Guerra Santa esta declarada, via el mecanismo propio de
        /// HolyWar (que mira los clanes con AreEnemyClans, no las etiquetas de reino).
        ///
        /// Las ALIANZAS se quedan (diosas, hadas, gigantes y humanos se reconocen como amigos):
        /// eso no genera peleas, solo evita que se ataquen entre ellos.
        private static void Feud()
        {
            try
            {
                Friendly(Actors.Goddess, new[] { "fairy", "giant", "human" });
                Friendly(Actors.Fairy, new[] { "goddess", "giant", "human" });
                Friendly(Actors.Giant, new[] { "goddess", "fairy", "human" });

                // Los vampiros siguen siendo hostiles: Meliodas los sello, no tienen amigos. Esto SI
                // se queda — el usuario solo pidio la paz entre demonios y diosas.
                Enemy(Actors.Vampire, "human");

                // Los reinos humanos vanilla reconocen a los recien llegados como gente, sin declarar
                // enemistad con los demonios (esa la lleva la Guerra Santa cuando toca).
                foreach (string k in new[] { "human", "nomads_human" })
                {
                    KingdomAsset h = AssetManager.kingdoms.get(k);
                    if (h == null) continue;
                    h.addFriendlyTag("goddess");
                    h.addFriendlyTag("fairy");
                    h.addFriendlyTag("giant");
                }
            }
            catch (System.Exception e)
            {
                SDSLog.Error("diplomacia de la Guerra Santa: " + e.Message);
            }
        }

        private static void Friendly(string kingdomId, string[] tags)
        {
            foreach (string id in new[] { kingdomId, "nomads_" + kingdomId })
            {
                KingdomAsset k = AssetManager.kingdoms.get(id);
                if (k == null) continue;
                for (int i = 0; i < tags.Length; i++) k.addFriendlyTag(tags[i]);
            }
        }

        private static void Enemy(string kingdomId, string tag)
        {
            foreach (string id in new[] { kingdomId, "nomads_" + kingdomId })
            {
                KingdomAsset k = AssetManager.kingdoms.get(id);
                if (k == null) continue;
                k.addEnemyTag(tag);
            }
        }

        private static string Name(string tag)
        {
            switch (tag)
            {
                case "goddess": return "Reino Celestial";
                case "fairy": return "Bosque del Rey Hada";
                case "giant": return "Calabozo de los Gigantes";
                case "demon": return "Purgatorio";
                case "vampire": return "Edinburgh";
                default: return tag;
            }
        }
    }
}
