using System.Collections.Generic;
using UnityEngine;

namespace SevenDeadlySins
{
    /// The five kinds of magic (DESIGN.md section 6).
    ///
    /// Every magic user in Britannia has EXACTLY ONE — the five traits are mutually exclusive — and
    /// each one has to earn its name in the simulation, not just in its tooltip:
    ///
    ///   Reforzador  multiplies his own physical stats while fighting
    ///   Encantador  buffs the allies standing around him
    ///   Hechicero   throws magic bolts from outside melee reach
    ///   Sanador     mends the worst-wounded ally in reach
    ///   Especial    a one-of-a-kind power, and the gate every Sin must pass
    ///
    /// Special is deliberately the rarest: SevenSins reads TypeOf() and refuses to hand a Sin to
    /// anyone who is not a Special-magic user, exactly as the series does.
    public static class MagicTypes
    {
        public const string Strengthener = "sds_magic_strengthener";
        public const string Enchanter = "sds_magic_enchanter";
        public const string Incantation = "sds_magic_incantation";
        public const string Healer = "sds_magic_healer";
        public const string Special = "sds_magic_special";

        public static readonly string[] All = { Strengthener, Enchanter, Incantation, Healer, Special };

        // --- statuses this system owns ---
        public const string StatusReinforced = "sds_status_reinforced";
        public const string StatusEnchanted = "sds_status_enchanted";
        public const string StatusSpecialMagic = "sds_status_special_magic";

        // --- effects this system owns ---
        public const string FxEnchant = "sds_fx_enchant";
        public const string FxHeal = "sds_fx_heal";

        /// The trait group is pinned by the design contract as an ID, not as an accessor name, so it
        /// is written literally here. TraitGroups is what actually registers it.
        private const string Group = "sds_group_magic";

        // --- per-actor bookkeeping, all in Actor.data so it survives a save ---
        private const string DataRolled = "sds_magic_rolled";        // the one-time "do you have magic at all" roll
        private const string DataSignature = "sds_magic_signature";  // which shape a Special user's power takes

        // Radii stay under 15 tiles on purpose: SDSUnit.Around searches a 3x3 block of chunks, and a
        // wider request would silently miss units sitting in the corners of that block.
        private const float EnchantRadius = 14f;
        private const float HealRadius = 14f;
        private const float BoltRange = 26f;

        private const int MinAge = 12;                 // magic manifests around puberty, never on a toddler
        private const float AwakenChance = 0.35f;      // a third of the sentient world carries magic at all

        public static void Init()
        {
            RegisterTraits();
            RegisterStatuses();
            RegisterEffects();

            // One magic type per person. Without this a unit could end up Healer AND Hechicero.
            SDSRegistry.Opposites(All);

            // Reinforcement is genuinely MULTIPLICATIVE, so it is registered as a Power Level
            // contributor rather than baked into the status. That way a Reforzador who is also
            // wearing the Demon Mark gets both multipliers instead of one overwriting the other.
            PowerLevel.AddContributor("magia_reforzador", ReinforcementMultiplier);

            SDSTick.Register(Tick);
        }

        // ---------------------------------------------------------------- registration

        private static void RegisterTraits()
        {
            // rate_inherit 40: magic tends to run in a bloodline without being guaranteed.
            // rate_birth stays 0 (SDSRegistry.Trait never sets it) — the game's birth pool is
            // species-blind and would otherwise roll "Sanador" onto a wolf.
            Type(Strengthener, "ui/icons/sds_magic_strengthener", 45f, 15f, 10f,
                "Reforzador",
                "Su magia multiplica su propio cuerpo. En combate su fuerza, su dano y su armadura se disparan.");

            Type(Enchanter, "ui/icons/sds_magic_enchanter", 15f, 25f, 30f,
                "Encantador",
                "Encanta a quienes lucha a su lado: los aliados cercanos pelean mejor mientras el vive.");

            Type(Incantation, "ui/icons/sds_magic_incantation", 10f, 20f, 45f,
                "Hechicero",
                "Recita conjuros y lanza proyectiles magicos desde lejos, sin entrar al cuerpo a cuerpo.");

            Type(Healer, "ui/icons/sds_magic_healer", 10f, 30f, 35f,
                "Sanador",
                "Cierra las heridas de los aliados que tiene cerca, empezando por el que peor esta.");

            Type(Special, "ui/icons/sds_magic_special", 25f, 55f, 70f,
                "Magia Especial",
                "Un poder unico e irrepetible, que no se parece al de nadie mas. Solo quien lo posee puede portar un Pecado Capital.");
        }

        private static void Type(string id, string icon, float strength, float spirit, float magic,
                                 string name, string info)
        {
            ActorTrait t = SDSRegistry.Trait(id, Group, icon, 40);
            PowerLevel.Grant(t, strength, spirit, magic);
            SDSRegistry.AddTrait(t);
            SDSLocale.Trait(id, name, info);
        }

        private static void RegisterStatuses()
        {
            // The Reforzador's own body, swollen with magic. sds_strength is on here as well as the
            // multiplier so the Power Level in the unit panel visibly jumps the moment he engages.
            StatusAsset reinforced = SDSRegistry.Status(StatusReinforced, "ui/icons/sds_status_reinforced", 8f);
            reinforced.base_stats.set("damage", 20f);
            reinforced.base_stats.set("armor", 12f);
            reinforced.base_stats.set("health", 80f);
            reinforced.base_stats.set("multiplier_damage", 0.35f);
            reinforced.base_stats.set(PowerLevel.StatStrength, 80f);
            // A buff that vanished the instant its owner was struck would never survive the fight it
            // exists for. The engine strips statuses on damage by default.
            reinforced.removed_on_damage = false;
            SDSRegistry.AddStatus(reinforced);
            SDSLocale.Status(StatusReinforced, "Cuerpo Reforzado",
                "Su magia le recorre los musculos: golpea mas fuerte y aguanta mucho mas.");

            StatusAsset enchanted = SDSRegistry.Status(StatusEnchanted, "ui/icons/sds_status_enchanted", 14f);
            enchanted.base_stats.set("damage", 15f);
            enchanted.base_stats.set("armor", 10f);
            enchanted.base_stats.set("speed", 4f);
            enchanted.base_stats.set("multiplier_damage", 0.15f);
            enchanted.base_stats.set(PowerLevel.StatSpirit, 25f);
            enchanted.removed_on_damage = false;
            SDSRegistry.AddStatus(enchanted);
            SDSLocale.Status(StatusEnchanted, "Encantado",
                "Un Encantador le ha reforzado: pelea por encima de lo que su cuerpo daria de si.");

            StatusAsset special = SDSRegistry.Status(StatusSpecialMagic, "ui/icons/sds_status_special_magic", 10f);
            special.base_stats.set("damage", 25f);
            special.base_stats.set("armor", 15f);
            special.base_stats.set(PowerLevel.StatMagic, 120f);
            special.base_stats.set(PowerLevel.StatSpirit, 60f);
            special.removed_on_damage = false;
            SDSRegistry.AddStatus(special);
            SDSLocale.Status(StatusSpecialMagic, "Magia Especial Desatada",
                "Ha liberado su poder unico. Nadie mas en el mundo puede hacer exactamente esto.");
        }

        private static void RegisterEffects()
        {
            SDSRegistry.Effect(FxEnchant, "effects/sds_fx_enchant/");
            SDSRegistry.Effect(FxHeal, "effects/sds_fx_heal/");
        }

        // ---------------------------------------------------------------- public API

        /// The magic trait this unit carries, or null. The five are mutually exclusive, so there is
        /// at most one — but the loop is written over All so a stray duplicate still resolves.
        public static string TypeOf(Actor a)
        {
            if (a == null) return null;
            for (int i = 0; i < All.Length; i++)
                if (a.hasTrait(All[i])) return All[i];
            return null;
        }

        /// The gate SevenSins reads: only a Special-magic user may ever bear a Sin.
        public static bool IsSpecial(Actor a)
        {
            return a != null && a.hasTrait(Special);
        }

        /// Gives this unit a magic type, rolled by weight, and latches it so nothing rolls again.
        /// Always produces a type — the "does this person have magic at all?" question is answered
        /// by TryAwaken, not here, so Legends can hand a named character their magic outright.
        public static void Assign(Actor a)
        {
            if (a == null || !a.isAlive()) return;
            if (!SDSUnit.IsSentient(a)) return;
            if (TypeOf(a) != null) { SDSData.SetBool(a, DataRolled, true); return; }

            Give(a, Roll());
        }

        /// Hands over one specific type, stripping the other four. Used by Assign and by Legends when
        /// a named character's magic is fixed by canon (Merlin is Special, Ban is a Reforzador).
        public static void Give(Actor a, string magicType)
        {
            if (a == null || string.IsNullOrEmpty(magicType)) return;

            SDSTraits.GiveExclusive(a, magicType, All);
            SDSData.SetBool(a, DataRolled, true);
        }

        /// Weighted draw. Special sits at 5%: it is the rarest magic in Britannia and the only door
        /// to a Sin, so it must stay scarce or the Seven stop meaning anything.
        private static string Roll()
        {
            float r = Random.value;
            if (r < 0.32f) return Strengthener;
            if (r < 0.56f) return Enchanter;
            if (r < 0.79f) return Incantation;
            if (r < 0.95f) return Healer;
            return Special;
        }

        // ---------------------------------------------------------------- tick

        private static void Tick(Actor a, float dt)
        {
            string type = TypeOf(a);
            if (type == null)
            {
                TryAwaken(a);
                return;
            }

            if (type == Strengthener) { TickStrengthener(a); return; }
            if (type == Enchanter) { TickEnchanter(a); return; }
            if (type == Incantation) { TickIncantation(a); return; }
            if (type == Healer) { TickHealer(a, dt); return; }
            if (type == Special) TickSpecial(a);
        }

        /// The once-per-lifetime question: does this person have magic at all? Latched in Actor.data
        /// so a unit who came up empty is never asked again — otherwise every sweep would be another
        /// 35% roll and the whole world would end up a magic user within a minute.
        private static void TryAwaken(Actor a)
        {
            // Cheapest rejection first: this runs for every unit in the world on every sweep, and
            // most of them are wolves. A HashSet hit beats a dictionary read on Actor.data.
            if (!SDSUnit.IsSentient(a)) return;
            if (SDSData.GetBool(a, DataRolled)) return;
            if (AgeOf(a) < MinAge) return;          // ask again when they have grown up

            SDSData.SetBool(a, DataRolled, true);
            if (Random.value >= AwakenChance) return;

            Give(a, Roll());
        }

        // ---------------------------------------------------------------- Reforzador

        /// Muscle magic: the moment he has someone to fight, his own body is amplified.
        private static void TickStrengthener(Actor a)
        {
            if (!a.has_attack_target) return;
            if (a.hasStatus(StatusReinforced)) return;
            if (!SDSData.TryUse(a, Strengthener, Cooldown(6f))) return;

            try { a.addStatusEffect(StatusReinforced, 8f); }
            catch { }
        }

        /// The multiplicative half of reinforcement, composed with every other transformation.
        private static float ReinforcementMultiplier(Actor a)
        {
            if (a == null || !a.hasTrait(Strengthener)) return 1f;
            return a.hasStatus(StatusReinforced) ? 1.25f : 1f;
        }

        // ---------------------------------------------------------------- Encantador

        /// Lays his enchantment on the squad around him. Capped at six so one Encantador in a siege
        /// does not walk a whole army's worth of statuses every ten seconds.
        private static void TickEnchanter(Actor a)
        {
            if (!SDSData.TryUse(a, Enchanter, Cooldown(10f))) return;

            int touched = 0;
            List<Actor> nearby = SDSUnit.Around(a, EnchantRadius);
            for (int i = 0; i < nearby.Count; i++)
            {
                Actor ally = nearby[i];
                if (!SDSUnit.IsAlly(a, ally)) continue;
                if (ally.hasStatus(StatusEnchanted)) continue;

                try { ally.addStatusEffect(StatusEnchanted, 14f); }
                catch { continue; }

                touched++;
                if (touched >= 6) break;
            }

            if (touched > 0) SDSFx.Play(FxEnchant, a.current_tile);
        }

        // ---------------------------------------------------------------- Hechicero

        /// Resolved lazily, never during OnModLoad: Projectiles.Init has to have run first, and
        /// touching the asset pipeline early is what poisons the sprite cache for the session.
        private static string _boltId;
        private static bool _boltResolved;

        private static string BoltId
        {
            get
            {
                if (_boltResolved) return _boltId;
                _boltResolved = true;
                _boltId = FirstRegisteredProjectile("sds_proj_ark", "sds_proj_magic", "arrow");
                return _boltId;
            }
        }

        private static string FirstRegisteredProjectile(params string[] candidates)
        {
            for (int i = 0; i < candidates.Length; i++)
            {
                try
                {
                    if (AssetManager.projectiles.get(candidates[i]) != null) return candidates[i];
                }
                catch { }
            }
            SDSLog.Warn("ningun proyectil magico registrado; el Hechicero golpeara sin visual");
            return null;
        }

        /// Bolts from range. The projectile is the visual; the damage is applied directly, the same
        /// way the rest of the mod's ranged abilities do it, so a blocked or collided projectile
        /// cannot silently swallow the whole cast.
        private static void TickIncantation(Actor a)
        {
            Actor target = a.attack_target as Actor;
            if (target == null || !target.isAlive()) return;
            if (a.current_tile == null || target.current_tile == null) return;
            if (!WithinRange(a, target, BoltRange)) return;
            if (!SDSData.TryUse(a, Incantation, Cooldown(5f))) return;

            Bolt(a, target, 1f);
        }

        private static void Bolt(Actor caster, Actor target, float power)
        {
            string bolt = BoltId;
            if (!string.IsNullOrEmpty(bolt))
            {
                try
                {
                    World.world.projectiles.spawn(caster, target, bolt,
                        caster.current_tile.posV3, target.current_tile.posV3);
                }
                catch { }
            }

            // Scales off the caster's Magic, so a village hedge-wizard stings and Merlin erases.
            float damage = (12f + PowerLevel.Magic(caster) * 0.12f) * power;
            try { target.getHit(damage, true, AttackType.Other, caster, true); }
            catch { }
        }

        private static bool WithinRange(Actor a, Actor b, float range)
        {
            float dx = a.current_tile.x - b.current_tile.x;
            float dy = a.current_tile.y - b.current_tile.y;
            return dx * dx + dy * dy <= range * range;
        }

        // ---------------------------------------------------------------- Sanador

        private const float HealerSelfPerSecond = 4f;
        private const float HealerAllyInterval = 2f;

        /// Mends himself continuously and, every couple of seconds, the ally in the worst shape
        /// within reach — one at a time, the way a field medic actually works.
        ///
        /// The ally sweep is on a timer rather than on every tick because Sanadores are common
        /// (16% of magic users) and each sweep is a proximity scan.
        private static void TickHealer(Actor a, float dt)
        {
            if (a.data.health < a.getMaxHealth())
            {
                try { a.restoreHealth((int)(HealerSelfPerSecond * dt)); }
                catch { }
            }

            if (!SDSData.TryUse(a, Healer, Cooldown(HealerAllyInterval))) return;

            HealWorstAlly(a, 1f);
        }

        /// Returns true when someone was actually treated.
        private static bool HealWorstAlly(Actor healer, float power)
        {
            Actor worst = null;
            float worstRatio = 1f;

            List<Actor> nearby = SDSUnit.Around(healer, HealRadius);
            for (int i = 0; i < nearby.Count; i++)
            {
                Actor other = nearby[i];
                if (!SDSUnit.IsAlly(healer, other)) continue;

                float max = other.getMaxHealth();
                if (max <= 0f) continue;

                float ratio = other.data.health / max;
                if (ratio >= 1f || ratio >= worstRatio) continue;

                worstRatio = ratio;
                worst = other;
            }

            if (worst == null) return false;

            float amount = (10f + PowerLevel.Magic(healer) * 0.08f) * power;
            try { worst.restoreHealth(Mathf.Max(1, (int)amount)); }
            catch { return false; }

            SDSFx.Play(FxHeal, worst.current_tile);
            return true;
        }

        // ---------------------------------------------------------------- Especial

        /// Special magic is by definition unlike anyone else's, so it cannot be one fixed routine.
        /// Each bearer draws a signature ONCE, keeps it for life (it is stored in Actor.data and
        /// survives the save), and unleashes that one shape of power — amplified well past what the
        /// ordinary four schools manage — on a long cooldown.
        private static void TickSpecial(Actor a)
        {
            int signature = SDSData.GetInt(a, DataSignature, -1);
            if (signature < 0)
            {
                signature = Random.Range(0, 4);
                SDSData.SetInt(a, DataSignature, signature);
            }

            if (!a.has_attack_target) return;
            if (!SDSData.TryUse(a, Special, Cooldown(18f))) return;

            try { a.addStatusEffect(StatusSpecialMagic, 10f); }
            catch { }

            switch (signature)
            {
                case 0:  // a body no ordinary Reforzador could build
                    try { a.addStatusEffect(StatusReinforced, 12f); }
                    catch { }
                    break;

                case 1:  // an enchantment that sweeps the whole battle line at once
                    EnchantWide(a);
                    break;

                case 2:  // a volley, not a bolt
                    Actor target = a.attack_target as Actor;
                    if (target != null && target.isAlive() &&
                        a.current_tile != null && target.current_tile != null)
                    {
                        Bolt(a, target, 2.2f);
                    }
                    break;

                default: // a wave of healing across the squad
                    for (int i = 0; i < 3; i++)
                    {
                        if (!HealWorstAlly(a, 2.5f)) break;
                    }
                    break;
            }

            SDSFx.Play(FxEnchant, a.current_tile);
        }

        private static void EnchantWide(Actor a)
        {
            List<Actor> nearby = SDSUnit.Around(a, EnchantRadius);
            int touched = 0;
            for (int i = 0; i < nearby.Count; i++)
            {
                Actor ally = nearby[i];
                if (!SDSUnit.IsAlly(a, ally)) continue;

                try { ally.addStatusEffect(StatusEnchanted, 20f); }
                catch { continue; }

                touched++;
                if (touched >= 12) break;
            }
        }

        // ---------------------------------------------------------------- helpers

        /// With cooldowns switched off in the config the abilities do not become free — they become
        /// fast. A true zero would fire an ability on every sweep for every unit in the world.
        private static float Cooldown(float seconds)
        {
            return SDSConfig.AbilityCooldowns ? seconds : seconds * 0.25f;
        }

        private static int AgeOf(Actor a)
        {
            try { return a.getAge(); }
            catch { return 0; }
        }
    }
}
