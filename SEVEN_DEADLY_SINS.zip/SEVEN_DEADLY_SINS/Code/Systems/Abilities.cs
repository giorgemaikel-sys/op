using System.Collections.Generic;
using UnityEngine;

namespace SevenDeadlySins
{
    /// The abilities that do not need a file of their own.
    ///
    /// Four of these traits (Creation, Invasion, Disaster, Infinity) are already REGISTERED by
    /// SevenSins because they come attached to a Sin — this file only gives them behaviour. The
    /// other three (Hellblaze, Ark, Purge) belong to bloodlines rather than to Sins, so they are
    /// registered here.
    public static class Abilities
    {
        public const string Creation = "sds_ability_creation";
        public const string Invasion = "sds_ability_invasion";
        public const string Disaster = "sds_ability_disaster";
        public const string Infinity = "sds_ability_infinity";
        public const string Hellblaze = "sds_ability_hellblaze";
        public const string Ark = "sds_ability_ark";
        public const string Purge = "sds_ability_purge";

        // Hellblaze es del Rey Demonio; Ark y Purge son luz de diosa. Van a grupos distintos porque
        // son cosas distintas, aunque las registre el mismo archivo.
        private const string GroupDemonic = "sds_group_demonic";
        private const string GroupGrace = "sds_group_grace";

        public static void Init()
        {
            Register(Hellblaze, GroupDemonic, "Llama del Infierno",
                "Fuego negro del Rey Demonio. Las heridas que abre no se cierran ni se curan.",
                70f, 40f, 90f);
            Register(Ark, GroupGrace, "Ark",
                "Luz del Clan de las Diosas. Cierra las heridas de los suyos y abrasa a los demonios.",
                30f, 80f, 100f);
            Register(Purge, GroupGrace, "Purga",
                "Llama blanca sagrada. Solo responde a quien sostiene el sol.",
                60f, 70f, 110f);

            SDSTick.Register(Tick);
        }

        private static void Register(string id, string group, string nameEs, string infoEs, float str, float spi, float mag)
        {
            // Guarded: SevenSins may already own an id if the design ever moves one across.
            if (AssetManager.traits.dict.ContainsKey(id)) return;

            ActorTrait t = SDSRegistry.Trait(id, group, "ui/icons/" + id);
            t.type = TraitType.Positive;
            PowerLevel.Grant(t, str, spi, mag);
            SDSRegistry.AddTrait(t);
            SDSLocale.Trait(id, nameEs, infoEs);
        }

        // ---------------------------------------------------------------- dispatch

        private static void Tick(Actor a, float dt)
        {
            if (a == null || !a.isAlive() || a.data == null) return;

            // Infinity is a passive and must run every sweep; the rest are active and gated by their
            // own cooldowns, so an early return on "not fighting" would break her immunity.
            if (a.hasTrait(Infinity)) TickInfinity(a);

            if (!a.has_attack_target) return;

            if (a.hasTrait(Creation)) TickCreation(a);
            if (a.hasTrait(Invasion)) TickInvasion(a);
            if (a.hasTrait(Disaster)) TickDisaster(a);
            if (a.hasTrait(Hellblaze)) TickHellblaze(a);
            if (a.hasTrait(Ark)) TickArk(a);
            if (a.hasTrait(Purge)) TickPurge(a);
        }

        private static float CD(float seconds)
        {
            return SDSConfig.AbilityCooldowns ? seconds : 0.2f;
        }

        /// The nearest living enemy, or null.
        private static Actor Enemy(Actor a, float radius)
        {
            List<Actor> nearby = SDSUnit.Around(a, radius);
            for (int i = 0; i < nearby.Count; i++)
            {
                Actor o = nearby[i];
                if (o != null && o.isAlive() && o.kingdom != a.kingdom) return o;
            }
            return null;
        }

        // ---------------------------------------------------------------- Creation (Diane, Drole)

        /// Throws the ground at people. The rock scales off Strength because Creation is a giant's
        /// magic — it is leverage, not sorcery.
        private static void TickCreation(Actor a)
        {
            if (!SDSData.TryUse(a, "creation", CD(4f))) return;

            Actor target = Enemy(a, 14f);
            if (target == null) return;

            SDSFx.Projectile(a, target, Projectiles.Creation);
            try { target.getHit(12f + PowerLevel.Strength(a) * 0.05f, true, AttackType.Other, a, true); }
            catch { }
            SDSFx.At(target, "sds_fx_creation", 0.4f);
        }

        // ---------------------------------------------------------------- Invasion (Gowther)

        /// Reaches into a mind and rewrites it. Two outcomes, because Gowther uses both: he takes
        /// people onto his side, and he empties them out.
        private static void TickInvasion(Actor a)
        {
            if (!SDSData.TryUse(a, "invasion", CD(12f))) return;

            Actor target = Enemy(a, 12f);
            if (target == null || target.kingdom == null) return;

            // Stronger minds resist. Without this he converts Commandments, which is absurd.
            if (PowerLevel.Get(target) > PowerLevel.Get(a)) return;

            if (Random.value < 0.5f)
            {
                // Wipe the memory: rank and training go first.
                for (int i = 0; i < HolyKnights.All.Length; i++)
                    SDSTraits.Remove(target, HolyKnights.All[i]);

                SDSLog.Tip(SDSLocale.T(
                    target.getName() + " ha olvidado quien era.",
                    target.getName() + " has forgotten who they were."));
            }
            else
            {
                try { target.setKingdom(a.kingdom); }
                catch { return; }

                SDSLog.Tip(SDSLocale.T(
                    target.getName() + " ahora cree que siempre estuvo de este lado.",
                    target.getName() + " now believes they were always on this side."));
            }

            SDSFx.At(target, "sds_fx_infinity", 0.35f);
        }

        // ---------------------------------------------------------------- Disaster (King)

        /// The Fairy King's full power: the spear goes out, and the forest takes life back in.
        private static void TickDisaster(Actor a)
        {
            if (!SDSData.TryUse(a, "disaster", CD(6f))) return;

            Actor target = Enemy(a, 15f);
            if (target == null) return;

            SDSFx.Projectile(a, target, Projectiles.Chastiefol);

            float power = 14f + PowerLevel.Magic(a) * 0.06f;
            try { target.getHit(power, true, AttackType.Other, a, true); }
            catch { }

            // Drains the area and feeds him with it.
            List<Actor> nearby = SDSUnit.Around(a, 7f);
            float drained = 0f;
            for (int i = 0; i < nearby.Count; i++)
            {
                Actor o = nearby[i];
                if (o == null || !o.isAlive() || o.kingdom == a.kingdom) continue;
                try { o.getHit(4f, true, AttackType.Other, a, true); drained += 2f; }
                catch { }
            }

            if (drained > 0f)
            {
                try { a.restoreHealth(Mathf.Max(1, Mathf.RoundToInt(drained))); }
                catch { }
            }

            SDSFx.At(target, "sds_fx_chastiefol", 0.4f);
        }

        // ---------------------------------------------------------------- Infinity (Merlin)

        /// Nothing sticks to her, and what she casts does not expire.
        ///
        /// The immunity is NOT enforced here. It is enforced at the point of application, in
        /// SDSStatus.Inflict, which refuses to put any negative status on a bearer of Infinity in the
        /// first place. That is both truer to "nothing sticks to her" and the only version that works
        /// without a verified status-removal signature — see the note in SDSStatus.
        ///
        /// All this does is keep the visible mark on her.
        private static void TickInfinity(Actor a)
        {
            if (a.hasStatus("sds_status_infinity")) return;
            if (!SDSData.TryUse(a, "infinity_mark", 20f)) return;

            try { a.addStatusEffect("sds_status_infinity", 9999f); }
            catch { }
        }

        // ---------------------------------------------------------------- Hellblaze

        /// Black flame. The damage is secondary — what matters is that the wound will not close,
        /// which is what makes it the only thing that can put down an immortal.
        private static void TickHellblaze(Actor a)
        {
            if (!SDSData.TryUse(a, "hellblaze", CD(5f))) return;

            Actor target = Enemy(a, 12f);
            if (target == null) return;

            SDSFx.Projectile(a, target, Projectiles.Hellblaze);

            try { target.getHit(10f + PowerLevel.Magic(a) * 0.05f, true, AttackType.Fire, a, true); }
            catch { }

            // Refused outright against Infinity, and then the flame never shows — an immune target
            // should read as "nothing happened", not as a hit that failed to land.
            if (SDSStatus.Inflict(target, "sds_status_hellblaze", 20f))
                SDSFx.At(target, "sds_fx_hellblaze", 0.4f);
        }

        // ---------------------------------------------------------------- Ark

        /// Mends the faithful, burns the demonic. The clan trait already does a passive version of
        /// this; the ability is the deliberate, stronger cast.
        private static void TickArk(Actor a)
        {
            if (!SDSData.TryUse(a, "ark", CD(5f))) return;

            float magic = PowerLevel.Magic(a);
            List<Actor> nearby = SDSUnit.Around(a, 11f);
            bool used = false;

            for (int i = 0; i < nearby.Count; i++)
            {
                Actor o = nearby[i];
                if (o == null || !o.isAlive()) continue;

                // SOLO quema al demonio ENEMIGO DE VERDAD (reinos en guerra). Antes quemaba a
                // cualquier demonio "por su sangre" — por eso Elizabeth quemaba a Meliodas y se
                // liaban. Como ya no hay enemistad permanente demonio-diosa, `Hostile` es falso en
                // paz: Ark solo cura, y solo quema durante una guerra real.
                if (o.hasTrait(Clans.Demon) && Clans.Hostile(a, o))
                {
                    try { o.getHit(12f + magic * 0.06f, true, AttackType.Fire, a, true); used = true; }
                    catch { }
                }
                else if (SDSUnit.IsAlly(a, o))   // aliado robusto: cura aunque el hibrido sea salvaje
                {
                    try { o.restoreHealth(Mathf.Max(1, Mathf.RoundToInt(8f + magic * 0.04f))); used = true; }
                    catch { }

                    // El estado de bendicion estaba registrado con icono y texto y no lo aplicaba
                    // nadie. Ark cura Y bendice; sin esto solo curaba.
                    SDSStatus.Inflict(o, "sds_status_ark_blessing", 12f);
                }
            }

            if (used) SDSFx.At(a, "sds_fx_ark", 0.5f);
        }

        // ---------------------------------------------------------------- Purge

        /// White flame. Hits harder than Ark and does not discriminate by kingdom — only by blood.
        private static void TickPurge(Actor a)
        {
            if (!SDSData.TryUse(a, "purge", CD(7f))) return;

            Actor target = Enemy(a, 13f);
            if (target == null) return;

            float power = 18f + PowerLevel.Magic(a) * 0.07f;
            if (target.hasTrait(Clans.Demon)) power *= 2f;   // it was made for demons

            try { target.getHit(power, true, AttackType.Fire, a, true); }
            catch { }

            SDSFx.At(target, "sds_fx_purge", 0.45f);
        }
    }
}
