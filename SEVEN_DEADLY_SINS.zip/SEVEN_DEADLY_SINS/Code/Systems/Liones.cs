using System.Collections.Generic;
using UnityEngine;

namespace SevenDeadlySins
{
    /// Los Caballeros Sagrados de Liones y los Vampiros de Edimburgo.
    ///
    /// El mod tenia los rangos de Caballero Sagrado desde el principio, pero ningun caballero: un
    /// Gran Maestro era un aldeano con mejores numeros. Estas son las magias con nombre propio de
    /// los que salen en la serie, para que Gilthunder pelee como Gilthunder y no como un humano con
    /// una espada mas cara.
    ///
    /// Todas son de humanos y no requieren rango: en la serie Guila y Jericho reciben su magia de
    /// la sangre de demonio, no de un ascenso. El rango y la magia son cosas distintas — igual que
    /// en MagicProgression.
    public static class Liones
    {
        // --- Caballeros Sagrados -----------------------------------------------
        public const string Lightning = "sds_ability_lightning";     // Gilthunder
        public const string Tempest = "sds_ability_tempest";         // Howzer
        public const string Explosion = "sds_ability_explosion";     // Guila
        public const string IceMagic = "sds_ability_ice";            // Jericho
        public const string Wall = "sds_ability_wall";               // Griamore
        public const string Break = "sds_ability_break";             // Dreyfus
        public const string Acid = "sds_ability_acid";               // Hendrickson

        // --- Vampiros ------------------------------------------------------------
        public const string BloodDrain = "sds_ability_blood_drain";  // Izraf, Ren

        public const string StatusWall = "sds_status_wall";

        private const string Group = TraitGroups.KnightMagic;

        public static void Init()
        {
            A(Lightning, "Rayo",
                "La magia de Gilthunder. Cae sobre el enemigo mas lejano, porque un rayo no necesita acercarse.",
                spi: 90f, mag: 210f);

            A(Tempest, "Tempestad",
                "La magia de Howzer. Un vendaval que barre todo lo que tiene delante.",
                spi: 70f, mag: 180f);

            A(Explosion, "Explosion",
                "La magia de Guila. Deja cargas que revientan donde caen.",
                spi: 60f, mag: 190f);

            A(IceMagic, "Hielo",
                "La magia de Jericho. Congela al que toca y le roba el paso.",
                spi: 70f, mag: 160f);

            A(Wall, "Muro",
                "La magia de Griamore. Defensa perfecta mientras aguante la voluntad de proteger.",
                spi: 200f, mag: 90f, armor: 25f);

            A(Break, "Quiebra",
                "La magia de Dreyfus. Rompe lo que golpea, empezando por la armadura.",
                str: 140f, spi: 60f, mag: 80f, damage: 16f);

            A(Acid, "Acido",
                "La magia de Hendrickson. Disuelve lo que alcanza y no deja que cierre.",
                spi: 80f, mag: 200f);

            // Esta no es magia de caballero: es lo que corre por la sangre de un vampiro.
            A(BloodDrain, "Sed de Sangre",
                "La magia de los vampiros de Edimburgo. Cada mordisco los alimenta.",
                str: 120f, spi: 80f, mag: 60f, group: TraitGroups.Bloodline);

            WallStatus();
            SDSTick.Register(Tick);
        }

        private static void A(string id, string nameEs, string infoEs,
                              float str = 0f, float spi = 0f, float mag = 0f,
                              float damage = 0f, float armor = 0f, string group = null)
        {
            if (AssetManager.traits.dict.ContainsKey(id)) return;

            ActorTrait t = SDSRegistry.Trait(id, group ?? Group, "ui/icons/" + id);
            t.type = TraitType.Positive;
            PowerLevel.Grant(t, str, spi, mag);
            if (damage != 0f) t.base_stats["damage"] = damage;
            if (armor != 0f) t.base_stats["armor"] = armor;

            SDSRegistry.AddTrait(t);
            SDSLocale.Trait(id, nameEs, infoEs);
        }

        private static void WallStatus()
        {
            if (AssetManager.status.dict.ContainsKey(StatusWall)) return;

            StatusAsset s = SDSRegistry.Status(StatusWall, "ui/icons/" + StatusWall, 10f);
            s.base_stats["armor"] = 120f;
            s.base_stats["speed"] = -60f;
            s.removed_on_damage = false;
            SDSRegistry.AddStatus(s);
            SDSLocale.Status(StatusWall, "Muro",
                "Protegido por la muralla de Griamore. Casi nada la atraviesa, pero moverse cuesta.");
        }

        // ---------------------------------------------------------------- comportamiento

        private static float CD(float s)
        {
            return SDSConfig.AbilityCooldowns ? s : 0.2f;
        }

        private static Actor Enemy(Actor a, float radius)
        {
            List<Actor> near = SDSUnit.Around(a, radius);
            for (int i = 0; i < near.Count; i++)
            {
                Actor o = near[i];
                if (o != null && o.isAlive() && o.kingdom != a.kingdom) return o;
            }
            return null;
        }

        private static void Tick(Actor a, float dt)
        {
            if (a == null || !a.isAlive() || a.data == null) return;

            // Estas magias con NOMBRE (el rayo de Gilthunder, el viento de Howzer) las llevan los
            // personajes con nombre. Los Caballeros Sagrados genericos tienen la suya propia y unica
            // por otro sistema (KnightPowers), no estas. La marca saca a la poblacion antes de nada.
            if (!SDSUnit.RunsAbilities(a)) return;
            if (Curses.Incapacitated(a)) return;

            // El Muro protege incluso fuera de combate: es lo que hace Griamore.
            if (a.hasTrait(Wall)) TickWall(a);

            if (!a.has_attack_target) return;

            if (a.hasTrait(Lightning)) TickLightning(a);
            if (a.hasTrait(Tempest)) TickTempest(a);
            if (a.hasTrait(Explosion)) TickExplosion(a);
            if (a.hasTrait(IceMagic)) TickIce(a);
            if (a.hasTrait(Break)) TickBreak(a);
            if (a.hasTrait(Acid)) TickAcid(a);
            if (a.hasTrait(BloodDrain)) TickDrain(a);
        }

        /// Gilthunder. Golpea al enemigo MAS LEJANO que alcance: un rayo no se acerca a nada.
        private static void TickLightning(Actor a)
        {
            if (!SDSData.TryUse(a, "lightning", CD(6f))) return;

            List<Actor> near = SDSUnit.Around(a, 16f);
            Actor farthest = null;

            // La lista viene ordenada de cerca a lejos, asi que el ultimo hostil es el mas lejano.
            for (int i = 0; i < near.Count; i++)
            {
                Actor o = near[i];
                if (o != null && o.isAlive() && o.kingdom != a.kingdom) farthest = o;
            }
            if (farthest == null) return;

            try { farthest.getHit(18f + PowerLevel.Magic(a) * 0.07f, true, AttackType.Other, a, true); }
            catch { return; }

            SDSFx.At(farthest, "sds_fx_flash", 0.5f);
        }

        /// Howzer. Barrido amplio con empuje.
        private static void TickTempest(Actor a)
        {
            if (!SDSData.TryUse(a, "tempest", CD(7f))) return;

            float power = 11f + PowerLevel.Magic(a) * 0.05f;
            List<Actor> near = SDSUnit.Around(a, 9f);
            bool used = false;

            for (int i = 0; i < near.Count; i++)
            {
                Actor o = near[i];
                if (o == null || !o.isAlive() || o.kingdom == a.kingdom) continue;
                try { o.getHit(power, true, AttackType.Other, a, true); used = true; }
                catch { }
            }
            if (used) SDSFx.At(a, "sds_fx_tornado", 0.6f);
        }

        /// Guila. Una carga que revienta en area sobre el objetivo.
        private static void TickExplosion(Actor a)
        {
            if (!SDSData.TryUse(a, "explosion", CD(8f))) return;

            Actor target = Enemy(a, 13f);
            if (target == null) return;

            float power = 15f + PowerLevel.Magic(a) * 0.06f;
            List<Actor> blast = SDSUnit.Around(target, 4f);

            try { target.getHit(power, true, AttackType.Fire, a, true); }
            catch { return; }

            for (int i = 0; i < blast.Count; i++)
            {
                Actor o = blast[i];
                if (o == null || !o.isAlive() || o.kingdom == a.kingdom) continue;
                try { o.getHit(power * 0.6f, true, AttackType.Fire, a, true); }
                catch { }
            }

            SDSFx.At(target, "sds_fx_creation", 0.6f);
            SDSFx.Wave(target, 2.5f, 1.5f);
        }

        /// Jericho. Menos dano, pero deja al objetivo sin paso.
        private static void TickIce(Actor a)
        {
            if (!SDSData.TryUse(a, "ice", CD(6f))) return;

            Actor target = Enemy(a, 10f);
            if (target == null) return;

            try { target.getHit(9f + PowerLevel.Magic(a) * 0.04f, true, AttackType.Other, a, true); }
            catch { return; }

            SDSStatus.Inflict(target, Curses.Paralyzed, 3f);
            SDSFx.At(target, "sds_fx_ocean", 0.45f);
        }

        /// Griamore. Se planta y aguanta. Solo mientras hay alguien a quien proteger cerca.
        private static void TickWall(Actor a)
        {
            if (a.hasStatus(StatusWall)) return;
            if (!SDSData.TryUse(a, "wall", CD(9f))) return;

            // Su magia nace de proteger a alguien: sin nadie que proteger, no la levanta.
            bool someoneToGuard = false;
            List<Actor> near = SDSUnit.Around(a, 6f);
            for (int i = 0; i < near.Count; i++)
            {
                Actor o = near[i];
                if (SDSUnit.IsAlly(a, o)) { someoneToGuard = true; break; }
            }
            if (!someoneToGuard) return;

            SDSStatus.Inflict(a, StatusWall, 12f);
            SDSFx.At(a, "sds_fx_enchant", 0.5f);
        }

        /// Dreyfus. Rompe la armadura antes que la carne.
        private static void TickBreak(Actor a)
        {
            if (!SDSData.TryUse(a, "break", CD(5f))) return;

            Actor target = Enemy(a, 4f);
            if (target == null) return;

            try { target.getHit(20f + PowerLevel.Strength(a) * 0.05f, true, AttackType.Other, a, true); }
            catch { return; }

            // Quiebra: el objetivo queda mas blando durante un rato.
            SDSStatus.Inflict(target, Curses.Ash, 6f);
            SDSFx.At(target, "sds_fx_creation", 0.4f);
        }

        /// Hendrickson. El acido no deja cerrar la herida — la misma regla que la llama negra.
        private static void TickAcid(Actor a)
        {
            if (!SDSData.TryUse(a, "acid", CD(7f))) return;

            Actor target = Enemy(a, 11f);
            if (target == null) return;

            SDSFx.Projectile(a, target, Projectiles.Magic);
            try { target.getHit(12f + PowerLevel.Magic(a) * 0.05f, true, AttackType.Other, a, true); }
            catch { return; }

            SDSStatus.Inflict(target, "sds_status_hellblaze", 10f);
            SDSFx.At(target, "sds_fx_soul", 0.45f);
        }

        /// Los vampiros. Muerden y se curan con lo que sacan.
        private static void TickDrain(Actor a)
        {
            if (!SDSData.TryUse(a, "blood_drain", CD(3f))) return;

            Actor prey = Enemy(a, 3f);
            if (prey == null) return;

            float bite = 10f + PowerLevel.Strength(a) * 0.03f;
            try { prey.getHit(bite, true, AttackType.Other, a, true); }
            catch { return; }

            try { a.restoreHealth(Mathf.Max(1, Mathf.RoundToInt(bite * 0.7f))); }
            catch { }

            SDSFx.At(prey, "sds_fx_snatch", 0.4f);
        }
    }
}
