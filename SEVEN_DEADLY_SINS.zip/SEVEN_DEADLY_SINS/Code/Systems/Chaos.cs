using System.Collections.Generic;
using UnityEngine;

namespace SevenDeadlySins
{
    /// EL CAOS. Lo que habia antes del Rey Demonio y de la Diosa Suprema.
    ///
    /// Es el final del manga, y hasta ahora al mod le faltaba entero. Todo lo que habia arriba del
    /// todo eran el Rey Demonio y la Diosa Suprema, y en la serie los dos son hijos de algo
    /// anterior: el Caos, la fuerza original que Arthur acaba heredando para convertirse en Rey del
    /// Caos. Cath Palug — el gato — es su fragmento y su guardian.
    ///
    /// COMO SE COMPORTA, Y POR QUE ASI. El Caos no toma partido. No es "el malo mas fuerte": es
    /// anterior a la division entre demonios y diosas, asi que aqui no favorece a ningun clan y
    /// golpea a los dos bandos por igual. Lo que hace es DESHACER — crear y destruir sin criterio,
    /// que es de lo que se queja Arthur cuando lo recibe.
    ///
    /// Y es el unico poder del mod que esta por encima del Rey Demonio. Esa relacion es lo que
    /// importa que se lea en los numeros, no la cifra concreta.
    public static class Chaos
    {
        public const string TraitChaos = "sds_chaos";
        public const string TraitCathPalug = "sds_cath_palug";
        public const string StatusUnmade = "sds_status_unmade";

        /// Radio en el que el Caos deshace lo que encuentra.
        private const float Radius = 12f;

        public static void Init()
        {
            ChaosTrait();
            CathTrait();
            UnmadeStatus();

            SDSTick.Register(Tick);
        }

        private static void ChaosTrait()
        {
            if (AssetManager.traits.dict.ContainsKey(TraitChaos)) return;

            ActorTrait t = SDSRegistry.Trait(TraitChaos, TraitGroups.Demonic, "ui/icons/" + TraitChaos);
            t.type = TraitType.Positive;

            // El apice absoluto: el doble que el Rey Demonio y la Diosa Suprema (un millon cada uno),
            // porque el Caos es de lo que ESTAN HECHOS ellos dos. Dos millones = el techo de la
            // escalera, el unico que llega al factor de combate maximo. 600+680+720 = 2.000.000.
            PowerLevel.Grant(t, 600000f, 680000f, 720000f);
            t.base_stats["health"] = 8000f;
            t.base_stats["damage"] = 350f;
            t.base_stats["armor"] = 150f;
            t.base_stats["multiplier_lifespan"] = 60f;

            SDSRegistry.AddTrait(t);
            SDSLocale.Trait(TraitChaos, "Caos",
                "La fuerza anterior al Rey Demonio y a la Diosa Suprema. No crea ni destruye: hace las dos cosas sin distinguirlas.");
        }

        private static void CathTrait()
        {
            if (AssetManager.traits.dict.ContainsKey(TraitCathPalug)) return;

            ActorTrait t = SDSRegistry.Trait(TraitCathPalug, TraitGroups.Demonic, "ui/icons/" + TraitCathPalug);
            t.type = TraitType.Positive;

            // Cath Palug es el Caos ENCARNADO en forma de gato, no un fragmento menor: en la serie es
            // practicamente indestructible. Va por encima de los dos dioses (un millon) pero por
            // debajo del Arthur ya coronado Rey del Caos (dos millones). 400+430+470 = 1.300.000.
            PowerLevel.Grant(t, 400000f, 430000f, 470000f);
            t.base_stats["health"] = 6000f;
            t.base_stats["damage"] = 300f;
            t.base_stats["armor"] = 130f;
            t.base_stats["multiplier_lifespan"] = 40f;

            SDSRegistry.AddTrait(t);
            SDSLocale.Trait(TraitCathPalug, "Cath Palug",
                "El guardian del Caos con forma de gato. Parece inofensivo hasta que deja de parecerlo.");
        }

        private static void UnmadeStatus()
        {
            if (AssetManager.status.dict.ContainsKey(StatusUnmade)) return;

            StatusAsset s = SDSRegistry.Status(StatusUnmade, "ui/icons/" + StatusUnmade, 8f);
            s.base_stats["damage"] = -40f;
            s.base_stats["armor"] = -40f;
            s.base_stats["speed"] = -30f;
            s.removed_on_damage = false;

            SDSRegistry.AddStatus(s);
            SDSLocale.Status(StatusUnmade, "Deshecho",
                "El Caos ha empezado a deshacerlo. Lo que era ya no termina de serlo.");
        }

        // ---------------------------------------------------------------- comportamiento

        private static void Tick(Actor a, float dt)
        {
            // La marca de personaje con nombre es una lectura de bool y saca a la poblacion entera
            // antes de tocar un solo hasTrait. Mismo patron que el resto de sistemas del mod.
            if (!SDSUnit.IsNamed(a)) return;
            if (a == null || !a.isAlive() || a.data == null) return;

            bool full = a.hasTrait(TraitChaos);
            if (!full && !a.hasTrait(TraitCathPalug)) return;

            if (Curses.Incapacitated(a)) return;

            Unmake(a, full);
        }

        /// Deshace lo que tiene alrededor, SIN mirar de quien es.
        ///
        /// Aqui esta lo que separa al Caos de todo lo demas del mod: el aura del Rey Demonio cura a
        /// los demonios y muerde al resto, la de la Diosa Suprema hace lo contrario. Esta no
        /// distingue. El Caos es anterior a esa pelea y no le interesa: golpea a los dos bandos, y a
        /// los del propio reino tambien. Por eso da miedo tenerlo cerca aunque sea tuyo.
        private static void Unmake(Actor a, bool full)
        {
            if (!SDSData.TryUse(a, "chaos", SDSConfig.AbilityCooldowns ? (full ? 3f : 5f) : 0.3f)) return;

            float radius = full ? Radius : Radius * 0.6f;
            float bite = full ? 40f : 18f;

            List<Actor> near = SDSUnit.Around(a, radius);
            bool used = false;

            for (int i = 0; i < near.Count; i++)
            {
                Actor o = near[i];
                if (o == null || !o.isAlive() || o == a) continue;

                // Ni clan ni reino. Lo unico que se respeta es a otro portador del Caos: dos
                // fragmentos de la misma cosa no se deshacen entre si.
                if (o.hasTrait(TraitChaos) || o.hasTrait(TraitCathPalug)) continue;

                try { o.getHit(bite, true, AttackType.Other, a, true); }
                catch { continue; }

                SDSStatus.Inflict(o, StatusUnmade, 8f);
                used = true;
            }

            if (!used) return;

            SDSFx.At(a, "sds_fx_infinity", full ? 0.8f : 0.5f);
            if (full) SDSFx.Wave(a, 4f, 3f);
        }

        /// Entrega el Caos. Lo usa Legends para Arthur y el boton de invocacion.
        public static void Crown(Actor a)
        {
            if (a == null) return;
            SDSTraits.Give(a, TraitChaos);
            SDSLog.Chronicle(SDSLocale.T(
                a.getName() + " ha heredado el Caos.",
                a.getName() + " has inherited Chaos."));
        }
    }
}
