using System.Collections.Generic;

namespace SevenDeadlySins
{
    /// The people with names.
    ///
    /// Kits are applied on a delay rather than at spawn. The reason is ordering: a unit spawned by a
    /// power button exists before every system has finished handing out clans, and giving someone the
    /// Wrath before Clans.Assign has made them human means the Sin is stripped a moment later when
    /// the clan arrives and takes its opposites with it. Marking the unit and letting the tick dress
    /// it one sweep later sidesteps the whole ordering problem.
    public static class Legends
    {
        public class Legend
        {
            public string id;          // sds_legend_meliodas
            public string name;        // Meliodas
            public string race;        // always "human" now; kept so a creature could be added
            public string clan;
            public string sin;         // null if not a Sin
            public string commandment; // null if not a Commandment
            public string treasure;    // null unless the character carries a named weapon of their own
            public string[] extra;     // loose traits
        }

        private const string KeyPending = "sds_legend_pending";

        public static readonly List<Legend> Table = new List<Legend>();

        public static void Init()
        {
            // --- the Seven Deadly Sins ---------------------------------------------
            // Every one of them is a plain vanilla human wearing traits. See Actors for why.
            // Meliodas es clan HUMAN (solo los humanos portan un Pecado), pero canonicamente es un
            // DEMONIO: se le da Sangre de Demonio para que sus hijos hereden su lado demoniaco (Tristan
            // es medio demonio). Sin esto, cruzarlo no transmitia NADA de demonio.
            Sin("meliodas", "Meliodas", SevenSins.Wrath,
                new[] { Abilities.Hellblaze, SevenDeadlySins.Traits.DemonBlood }, Actors.Human, Clans.Human);
            Sin("ban", "Ban", SevenSins.Greed,
                new[] { SevenDeadlySins.Traits.Immortal }, Actors.Human, Clans.Human);
            Sin("diane", "Diane", SevenSins.Envy,
                new[] { SevenDeadlySins.Traits.GiantStrength }, Actors.Human, Clans.Giant);
            Sin("gowther", "Gowther", SevenSins.Lust,
                null, Actors.Human, Clans.Human);
            Sin("king", "King", SevenSins.Sloth,
                new[] { SevenDeadlySins.Traits.FairyWings }, Actors.Human, Clans.Fairy);
            // Infinity sola no hacia nada: es un multiplicador de duracion sin nada que multiplicar.
            // Estos son los hechizos sobre los que se apoya.
            Sin("merlin", "Merlin", SevenSins.Gluttony,
                new[] { Merlin.PerfectCube, Merlin.AbsoluteCancel, Merlin.EndlessWhirl },
                Actors.Human, Clans.Human);
            Sin("escanor", "Escanor", SevenSins.Pride,
                null, Actors.Human, Clans.Human);

            // --- the Ten Commandments ----------------------------------------------
            // Gloxinia is a Fairy and Drole is a Giant. They took Commandments without being demons,
            // and getting that wrong is the single most obvious canon error this file could make.
            Cmd("zeldris", "Zeldris", TenCommandments.Piety);
            Cmd("estarossa", "Estarossa", TenCommandments.Love);
            Cmd("galand", "Galand", TenCommandments.Truth);
            Cmd("melascula", "Melascula", TenCommandments.Faith);
            Cmd("fraudrin", "Fraudrin", TenCommandments.Selflessness);
            Cmd("grayroad", "Grayroad", TenCommandments.Pacifism);
            Cmd("monspeet", "Monspeet", TenCommandments.Reticence);
            Cmd("derieri", "Derieri", TenCommandments.Purity);
            Cmd("gloxinia", "Gloxinia", TenCommandments.Repose, Actors.Human, Clans.Fairy);
            Cmd("drole", "Drole", TenCommandments.Patience, Actors.Human, Clans.Giant);

            // --- everyone else ------------------------------------------------------
            Other("elizabeth", "Elizabeth", Actors.Human, Clans.Goddess,
                new[] { Abilities.Ark, SevenDeadlySins.Traits.Reincarnation });
            // The Four Archangels. Mael keeps Sunshine rather than getting a fourth invented one:
            // it is the grace that was taken FROM him.
            Other("ludociel", "Ludociel", Actors.Human, Clans.Goddess,
                new[] { Archangels.Archangel, Archangels.Flash, Abilities.Ark });
            Other("mael", "Mael", Actors.Human, Clans.Goddess,
                new[] { Abilities.Purge, Sunshine.Ability });
            Other("sariel", "Sariel", Actors.Human, Clans.Goddess,
                new[] { Archangels.Archangel, Archangels.Tornado, Abilities.Ark });
            Other("tarmiel", "Tarmiel", Actors.Human, Clans.Goddess,
                new[] { Archangels.Archangel, Archangels.Ocean, Abilities.Ark });

            // Purgatory.
            Other("demon_king", "Rey Demonio", Actors.Human, Clans.Demon,
                new[] { DemonKing.TraitKing, Abilities.Hellblaze, SevenDeadlySins.Traits.DemonBlood,
                        SevenDeadlySins.Traits.Immortal });
            Other("chandler", "Chandler", Actors.Human, Clans.Demon,
                new[] { DemonKing.TraitMaster, Abilities.Hellblaze });
            Other("cusack", "Cusack", Actors.Human, Clans.Demon,
                new[] { DemonKing.TraitMaster, Abilities.Hellblaze });
            Other("supreme_deity", "Diosa Suprema", Actors.Goddess, Clans.Goddess,
                new[] { Archangels.SupremeLight, Abilities.Ark, SevenDeadlySins.Traits.GoddessBlood,
                        SevenDeadlySins.Traits.Immortal });
            Other("arthur", "Arthur Pendragon", "human", Clans.Human, new[] { MagicTypes.Special });
            Other("hawk", "Hawk", "human", Clans.Human, null);

            // Cuatro Jinetes del Apocalipsis. Percival, el vaso del Caos y protagonista de la
            // secuela. Tristan y Lancelot no van aqui: nacen del sistema de herencia si cruzas a
            // sus padres (Meliodas x Elizabeth, Ban x Elaine).
            Other("percival", "Percival", "human", Clans.Human,
                new[] { FourKnights.Ripple, MagicTypes.Special });
            Other("gawain", "Gawain", "human", Clans.Human,
                new[] { Sunshine.Ability, MagicTypes.Special });

            // --- El Caos ---------------------------------------------------------
            //
            // El final del manga. Arthur no se queda en el rey nino que busca su espada: hereda el
            // Caos, la fuerza de la que salieron el Rey Demonio y la Diosa Suprema. Va aparte de
            // "arthur" a proposito — son el mismo personaje en dos momentos, y quien quiera el
            // principio de su historia no deberia recibir el final de propina.
            Other("chaos_king", "Arthur, Rey del Caos", "human", Clans.Human,
                new[] { Chaos.TraitChaos, MagicTypes.Special });
            Other("cath_palug", "Cath Palug", "human", Clans.Human,
                new[] { Chaos.TraitCathPalug });

            // --- Los Caballeros Sagrados de Liones -------------------------------
            // El mod tenia los rangos desde el principio y ningun caballero que los llevara.
            Other("zaratras", "Zaratras", Actors.Human, Clans.Human,
                new[] { HolyKnights.GrandMaster, Liones.Lightning, MagicTypes.Special });
            Other("gilthunder", "Gilthunder", Actors.Human, Clans.Human,
                new[] { HolyKnights.GreatHolyKnight, Liones.Lightning });
            Other("howzer", "Howzer", Actors.Human, Clans.Human,
                new[] { HolyKnights.HolyKnight, Liones.Tempest });
            Other("guila", "Guila", Actors.Human, Clans.Human,
                new[] { HolyKnights.HolyKnight, Liones.Explosion });
            Other("jericho", "Jericho", Actors.Human, Clans.Human,
                new[] { HolyKnights.Apprentice, Liones.IceMagic });
            Other("griamore", "Griamore", Actors.Human, Clans.Human,
                new[] { HolyKnights.HolyKnight, Liones.Wall });
            Other("dreyfus", "Dreyfus", Actors.Human, Clans.Human,
                new[] { HolyKnights.GrandMaster, Liones.Break });
            // Hendrickson bebio sangre de demonio: por eso lleva el rasgo ademas del rango.
            Other("hendrickson", "Hendrickson", Actors.Human, Clans.Human,
                new[] { HolyKnights.GrandMaster, Liones.Acid, SevenDeadlySins.Traits.DemonBlood });
            Other("bartra", "Bartra Liones", Actors.Human, Clans.Human,
                new[] { MagicTypes.Special });

            // --- Los Vampiros de Edimburgo ---------------------------------------
            Other("izraf", "Izraf", Actors.Vampire, Clans.Vampire,
                new[] { Liones.BloodDrain, SevenDeadlySins.Traits.VampireThirst });
            Other("gelda", "Gelda", Actors.Vampire, Clans.Vampire,
                new[] { Liones.BloodDrain, MagicTypes.Special });
            Other("ren", "Ren", Actors.Vampire, Clans.Vampire,
                new[] { Liones.BloodDrain, SevenDeadlySins.Traits.VampireThirst });

            // --- El Bosque del Rey Hada -------------------------------------------
            Other("elaine", "Elaine", Actors.Fairy, Clans.Fairy,
                new[] { SevenDeadlySins.Traits.FairyWings, Abilities.Ark });
            Other("helbram", "Helbram", Actors.Fairy, Clans.Fairy,
                new[] { SevenDeadlySins.Traits.FairyWings, Liones.Tempest });
            Other("gerheade", "Gerheade", Actors.Fairy, Clans.Fairy,
                new[] { SevenDeadlySins.Traits.FairyWings, MagicTypes.Enchanter });

            // --- El Calabozo de los Gigantes --------------------------------------
            Other("matrona", "Matrona", Actors.Giant, Clans.Giant,
                new[] { SevenDeadlySins.Traits.GiantStrength, Liones.Break });
            // Dolores, la hija de Drole; Dubs, el gigante artesano que forjo el Ataud de la
            // Oscuridad Eterna.
            Other("dolores", "Dolores", Actors.Giant, Clans.Giant,
                new[] { SevenDeadlySins.Traits.GiantStrength });
            Other("dubs", "Dubs", Actors.Giant, Clans.Giant,
                new[] { SevenDeadlySins.Traits.GiantStrength, MagicTypes.Strengthener });

            // ====================================================================
            //  LOS CUATRO JINETES DEL APOCALIPSIS (la secuela) y su mundo
            // ====================================================================
            // Tristan (hijo de Meliodas y Elizabeth) y Lancelot (hijo de Ban y Elaine) tambien
            // nacen del sistema de herencia si cruzas a sus padres; aqui van como leyendas propias
            // para poder invocarlos directos, con la magia de la secuela.
            Other("tristan", "Tristan", Actors.Human, Clans.Goddess,
                new[] { LegendMagic.Compassion, Abilities.Ark, SevenDeadlySins.Traits.DemonBlood,
                        SevenDeadlySins.Traits.GoddessBlood });
            Other("lancelot", "Lancelot", Actors.Human, Clans.Human,
                new[] { LegendMagic.Perception, SevenDeadlySins.Traits.FairyWings });
            Other("donny", "Donny", Actors.Human, Clans.Human,
                new[] { LegendMagic.Telekinesis });
            Other("nasiens", "Nasiens", Actors.Human, Clans.Human,
                new[] { LegendMagic.Venom });
            Other("anne", "Anne", Actors.Human, Clans.Human,
                new[] { HolyKnights.Apprentice, LegendMagic.Insight });
            // El zorro parlante, revelado como el dios Cernunnos.
            Other("cernunnos", "Sin", Actors.Human, Clans.Human,
                new[] { MagicTypes.Special });

            // --- Los Caballeros del Caos de Camelot ------------------------------
            Other("ironside", "Ironside", Actors.Human, Clans.Human,
                new[] { HolyKnights.GreatHolyKnight, LegendMagic.PurgatoryFlame });
            Other("pellegarde", "Pellegarde", Actors.Human, Clans.Human,
                new[] { HolyKnights.GreatHolyKnight, LegendMagic.Salamander });
            Other("varghese", "Varghese", Actors.Human, Clans.Human,
                new[] { HolyKnights.GrandMaster, MagicTypes.Strengthener });
            Other("mortlach", "Mortlach", Actors.Human, Clans.Human,
                new[] { HolyKnights.HolyKnight, Liones.Break });
            Other("talisker", "Talisker", Actors.Human, Clans.Human,
                new[] { HolyKnights.HolyKnight, Liones.Tempest });
            Other("fiddich", "Fiddich", Actors.Human, Clans.Human,
                new[] { HolyKnights.HolyKnight, Liones.Lightning });
            Other("ardbeg", "Ardbeg", Actors.Human, Clans.Human,
                new[] { HolyKnights.HolyKnight, MagicTypes.Special });

            // --- La nueva generacion de Caballeros de Liones (con Tristan) -------
            Other("chion", "Chion", Actors.Human, Clans.Human,
                new[] { HolyKnights.HolyKnight, MagicTypes.Enchanter });
            Other("jade", "Jade", Actors.Human, Clans.Human,
                new[] { HolyKnights.HolyKnight, Liones.Lightning });
            Other("isolde", "Isolde", Actors.Human, Clans.Human,
                new[] { HolyKnights.HolyKnight, MagicTypes.Enchanter });

            // ====================================================================
            //  MAS CABALLEROS SAGRADOS DE LIONES y sus ordenes
            // ====================================================================
            // La familia real y los caballeros con nombre que faltaban.
            Other("margaret", "Margaret", Actors.Human, Clans.Human,
                new[] { Abilities.Ark, MagicTypes.Healer });
            Other("veronica", "Veronica", Actors.Human, Clans.Human,
                new[] { HolyKnights.HolyKnight, MagicTypes.Strengthener });
            Other("vivian", "Vivian", Actors.Human, Clans.Human,
                new[] { LegendMagic.Hex, MagicTypes.Incantation });
            Other("gustaf", "Gustaf", Actors.Human, Clans.Human,
                new[] { HolyKnights.HolyKnight, MagicTypes.Strengthener });
            Other("twigo", "Twigo", Actors.Human, Clans.Human,
                new[] { HolyKnights.HolyKnight, Liones.Break });
            Other("alioni", "Alioni", Actors.Human, Clans.Human,
                new[] { HolyKnights.Apprentice });
            Other("cain", "Cain Barzad", Actors.Human, Clans.Human,
                new[] { HolyKnights.GreatHolyKnight, Liones.Explosion });

            // --- Las Pleyades del Cielo Azul -------------------------------------
            Other("denzel", "Denzel Liones", Actors.Human, Clans.Human,
                new[] { HolyKnights.GreatHolyKnight, LegendMagic.Judgement, Abilities.Ark });
            Other("deathpierce", "Deathpierce", Actors.Human, Clans.Human,
                new[] { HolyKnights.GreatHolyKnight, LegendMagic.Melody });
            Other("waillo", "Waillo", Actors.Human, Clans.Human,
                new[] { HolyKnights.HolyKnight, MagicTypes.Strengthener });
            Other("deldry", "Deldry", Actors.Human, Clans.Human,
                new[] { HolyKnights.HolyKnight, MagicTypes.Enchanter });
            Other("dogedo", "Dogedo", Actors.Human, Clans.Human,
                new[] { HolyKnights.HolyKnight, MagicTypes.Strengthener });
            Other("arden", "Arden", Actors.Human, Clans.Human,
                new[] { HolyKnights.HolyKnight, MagicTypes.Incantation });

            // --- Rugido del Alba (Dawn Roar) -------------------------------------
            Other("slader", "Slader", Actors.Human, Clans.Human,
                new[] { HolyKnights.GreatHolyKnight, LegendMagic.Overpower });
            Other("weinheidt", "Weinheidt", Actors.Human, Clans.Human,
                new[] { HolyKnights.HolyKnight, LegendMagic.Snipe });
            Other("simon", "Simon", Actors.Human, Clans.Human,
                new[] { HolyKnights.HolyKnight, MagicTypes.Strengthener });
            Other("jillian", "Jillian", Actors.Human, Clans.Human,
                new[] { HolyKnights.HolyKnight, MagicTypes.Enchanter });

            // --- Los Colmillos Raros (Weird Fangs) -------------------------------
            Other("golgius", "Golgius", Actors.Human, Clans.Human,
                new[] { HolyKnights.HolyKnight, LegendMagic.Vanish });
            Other("friesia", "Friesia", Actors.Human, Clans.Human,
                new[] { HolyKnights.HolyKnight, LegendMagic.Swarm });
            Other("ruin", "Ruin", Actors.Human, Clans.Human,
                new[] { HolyKnights.HolyKnight, LegendMagic.Venom });
            Other("jude", "Jude", Actors.Human, Clans.Human,
                new[] { HolyKnights.HolyKnight, MagicTypes.Incantation });

            // ====================================================================
            //  MAS RAZAS: vampiros, hadas, diosas y demonios que faltaban
            // ====================================================================
            // --- Mas Vampiros de Edimburgo ---------------------------------------
            Other("ganne", "Ganne", Actors.Vampire, Clans.Vampire,
                new[] { Liones.BloodDrain, SevenDeadlySins.Traits.VampireThirst });
            Other("mod", "Mod", Actors.Vampire, Clans.Vampire,
                new[] { Liones.BloodDrain, SevenDeadlySins.Traits.VampireThirst });
            Other("orlondi", "Orlondi", Actors.Vampire, Clans.Vampire,
                new[] { Liones.BloodDrain, SevenDeadlySins.Traits.VampireThirst });

            // --- Mas Hadas: Puck, el companero travieso del Rey Hada -------------
            Other("puck", "Puck", Actors.Fairy, Clans.Fairy,
                new[] { SevenDeadlySins.Traits.FairyWings, MagicTypes.Enchanter });

            // --- Mas Diosas: Nerobasta, la diosa cobarde -------------------------
            Other("nerobasta", "Nerobasta", Actors.Goddess, Clans.Goddess,
                new[] { Abilities.Ark });

            // --- El Demonio Original (Chandler y Cusack fundidos en uno) ----------
            Other("original_demon", "Demonio Original", Actors.Human, Clans.Demon,
                new[] { DemonKing.TraitMaster, Abilities.Hellblaze, SevenDeadlySins.Traits.DemonBlood,
                        SevenDeadlySins.Traits.Immortal });

            // Las armas de los Cuatro Jinetes del Apocalipsis van a sus dueños. (Los Tesoros
            // Sagrados de los Pecados los reparte la tabla de Pecados; estos no vienen de un Pecado.)
            Arm("percival", SacredTreasures.PercivalStaff);
            Arm("tristan", SacredTreasures.TristanSword);
            Arm("lancelot", SacredTreasures.LancelotBow);
            Arm("gawain", SacredTreasures.GawainSword);

            foreach (Legend l in Table) SDSLocale.Add(l.id, l.name);
        }

        /// Le pone a una leyenda su arma propia (la que no viene de un Pecado).
        private static void Arm(string key, string treasure)
        {
            Legend l = Get("sds_legend_" + key);
            if (l != null) l.treasure = treasure;
        }

        /// Registered from Main AFTER every trait exists.
        public static void ApplyKits()
        {
            SDSTick.Register(TickDress);
        }

        // ---------------------------------------------------------------- table builders

        private static void Sin(string key, string name, string sin, string[] extra,
                                string race = "human", string clan = null)
        {
            Table.Add(new Legend
            {
                id = "sds_legend_" + key,
                name = name,
                race = race,
                clan = clan ?? Clans.Human,
                sin = sin,
                extra = extra,
            });
        }

        private static void Cmd(string key, string name, string commandment,
                                string race = null, string clan = null)
        {
            Table.Add(new Legend
            {
                id = "sds_legend_" + key,
                name = name,
                race = race ?? Actors.Human,
                clan = clan ?? Clans.Demon,
                commandment = commandment,
            });
        }

        private static void Other(string key, string name, string race, string clan, string[] extra)
        {
            Table.Add(new Legend
            {
                id = "sds_legend_" + key,
                name = name,
                race = race,
                clan = clan,
                extra = extra,
            });
        }

        public static Legend Get(string legendId)
        {
            for (int i = 0; i < Table.Count; i++)
                if (Table[i].id == legendId) return Table[i];
            return null;
        }

        // ---------------------------------------------------------------- spawning

        /// Spawns a named character at a tile. The kit is applied a sweep later by TickDress.
        public static Actor Spawn(string legendId, WorldTile tile)
        {
            Legend l = Get(legendId);
            if (l == null || tile == null) return null;

            string race = l.race;
            if (AssetManager.actor_library.get(race) == null) race = "human";

            Actor a = null;
            try
            {
                a = World.world.units.spawnNewUnit(race, tile,
                    pSpawnSound: true, pMiracleSpawn: true, pSpawnHeight: 3f);
            }
            catch { }
            if (a == null) return null;

            try { a.setName(l.name); }
            catch { }

            // Marked now, dressed on the next sweep. See the note at the top of the file.
            SDSData.SetString(a, KeyPending, legendId);

            // The gate every character system opens with. Set at spawn rather than when the kit
            // lands, so a legend is recognised from its very first tick.
            SDSData.SetBool(a, SDSData.Named, true);
            return a;
        }

        /// Gives a marked unit everything its character is supposed to have, once.
        private static void TickDress(Actor a, float dt)
        {
            if (a == null || !a.isAlive() || a.data == null) return;

            // Leer una cadena de Actor.data en cada unidad y cada barrido no es gratis. La marca de
            // leyenda es un bool y la pone el propio Spawn, asi que filtra primero.
            if (!SDSUnit.IsNamed(a)) return;

            string legendId = SDSData.GetString(a, KeyPending, "");
            if (string.IsNullOrEmpty(legendId)) return;

            Legend l = Get(legendId);
            if (l == null)
            {
                SDSData.SetString(a, KeyPending, "");
                return;
            }

            // Clan first. It carries opposites, so anything given before it would be stripped.
            Clans.Give(a, l.clan);

            if (!string.IsNullOrEmpty(l.sin))
            {
                SevenSins.Bestow(a, l.sin);

                string treasure = SevenSins.TreasureOf(l.sin);
                if (!string.IsNullOrEmpty(treasure)) SacredTreasures.Bestow(a, treasure);
            }

            if (!string.IsNullOrEmpty(l.commandment)) TenCommandments.Bestow(a, l.commandment);

            // Un arma propia que no viene de un Pecado: las de los Cuatro Jinetes.
            if (!string.IsNullOrEmpty(l.treasure)) SacredTreasures.Bestow(a, l.treasure);

            if (l.extra != null)
            {
                for (int i = 0; i < l.extra.Length; i++) SDSTraits.Give(a, l.extra[i]);
            }

            SDSData.SetString(a, KeyPending, "");

            SDSLog.Chronicle(SDSLocale.T(
                l.name + " ha aparecido en Britannia.",
                l.name + " has appeared in Britannia."));
        }
    }
}
