using System.Collections.Generic;
using UnityEngine;

namespace SevenDeadlySins
{
    /// Los Cuatro Jinetes del Apocalipsis — la serie que el usuario sigue al dia.
    ///
    /// De momento, Percival. Es el protagonista: nieto de Varghese, hijo de Ironside, y sobre todo
    /// un VASO DEL CAOS — la misma fuerza que hereda Arthur. Su magia no encaja en las cinco clases
    /// normales porque el Caos no crea ni destruye, hace las dos cosas: por eso su golpe de firma
    /// DANA a los enemigos y CURA a los suyos en la misma onda. Eso es Percival.
    ///
    /// Hay sitio aqui para los otros tres (Tristan, Lancelot, Gawain), pero Tristan y Lancelot ya
    /// nacen del sistema de herencia si cruzas a sus padres, asi que Percival es el que faltaba.
    public static class FourKnights
    {
        public const string Ripple = "sds_ability_ripple";       // Percival, vaso del Caos

        public static void Init()
        {
            Ability();
            SDSTick.Register(Tick);
        }

        private static void Ability()
        {
            if (AssetManager.traits.dict.ContainsKey(Ripple)) return;

            ActorTrait t = SDSRegistry.Trait(Ripple, TraitGroups.Demonic, "ui/icons/" + Ripple);
            t.type = TraitType.Positive;

            // Fuerte, pero no a la altura de un Mandamiento: Percival empieza siendo un crio con un
            // don enorme sin domar, no un monstruo hecho. Su poder crece en la serie, no de salida.
            PowerLevel.Grant(t, 300f, 500f, 600f);
            t.base_stats["health"] = 150f;

            SDSRegistry.AddTrait(t);
            SDSLocale.Trait(Ripple, "Onda del Caos",
                "La magia de Percival. El Caos que lleva dentro hiere al enemigo y cura al amigo en la misma onda.");
        }

        private static float CD(float s)
        {
            return SDSConfig.AbilityCooldowns ? s : 0.3f;
        }

        private static void Tick(Actor a, float dt)
        {
            if (a == null || !a.isAlive() || a.data == null) return;

            // Es una habilidad de personaje con nombre: la marca saca a la poblacion antes de nada.
            if (!SDSUnit.RunsAbilities(a)) return;
            if (!a.hasTrait(Ripple)) return;
            if (Curses.Incapacitated(a)) return;
            if (!a.has_attack_target) return;

            if (!SDSData.TryUse(a, "ripple", CD(7f))) return;

            float magic = PowerLevel.Magic(a);
            List<Actor> near = SDSUnit.Around(a, 8f);
            bool used = false;

            for (int i = 0; i < near.Count; i++)
            {
                Actor o = near[i];
                if (o == null || !o.isAlive() || o == a) continue;

                if (SDSUnit.IsAlly(a, o))
                {
                    // Crear: cura a los suyos.
                    if (o.data != null && o.data.health < o.getMaxHealth())
                    {
                        try { o.restoreHealth(Mathf.Max(1, Mathf.RoundToInt(10f + magic * 0.05f))); used = true; }
                        catch { }
                    }
                }
                else if (Clans.Hostile(a, o))
                {
                    // Destruir: hiere al enemigo.
                    try { o.getHit(14f + magic * 0.06f, true, AttackType.Other, a, true); used = true; }
                    catch { }
                }
            }

            if (used)
            {
                SDSFx.At(a, "sds_fx_infinity", 0.6f);
                SDSFx.Wave(a, 3f, 2f);
            }
        }
    }
}
