using System.Collections.Generic;
using UnityEngine;

namespace SevenDeadlySins
{
    /// LA HABILIDAD PROPIA DE CADA HIBRIDO DE RAZA.
    ///
    /// Antes un hibrido solo heredaba las DOS habilidades de clan de sus padres (la llama del demonio
    /// y el Ark de la diosa, por ejemplo). El usuario lo pidio distinto: un hibrido no es la suma de
    /// dos clanes, es SU PROPIA cosa — como Tristan, que no lucha como un demonio ni como una diosa,
    /// sino como un Nephilim. Aqui esta esa habilidad UNICA: una por cada uno de los 15 cruces de
    /// razas, con su nombre, su efecto distinto y su FX propio (sds_fx_hybrid_<par>, sin reutilizar).
    ///
    /// Es hermano de SinLegacy pero para razas en vez de Pecados: misma mecanica (STATUS de 25 s cada
    /// 30 s, mas un golpe de firma), primos en las primitivas de AbilityOps.
    public static class HybridLegacy
    {
        private sealed class Hyb
        {
            public string key;                 // "demon_goddess" (orden de HybridForms.Order)
            public string abilityTrait;        // marca permanente
            public string ability;             // STATUS de 25 s que da
            public string nameEs, nameEn, desc;
        }

        private static readonly Dictionary<string, Hyb> _table = new Dictionary<string, Hyb>();

        // La ficha del hijo guarda SU clave de par, para que el Tick sea O(1) (no 15 hasTrait).
        private const string KeyHyb = "sds_hyblegacy_key";

        private const float AbilityDuration = 25f;
        private const float AbilityCooldown = 30f;

        // nombre (ES, EN) y descripcion de lo que HACE cada uno. Mismos nombres tematicos que su forma.
        private static readonly (string key, string es, string en, string desc)[] Defs =
        {
            ("human_demon",    "Demonio Encarnado", "Incarnate Demon",   "descarga una hoja de llama negra que drena la vida del enemigo y cierra sus propias heridas"),
            ("human_goddess",  "Angel Encarnado",   "Incarnate Angel",   "un destello de luz que cura a los aliados cercanos y hiere al enemigo mas proximo"),
            ("human_fairy",    "Elfo Mayor",        "Elder Fae",         "lanza una espina del bosque y drena la vida de todo lo hostil alrededor"),
            ("human_giant",    "Coloso",            "Colossus",          "descarga un pisoton que sacude la tierra y aparta con fuerza a los enemigos del area"),
            ("human_vampire",  "Senor de Sangre",   "Blood Lord",        "un mordisco brutal a un solo objetivo que le roba mucha vida"),
            ("demon_goddess",  "Crepusculo",        "Twilight",          "el poder Nephilim: cura a los aliados Y quema a los enemigos alrededor a la vez, luz y oscuridad en un mismo instante"),
            ("demon_fairy",    "Sombra del Bosque", "Forest Shade",      "una lanza de sombra que quema en area y deja a los enemigos atrapados (paralizados)"),
            ("demon_giant",    "Titan Oscuro",      "Dark Titan",        "hace erupcionar roca envuelta en llama negra que petrifica a los enemigos del area"),
            ("demon_vampire",  "Devorador Nocturno","Night Devourer",    "drena la vida de todos los enemigos cercanos y los marca con llama negra que no cierra"),
            ("goddess_fairy",  "Luz del Bosque",    "Forest Light",      "cura a los aliados y clava una lanza de luz en el enemigo mas lejano, sin fallo"),
            ("goddess_giant",  "Titan Sagrado",     "Sacred Titan",      "cura a los aliados y descarga un martillo de luz sobre todos los enemigos del area"),
            ("goddess_vampire","Caliz de Luz",      "Chalice of Light",  "drena la vida de los enemigos y la vuelca en curar a los aliados cercanos"),
            ("fairy_giant",    "Guardian Ancestral","Ancestral Warden",  "levanta la tierra en area sobre los enemigos y con esa fuerza cura a los aliados"),
            ("fairy_vampire",  "Espectro del Bosque","Forest Wraith",    "drena la vida del area y siembra un sueno que paraliza a los enemigos"),
            ("giant_vampire",  "Devorador Colosal", "Colossal Devourer", "un zarpazo colosal que drena a todos los enemigos del area y los lanza por los aires"),
        };

        public static void Init()
        {
            for (int i = 0; i < Defs.Length; i++)
            {
                var d = Defs[i];
                Hyb h = new Hyb
                {
                    key = d.key,
                    abilityTrait = "sds_ability_hyb_" + d.key,
                    ability = "sds_status_hyb_ab_" + d.key,
                    nameEs = d.es, nameEn = d.en, desc = d.desc,
                };
                _table[d.key] = h;

                RegisterTrait(h);
                RegisterStatus(h);

                string info = "Habilidad de un hibrido " + h.nameEs + ": " + h.desc + ". Dura 25s, se relanza cada 30s.";
                SDSLocale.Trait(h.abilityTrait, h.nameEs, info);
                SDSLocale.Status(h.ability, h.nameEs, info);
                SDSLocale.TraitLore(h.abilityTrait,
                    "Nace SOLO del cruce de dos razas concretas. Es su poder PROPIO — ni el de un clan ni "
                    + "el del otro — y se desata como estado 25s cada 30s.");
            }

            SDSTick.Register(Tick);
        }

        private static void RegisterTrait(Hyb h)
        {
            if (AssetManager.traits.dict.ContainsKey(h.abilityTrait)) return;
            ActorTrait t = SDSRegistry.Trait(h.abilityTrait, TraitGroups.Bloodline, "ui/icons/sds_ability_hyb_" + h.key);
            t.type = TraitType.Positive;
            PowerLevel.Grant(t, 400f, 400f, 400f);
            t.base_stats["damage"] = 18f;
            SDSRegistry.AddTrait(t);
        }

        private static void RegisterStatus(Hyb h)
        {
            if (AssetManager.status.dict.ContainsKey(h.ability)) return;
            StatusAsset s = SDSRegistry.Status(h.ability, "ui/icons/sds_ability_hyb_" + h.key, AbilityDuration);
            PowerLevel.Grant(s, 2000f, 2000f, 2000f);   // impulso moderado, no un pico de 10k PL
            s.base_stats["damage"] = 24f;
            s.base_stats["armor"] = 14f;
            s.removed_on_damage = false;
            SDSRegistry.AddStatus(s);
        }

        /// El id del clan hibrido es "sds_clan_hybrid_<a>_<b>"; su clave de par es "<a>_<b>".
        private static string KeyFromHybridClan(string hclan)
        {
            if (string.IsNullOrEmpty(hclan)) return null;
            string key = hclan.Replace("sds_clan_hybrid_", "");
            return _table.ContainsKey(key) ? key : null;
        }

        /// Concede al bebe hibrido su habilidad UNICA (marca + dato para el Tick). Devuelve true si se
        /// aplico — Offspring lo usa como "firma ya asignada".
        public static bool TryApply(Actor baby, string hclan)
        {
            if (baby == null) return false;
            string key = KeyFromHybridClan(hclan);
            if (key == null) return false;

            Hyb h;
            if (!_table.TryGetValue(key, out h)) return false;

            try
            {
                SDSTraits.Give(baby, h.abilityTrait);
                SDSData.SetString(baby, KeyHyb, key);
                SDSUnit.MarkAbilityUser(baby);   // que su comportamiento CORRA aunque no sea leyenda
            }
            catch { }
            return true;
        }

        private static float CD(float s) { return SDSConfig.AbilityCooldowns ? s : 0.3f; }

        private static void Tick(Actor a, float dt)
        {
            if (a == null || !a.isAlive() || a.data == null) return;
            if (!SDSUnit.RunsAbilities(a)) return;
            if (!a.isAdult()) return;   // los hijos crecen hacia su poder; un bebe no lanza

            string key = SDSData.GetString(a, KeyHyb, "");
            if (string.IsNullOrEmpty(key)) return;

            Hyb h;
            if (!_table.TryGetValue(key, out h)) return;

            if (Curses.Incapacitated(a)) return;

            // Dispara cuando hay algo que hacer: enemigo a tiro o aliado herido cerca.
            bool foe = AbilityOps.NearestEnemy(a, 13f) != null;
            bool wounded = HasWoundedAlly(a, 12f);
            if (!foe && !wounded) return;

            if (a.hasStatus(h.ability)) return;
            if (!SDSData.TryUse(a, "hyblegacy_cast", CD(AbilityCooldown))) return;

            if (!SDSStatus.Inflict(a, h.ability, AbilityDuration)) return;
            SDSFx.At(a, "sds_fx_hybrid_" + key, 0.85f);   // su FX PROPIO, unico por par

            CastAbility(a, key);
        }

        private static bool HasWoundedAlly(Actor a, float radius)
        {
            List<Actor> near = SDSUnit.Around(a, radius);
            for (int i = 0; i < near.Count; i++)
            {
                Actor o = near[i];
                if (!SDSUnit.IsAlly(a, o)) continue;
                if (o.data != null && o.data.health < o.getMaxHealth()) return true;
            }
            return false;
        }

        /// El efecto PROPIO y distinto de cada uno de los 15 cruces. Reutiliza las primitivas de
        /// AbilityOps pero en combinaciones unicas: ninguna hace lo mismo que otra.
        private static void CastAbility(Actor a, string key)
        {
            try
            {
                Actor t = AbilityOps.NearestEnemy(a, 13f);
                float m = PowerLevel.Magic(a);
                float s = PowerLevel.Strength(a);
                switch (key)
                {
                    case "human_demon":     // Demonio Encarnado: llama negra que drena
                        AbilityOps.Drain(a, t, 16f + s * 0.05f);
                        if (t != null) SDSStatus.Inflict(t, "sds_status_hellblaze", 8f);
                        break;
                    case "human_goddess":   // Angel Encarnado: cura y hiere con luz
                        AbilityOps.HealAllies(a, 11f, 12f + m * 0.05f);
                        AbilityOps.Hit(a, t, 12f + m * 0.05f, AttackType.Other, "sds_fx_ark");
                        break;
                    case "human_fairy":     // Elfo Mayor: espina + drena el area
                        if (t != null) { SDSFx.Projectile(a, t, Projectiles.Chastiefol); AbilityOps.Hit(a, t, 12f + m * 0.05f, AttackType.Other, null); }
                        AbilityOps.DrainAll(a, 6f, 8f + m * 0.03f);
                        break;
                    case "human_giant":     // Coloso: pisoton en area con empuje
                        AbilityOps.AoE(a, 6f, 16f + s * 0.06f, AttackType.Other, "sds_fx_creation", null, 0f);
                        break;
                    case "human_vampire":   // Senor de Sangre: mordisco que roba mucho
                        AbilityOps.Drain(a, t, 22f + s * 0.06f);
                        break;
                    case "demon_goddess":   // Crepusculo (Nephilim): cura Y quema a la vez
                        AbilityOps.HealAllies(a, 11f, 14f + m * 0.05f);
                        AbilityOps.AoE(a, 7f, 14f + m * 0.05f, AttackType.Fire, "sds_fx_hellblaze", null, 0f);
                        break;
                    case "demon_fairy":     // Sombra del Bosque: fuego en area que paraliza
                        AbilityOps.AoE(a, 6f, 13f + m * 0.05f, AttackType.Fire, "sds_fx_hellblaze", Curses.Paralyzed, 3f);
                        break;
                    case "demon_giant":     // Titan Oscuro: roca y llama que petrifica
                        AbilityOps.AoE(a, 6f, 16f + s * 0.05f, AttackType.Fire, "sds_fx_creation", Curses.Petrified, 3f);
                        break;
                    case "demon_vampire":   // Devorador Nocturno: drena el area + llama negra
                        AbilityOps.DrainAll(a, 7f, 11f + s * 0.04f);
                        if (t != null) SDSStatus.Inflict(t, "sds_status_hellblaze", 6f);
                        break;
                    case "goddess_fairy":   // Luz del Bosque: cura + lanza de luz al mas lejano
                        AbilityOps.HealAllies(a, 11f, 12f + m * 0.05f);
                        AbilityOps.Hit(a, AbilityOps.FarthestEnemy(a, 15f), 16f + m * 0.05f, AttackType.Other, "sds_fx_ark");
                        break;
                    case "goddess_giant":   // Titan Sagrado: cura + martillo de luz en area
                        AbilityOps.HealAllies(a, 11f, 14f + m * 0.05f);
                        AbilityOps.AoE(a, 6f, 14f + m * 0.05f, AttackType.Other, "sds_fx_ark", null, 0f);
                        break;
                    case "goddess_vampire": // Caliz de Luz: drena a enemigos y cura a aliados
                        AbilityOps.DrainAll(a, 7f, 10f + m * 0.04f);
                        AbilityOps.HealAllies(a, 10f, 12f + m * 0.05f);
                        break;
                    case "fairy_giant":     // Guardian Ancestral: tierra en area + cura
                        AbilityOps.AoE(a, 6f, 13f + s * 0.05f, AttackType.Other, "sds_fx_creation", null, 0f);
                        AbilityOps.HealAllies(a, 10f, 10f + m * 0.04f);
                        break;
                    case "fairy_vampire":   // Espectro del Bosque: drena + sueno que paraliza
                        AbilityOps.DrainAll(a, 6f, 9f + m * 0.04f);
                        AbilityOps.AoE(a, 6f, 6f + m * 0.03f, AttackType.Other, "sds_fx_snatch", Curses.Paralyzed, 3f);
                        break;
                    case "giant_vampire":   // Devorador Colosal: drena el area con fuerza
                        AbilityOps.DrainAll(a, 7f, 14f + s * 0.05f);
                        AbilityOps.AoE(a, 6f, 10f + s * 0.05f, AttackType.Other, "sds_fx_creation", null, 0f);
                        break;
                }
            }
            catch { }
        }
    }
}
