using System.Collections.Generic;

namespace SevenDeadlySins
{
    /// Un CLAN propio para cada mezcla de razas.
    ///
    /// El usuario lo pidio: un hibrido no es "un demonio con algo de diosa", es su propia cosa —
    /// medio demonio medio diosa, como Tristan, que no pertenece del todo a ninguno de los dos
    /// bandos. Aqui esta ese clan: uno por cada par de razas, quince en total, generados en bucle
    /// para no escribir quince veces lo mismo.
    ///
    /// El rasgo de clan hibrido es modesto en numeros: la fuerza de un hibrido viene del poder que
    /// hereda de sus padres (50%, o 25% si el padre ya era hibrido). Esto solo es la IDENTIDAD —
    /// que se sepa, de un vistazo, que esta unidad es un cruce y de que dos sangres.
    public static class HybridClans
    {
        /// clan base -> (parte del id, nombre corto para el clan hibrido)
        private static readonly (string trait, string key, string es, string en)[] Bases =
        {
            (Clans.Human,   "human",   "Humano",  "Human"),
            (Clans.Demon,   "demon",   "Demonio", "Demon"),
            (Clans.Goddess, "goddess", "Diosa",   "Goddess"),
            (Clans.Fairy,   "fairy",   "Hada",    "Fairy"),
            (Clans.Giant,   "giant",   "Gigante", "Giant"),
            (Clans.Vampire, "vampire", "Vampiro", "Vampire"),
        };

        /// clave de par ordenada ("demon|goddess") -> id del rasgo de clan hibrido.
        private static readonly Dictionary<string, string> _byPair = new Dictionary<string, string>();

        public static void Init()
        {
            // Todos los pares no ordenados. i<j evita duplicar (demonio-diosa = diosa-demonio).
            for (int i = 0; i < Bases.Length; i++)
                for (int j = i + 1; j < Bases.Length; j++)
                    Register(Bases[i], Bases[j]);
        }

        private static void Register((string trait, string key, string es, string en) a,
                                     (string trait, string key, string es, string en) b)
        {
            string id = "sds_clan_hybrid_" + a.key + "_" + b.key;
            if (AssetManager.traits.dict.ContainsKey(id)) return;

            ActorTrait t = SDSRegistry.Trait(id, TraitGroups.Bloodline, "ui/icons/" + id);
            t.type = TraitType.Positive;

            // Un pelin por encima de un mestizo cualquiera, y vive mas: la ventaja de dos sangres.
            PowerLevel.Grant(t, 50f, 50f, 50f);
            t.base_stats["health"] = 90f;
            t.base_stats["multiplier_lifespan"] = 3f;

            SDSRegistry.AddTrait(t);
            SDSLocale.Trait(id, "Hibrido " + a.es + "-" + b.es,
                "Nacido del cruce de dos razas: " + a.es + " y " + b.es + ". No pertenece del todo a ninguna.");
            SDSLocale.Add("trait_" + id, "Hibrido " + a.es + "-" + b.es);

            _byPair[Key(a.key, b.key)] = id;
        }

        private static string Key(string a, string b)
        {
            return string.CompareOrdinal(a, b) < 0 ? a + "|" + b : b + "|" + a;
        }

        /// El clan hibrido que corresponde a estos dos clanes base, o null si no hay.
        public static string For(string clanTraitA, string clanTraitB)
        {
            string ka = KeyOf(clanTraitA);
            string kb = KeyOf(clanTraitB);
            if (ka == null || kb == null || ka == kb) return null;

            string id;
            return _byPair.TryGetValue(Key(ka, kb), out id) ? id : null;
        }

        /// Igual que For, pero desde las CLAVES de raza ("demon", "goddess"...) en vez de los rasgos
        /// de clan. Necesario porque un padre hibrido ya no lleva clan base — su raza se saca de la
        /// sangre (SDSUnit.RaceKeyOf), y aun asi sus hijos deben tener su clan hibrido.
        public static string ForKeys(string keyA, string keyB)
        {
            if (keyA == null || keyB == null || keyA == keyB) return null;
            string id;
            return _byPair.TryGetValue(Key(keyA, keyB), out id) ? id : null;
        }

        private static string KeyOf(string clanTrait)
        {
            for (int i = 0; i < Bases.Length; i++)
                if (Bases[i].trait == clanTrait) return Bases[i].key;
            return null;
        }
    }
}
