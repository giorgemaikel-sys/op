using System.Collections.Generic;
using UnityEngine;

namespace SevenDeadlySins
{
    /// What the Sacred Treasures actually DO.
    ///
    /// Until now a treasure was a number bolted onto its owner. In the series each one is a
    /// character in its own right: Chastiefol changes shape depending on what King needs, Lostvayne
    /// makes copies of Meliodas that fight beside him, Rhitta is so heavy at night that nobody can
    /// lift it. This is that.
    ///
    /// Every art is gated on the RIGHTFUL bearer. Picking up Rhitta does not make you Escanor, and a
    /// treasure in the wrong hands is just a heavy stick.
    public static class TreasureArts
    {
        private const string KeyForm = "sds_chastiefol_form";
        private const string KeyClones = "sds_lostvayne_clones";

        // Las FASES de cada arma: un estado visible propio (con su icono y su empujon) que aparece
        // cuando el Tesoro obra, para que se VEA el arma en su forma y no solo salga en la cronica.
        public const string PhChastiefolGuard = "sds_status_ph_chastiefol_guard";
        public const string PhChastiefolSun = "sds_status_ph_chastiefol_sun";
        public const string PhChastiefolStar = "sds_status_ph_chastiefol_star";
        public const string PhLostvayne = "sds_status_ph_lostvayne";
        public const string PhRhitta = "sds_status_ph_rhitta";
        public const string PhGideon = "sds_status_ph_gideon";
        public const string PhCourechouse = "sds_status_ph_courechouse";
        public const string PhHerritt = "sds_status_ph_herritt";
        public const string PhAldan = "sds_status_ph_aldan";

        public static void Init()
        {
            Phases();
            SDSTick.Register(Tick);

            // Aparte del tick de los tesoros: la caducidad de un clon no depende de que su dueno
            // siga vivo ni de que lleve el arma encima.
            SDSTick.Register(TickClone);
        }

        private static void Phases()
        {
            Ph(PhChastiefolGuard, "Chastiefol: Guardian", "Forma Uno. La lanza se hace escudo: aguanta.",
               spi: 800f, armor: 120f);
            Ph(PhChastiefolSun, "Chastiefol: Girasol", "Forma Cuatro. Estalla en un sol que barre el area.",
               mag: 600f, damage: 50f);
            Ph(PhChastiefolStar, "Chastiefol: Estrella", "Forma Siete. Una estocada que atraviesa cualquier cosa.",
               str: 800f, damage: 80f);
            Ph(PhLostvayne, "Lostvayne: Clon Fisico", "La espada sagrada se divide: clones que pelean por el.",
               str: 1000f, damage: 30f);
            Ph(PhRhitta, "Rhitta: Cruel Sol", "El hacha divina cae como una estrella al mediodia.",
               str: 2000f, mag: 1000f, damage: 60f);
            Ph(PhGideon, "Gideon: Martillo de Guerra", "El martillo gigante lanza por los aires lo que toca.",
               str: 1500f, damage: 50f, armor: 40f);
            Ph(PhCourechouse, "Courechouse: Baston Cuadruple", "Cuatro golpes rapidos antes de que caiga el primero.",
               str: 1000f, damage: 40f, speed: 15f);
            Ph(PhHerritt, "Herritt: Arco Gemelo", "Dos flechas de luz a dos blancos a la vez.",
               mag: 1200f, damage: 40f);
            Ph(PhAldan, "Aldan: Esfera Arcana", "La Estrella de la Manana de Merlin: magia pura condensada.",
               mag: 1500f, damage: 30f);
        }

        private static void Ph(string id, string name, string info, float str = 0f, float spi = 0f, float mag = 0f,
                               float damage = 0f, float armor = 0f, float speed = 0f)
        {
            if (AssetManager.status.dict.ContainsKey(id)) return;
            StatusAsset s = SDSRegistry.Status(id, "ui/icons/" + id, 6f);
            if (str != 0f || spi != 0f || mag != 0f) PowerLevel.Grant(s, str, spi, mag);
            if (damage != 0f) s.base_stats["damage"] = damage;
            if (armor != 0f) s.base_stats["armor"] = armor;
            if (speed != 0f) s.base_stats["speed"] = speed;
            s.removed_on_damage = false;
            SDSRegistry.AddStatus(s);
            SDSLocale.Status(id, name, info);
        }

        /// Aplica la fase visible (6s) al que empuna el arma.
        private static void Phase(Actor a, string id) { SDSStatus.Inflict(a, id, 6f); }

        /// True when this unit is the Sin the treasure belongs to.
        private static bool Wields(Actor a, string treasureId)
        {
            if (a == null) return false;
            string sin = SDSUnit.SinOf(a);
            return sin != null && SevenSins.TreasureOf(sin) == treasureId;
        }

        private static float CD(float s)
        {
            return SDSConfig.AbilityCooldowns ? s : 0.2f;
        }

        private static void Tick(Actor a, float dt)
        {
            // ONE hash lookup before anything else. This used to call SDSUnit.SinOf on every unit in
            // the world every sweep — seven string-keyed hasTrait lookups each — and that, more than
            // anything else in the mod, is what made the game stutter. Only the seven named bodies
            // get past this line.
            if (!SDSUnit.IsNamed(a)) return;

            if (!a.isAlive() || a.data == null) return;
            if (Curses.Incapacitated(a)) return;

            string sin = SDSUnit.SinOf(a);
            if (sin == null) return;

            // Only the Sin's own treasure is considered, so this is one dictionary hop per Sin per
            // sweep rather than seven checks.
            string treasure = SevenSins.TreasureOf(sin);
            if (string.IsNullOrEmpty(treasure)) return;

            switch (treasure)
            {
                case SacredTreasures.Chastiefol: Chastiefol(a); break;
                case SacredTreasures.Lostvayne: Lostvayne(a); break;
                case SacredTreasures.Rhitta: Rhitta(a); break;
                case SacredTreasures.Gideon: Gideon(a); break;
                case SacredTreasures.Courechouse: Courechouse(a); break;
                case SacredTreasures.Herritt: Herritt(a); break;
                case SacredTreasures.Aldan: Aldan(a); break;
            }
        }

        // ---------------------------------------------------------------- Chastiefol (King)

        /// The spear has ten forms in the manga. Three are implemented, because three are the ones
        /// that read differently in a WorldBox fight: a guard that shields, a spread that hits a
        /// crowd, and a single thrust that hits one target very hard.
        ///
        /// It cycles rather than being chosen: King swaps forms constantly, and a spear that changes
        /// shape mid-fight is more faithful than one the player has to micromanage.
        private static void Chastiefol(Actor a)
        {
            if (!a.has_attack_target) return;
            if (!SDSData.TryUse(a, "chastiefol", CD(5f))) return;

            int form = (SDSData.GetInt(a, KeyForm, 0) + 1) % 3;
            SDSData.SetInt(a, KeyForm, form);

            float magic = PowerLevel.Magic(a);

            if (form == 0)
            {
                // Forma Uno: Guardian. Se planta y aguanta.
                SDSStatus.Inflict(a, "sds_status_reinforced", 8f);
                SDSFx.At(a, "sds_fx_chastiefol", 0.5f);
                Phase(a, PhChastiefolGuard);
                Say(a, "Chastiefol, Forma Uno: Guardian", "Chastiefol, Form One: Guardian");
                return;
            }

            if (form == 1)
            {
                // Forma Cuatro: Girasol. Un estallido que alcanza a todo lo cercano.
                List<Actor> nearby = SDSUnit.Around(a, 9f);
                bool used = false;
                for (int i = 0; i < nearby.Count; i++)
                {
                    Actor o = nearby[i];
                    if (o == null || !o.isAlive() || o.kingdom == a.kingdom) continue;
                    try { o.getHit(12f + magic * 0.05f, true, AttackType.Fire, a, true); used = true; }
                    catch { }
                }
                if (used)
                {
                    SDSFx.At(a, "sds_fx_sunshine", 0.6f);
                    Phase(a, PhChastiefolSun);
                    Say(a, "Chastiefol, Forma Cuatro: Girasol", "Chastiefol, Form Four: Sunflower");
                }
                return;
            }

            // Forma Siete: Estrella. Una estocada contra un solo objetivo.
            Actor target = Nearest(a, 15f);
            if (target == null) return;

            SDSFx.Projectile(a, target, Projectiles.Chastiefol);
            try { target.getHit(30f + magic * 0.12f, true, AttackType.Other, a, true); }
            catch { return; }

            SDSFx.At(target, "sds_fx_chastiefol", 0.6f);
            Phase(a, PhChastiefolStar);
            Say(a, "Chastiefol, Forma Siete: Estrella", "Chastiefol, Form Seven: Star");
        }

        // ---------------------------------------------------------------- Lostvayne (Meliodas)

        /// Cuantos clones invoca de golpe, cuanto duran, y cada cuanto puede repetir.
        private const int CloneCount = 2;
        private const float CloneLife = 10f;
        private const float CloneCooldown = 50f;

        private const string KeyCloneAge = "sds_clone_age";
        private const string KeyCloneOwner = "sds_clone_owner";

        /// Clon Fisico. Meliodas se desdobla para pelear a su lado.
        ///
        /// Reescrito con lo que pediste, y arreglando lo que estaba roto:
        ///   - Invoca DOS de golpe, no uno.
        ///   - Duran 10 segundos y se desvanecen.
        ///   - Cooldown de 50 segundos.
        ///   - Nacen ADULTOS. Antes salian de bebe (faltaba pAdultAge) — un clon-nino no defiende a
        ///     nadie. Ahora es una copia de combate de verdad.
        ///   - Llevan las HABILIDADES de Meliodas (Full Counter, su forma) y peleen como el, no como
        ///     un aldeano con su cara.
        ///   - Van a su reino y a por su mismo enemigo: estan para defenderle.
        private static void Lostvayne(Actor a)
        {
            if (!a.has_attack_target) return;
            if (!Progression.Has(a, Progression.Awakened)) return;
            if (!SDSData.TryUse(a, "lostvayne", CD(CloneCooldown))) return;
            if (a.current_tile == null || a.asset == null) return;

            int born = 0;
            for (int i = 0; i < CloneCount; i++)
                if (SpawnClone(a)) born++;

            if (born > 0) { Phase(a, PhLostvayne); Say(a, "Lostvayne: Clon Fisico", "Lostvayne: Physical Clone"); }
        }

        private static bool SpawnClone(Actor a)
        {
            Actor clone = null;
            try
            {
                // pAdultAge: true — LA correccion del "clon nino". La firma completa hace falta para
                // llegar al ultimo parametro.
                clone = World.world.units.spawnNewUnit(a.asset.id, a.current_tile,
                    pSpawnSound: false, pMiracleSpawn: false, pSpawnHeight: 0f,
                    pSubspecies: null, pGiveOwnerlessItems: false, pAdultAge: true);
            }
            catch { }
            if (clone == null) return false;

            try
            {
                clone.setName(a.getName());
                if (a.kingdom != null) clone.setKingdom(a.kingdom);

                // Una copia, no un rival: mas debil, y no puede hacer copias de si mismo.
                clone.stats[PowerLevel.StatStrength] = PowerLevel.Strength(a) * 0.5f;
                clone.stats[PowerLevel.StatSpirit] = PowerLevel.Spirit(a) * 0.5f;
                clone.stats[PowerLevel.StatMagic] = PowerLevel.Magic(a) * 0.5f;

                // Las habilidades de Meliodas: que pelee COMO el. Sin las de clase (no las tiene).
                foreach (string id in SDSRegistry.TraitIds)
                    if (id != null && id.StartsWith("sds_ability_") && a.hasTrait(id))
                        SDSTraits.Give(clone, id);

                // A por el mismo enemigo que su original: esta para defenderle.
                if (a.has_attack_target && a.attack_target != null)
                {
                    try { clone.setAttackTarget(a.attack_target); }
                    catch { }
                }
            }
            catch { }

            SDSData.SetFloat(clone, KeyCloneAge, 0f);        // marca de clon + cuenta atras
            SDSData.SetLong(clone, KeyCloneOwner, a.data.id);

            SDSFx.At(clone, "sds_fx_lostvayne", 0.55f);
            return true;
        }

        /// Los clones se desvanecen a los 10 segundos. Un clon no vuelve a clonarse: el KeyCloneAge
        /// lo marca, y Lostvayne solo lo lanza el original (los clones no ejecutan el arte porque no
        /// llevan el tesoro en mano — Wields lo comprueba).
        private static void TickClone(Actor a, float dt)
        {
            if (a == null || !a.isAlive() || a.data == null) return;

            float age = SDSData.GetFloat(a, KeyCloneAge, -1f);
            if (age < 0f) return;                      // no es un clon

            age += dt;
            if (age < CloneLife) { SDSData.SetFloat(a, KeyCloneAge, age); return; }

            SDSFx.At(a, "sds_fx_lostvayne", 0.5f);
            try { a.die(true, AttackType.Other, false, false); }
            catch { }
        }

        // ---------------------------------------------------------------- Rhitta (Escanor)

        /// The divine axe. Its weight follows the sun exactly as its owner does — at night Escanor
        /// cannot swing it at all, and at noon it lands like a falling star.
        private static void Rhitta(Actor a)
        {
            if (!a.has_attack_target) return;

            float sun = DayCycle.SunHeight();
            if (sun < 0.25f) return;      // de noche no puede ni levantarla

            if (!SDSData.TryUse(a, "rhitta", CD(8f))) return;

            Actor target = Nearest(a, 6f);
            if (target == null) return;

            float power = (20f + PowerLevel.Strength(a) * 0.05f) * (0.5f + sun * 2f);
            try { target.getHit(power, true, AttackType.Fire, a, true); }
            catch { return; }

            SDSFx.At(target, "sds_fx_rhitta", 0.75f);
            SDSFx.Wave(a, 2.5f, 1.5f);
            Phase(a, PhRhitta);
            if (DayCycle.IsNoon) Say(a, "Rhitta: Cruel Sol", "Rhitta: Cruel Sun");
        }

        // ---------------------------------------------------------------- the rest

        /// Gideon. A war hammer: one target, heavy damage, everything nearby thrown clear.
        private static void Gideon(Actor a)
        {
            if (!a.has_attack_target) return;
            if (!SDSData.TryUse(a, "gideon", CD(7f))) return;

            List<Actor> nearby = SDSUnit.Around(a, 6f);
            bool used = false;
            for (int i = 0; i < nearby.Count; i++)
            {
                Actor o = nearby[i];
                if (o == null || !o.isAlive() || o.kingdom == a.kingdom) continue;
                try { o.getHit(18f + PowerLevel.Strength(a) * 0.06f, true, AttackType.Other, a, true); used = true; }
                catch { }
            }
            if (used)
            {
                SDSFx.At(a, "sds_fx_gideon", 0.7f);
                SDSFx.Wave(a, 3f, 2f);
                Phase(a, PhGideon);
            }
        }

        /// Courechouse. A four-section staff: several fast strikes on one target.
        private static void Courechouse(Actor a)
        {
            if (!a.has_attack_target) return;
            if (!SDSData.TryUse(a, "courechouse", CD(4f))) return;

            Actor target = Nearest(a, 4f);
            if (target == null) return;

            float per = 6f + PowerLevel.Strength(a) * 0.02f;
            for (int i = 0; i < 4; i++)
            {
                if (!target.isAlive()) break;
                try { target.getHit(per, true, AttackType.Other, a, true); }
                catch { break; }
            }
            SDSFx.At(target, "sds_fx_courechouse", 0.45f);
            Phase(a, PhCourechouse);
        }

        /// Herritt. A twin bow: two arrows, two targets.
        private static void Herritt(Actor a)
        {
            if (!a.has_attack_target) return;
            if (!SDSData.TryUse(a, "herritt", CD(5f))) return;

            float power = 10f + PowerLevel.Magic(a) * 0.04f;
            int shot = 0;

            List<Actor> nearby = SDSUnit.Around(a, 14f);
            for (int i = 0; i < nearby.Count && shot < 2; i++)
            {
                Actor o = nearby[i];
                if (o == null || !o.isAlive() || o.kingdom == a.kingdom) continue;

                SDSFx.Projectile(a, o, Projectiles.Herritt);
                try { o.getHit(power, true, AttackType.Other, a, true); }
                catch { continue; }
                shot++;
            }
            if (shot > 0) { SDSFx.At(a, "sds_fx_herritt", 0.4f); Phase(a, PhHerritt); }
        }

        /// Aldan. Merlin's orb: it does not strike, it AMPLIFIES — her magic swells while she holds it.
        private static void Aldan(Actor a)
        {
            // El orbe tiene su propio estado y su propia regla de duracion, en Merlin.cs: con
            // Infinity la amplificacion no se le pasa. Antes reciclaba el estado generico de magia
            // especial durante catorce segundos, que para el tesoro de la mejor maga de Britannia
            // era practicamente no hacer nada.
            Merlin.Aldan(a);
            Phase(a, PhAldan);
        }

        // ---------------------------------------------------------------- helpers

        private static Actor Nearest(Actor a, float radius)
        {
            List<Actor> nearby = SDSUnit.Around(a, radius);
            for (int i = 0; i < nearby.Count; i++)
            {
                Actor o = nearby[i];
                if (o != null && o.isAlive() && o.kingdom != a.kingdom) return o;
            }
            return null;
        }

        /// Announces a named technique. Throttled by SDSLog, so a battlefield full of Sins does not
        /// turn the tip bar into a slot machine.
        private static void Say(Actor a, string es, string en)
        {
            SDSLog.Tip(a.getName() + ": " + SDSLocale.T(es, en));
        }
    }
}
