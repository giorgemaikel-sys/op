using System.Collections.Generic;
using UnityEngine;

namespace SevenDeadlySins
{
    /// EL ECO DE UN SOLO PECADO — la herencia de los hijos MEDIO-Pecado.
    ///
    /// El usuario lo pidio claro: "no solo los hijos PUROS de Pecados (los de dos Pecados) deben tener
    /// esas habilidades, tambien los hibridos de Pecado mitad si mitad no". Un hijo con UN solo padre
    /// Pecado — Meliodas con una hada, Escanor con una giganta — no es un hijo-legado (ese necesita DOS
    /// Pecados), pero tampoco es cualquiera: lleva el ECO del Pecado de su padre. Aqui esta ese eco:
    /// siete habilidades, una por Pecado, mas debiles que la de un hijo de dos Pecados pero con el
    /// mismo sabor. Es su herencia a medias hecha poder.
    ///
    /// Hermano de SinLegacy y HybridLegacy: misma mecanica (STATUS 25 s cada 30 s + golpe de firma),
    /// mismas primitivas (AbilityOps).
    public static class HalfSinLegacy
    {
        private sealed class Half
        {
            public string sin;                 // el rasgo de Pecado del padre
            public string code;                // "wr", "gr"...
            public string abilityTrait, ability;
            public string nameEs, nameEn, desc, fx, icon;
        }

        private static readonly Dictionary<string, Half> _bySin = new Dictionary<string, Half>();
        private const string KeyHalf = "sds_halfsin_key";
        private const float AbilityDuration = 25f;
        private const float AbilityCooldown = 30f;

        // Pecado -> (codigo, nombre ES, nombre EN, que hace, FX reutilizado)
        private static readonly (string sin, string code, string es, string en, string desc, string fx)[] Defs =
        {
            (SevenSins.Wrath,    "wr", "Eco de Ira",      "Echo of Wrath",    "descarga una hoja de llama negra que quema al enemigo y no deja que la herida cierre", "sds_fx_hellblaze"),
            (SevenSins.Greed,    "gr", "Eco de Codicia",  "Echo of Greed",    "roba la vida del enemigo mas cercano para curarse", "sds_fx_snatch"),
            (SevenSins.Envy,     "en", "Eco de Envidia",  "Echo of Envy",     "sacude la tierra en un area y golpea a todos los enemigos alrededor", "sds_fx_creation"),
            (SevenSins.Lust,     "lu", "Eco de Lujuria",  "Echo of Lust",     "nubla la mente de los enemigos del area y los deja paralizados", "sds_fx_infinity"),
            (SevenSins.Sloth,    "sl", "Eco de Pereza",   "Echo of Sloth",    "lanza una espina de espiritu al enemigo y cura a los aliados cercanos", "sds_fx_heal"),
            (SevenSins.Gluttony, "gl", "Eco de Gula",     "Echo of Gluttony", "devora la magia del area: drena a los enemigos y petrifica al mas cercano", "sds_fx_infinity"),
            (SevenSins.Pride,    "pr", "Eco de Orgullo",  "Echo of Pride",    "una hoja de sol: fuego devastador sobre un solo objetivo", "sds_fx_sunshine"),
        };

        public static void Init()
        {
            for (int i = 0; i < Defs.Length; i++)
            {
                var d = Defs[i];
                Half h = new Half
                {
                    sin = d.sin, code = d.code,
                    abilityTrait = "sds_ability_half_" + d.code,
                    ability = "sds_status_half_ab_" + d.code,
                    nameEs = d.es, nameEn = d.en, desc = d.desc, fx = d.fx,
                    icon = "ui/icons/sds_ability_half_" + d.code,   // su propio icono (eco del Pecado)
                };
                _bySin[d.sin] = h;

                RegisterTrait(h);
                RegisterStatus(h);

                string info = "El eco del Pecado del padre en un hijo medio-Pecado: " + h.desc + ". Dura 25s, se relanza cada 30s.";
                SDSLocale.Trait(h.abilityTrait, h.nameEs, info);
                SDSLocale.Status(h.ability, h.nameEs, info);
                SDSLocale.TraitLore(h.abilityTrait,
                    "Nace de un hijo con UN solo padre Pecado (el otro no lo es). No es la habilidad "
                    + "entera de un hijo de dos Pecados, es su ECO — mas debil, pero del mismo linaje.");
            }

            SDSTick.Register(Tick);
        }

        private static void RegisterTrait(Half h)
        {
            if (AssetManager.traits.dict.ContainsKey(h.abilityTrait)) return;
            ActorTrait t = SDSRegistry.Trait(h.abilityTrait, TraitGroups.SinPowers, h.icon);
            t.type = TraitType.Positive;
            PowerLevel.Grant(t, 250f, 250f, 250f);
            t.base_stats["damage"] = 12f;
            SDSRegistry.AddTrait(t);
        }

        private static void RegisterStatus(Half h)
        {
            if (AssetManager.status.dict.ContainsKey(h.ability)) return;
            StatusAsset s = SDSRegistry.Status(h.ability, h.icon, AbilityDuration);
            PowerLevel.Grant(s, 900f, 900f, 900f);   // un eco: mas modesto que un hijo de dos Pecados
            s.base_stats["damage"] = 16f;
            s.base_stats["armor"] = 10f;
            s.removed_on_damage = false;
            SDSRegistry.AddStatus(s);
        }

        /// El unico padre Pecado, o null si hay dos o ninguno. (Dos Pecados los coge SinLegacy antes.)
        private static string LoneSin(Actor p1, Actor p2)
        {
            string s1 = SDSUnit.SinOf(p1);
            string s2 = SDSUnit.SinOf(p2);
            if (s1 != null && s2 != null) return null;   // dos Pecados: no es medio-Pecado
            return s1 ?? s2;
        }

        public static bool TryApply(Actor baby, Actor p1, Actor p2)
        {
            if (baby == null) return false;
            string sin = LoneSin(p1, p2);
            if (sin == null) return false;

            Half h;
            if (!_bySin.TryGetValue(sin, out h)) return false;

            try
            {
                SDSTraits.Give(baby, h.abilityTrait);
                SDSData.SetString(baby, KeyHalf, sin);
                SDSUnit.MarkAbilityUser(baby);
            }
            catch { }
            return true;
        }

        private static float CD(float s) { return SDSConfig.AbilityCooldowns ? s : 0.3f; }

        private static void Tick(Actor a, float dt)
        {
            if (a == null || !a.isAlive() || a.data == null) return;
            if (!SDSUnit.RunsAbilities(a)) return;
            if (!a.isAdult()) return;

            string sin = SDSData.GetString(a, KeyHalf, "");
            if (string.IsNullOrEmpty(sin)) return;

            Half h;
            if (!_bySin.TryGetValue(sin, out h)) return;

            if (Curses.Incapacitated(a)) return;

            bool foe = AbilityOps.NearestEnemy(a, 13f) != null;
            bool wounded = HasWoundedAlly(a, 12f);
            if (!foe && !wounded) return;

            if (a.hasStatus(h.ability)) return;
            if (!SDSData.TryUse(a, "halfsin_cast", CD(AbilityCooldown))) return;

            if (!SDSStatus.Inflict(a, h.ability, AbilityDuration)) return;
            SDSFx.At(a, h.fx, 0.7f);

            CastAbility(a, h.code);
        }

        private static bool HasWoundedAlly(Actor a, float radius)
        {
            List<Actor> near = SDSUnit.Around(a, radius);
            for (int i = 0; i < near.Count; i++)
            {
                Actor o = near[i];
                if (!SDSUnit.IsAlly(a, o)) continue;
                if (o.data != null && o.data.health < o.getMaxHealth()) return true;
            }
            return false;
        }

        private static void CastAbility(Actor a, string code)
        {
            try
            {
                Actor t = AbilityOps.NearestEnemy(a, 13f);
                float m = PowerLevel.Magic(a);
                float s = PowerLevel.Strength(a);
                switch (code)
                {
                    case "wr":  // Ira: llama negra
                        AbilityOps.Hit(a, t, 15f + s * 0.05f, AttackType.Fire, "sds_fx_hellblaze");
                        if (t != null) SDSStatus.Inflict(t, "sds_status_hellblaze", 6f);
                        break;
                    case "gr":  // Codicia: roba vida
                        AbilityOps.Drain(a, t, 14f + s * 0.05f);
                        break;
                    case "en":  // Envidia: tierra en area
                        AbilityOps.AoE(a, 6f, 12f + s * 0.05f, AttackType.Other, "sds_fx_creation", null, 0f);
                        break;
                    case "lu":  // Lujuria: paraliza el area
                        AbilityOps.AoE(a, 6f, 7f + m * 0.03f, AttackType.Other, "sds_fx_infinity", Curses.Paralyzed, 3f);
                        break;
                    case "sl":  // Pereza: espina de espiritu + cura
                        if (t != null) { SDSFx.Projectile(a, t, Projectiles.Chastiefol); AbilityOps.Hit(a, t, 12f + m * 0.04f, AttackType.Other, null); }
                        AbilityOps.HealAllies(a, 10f, 10f + m * 0.04f);
                        break;
                    case "gl":  // Gula: drena el area y petrifica
                        AbilityOps.DrainAll(a, 7f, 9f + m * 0.04f);
                        if (t != null) SDSStatus.Inflict(t, Curses.Petrified, 3f);
                        break;
                    case "pr":  // Orgullo: hoja de sol pesada
                        AbilityOps.Hit(a, t, 22f + m * 0.06f, AttackType.Fire, "sds_fx_sunshine");
                        break;
                }
            }
            catch { }
        }
    }
}
