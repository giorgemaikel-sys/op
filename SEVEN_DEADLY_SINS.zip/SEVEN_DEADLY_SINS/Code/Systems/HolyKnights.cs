using UnityEngine;

namespace SevenDeadlySins
{
    /// The Holy Knight ladder (DESIGN.md section 7).
    ///
    ///   Aprendiz -> Caballero Sagrado -> Gran Caballero Sagrado -> Gran Maestro
    ///
    /// Four mutually exclusive ranks, climbed by blood and by years: a knight rises when he has
    /// killed enough SINCE HIS LAST PROMOTION and is old enough to be trusted with the next seat.
    /// Every rung is a real jump in Power Level, so a Gran Maestro (~3.400) stands alongside one of
    /// the Seven Sins, which is exactly where Hendrickson and Dreyfus sit in the series.
    ///
    /// Only the Human clan climbs it. The Holy Knights are Liones' human order — a demon does not
    /// get knighted, and DESIGN.md hands the ranks to the Human clan alone.
    public static class HolyKnights
    {
        public const string Apprentice = "sds_rank_apprentice";
        public const string HolyKnight = "sds_rank_holy_knight";
        public const string GreatHolyKnight = "sds_rank_great_holy_knight";
        public const string GrandMaster = "sds_rank_grand_master";

        public static readonly string[] All = { Apprentice, HolyKnight, GreatHolyKnight, GrandMaster };

        /// Pinned by the design contract as an ID, not as an accessor name. TraitGroups registers it.
        private const string Group = "sds_group_ranks";

        /// One rung of the ladder.
        private class Rung
        {
            public readonly string trait;
            public readonly string nameEs;
            public readonly string nameEn;
            public readonly int age;             // minimum years
            public readonly int killsSinceLast;  // kills earned SINCE the previous promotion

            public Rung(string trait, string nameEs, string nameEn, int age, int killsSinceLast)
            {
                this.trait = trait;
                this.nameEs = nameEs;
                this.nameEn = nameEn;
                this.age = age;
                this.killsSinceLast = killsSinceLast;
            }
        }

        // Ascending. Index in this array IS the rank order, and Promote only ever steps forward by
        // one, so nothing here can demote a knight who already earned a higher seat.
        private static readonly Rung[] Ladder =
        {
            new Rung(Apprentice,      "Aprendiz de Caballero Sagrado", "Holy Knight Apprentice", 14, 0),
            new Rung(HolyKnight,      "Caballero Sagrado",             "Holy Knight",            18, 5),
            new Rung(GreatHolyKnight, "Gran Caballero Sagrado",        "Great Holy Knight",      28, 15),
            new Rung(GrandMaster,     "Gran Maestro",                  "Grand Master",           40, 35),
        };

        public static void Init()
        {
            RegisterTraits();

            // A knight holds one rank. Without this a veteran would accumulate all four at once and
            // stack their stats, which is how you get a 5.000 Power Level apprentice.
            SDSRegistry.Opposites(All);

            SDSTick.Register(Tick);
        }

        // ---------------------------------------------------------------- registration

        private static void RegisterTraits()
        {
            // rate_inherit 0: rank is earned, never inherited. A Gran Maestro's son starts at nothing
            // like everyone else. (rate_birth is never set at all — see SDSRegistry.Trait.)
            Rank(Apprentice, "ui/icons/sds_rank_apprentice",
                30f, 20f, 10f, 40f, 6f, 3f, 0f,
                "Aprendiz de Caballero Sagrado",
                "Entrenado en el castillo, aun sin nombramiento. Su magia despierta pero no domina nada todavia.");

            Rank(HolyKnight, "ui/icons/sds_rank_holy_knight",
                220f, 160f, 120f, 250f, 35f, 25f, 3f,
                "Caballero Sagrado",
                "Caballero de pleno derecho de Liones. Vale por una compania entera de soldados rasos.");

            Rank(GreatHolyKnight, "ui/icons/sds_rank_great_holy_knight",
                700f, 520f, 430f, 700f, 90f, 60f, 5f,
                "Gran Caballero Sagrado",
                "Manda sobre los demas caballeros. Muy pocos alcanzan este rango, y ninguno lo hace joven.");

            Rank(GrandMaster, "ui/icons/sds_rank_grand_master",
                1500f, 1050f, 850f, 1500f, 180f, 110f, 7f,
                "Gran Maestro",
                "La cuspide de la orden: responde solo ante el rey. Su nivel de poder roza el de un Pecado Capital.");
        }

        private static void Rank(string id, string icon,
                                 float strength, float spirit, float magic,
                                 float health, float damage, float armor, float speed,
                                 string name, string info)
        {
            ActorTrait t = SDSRegistry.Trait(id, Group, icon, 0);
            PowerLevel.Grant(t, strength, spirit, magic);

            // The Power Level is the badge, but the rank has to be felt in an actual fight too.
            t.base_stats.set("health", health);
            t.base_stats.set("damage", damage);
            t.base_stats.set("armor", armor);
            if (speed > 0f) t.base_stats.set("speed", speed);

            SDSRegistry.AddTrait(t);
            SDSLocale.Trait(id, name, info);
        }

        // ---------------------------------------------------------------- public API

        /// The rank this unit holds, or null. Highest first, so a unit left holding two by some
        /// other system still reads as the better one.
        public static string RankOf(Actor a)
        {
            if (a == null) return null;
            for (int i = Ladder.Length - 1; i >= 0; i--)
                if (a.hasTrait(Ladder[i].trait)) return Ladder[i].trait;
            return null;
        }

        /// Advances this knight exactly ONE rung, if he has earned it. Safe to call every tick:
        /// it is a no-op for anyone who does not currently qualify.
        public static void Promote(Actor a)
        {
            if (a == null || !a.isAlive() || a.data == null) return;
            if (!SDSUnit.IsSentient(a)) return;

            // The order is human. SDSUnit.IsHuman reads the Human CLAN trait, not the race, so a
            // demon wearing a human body still cannot be knighted.
            if (!SDSUnit.IsHuman(a)) return;

            // NO TODO EL MUNDO ES CABALLERO. Antes cualquier humano de 14 anos se hacia Aprendiz
            // solo, y el mundo entero acababa de armadura. Los Caballeros Sagrados son una orden,
            // no una etapa de la vida: solo una fraccion vale. Se tira el dado UNA vez por unidad.
            if (!IsCandidate(a)) return;

            int current = IndexOf(RankOf(a));
            if (current >= Ladder.Length - 1) return;    // already Gran Maestro: nowhere left to go

            Rung next = Ladder[current + 1];
            if (AgeOf(a) < next.age) return;
            if (KillsSinceLastRank(a) < next.killsSinceLast) return;

            Award(a, next);
        }

        /// Fraccion de humanos que pueden llegar a caballero. El dado se guarda para que sea estable.
        private const float KnightFraction = 0.18f;
        private const string KeyKnightRolled = "sds_knight_rolled";
        private const string KeyKnightOk = "sds_knight_ok";

        private static bool IsCandidate(Actor a)
        {
            if (SDSData.GetBool(a, KeyKnightRolled))
                return SDSData.GetBool(a, KeyKnightOk);

            bool ok = Randy.randomChance(KnightFraction);
            SDSData.SetBool(a, KeyKnightRolled, true);
            SDSData.SetBool(a, KeyKnightOk, ok);
            return ok;
        }

        /// Cada caballero recibe su habilidad UNICA — no una de un puñado, sino una combinacion
        /// propia de elemento y forma. Cien caballeros, cien habilidades. Ver KnightPowers.
        private static void GiveKnightMagic(Actor a)
        {
            KnightPowers.Assign(a);
        }

        // ---------------------------------------------------------------- internals

        private static int IndexOf(string trait)
        {
            if (string.IsNullOrEmpty(trait)) return -1;
            for (int i = 0; i < Ladder.Length; i++)
                if (Ladder[i].trait == trait) return i;
            return -1;
        }

        /// Kills banked since the last promotion. This is the whole reason SDSData.KillsAtLastRank
        /// exists: comparing against the LIFETIME total would leave a fresh Caballero Sagrado already
        /// over the bar for the next rung, and the tick would walk him to Gran Maestro in four sweeps.
        private static int KillsSinceLastRank(Actor a)
        {
            int total = 0;
            try { total = a.data.kills; }
            catch { return 0; }

            int atLastRank = SDSData.GetInt(a, SDSData.KillsAtLastRank, 0);
            return Mathf.Max(0, total - atLastRank);
        }

        private static void Award(Actor a, Rung rung)
        {
            SDSTraits.Give(a, rung.trait);

            // If the trait did not stick — an opposite list that never got applied, a trait the
            // registry rejected — do NOT record the promotion and do NOT announce it. Otherwise the
            // tick retries it on every single sweep and buries the world log.
            if (!a.hasTrait(rung.trait)) return;

            // Reset the counter FIRST, so even a failure further down cannot leave him eligible for
            // the next rung on the very next sweep.
            int total = 0;
            try { total = a.data.kills; }
            catch { }
            SDSData.SetInt(a, SDSData.KillsAtLastRank, total);

            // A partir de Caballero Sagrado (rango 1), su magia propia. El Aprendiz aun no: primero
            // se gana el puesto, luego la magia.
            if (rung.trait != Apprentice) GiveKnightMagic(a);

            Announce(a, rung);
        }

        private static void Announce(Actor a, Rung rung)
        {
            string who = "";
            try { who = a.getName(); }
            catch { }
            if (string.IsNullOrEmpty(who)) return;

            // A Gran Maestro is a once-in-a-generation event and belongs in the world's history.
            if (rung.trait == GrandMaster)
            {
                SDSLog.Chronicle(SDSLocale.T(
                    who + " ha sido nombrado Gran Maestro de los Caballeros Sagrados.",
                    who + " has been named Grand Master of the Holy Knights."));
                return;
            }

            // A Gran Caballero Sagrado is worth a passing notice, nothing more.
            if (rung.trait == GreatHolyKnight)
            {
                SDSLog.Tip(SDSLocale.T(
                    who + " ha ascendido a Gran Caballero Sagrado",
                    who + " has been promoted to Great Holy Knight"));
                return;
            }

            // Apprentices and plain Holy Knights are made by the dozen in any real kingdom. Announcing
            // them would drown out every other message on screen.
        }

        private static void Tick(Actor a, float dt)
        {
            if (!SDSConfig.HolyKnightPromotion) return;

            // Cheapest possible rejection first: this runs for every unit in the world, and most of
            // them are wolves, demons and fairies who will never see the inside of Liones castle.
            if (!SDSUnit.IsHuman(a)) return;

            Promote(a);
        }

        private static int AgeOf(Actor a)
        {
            try { return a.getAge(); }
            catch { return 0; }
        }
    }
}
