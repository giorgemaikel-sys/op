using System.Collections.Generic;
using UnityEngine;

namespace SevenDeadlySins
{
    /// MECANICAS DE COMBATE — para que una pelea del mod se sienta como una de la serie y no como dos
    /// aldeanos dandose con palos. Todo son ESTADOS y COMPORTAMIENTO (categoria segura: no toca
    /// actores ni texturas), gateado barato (clan del mod primero, luego cooldowns) para no lastrar
    /// un mundo grande.
    ///
    /// Cada mecanica es canon: los Pecados pelean mas fuerte acorralados, los demonios regeneran, los
    /// gigantes aguantan, Derieri y Monspeet hacen su Combo Estelar, Meliodas y Elizabeth se sostienen
    /// el uno al otro... Son ~16 reglas nuevas que se disparan solas segun quien pelea y como.
    public static class Combat
    {
        // ---- estados (buffs y debuffs) ----
        public const string LastStand = "sds_status_last_stand";
        public const string Bloodlust = "sds_status_bloodlust";
        public const string Fear = "sds_status_fear";
        public const string WarCry = "sds_status_war_cry";
        public const string ArmorBreak = "sds_status_armor_break";
        public const string GiantEndure = "sds_status_giant_endure";
        public const string FairyGrace = "sds_status_fairy_grace";
        public const string ComboStar = "sds_status_combo_star";
        public const string Fellowship = "sds_status_fellowship";
        public const string Bond = "sds_status_bond";

        private const string KeyKills = "sds_combat_kills";

        public static void Init()
        {
            // buffs (positivos)
            St(LastStand, "Ultima Resistencia", "Acorralado, pelea con todo lo que le queda: mas fuerza y dano.",
               str: 2500f, spi: 1500f, mag: 1000f, damage: 40f, speed: 12f);
            St(Bloodlust, "Sed de Batalla", "Cada muerte le enciende la sangre: golpea mas fuerte y mas rapido.",
               str: 1200f, damage: 30f, speed: 15f);
            St(WarCry, "Grito de Guerra", "El grito de su rey lo empuja: pelea con brios renovados.",
               str: 800f, spi: 800f, damage: 20f, speed: 8f);
            St(GiantEndure, "Aguante de Gigante", "La piel de un gigante no se rompe facil.",
               armor: 60f, spi: 1000f);
            St(FairyGrace, "Gracia de Hada", "Ligero como el viento: esquiva lo que otros no.",
               speed: 30f, spi: 600f);
            St(ComboStar, "Combo Estelar", "Purga y Silencio juntos: el combo de Derieri y Monspeet, imparable.",
               str: 4000f, spi: 4000f, mag: 4000f, damage: 80f);
            St(Fellowship, "Camaraderia de los Pecados", "Los Pecados espalda con espalda son mas que la suma.",
               str: 1500f, spi: 1500f, mag: 1500f, damage: 30f);
            St(Bond, "El Vinculo Eterno", "Meliodas y Elizabeth se sostienen el uno al otro contra todo.",
               str: 2000f, spi: 2000f, mag: 2000f, damage: 30f, armor: 15f);

            // debuffs (negativos)
            StBad(Fear, "Terror", "Ante una presencia abrumadora, las piernas flaquean: mas lento y mas debil.",
               str: -400f, damage: -30f, speed: -40f);
            StBad(ArmorBreak, "Armadura Rota", "Su defensa esta hecha pedazos: recibe mucho mas dano.",
               armor: -80f, spi: -800f);

            SDSTick.Register(Tick);
        }

        private static void St(string id, string name, string info, float str = 0f, float spi = 0f, float mag = 0f,
                               float damage = 0f, float armor = 0f, float speed = 0f)
        {
            if (AssetManager.status.dict.ContainsKey(id)) return;
            StatusAsset s = SDSRegistry.Status(id, "ui/icons/" + id, 8f);
            if (str != 0f || spi != 0f || mag != 0f) PowerLevel.Grant(s, str, spi, mag);
            if (damage != 0f) s.base_stats["damage"] = damage;
            if (armor != 0f) s.base_stats["armor"] = armor;
            if (speed != 0f) s.base_stats["speed"] = speed;
            s.removed_on_damage = false;
            SDSRegistry.AddStatus(s);
            SDSLocale.Status(id, name, info);
        }

        private static void StBad(string id, string name, string info, float str = 0f, float spi = 0f, float mag = 0f,
                                  float damage = 0f, float armor = 0f, float speed = 0f)
        {
            St(id, name, info, str, spi, mag, damage, armor, speed);
        }

        // ---------------------------------------------------------------- comportamiento

        private static void Tick(Actor a, float dt)
        {
            if (a == null || !a.isAlive() || a.data == null) return;

            // Puerta barata: solo unidades de un pueblo del mod. Casi toda la fauna sale aqui.
            string clan = SDSUnit.ClanOf(a);
            if (clan == null) return;

            float max = a.getMaxHealth();
            if (max <= 0f) return;
            float hp = a.data.health;
            bool named = SDSUnit.IsNamed(a);
            bool fighting = a.has_attack_target;

            // 1) SED DE BATALLA + SEGUNDO ALIENTO: al matar. Se mira cada par de segundos.
            if (SDSData.TryUse(a, "combat_kills", 2f))
            {
                int kills = 0; try { kills = a.data.kills; } catch { }
                int last = SDSData.GetInt(a, KeyKills, kills);
                if (kills > last)
                {
                    SDSStatus.Inflict(a, Bloodlust, 8f);
                    if (named && hp < max) { try { a.restoreHealth(Mathf.RoundToInt(max * 0.12f)); } catch { } }  // segundo aliento
                }
                SDSData.SetInt(a, KeyKills, kills);
            }

            // ---- clan pasivo (barato, por rasgo) ----

            // 2) REGENERACION DEMONIACA: un demonio en combate se cura solo.
            if (fighting && clan == Clans.Demon && SDSData.TryUse(a, "demon_regen", 2f) && hp < max)
            {
                try { a.restoreHealth(Mathf.Max(1, Mathf.RoundToInt(max * 0.03f))); } catch { }
            }
            // 3) AGUANTE DE GIGANTE.
            if (fighting && clan == Clans.Giant && !a.hasStatus(GiantEndure)) SDSStatus.Inflict(a, GiantEndure, 8f);
            // 4) GRACIA DE HADA.
            if (fighting && clan == Clans.Fairy && !a.hasStatus(FairyGrace)) SDSStatus.Inflict(a, FairyGrace, 8f);
            // 5) LUZ DE DIOSA: una diosa cura a los aliados heridos cerca.
            if (clan == Clans.Goddess && SDSData.TryUse(a, "goddess_light", 3f)) HealAlliesNear(a, 8f, max);

            // ---- mecanicas de los NOMBRADOS (mas caras, gateadas por IsNamed) ----
            if (!named) return;

            float power = 0f; try { power = PowerLevel.Cached(a); } catch { }

            // 6) ULTIMA RESISTENCIA: acorralado, un Pecado saca su mejor pelea.
            if (hp < max * 0.25f && !a.hasStatus(LastStand)) SDSStatus.Inflict(a, LastStand, 6f);

            // 7) GRITO DE GUERRA: un rey empuja a los suyos.
            bool king = false; try { king = a.isKing(); } catch { }
            if (king && SDSData.TryUse(a, "war_cry", 15f)) Rally(a, 9f);

            if (fighting && power > 4000f && SDSData.TryUse(a, "named_strike", 4f))
            {
                Actor t = a.attack_target != null ? a.attack_target.a : null;
                if (t != null && t.isAlive() && t.kingdom != a.kingdom)
                {
                    // 8) QUIEBRA-ARMADURA: un golpe fuerte deja al rival sin defensa.
                    SDSStatus.Inflict(t, ArmorBreak, 6f);
                    // 9) GOLPE DE GRACIA: si el rival esta al borde, se acaba la pelea.
                    if (t.data != null && t.data.health < t.getMaxHealth() * 0.18f)
                    {
                        try { t.getHit(40f + power * 0.02f, true, AttackType.Other, a, true); } catch { }
                        SDSFx.At(t, "sds_fx_full_counter", 0.5f);
                    }
                }
            }

            // 10) PRESENCIA ABRUMADORA: los debiles cerca de un coloso hostil tiemblan.
            if (power > 8000f && SDSData.TryUse(a, "presence", 5f)) Intimidate(a, 8f, power);

            // 11) CHOQUE DE TITANES: dos colosos hostiles juntos sacuden la tierra.
            if (power > 15000f && fighting && SDSData.TryUse(a, "clash", 6f)) Clash(a, power);

            // ---- combos y vinculos con nombre ----

            // 12) COMBO ESTELAR: Derieri (Pureza) + Monspeet (Silencio).
            if (a.hasTrait(TenCommandments.Purity) && SDSData.TryUse(a, "combo_star", 4f)
                && HasNearby(a, 10f, TenCommandments.Reticence))
            {
                SDSStatus.Inflict(a, ComboStar, 8f);
                Actor m = FindNearby(a, 10f, TenCommandments.Reticence);
                if (m != null) SDSStatus.Inflict(m, ComboStar, 8f);
            }

            // 13) CAMARADERIA: tres o mas Pecados juntos.
            if (SDSUnit.IsSin(a) && SDSData.TryUse(a, "fellowship", 4f) && CountSins(a, 10f) >= 3)
                SDSStatus.Inflict(a, Fellowship, 8f);

            // 14) EL VINCULO: Meliodas (Ira) cerca de Elizabeth.
            if (a.hasTrait(SevenSins.Wrath) && SDSData.TryUse(a, "bond", 4f))
            {
                Actor eli = FindNearbyName(a, 12f, "Elizabeth");
                if (eli != null) { SDSStatus.Inflict(a, Bond, 8f); SDSStatus.Inflict(eli, Bond, 8f); }
            }
        }

        // ---------------------------------------------------------------- helpers

        private static void HealAlliesNear(Actor a, float r, float _)
        {
            List<Actor> near = SDSUnit.Around(a, r);
            bool used = false;
            for (int i = 0; i < near.Count; i++)
            {
                Actor o = near[i];
                if (!SDSUnit.IsAlly(a, o)) continue;
                if (o.data == null || o.data.health >= o.getMaxHealth()) continue;
                try { o.restoreHealth(Mathf.Max(1, Mathf.RoundToInt(o.getMaxHealth() * 0.04f))); used = true; } catch { }
            }
            if (used) SDSFx.At(a, "sds_fx_ark", 0.4f);
        }

        private static void Rally(Actor a, float r)
        {
            List<Actor> near = SDSUnit.Around(a, r);
            bool used = false;
            for (int i = 0; i < near.Count; i++)
            {
                Actor o = near[i];
                if (o == a || !SDSUnit.IsAlly(a, o)) continue;
                SDSStatus.Inflict(o, WarCry, 12f); used = true;
            }
            if (used) SDSFx.At(a, "sds_fx_sunshine", 0.4f);
        }

        private static void Intimidate(Actor a, float r, float power)
        {
            List<Actor> near = SDSUnit.Around(a, r);
            for (int i = 0; i < near.Count; i++)
            {
                Actor o = near[i];
                if (o == null || !o.isAlive() || o.kingdom == a.kingdom) continue;
                float op = 0f; try { op = PowerLevel.Cached(o); } catch { }
                if (op < power * 0.25f) SDSStatus.Inflict(o, Fear, 6f);   // solo a los MUY inferiores
            }
        }

        private static void Clash(Actor a, float power)
        {
            Actor t = a.attack_target != null ? a.attack_target.a : null;
            if (t == null || !t.isAlive()) return;
            float tp = 0f; try { tp = PowerLevel.Cached(t); } catch { }
            if (tp < 8000f) return;                          // solo entre colosos
            List<Actor> near = SDSUnit.Around(a, 5f);
            for (int i = 0; i < near.Count; i++)
            {
                Actor o = near[i];
                if (o == null || !o.isAlive() || o.kingdom == a.kingdom) continue;
                try { o.getHit(25f + power * 0.01f, true, AttackType.Other, a, true); } catch { }
            }
            SDSFx.At(a, "sds_fx_creation", 0.7f);
            SDSFx.Wave(a, 3f, 2f);
        }

        private static bool HasNearby(Actor a, float r, string trait) { return FindNearby(a, r, trait) != null; }

        private static Actor FindNearby(Actor a, float r, string trait)
        {
            List<Actor> near = SDSUnit.Around(a, r);
            for (int i = 0; i < near.Count; i++)
            {
                Actor o = near[i];
                if (o != null && o.isAlive() && o != a && o.hasTrait(trait)) return o;
            }
            return null;
        }

        private static Actor FindNearbyName(Actor a, float r, string name)
        {
            List<Actor> near = SDSUnit.Around(a, r);
            for (int i = 0; i < near.Count; i++)
            {
                Actor o = near[i];
                if (o == null || !o.isAlive() || o == a) continue;
                try { if (o.getName() == name) return o; } catch { }
            }
            return null;
        }

        private static int CountSins(Actor a, float r)
        {
            int n = 0;
            List<Actor> near = SDSUnit.Around(a, r);
            for (int i = 0; i < near.Count; i++)
            {
                Actor o = near[i];
                if (o != null && o.isAlive() && SDSUnit.IsSin(o)) n++;
            }
            return n;   // incluye a 'a' si es Pecado (esta en su propio radio)
        }
    }
}
