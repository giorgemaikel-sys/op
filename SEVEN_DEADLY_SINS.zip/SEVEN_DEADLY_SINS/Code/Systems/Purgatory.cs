using System.Collections.Generic;
using System.IO;
using HarmonyLib;
using UnityEngine;

namespace SevenDeadlySins
{
    /// El Purgatorio como MAPA APARTE.
    ///
    /// No es una region del mundo: es un segundo mundo entero. Entrar guarda Britannia en disco y
    /// carga el Purgatorio; salir hace lo contrario. Los dos reinos persisten entre saltos, asi que
    /// lo que dejes ardiendo en uno sigue ardiendo cuando vuelvas.
    ///
    /// DONDE SE GUARDA, Y POR QUE AHI. Los dos reinos viven en su propio directorio
    /// `<persistentDataPath>/sds_realms/`, JAMAS en `saves/`. El jugador tiene sesenta y una
    /// partidas ahi y este sistema escribe solo; una ruta mal construida se las lleva por delante.
    /// Guard() es la unica puerta de escritura y rechaza todo lo que no cuelgue de sds_realms.
    ///
    /// Que `saveWorldToDirectory` acepta una RUTA ABSOLUTA y no un nombre de slot esta comprobado
    /// en el juego, no supuesto: con el nombre pelado 'save1' devuelve cadena vacia, y con la ruta
    /// completa devuelve el `map.wbox` de dentro. La constante `saveslot_base` invita a pensar lo
    /// contrario y por eso se comprobo — equivocarse aqui no da un error, borra partidas.
    ///
    /// La existencia se comprueba a mano y no con `doesSaveExist`, porque esa devuelve False sobre
    /// partidas que existen de verdad. Comprobado tambien.
    ///
    /// LO QUE NO SOBREVIVE. Las unidades que mandas al Purgatorio se guardan en memoria, no en
    /// disco: si cierras el juego con gente al otro lado, se pierden. Serializarlas seria escribir
    /// un formato de guardado propio, y prefiero decirlo a fingir que no pasa.
    public static class Purgatory
    {
        /// El directorio propio es la unica linea entre este sistema y las partidas del jugador.
        private const string RealmsFolder = "sds_realms";

        private const string Overworld = "overworld";
        private const string Realm = "purgatory";

        private static bool _inPurgatory;

        /// Quien esta esperando a cruzar. Se materializan al entrar.
        private static readonly List<Traveller> _pending = new List<Traveller>();

        /// La ficha COMPLETA de una unidad que cruza. Antes solo llevaba nombre, raza, rasgos y los
        /// anos de Purgatorio — y al reconstruirse perdia sus KILLS y sus datos de forma hibrida,
        /// asi que un hibrido cruzado no podia despertar su forma (que se gana a golpe de kills).
        /// Ahora viaja todo lo que importa.
        private class Traveller
        {
            public string name;
            public string race;
            public List<string> traits = new List<string>();
            public float years;      // entrenamiento del Purgatorio
            public int kills;        // <- lo que se perdia y bloqueaba la forma hibrida
            public float hybStr, hybSpi, hybMag;   // poder heredado del hibrido
            public string formId;    // su forma hibrida con nombre
            public string hybClan;   // su clan hibrido (para conceder sus formas)
            public bool formPending;
            public int hybStage;     // etapa de forma ya despertada
            public int knightElem = -1, knightShape = -1;   // la habilidad unica de un caballero

            /// Copia de la unidad a la ficha, antes de destruirla.
            public void Capture(Actor a)
            {
                name = a.getName();
                race = a.asset != null ? a.asset.id : Actors.Human;
                years = SDSData.GetFloat(a, KeyYears, 0f);
                try { kills = a.data.kills; } catch { }
                hybStr = SDSData.GetFloat(a, Offspring.KeyHybStr, 0f);
                hybSpi = SDSData.GetFloat(a, Offspring.KeyHybSpi, 0f);
                hybMag = SDSData.GetFloat(a, Offspring.KeyHybMag, 0f);
                formId = SDSData.GetString(a, Offspring.KeyHybFormId, "");
                hybClan = SDSData.GetString(a, Offspring.KeyHybClan, "");
                formPending = SDSData.GetBool(a, Offspring.KeyHybFormPending);
                hybStage = SDSData.GetInt(a, Offspring.KeyHybStage, 0);
                if (a.hasTrait(KnightPowers.Trait))
                {
                    knightElem = SDSData.GetInt(a, KnightPowers.KeyElement, 0);
                    knightShape = SDSData.GetInt(a, KnightPowers.KeyShape, 0);
                }
                try
                {
                    foreach (string id in SDSRegistry.TraitIds)
                        if (a.hasTrait(id)) traits.Add(id);
                }
                catch { }
            }

            /// Vuelca la ficha sobre la unidad recien creada al otro lado.
            public void Restore(Actor a)
            {
                try { a.setName(name); } catch { }
                for (int k = 0; k < traits.Count; k++) SDSTraits.Give(a, traits[k]);
                if (years > 0f) SDSData.SetFloat(a, KeyYears, years);
                try { if (kills > 0) a.data.kills = kills; } catch { }
                if (hybStr != 0f) SDSData.SetFloat(a, Offspring.KeyHybStr, hybStr);
                if (hybSpi != 0f) SDSData.SetFloat(a, Offspring.KeyHybSpi, hybSpi);
                if (hybMag != 0f) SDSData.SetFloat(a, Offspring.KeyHybMag, hybMag);
                if (!string.IsNullOrEmpty(formId)) SDSData.SetString(a, Offspring.KeyHybFormId, formId);
                if (!string.IsNullOrEmpty(hybClan)) SDSData.SetString(a, Offspring.KeyHybClan, hybClan);
                if (formPending) SDSData.SetBool(a, Offspring.KeyHybFormPending, true);
                if (hybStage > 0) SDSData.SetInt(a, Offspring.KeyHybStage, hybStage);
                if (knightElem >= 0)
                {
                    SDSData.SetInt(a, KnightPowers.KeyElement, knightElem);
                    SDSData.SetInt(a, KnightPowers.KeyShape, knightShape);
                }
            }
        }

        /// Quien esta esperando a SALIR del Purgatorio. Se materializan en Britannia al volver.
        private static readonly List<Traveller> _extracting = new List<Traveller>();

        public static bool Inside { get { return _inPurgatory; } }

        /// ANOS que lleva esta unidad entrenando en el Purgatorio. Se guardan los anos y no el
        /// multiplicador para poder enseñarlos y para poder cambiar la curva sin romper partidas.
        private const string KeyYears = "sds_purgatory_years";

        /// Tope: x50 permanente. Suena bestia y lo es, y aun asi se queda MUY corto respecto a la
        /// serie — Meliodas pasa de 3.370 a 142.000 en Modo Asalto, que son mas de cuarenta veces,
        /// y el Rey Demonio anda por el millon. Un x4 en el sitio donde Ban se paso sesenta anos
        /// era ridiculo.
        private const float TrainingCap = 50f;

        /// Los sesenta anos de Ban valen x10. De ahi para arriba la curva sigue subiendo pero cada
        /// vez cuesta mas, que es como funciona entrenar: el salto grande es el primero.
        private const float BanYears = 60f;
        private const float BanMultiplier = 10f;

        /// El multiplicador permanente que le corresponde a estos anos dentro.
        ///
        /// Curva con exponente 0,7 en vez de lineal: 60 anos dan x10, 180 dan x20, 600 rozan el
        /// tope. Asi un minuto dentro ya cambia a la unidad de categoria, y quedarse siglos sigue
        /// mereciendo la pena sin que el numero se dispare al infinito.
        public static float MultiplierForYears(float years)
        {
            if (years <= 0f) return 1f;
            float m = 1f + (BanMultiplier - 1f) * Mathf.Pow(years / BanYears, 0.7f);
            return Mathf.Min(TrainingCap, m);
        }

        public static void Init()
        {
            // DOS cosas distintas, y las dos son canon.
            //
            // La primera es estar alli: el Purgatorio empuja a todo lo que pisa su suelo, y a los
            // demonios mucho mas, porque es su casa. Se pierde al salir.
            //
            // La segunda es haber peleado alli, y esa NO se pierde. Meliodas y Ban se pasaron
            // sesenta anos dentro cazando, y volvieron mas fuertes de lo que entraron; ese es el
            // sentido del sitio. Se acumula en la ficha de la unidad y se la lleva puesta a
            // Britannia — que es lo que hace que merezca la pena entrar.
            // Estar dentro. Subido de x1,35 a x3: el Purgatorio es el dominio del Rey Demonio, no
            // un bioma con mala prensa. Y a los suyos les multiplica por cinco, porque es su casa.
            PowerLevel.AddContributor("purgatory", a =>
            {
                if (!_inPurgatory) return 1f;
                return SDSUnit.IsDemon(a) ? 5f : 3f;
            });

            PowerLevel.AddContributor("purgatory_training", a =>
            {
                if (a == null || a.data == null) return 1f;
                return MultiplierForYears(SDSData.GetFloat(a, KeyYears, 0f));
            });

            SDSTick.Register(TickTraining);
            SDSTick.RegisterGlobal(TickArrivals);
            SDSTick.RegisterGlobal(TickProbe);

            // Cada partida su propio Purgatorio: al empezar un mundo nuevo, el de antes se borra.
            Main.harmony.PatchAll(typeof(NewWorldGuard));
        }

        /// UN PURGATORIO POR PARTIDA, y no el mismo para todas.
        ///
        /// El bug: el Purgatorio se guarda en una carpeta fija (`sds_realms/purgatory`), compartida
        /// por TODAS las partidas del jugador. Empezabas un mundo nuevo, entrabas, y te encontrabas
        /// el Purgatorio de la partida anterior — con sus demonios, su reloj y su antiguedad.
        ///
        /// El arreglo: cuando el JUEGO genera o carga un mundo (partida nueva, o cargar guardado),
        /// se resetea el Purgatorio — se borran los dos reinos y se olvida el estado. La proxima vez
        /// que entres, se genera uno limpio para ESTA partida. Mis propios saltos entre reinos van
        /// marcados con SelfInitiated, asi que no cuentan como partida nueva.
        internal static class NewWorldGuard
        {
            [HarmonyPatch(typeof(MapBox), nameof(MapBox.generateNewMap))]
            [HarmonyPostfix]
            public static void OnGenerate()
            {
                if (!SelfInitiated) ResetForNewWorld("mundo nuevo");
            }

            [HarmonyPatch(typeof(SaveManager), nameof(SaveManager.loadWorld), new[] { typeof(string), typeof(bool) })]
            [HarmonyPostfix]
            public static void OnLoad()
            {
                if (!SelfInitiated) ResetForNewWorld("partida cargada");
            }
        }

        /// Olvida el Purgatorio de la partida anterior y borra sus reinos del disco.
        private static void ResetForNewWorld(string reason)
        {
            _inPurgatory = false;
            _needsPopulating = false;
            _probed = false;
            _owedYears = 0f;
            _owedTold = 0.0;
            _restockIn = 0f;
            _pending.Clear();
            _extracting.Clear();
            PurgatoryTime.HardReset();

            try
            {
                if (Directory.Exists(PathOf(Realm))) Directory.Delete(PathOf(Realm), true);
                if (Directory.Exists(PathOf(Overworld))) Directory.Delete(PathOf(Overworld), true);
            }
            catch (System.Exception e) { SDSLog.Error("no se pudo limpiar el Purgatorio viejo: " + e.Message); }

            SDSLog.Info("purgatorio: reseteado para " + reason + " (cada partida el suyo)");
        }

        /// El entrenamiento del Purgatorio: sobrevivir suma, pelear suma el doble.
        ///
        /// Va atado al TIEMPO DILATADO, que es lo que le da sentido. Dentro corre un ano por
        /// segundo, asi que aguantar un minuto ahi son los sesenta anos que se paso Ban cazando — y
        /// se sale multiplicado por diez. Eso es lo que hace que entrar merezca la pena.
        ///
        /// Se cuenta por tiempo y no por muertes a proposito. Enganchar la muerte de una unidad
        /// pedia un parche de Harmony sobre el camino de morir, que es la forma mas rapida que hay
        /// de reventar una partida entera, y aqui no compensa: el resultado que se busca — el que
        /// aguanta ahi dentro sale hecho un monstruo — sale igual de bien contando el rato.
        private static void TickTraining(Actor a, float dt)
        {
            if (!_inPurgatory) return;
            if (a == null || !a.isAlive() || a.data == null) return;

            float years = SDSData.GetFloat(a, KeyYears, 0f);

            // Dentro pasa un ano por segundo real: ese es el ritmo que fija PurgatoryTime.
            float lived = dt * (PurgatoryTime.YearsPerMinute / 60f) * (a.has_attack_target ? 2f : 1f);
            AddYears(a, years, lived);
        }

        /// Suma anos de Purgatorio a una unidad y avisa cuando cambia de categoria.
        ///
        /// Publico porque lo usa tambien el cobro de la ausencia: las unidades que se quedaron
        /// dentro mientras el jugador estaba en Britannia han seguido entrenando igual.
        public static void AddYears(Actor a, float current, float extra)
        {
            if (a == null || a.data == null || extra <= 0f) return;

            float next = current + extra;
            SDSData.SetFloat(a, KeyYears, next);

            // Se avisa al cruzar cada multiplicador entero, no cada ano: con sesenta anos por
            // minuto, avisar por ano seria una tromba de texto ilegible.
            int before = Mathf.FloorToInt(MultiplierForYears(current));
            int after = Mathf.FloorToInt(MultiplierForYears(next));
            if (after <= before) return;

            // Solo el efecto visual. El aviso escrito se quito: al cobrar una ausencia se
            // endurecen decenas de unidades a la vez y era una tromba de texto que tapaba la
            // cronica entera. Se ve en el destello y en el panel de la unidad, que es donde toca.
            SDSFx.At(a, "sds_fx_demon_king", 0.5f);
        }

        /// Anos que lleva esta unidad dentro. Lo usa el panel de unidad.
        public static float YearsOf(Actor a)
        {
            if (a == null || a.data == null) return 0f;
            return SDSData.GetFloat(a, KeyYears, 0f);
        }

        private static bool _probed;

        /// Deja escrito en el log donde van a acabar los dos reinos, ANTES de escribir nada.
        ///
        /// Va en el tick y no en Init porque en Init no sirve de nada: al cargar los mods el juego
        /// todavia no ha puesto su ruta de guardado. Se queda en el mod despues de la puesta a punto
        /// porque si algun dia esto escribe donde no debe, el log dira donde antes de que se note.
        private static void TickProbe(float dt)
        {
            if (_probed) return;
            if (World.world == null) return;
            _probed = true;

            SDSLog.Info("purgatorio: reinos en " + RealmsDir
                        + " (britannia=" + Exists(Overworld)
                        + " purgatorio=" + Exists(Realm) + ")");

        }

        // ---------------------------------------------------------------- guardado

        private static string RealmsDir
        {
            get { return Path.Combine(Application.persistentDataPath, RealmsFolder); }
        }

        private static string PathOf(string realm)
        {
            return Path.Combine(RealmsDir, realm);
        }

        /// LA UNICA PUERTA DE ESCRITURA. Rechaza toda ruta que no cuelgue de sds_realms.
        ///
        /// Es paranoia deliberada, y barata: la comprobacion no cuesta nada y lo que protege son
        /// sesenta y una partidas. Se compara sobre la ruta ya normalizada para que un `..` de mas
        /// no pueda escaparse del directorio.
        private static bool Guard(string path)
        {
            if (string.IsNullOrEmpty(path)) return false;

            try
            {
                string full = Path.GetFullPath(path);
                string root = Path.GetFullPath(RealmsDir);

                if (!full.StartsWith(root, System.StringComparison.OrdinalIgnoreCase))
                {
                    SDSLog.Error("RUTA RECHAZADA, fuera de " + RealmsFolder + ": " + full);
                    return false;
                }
            }
            catch (System.Exception e)
            {
                SDSLog.Error("RUTA RECHAZADA, no se pudo normalizar: " + e.Message);
                return false;
            }

            return true;
        }

        /// A mano, y no con `doesSaveExist`: esa devuelve False sobre partidas que existen.
        private static bool Exists(string realm)
        {
            try { return File.Exists(Path.Combine(PathOf(realm), "map.wbox")); }
            catch { return false; }
        }

        private static bool Save(string realm)
        {
            string path = PathOf(realm);
            if (!Guard(path)) return false;

            try
            {
                Directory.CreateDirectory(path);
                SaveManager.saveWorldToDirectory(path, true, true);
                return true;
            }
            catch (System.Exception e)
            {
                SDSLog.Error("no se pudo guardar el reino '" + realm + "': " + e.Message);
                return false;
            }
        }

        /// Verdadero mientras SOY YO quien genera o carga un mundo (entrar/salir del Purgatorio).
        /// Los parches de mundo-nuevo lo miran para no confundir mis saltos con una partida nueva
        /// del jugador. Ver NewWorldGuard.
        internal static bool SelfInitiated;

        private static bool Load(string realm)
        {
            string path = PathOf(realm);
            if (!Guard(path)) return false;
            if (!Exists(realm)) return false;

            SaveManager manager = Manager();
            if (manager == null)
            {
                SDSLog.Error("no hay SaveManager en la escena; no se puede cargar");
                return false;
            }

            try
            {
                SelfInitiated = true;
                manager.loadWorld(path, false);
                return true;
            }
            catch (System.Exception e)
            {
                SDSLog.Error("no se pudo cargar el reino '" + realm + "': " + e.Message);
                return false;
            }
            finally { SelfInitiated = false; }
        }

        /// loadWorld es de instancia y nadie guarda una referencia estatica, asi que hay que
        /// pescarla de la escena. Se busca cada vez porque al cargar un mapa el objeto puede
        /// cambiar, y cachearlo daria una referencia muerta justo en la operacion mas destructiva.
        private static SaveManager Manager()
        {
            try { return Object.FindObjectOfType<SaveManager>(); }
            catch { return null; }
        }

        // ---------------------------------------------------------------- entrar y salir

        /// Britannia se guarda, el Purgatorio se carga. La primera vez se genera.
        public static bool Enter(WorldTile ignored)
        {
            if (_inPurgatory)
            {
                SDSLog.Tip(SDSLocale.T("Ya estas en el Purgatorio", "You are already in Purgatory"));
                return false;
            }

            if (!Save(Overworld))
            {
                SDSLog.Tip(SDSLocale.T("No se pudo guardar Britannia; no se entra",
                                       "Britannia could not be saved; not entering"));
                return false;
            }

            if (Exists(Realm))
            {
                if (!Load(Realm)) return false;
            }
            else
            {
                // Primera visita: hay que crearlo. SelfInitiated para que el parche de mundo-nuevo
                // no confunda esta generacion con una partida nueva del jugador.
                try
                {
                    SelfInitiated = true;
                    MapBox.instance.generateNewMap();
                }
                catch (System.Exception e)
                {
                    SDSLog.Error("no se pudo generar el Purgatorio: " + e.Message);
                    Load(Overworld);        // no dejar al jugador en la nada
                    return false;
                }
                finally { SelfInitiated = false; }
                _needsPopulating = true;
            }

            _inPurgatory = true;

            // Lo que corrio sin ti. Se apunta ahora y se cobra en el tick, cuando el reino cargado
            // ya tenga sus unidades montadas. En una primera visita no hay nada que cobrar.
            _owedYears = _needsPopulating ? 0f : PurgatoryTime.OwedYearsApplied;
            _owedTold = _needsPopulating ? 0.0 : PurgatoryTime.OwedYears;
            PurgatoryTime.ClearOwed();

            PurgatoryTime.Reset();
            PurgatoryTime.ResetAnnounce();

            SDSLog.Chronicle(SDSLocale.T(
                "Has cruzado al Purgatorio.", "You have crossed into Purgatory."));
            return true;
        }

        /// El Purgatorio se guarda tal y como lo dejas, y vuelves a Britannia.
        public static bool Exit(WorldTile ignored)
        {
            if (!_inPurgatory)
            {
                SDSLog.Tip(SDSLocale.T("No estas en el Purgatorio", "You are not in Purgatory"));
                return false;
            }

            // Salir a mitad de la carga guardaria un mundo incompleto encima del Purgatorio bueno.
            // Es la misma asincronia que arruinaba el moldeado, y aqui costaria un reino entero.
            if (SmoothLoader.isLoading())
            {
                SDSLog.Tip(SDSLocale.T("El Purgatorio aun se esta formando; espera",
                                       "Purgatory is still forming; wait"));
                return false;
            }

            Save(Realm);

            if (!Load(Overworld))
            {
                SDSLog.Tip(SDSLocale.T("No se encontro Britannia guardada",
                                       "No saved Britannia was found"));
                return false;
            }

            _inPurgatory = false;

            PurgatoryTime.Reset();
            PurgatoryTime.ResetAnnounce();

            SDSLog.Chronicle(SDSLocale.T(
                "Has vuelto de el Purgatorio.", "You have returned from Purgatory."));
            return true;
        }

        // ---------------------------------------------------------------- cruzar unidades

        /// Marca a la unidad para que aparezca en el Purgatorio la proxima vez que entres.
        ///
        /// La unidad se retira de ESTE mundo y se guarda su ficha — nombre, raza y rasgos. No se
        /// mueve un objeto de un mundo a otro porque no se puede: al cargar el otro mapa, este deja
        /// de existir. Lo que cruza es la descripcion, y al llegar se reconstruye.
        public static bool SendUnit(WorldTile tile)
        {
            Actor a = SDSUnit.At(tile);
            if (a == null)
            {
                SDSLog.Tip(SDSLocale.T("Nadie ahi a quien mandar", "Nobody there to send"));
                return false;
            }

            Traveller t = new Traveller();
            t.Capture(a);        // TODO: kills, forma hibrida, habilidad de caballero, no solo rasgos
            _pending.Add(t);

            SDSFx.At(a, "sds_fx_demon_king", 0.7f);
            try { a.die(true, AttackType.Other, false, false); }
            catch { }

            SDSLog.Tip(SDSLocale.T(
                t.name + " ha sido enviado al Purgatorio",
                t.name + " has been sent to Purgatory"));
            return true;
        }

        /// Reconstruye en Britannia a los que sacaste, una vez el mundo ha cargado del todo.
        ///
        /// Mismo cuidado que al entrar: no se toca hasta que SmoothLoader termina, porque cargar el
        /// mundo de vuelta tampoco es instantaneo y soltar unidades sobre un mapa a medias es el
        /// fallo que mas caro ha salido en este sistema.
        private static void DeliverExtracted()
        {
            if (_extracting.Count == 0) return;
            if (World.world == null || MapBox.instance == null) return;
            try { if (SmoothLoader.isLoading()) return; } catch { return; }

            List<Traveller> failed = new List<Traveller>();

            for (int i = 0; i < _extracting.Count; i++)
            {
                Traveller t = _extracting[i];

                WorldTile spot = null;
                try { spot = World.world.GetTile(MapBox.width / 2, MapBox.height / 2); }
                catch { }
                if (spot == null) { failed.Add(t); continue; }

                string race = t.race;
                if (AssetManager.actor_library.get(race) == null) race = Actors.Human;

                Actor born = null;
                try
                {
                    born = World.world.units.spawnNewUnit(race, spot,
                        pSpawnSound: true, pMiracleSpawn: true, pSpawnHeight: 4f,
                        pSubspecies: null, pGiveOwnerlessItems: false, pAdultAge: true);
                }
                catch { }
                if (born == null) { failed.Add(t); continue; }

                // TODO se vuelca: nombre, rasgos, kills, forma hibrida, poder, habilidad. Ya no
                // pierde nada al salir.
                t.Restore(born);

                SDSFx.At(born, "sds_fx_flash", 0.6f);
                SDSLog.Chronicle(SDSLocale.T(
                    t.name + " ha regresado del Purgatorio.",
                    t.name + " has returned from Purgatory."));
            }

            _extracting.Clear();
            _extracting.AddRange(failed);
        }

        /// Marca a la unidad para SACARLA del Purgatorio la proxima vez que salgas.
        ///
        /// Es el espejo exacto de SendUnit: se retira de este mundo, se guarda su ficha — y con
        /// ella los anos de entrenamiento que lleve ganados — y se reconstruye en Britannia al
        /// cruzar de vuelta. Asi es como sacas de aqui a alguien que ha salido convertido en un
        /// monstruo, con su poder puesto.
        public static bool ExtractUnit(WorldTile tile)
        {
            if (!_inPurgatory)
            {
                SDSLog.Tip(SDSLocale.T("Solo puedes sacar unidades estando dentro",
                                       "You can only pull units out from inside"));
                return false;
            }

            Actor a = SDSUnit.At(tile);
            if (a == null)
            {
                SDSLog.Tip(SDSLocale.T("Nadie ahi a quien sacar", "Nobody there to pull out"));
                return false;
            }

            Traveller t = new Traveller();
            t.Capture(a);        // TODO viaja: kills, forma hibrida, poder, habilidad de caballero
            _extracting.Add(t);

            SDSFx.At(a, "sds_fx_flash", 0.7f);
            try { a.die(true, AttackType.Other, false, false); }
            catch { }

            SDSLog.Tip(SDSLocale.T(
                t.name + " saldra del Purgatorio contigo",
                t.name + " will leave Purgatory with you"));
            return true;
        }

        private static bool _needsPopulating;
        private static float _restockIn;

        /// Cuantos nativos deberia haber sueltos. El Purgatorio no se vacia jamas: esa es su gracia.
        private const int Population = 70;

        /// La fauna, de mas comun a mas rara. El orden importa: es la jerarquia del Clan de los
        /// Demonios tal cual, con las alimanas abajo y Albion e Indura como algo que no se ve todos
        /// los dias. Las Emociones Perdidas son raras a proposito — hay siete, no setenta.
        private static readonly string[] Fauna =
        {
            Actors.PurgatoryBeast, Actors.PurgatoryBeast, Actors.PurgatoryBeast,
            Actors.PurgatoryBeast, Actors.PurgatoryBeast,
            Actors.GrayDemon, Actors.GrayDemon, Actors.GrayDemon,
            Actors.RedDemon, Actors.RedDemon,
            Actors.BlueDemon,
            Actors.LostEmotion,
            Actors.Indura,
            Actors.Albion,
        };

        /// Los nombres de las siete emociones que le arrancaron a Meliodas.
        ///
        /// En la serie sus emociones acabaron con cuerpo propio aqui dentro, y el y Ban se pasaron
        /// sesenta anos cazandolas para recuperarlas. El cuerpo es el mismo para las siete porque
        /// una criatura por emocion serian siete juegos de sprites para decir lo que dice el nombre.
        private static readonly string[] Emotions =
        {
            "Alegria Perdida", "Tristeza Perdida", "Miedo Perdido", "Amor Perdido",
            "Furia Perdida", "Piedad Perdida", "Esperanza Perdida",
        };

        /// Materializa a los que cruzaron, moldea el terreno y mantiene viva a la fauna.
        ///
        /// Va en el tick global y no dentro de Enter porque al cargar un mapa el mundo tarda unos
        /// frames en estar listo: invocar dentro de la misma llamada deja unidades en un mundo a
        /// medio construir.
        private static void TickArrivals(float dt)
        {
            // FUERA del Purgatorio: lo unico que corre es sacar a los que trajiste contigo.
            if (!_inPurgatory)
            {
                DeliverExtracted();
                return;
            }

            if (World.world == null || MapBox.instance == null) return;

            // ESPERAR A QUE EL MUNDO ESTE DEL TODO HECHO, para las DOS ramas.
            //
            // Ni `generateNewMap` ni `loadWorld` terminan cuando devuelven el control: encolan una
            // veintena de pasos en SmoothLoader. Esta guarda estaba solo en la rama de primera
            // visita, y por eso el cobro de la ausencia daba "0 unidades endurecidas" — corria
            // sobre un reino a medio cargar, cuando la lista de unidades todavia esta vacia. Es la
            // tercera vez que esta asincronia me muerde en este mismo sistema.
            if (SmoothLoader.isLoading()) return;

            if (_needsPopulating)
            {
                // "¿Ya hay una casilla de tierra?" NO vale como senal de fin de generacion: eso se
                // cumple hacia el paso ocho de veinte, y despues todavia corren doce pasadas de
                // vegetacion, los biomas y la limpieza — todas encima del Purgatorio ya esculpido.
                if (LandTile() == null) return;

                if (!PurgatoryLand.ShapeAll()) return;

                _needsPopulating = false;
                _restockIn = 2f;
                Seed();
            }
            else if (_owedYears > 0f)
            {
                // Y ademas, que las unidades esten de verdad montadas. Cargar termina antes de que
                // la lista este llena, asi que se espera a ver a alguien antes de cobrar.
                List<Actor> loaded = null;
                try { loaded = MapBox.instance.units.getSimpleList(); }
                catch { }
                if (loaded == null || loaded.Count == 0) return;

                CollectAbsence();
            }

            Arrivals();

            _restockIn -= dt;
            if (_restockIn > 0f) return;
            _restockIn = 6f;

            // Los jefes, diferidos desde Seed hasta ahora que el mundo ya acepta spawns de nombre.
            if (_needsBosses) SpawnBosses();

            Restock();
        }

        /// Anos que se APLICAN al mapa (acotados) y anos que se CUENTAN (los de verdad).
        private static float _owedYears;
        private static double _owedTold;

        /// Cuanto se le adelanta al reloj DE VERDAD al cobrar una ausencia. Mata mortales, no
        /// demonios. Ver CollectAbsence: sin este tope, un salto de millones de anos borra el reino.
        private const float AgeJumpYears = 500f;

        /// Cobra el tiempo que paso mientras estabas en Britannia.
        ///
        /// WorldBox corre un solo mundo, asi que el Purgatorio no puede simularse de verdad en
        /// segundo plano. Lo que se hace es contar el rato fuera y aplicarlo entero al cruzar: el
        /// reloj salta, los que se quedaron dentro han seguido entrenando todos esos anos, y la
        /// fauna se repone. El efecto es el que se pedia — te vas, vuelves, y aquello ha cambiado.
        private static void CollectAbsence()
        {
            // Dos numeros distintos y los dos hacen falta.
            //
            // `trainingYears` esta acotado, pero da igual: la curva de MultiplierForYears ya llega
            // a su tope por los seiscientos anos, asi que pasar de ahi no cambia nada de poder.
            //
            // `realYears` es lo que ha pasado DE VERDAD, y es el que va al reloj. Antes se usaba el
            // acotado tambien aqui, y por eso la edad subia una miseria comparada con los cientos de
            // miles de anos que se contaban.
            float trainingYears = _owedYears;
            double realYears = _owedTold;
            _owedYears = 0f;

            // PRIMERO el entrenamiento, DESPUES la vejez. El orden importa: adelantar el reloj mata
            // de viejo a los mortales, y si se hiciera antes, los que mueren no llegarian a apuntar
            // en su ficha los siglos que aguantaron. Asi el poder queda grabado aunque el cuerpo no
            // aguante — y quien sobreviva lo saca de alli.
            int hardened = 0;
            try
            {
                List<Actor> all = MapBox.instance.units.getSimpleList();
                for (int i = 0; i < all.Count; i++)
                {
                    Actor a = all[i];
                    if (a == null || !a.isAlive() || a.data == null) continue;

                    // TODO lo que respira ahi dentro, no solo la gente. Antes esto exigia
                    // `IsSentient` y el resultado era ridiculo: el Purgatorio esta poblado por
                    // bestias, asi que de setenta y pico habitantes se entrenaba UNO. Las alimanas
                    // que llevan medio millon de anos peleando ahi son justo las que tienen que dar
                    // miedo.
                    AddYears(a, SDSData.GetFloat(a, KeyYears, 0f), trainingYears);
                    hardened++;
                }
            }
            catch { }

            // EL RELOJ SALTA, PERO ACOTADO. Aqui estaba el peor bug del Purgatorio.
            //
            // La edad de una unidad se deduce del reloj (`Date.getYearsSince(created_time)`), asi que
            // adelantar el reloj envejece a todo lo de dentro. Estaba metiendo los QUINCE MILLONES de
            // anos completos, y eso no "envejece": aniquila. Hasta el Rey Demonio, con su vida x20,
            // moria de vejez al instante, y entrabas al Purgatorio a un cementerio.
            //
            // Se acota a AgeJumpYears. Es suficiente para lo que se busca — un mortal (vida ~80) que
            // se quedo dentro no sobrevive, pero un demonio (vida x20..x60, o sea miles de anos) si.
            // El numero enorme se sigue CONTANDO para la cronica; lo que se APLICA es esto.
            float aged = Mathf.Min((float)realYears, AgeJumpYears);
            try { MapBox.instance.map_stats.updateWorldTime(aged * PurgatoryTime.YearInWorldTime); }
            catch { }

            // El Purgatorio no se queda sin dueno. Si el Rey Demonio murio de viejo durante la
            // ausencia se vuelve a poner: el ES el Purgatorio, no un inquilino.
            EnsureKing();

            _restockIn = 1f;

            _owedTold = 0.0;

            // El jugador no quiere el aviso de cuantos anos han pasado. Se sigue apuntando en el
            // log tecnico, que es donde sirve para depurar, y no en la cronica del juego.

            SDSLog.Info("purgatorio: ausencia cobrada, " + realYears.ToString("N0")
                        + " anos al reloj, " + Mathf.FloorToInt(trainingYears)
                        + " de entrenamiento, " + hardened + " unidades endurecidas");
        }

        /// Se asegura de que el Rey Demonio siga ahi.
        private static void EnsureKing()
        {
            try
            {
                List<Actor> all = MapBox.instance.units.getSimpleList();
                for (int i = 0; i < all.Count; i++)
                {
                    Actor a = all[i];
                    if (a != null && a.isAlive() && a.hasTrait(DemonKing.TraitKing)) return;
                }
            }
            catch { return; }

            WorldTile spot = LandTile();
            if (spot == null) return;

            Actor king = Legends.Spawn("demon_king", spot);
            if (king == null) return;

            SDSFx.At(king, "sds_fx_demon_king", 1f);
            SDSLog.Chronicle(SDSLocale.T(
                "El Rey Demonio vuelve a alzarse en el Purgatorio.",
                "The Demon King rises again in Purgatory."));
        }

        /// Lo que hay el primer dia: los amos del Purgatorio.
        private static void Seed()
        {
            WorldTile spot = LandTile();
            if (spot == null)
            {
                // Pasa de verdad, y adivinar por que ya costo dos rondas. Que el mapa diga que es.
                try
                {
                    System.Text.StringBuilder sb = new System.Text.StringBuilder();
                    for (int i = 0; i < 12; i++)
                    {
                        WorldTile t = World.world.GetTile(Random.Range(2, MapBox.width - 2),
                                                          Random.Range(2, MapBox.height - 2));
                        sb.Append(t == null || t.main_type == null ? "?" : t.main_type.id).Append(' ');
                    }
                    SDSLog.Error("purgatorio: sin tierra firme. muestra del mapa: " + sb);
                }
                catch { }
                return;
            }

            // Los jefes NO se invocan aqui, y esa era la causa de "rey demonio=False": Seed corre en
            // el MISMO instante en que se termina de moldear el terreno, y el mundo todavia no
            // acepta el spawn de un personaje con nombre (mas pesado que una bestia). La fauna sale
            // porque su restock va con unos segundos de retraso; los jefes se difieren igual.
            _needsBosses = true;

            SDSLog.Chronicle(SDSLocale.T(
                "El Purgatorio despierta.", "Purgatory stirs."));
        }

        private static bool _needsBosses;

        /// Invoca al Rey Demonio y a sus dos maestros, ya con el mundo asentado. Se llama desde el
        /// ciclo de restock (con retraso), no desde Seed, por lo dicho arriba.
        private static void SpawnBosses()
        {
            _needsBosses = false;

            WorldTile spot = LandTile();
            if (spot == null) { _needsBosses = true; return; }   // reintenta a la siguiente vuelta

            Actor king = Legends.Spawn("demon_king", spot);
            Legends.Spawn("chandler", LandTile() ?? spot);
            Legends.Spawn("cusack", LandTile() ?? spot);

            SDSLog.Info("purgatorio: jefes invocados, rey demonio=" + (king != null));

            if (king != null)
            {
                SDSFx.At(king, "sds_fx_demon_king", 1f);
                SDSLog.Chronicle(SDSLocale.T(
                    "Su dueno esta en casa.", "Its master is home."));
            }
            else _needsBosses = true;     // no salio: se reintenta
        }

        /// Repone la fauna hasta el objetivo. Se cuenta de verdad en vez de soltar bichos a ciegas:
        /// un goteo constante sin techo llena el mapa y funde el rendimiento en diez minutos.
        private static void Restock()
        {
            List<Actor> all = null;
            try { all = MapBox.instance.units.getSimpleList(); }
            catch { }
            if (all == null) return;

            int natives = 0;
            for (int i = 0; i < all.Count; i++)
            {
                Actor a = all[i];
                if (a == null || !a.isAlive() || a.asset == null) continue;
                if (IsFauna(a.asset.id)) natives++;
            }

            int missing = Population - natives;
            if (missing <= 0) return;

            // Como mucho un punado por tanda: de golpe daria un tiron y un muro de bichos.
            int batch = Mathf.Min(missing, 6);
            for (int i = 0; i < batch; i++) SpawnNative();
        }

        private static bool IsFauna(string id)
        {
            for (int i = 0; i < Fauna.Length; i++) if (Fauna[i] == id) return true;
            return false;
        }

        private static void SpawnNative()
        {
            WorldTile spot = LandTile();
            if (spot == null) return;

            string what = Fauna[Random.Range(0, Fauna.Length)];
            if (AssetManager.actor_library.get(what) == null) return;

            Actor born = null;
            try
            {
                // `pAdultAge` para que no nazcan crias. Las bestias no tienen forma de cria — ver
                // Actors.Beast_ — y ademas una alimana bebe en el Purgatorio no tiene ningun
                // sentido: aqui no se cria nada, se sobrevive.
                born = World.world.units.spawnNewUnit(what, spot,
                    pSpawnSound: false, pMiracleSpawn: false, pSpawnHeight: 2f,
                    pSubspecies: null, pGiveOwnerlessItems: false, pAdultAge: true);
            }
            catch { }
            if (born == null) return;

            // Lo que nace en el Purgatorio nace ya curtido por el.
            //
            // Sin esto el sitio nunca se volvia mas peligroso: la fauna muere y se repone, asi que
            // los siglos que acumulaba el reino se perdian con cada relevo y las criaturas nuevas
            // salian recien hechas. Ahora heredan una parte de lo que lleva corrido el Purgatorio,
            // asi que volver dentro de medio millon de anos es volver a otro sitio.
            // Se escribe directo y no por AddYears: esa anuncia en la cronica, y con seis criaturas
            // cada seis segundos seria una tromba de texto que tapa todo lo demas.
            float inherited = Mathf.Min(600f, (float)(PurgatoryTime.PurgatoryYear / 1000.0));
            if (inherited >= 1f) SDSData.SetFloat(born, KeyYears, inherited);

            if (what == Actors.LostEmotion)
            {
                // Cada emocion lleva su nombre; el cuerpo es el mismo pero la criatura no.
                try { born.setName(Emotions[Random.Range(0, Emotions.Length)]); }
                catch { }
                SDSFx.At(born, "sds_fx_soul", 0.5f);
            }
            else
            {
                Actors.NameUnit(born, what);
            }
        }

        /// Una casilla de tierra firme donde se pueda dejar algo con vida.
        ///
        /// Se sortea y se comprueba en vez de recorrer el mapa: con el suelo del Purgatorio ya
        /// hecho, la enorme mayoria de casillas valen, asi que unos pocos intentos bastan y cuestan
        /// muchisimo menos que barrer cientos de miles de casillas cada seis segundos.
        private static WorldTile LandTile()
        {
            if (MapBox.instance == null) return null;

            for (int attempt = 0; attempt < 40; attempt++)
            {
                WorldTile t = null;
                try { t = World.world.GetTile(Random.Range(2, MapBox.width - 2),
                                              Random.Range(2, MapBox.height - 2)); }
                catch { }

                if (t == null || t.main_type == null) continue;
                if (t.main_type.liquid || t.main_type.ocean) continue;
                if (t.main_type.id != null && t.main_type.id.StartsWith("lava")) continue;

                return t;
            }
            return null;
        }

        /// Los que mandaste desde Britannia, ya con el suelo hecho bajo los pies.
        private static void Arrivals()
        {
            if (_pending.Count == 0) return;

            // Los que no consigan cuerpo se vuelven a la cola. Antes se limpiaba la lista entera al
            // final pasara lo que pasara, asi que una unidad que fallara al aparecer se perdia para
            // siempre — el jugador la mandaba al Purgatorio y no llegaba nunca.
            List<Traveller> failed = new List<Traveller>();

            for (int i = 0; i < _pending.Count; i++)
            {
                Traveller t = _pending[i];

                WorldTile spot = LandTile();
                if (spot == null) { failed.Add(t); continue; }

                string race = t.race;
                if (AssetManager.actor_library.get(race) == null) race = Actors.Human;

                Actor born = null;
                try
                {
                    born = World.world.units.spawnNewUnit(race, spot,
                        pSpawnSound: true, pMiracleSpawn: true, pSpawnHeight: 4f,
                        pSubspecies: null, pGiveOwnerlessItems: false, pAdultAge: true);
                }
                catch { }
                if (born == null) { failed.Add(t); continue; }

                // TODO se vuelca: kills, forma hibrida, poder, habilidad. Un hibrido que mandas al
                // Purgatorio ya no pierde sus kills, asi que puede seguir sumando hacia su forma.
                t.Restore(born);

                SDSFx.At(born, "sds_fx_hellblaze", 0.6f);
            }

            _pending.Clear();
            _pending.AddRange(failed);
        }
    }
}
