using System.Collections.Generic;
using UnityEngine;

namespace SevenDeadlySins
{
    /// Una habilidad DISTINTA para cada Caballero Sagrado.
    ///
    /// El usuario lo dejo claro: si hay cien caballeros, quiere cien habilidades distintas — no que
    /// se repartan siete y se repitan. Cien habilidades escritas a mano no existen, asi que se
    /// generan: cada caballero recibe una combinacion de ELEMENTO x FORMA, y hay diez elementos por
    /// diez formas = cien combinaciones. Dos caballeros con el mismo par son rarisimos, y aun asi
    /// sus numeros salen de su propio Nivel de Poder, asi que ni esos pelean igual.
    ///
    /// El ELEMENTO decide con que dana (tipo, estado, color). La FORMA decide a quien y como (a uno,
    /// en area, al mas lejano, a si mismo, a los suyos...). El caballero guarda su par en la ficha,
    /// asi que su habilidad es la misma toda su vida, la suya.
    public static class KnightPowers
    {
        public const string Trait = "sds_knight_power";

        // Publicas para que el Purgatorio las conserve al cruzar una unidad (ver Purgatory).
        public const string KeyElement = "sds_knight_elem";
        public const string KeyShape = "sds_knight_shape";

        // ---------------------------------------------------------------- elementos

        private class Element
        {
            public string es, en, fx, status; public AttackType type; public float statusTime;
            public Element(string es, string en, string fx, AttackType type, string status = null, float statusTime = 0f)
            { this.es = es; this.en = en; this.fx = fx; this.type = type; this.status = status; this.statusTime = statusTime; }
        }

        private static readonly Element[] Elements =
        {
            new Element("Rayo", "Lightning", "sds_fx_flash", AttackType.Other),
            new Element("Fuego", "Fire", "sds_fx_sunshine", AttackType.Fire, "sds_status_hellblaze", 6f),
            new Element("Hielo", "Ice", "sds_fx_ocean", AttackType.Other, Curses.Paralyzed, 3f),
            new Element("Viento", "Wind", "sds_fx_tornado", AttackType.Other),
            new Element("Tierra", "Earth", "sds_fx_creation", AttackType.Other, Curses.Ash, 6f),
            new Element("Luz", "Light", "sds_fx_ark", AttackType.Fire),
            new Element("Oscuridad", "Darkness", "sds_fx_hellblaze", AttackType.Other, "sds_status_hellblaze", 8f),
            new Element("Veneno", "Poison", "sds_fx_soul", AttackType.Other, "sds_status_hellblaze", 10f),
            new Element("Sangre", "Blood", "sds_fx_snatch", AttackType.Other),      // roba vida (shape lo aplica)
            new Element("Acero", "Steel", "sds_fx_creation", AttackType.Other, Curses.Ash, 5f),
        };

        // ---------------------------------------------------------------- formas

        private enum Shape { Bolt, Nova, Beam, Chain, Hex, Guard, Rush, Rally, Quake, Snipe }

        private static readonly string[] ShapeEs =
        { "Descarga", "Estallido", "Rayo Directo", "Cadena", "Maldicion", "Guardia", "Embate", "Aliento", "Sacudida", "Precision" };
        private static readonly string[] ShapeEn =
        { "Bolt", "Burst", "Beam", "Chain", "Hex", "Guard", "Charge", "Rally", "Quake", "Snipe" };

        public static void Init()
        {
            Ability();
            SDSTick.Register(Tick);
        }

        private static void Ability()
        {
            if (AssetManager.traits.dict.ContainsKey(Trait)) return;

            ActorTrait t = SDSRegistry.Trait(Trait, TraitGroups.KnightMagic, "ui/icons/sds_knight_power");
            t.type = TraitType.Positive;
            PowerLevel.Grant(t, 60f, 40f, 120f);
            SDSRegistry.AddTrait(t);
            SDSLocale.Trait(Trait, "Magia de Caballero",
                "La magia propia de este Caballero Sagrado. No hay dos iguales.");
        }

        /// Le asigna su combinacion unica a un caballero, una sola vez. La llama HolyKnights al
        /// ascender a Caballero Sagrado.
        public static void Assign(Actor a)
        {
            if (a == null || a.data == null) return;
            if (a.hasTrait(Trait)) return;      // ya tiene la suya

            SDSData.SetInt(a, KeyElement, Randy.randomInt(0, Elements.Length));
            SDSData.SetInt(a, KeyShape, Randy.randomInt(0, ShapeEs.Length));
            SDSTraits.Give(a, Trait);
        }

        /// El nombre de la habilidad de este caballero, para el panel de unidad. "Descarga de Rayo".
        public static string NameOf(Actor a)
        {
            if (a == null || a.data == null || !a.hasTrait(Trait)) return null;
            int e = Mathf.Clamp(SDSData.GetInt(a, KeyElement, 0), 0, Elements.Length - 1);
            int s = Mathf.Clamp(SDSData.GetInt(a, KeyShape, 0), 0, ShapeEs.Length - 1);
            bool en = SDSLocale.English;
            return (en ? ShapeEn[s] + " of " + Elements[e].en : ShapeEs[s] + " de " + Elements[e].es);
        }

        // ---------------------------------------------------------------- comportamiento

        private static float CD(float s) { return SDSConfig.AbilityCooldowns ? s : 0.3f; }

        private static void Tick(Actor a, float dt)
        {
            if (a == null || !a.isAlive() || a.data == null) return;
            if (!a.hasTrait(Trait)) return;
            if (Curses.Incapacitated(a)) return;
            if (!SDSData.TryUse(a, "knight_power", CD(6f))) return;

            int ei = Mathf.Clamp(SDSData.GetInt(a, KeyElement, 0), 0, Elements.Length - 1);
            int si = Mathf.Clamp(SDSData.GetInt(a, KeyShape, 0), 0, ShapeEs.Length - 1);
            Element e = Elements[ei];
            float power = 10f + PowerLevel.Magic(a) * 0.05f;

            switch ((Shape)si)
            {
                case Shape.Guard:  DoGuard(a, e); break;
                case Shape.Rush:   DoRush(a, e, power); break;
                case Shape.Rally:  DoRally(a, e); break;
                case Shape.Nova:   DoArea(a, e, power, 5f); break;
                case Shape.Quake:  DoArea(a, e, power * 1.3f, 7f); break;
                case Shape.Chain:  DoChain(a, e, power, 3); break;
                case Shape.Hex:    DoHex(a, e, power); break;
                case Shape.Beam:   DoFarthest(a, e, power * 1.4f, 16f); break;
                case Shape.Snipe:  DoFarthest(a, e, power * 1.8f, 20f); break;
                default:           DoBolt(a, e, power, 12f); break;   // Bolt
            }
        }

        private static void Apply(Actor a, Actor o, Element e, float dmg)
        {
            try { o.getHit(dmg, true, e.type, a, true); } catch { return; }
            if (e.status != null) SDSStatus.Inflict(o, e.status, e.statusTime);
            if (e.fx == "sds_fx_snatch")   // Sangre: roba vida
            {
                try { a.restoreHealth(Mathf.Max(1, Mathf.RoundToInt(dmg * 0.5f))); } catch { }
            }
        }

        private static Actor Enemy(Actor a, float r)
        {
            List<Actor> near = SDSUnit.Around(a, r);
            for (int i = 0; i < near.Count; i++)
                if (near[i] != null && near[i].isAlive() && Clans.Hostile(a, near[i])) return near[i];
            return null;
        }

        private static void DoBolt(Actor a, Element e, float dmg, float r)
        {
            Actor t = Enemy(a, r); if (t == null) return;
            SDSFx.Projectile(a, t, Projectiles.Magic);
            Apply(a, t, e, dmg);
            SDSFx.At(t, e.fx, 0.45f);
        }

        private static void DoFarthest(Actor a, Element e, float dmg, float r)
        {
            List<Actor> near = SDSUnit.Around(a, r);
            Actor far = null;
            for (int i = 0; i < near.Count; i++)
                if (near[i] != null && near[i].isAlive() && Clans.Hostile(a, near[i])) far = near[i];
            if (far == null) return;
            Apply(a, far, e, dmg);
            SDSFx.At(far, e.fx, 0.5f);
        }

        private static void DoArea(Actor a, Element e, float dmg, float r)
        {
            List<Actor> near = SDSUnit.Around(a, r);
            bool used = false;
            for (int i = 0; i < near.Count; i++)
            {
                Actor o = near[i];
                if (o == null || !o.isAlive() || o == a || !Clans.Hostile(a, o)) continue;
                Apply(a, o, e, dmg); used = true;
            }
            if (used) { SDSFx.At(a, e.fx, 0.6f); SDSFx.Wave(a, 2.5f, 1.5f); }
        }

        private static void DoChain(Actor a, Element e, float dmg, int max)
        {
            List<Actor> near = SDSUnit.Around(a, 12f);
            int hit = 0;
            for (int i = 0; i < near.Count && hit < max; i++)
            {
                Actor o = near[i];
                if (o == null || !o.isAlive() || o == a || !Clans.Hostile(a, o)) continue;
                Apply(a, o, e, dmg); SDSFx.At(o, e.fx, 0.4f); hit++;
            }
        }

        private static void DoHex(Actor a, Element e, float dmg)
        {
            Actor t = Enemy(a, 10f); if (t == null) return;
            Apply(a, t, e, dmg * 0.5f);
            if (e.status != null) SDSStatus.Inflict(t, e.status, e.statusTime + 3f);
            SDSFx.At(t, e.fx, 0.5f);
        }

        private static void DoGuard(Actor a, Element e)
        {
            SDSStatus.Inflict(a, MagicTypes.StatusReinforced, 8f);
            SDSFx.At(a, e.fx, 0.5f);
        }

        private static void DoRush(Actor a, Element e, float dmg)
        {
            SDSStatus.Inflict(a, RaceMagic.StatusHaste, 6f);
            Actor t = Enemy(a, 6f);
            if (t != null) { Apply(a, t, e, dmg * 1.2f); SDSFx.At(t, e.fx, 0.5f); }
            else SDSFx.At(a, e.fx, 0.4f);
        }

        private static void DoRally(Actor a, Element e)
        {
            List<Actor> near = SDSUnit.Around(a, 6f);
            bool used = false;
            for (int i = 0; i < near.Count; i++)
            {
                Actor o = near[i];
                if (!SDSUnit.IsAlly(a, o)) continue;
                if (o.data != null && o.data.health < o.getMaxHealth())
                {
                    try { o.restoreHealth(Mathf.Max(1, Mathf.RoundToInt(8f + PowerLevel.Magic(a) * 0.04f))); used = true; }
                    catch { }
                }
            }
            if (used) SDSFx.At(a, "sds_fx_ark", 0.5f);
        }
    }
}
