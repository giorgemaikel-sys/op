using System.Collections.Generic;
using UnityEngine;

namespace SevenDeadlySins
{
    /// The abilities an ORDINARY magic user can learn.
    ///
    /// These exist because the magic ladder was handing out the wrong things. It used to unlock
    /// Full Counter, Snatch, Hellblaze, Ark, Flash — the signature powers of Meliodas, Ban, the
    /// Demon King, the Goddess Clan and Ludociel. A villager who fought enough battles ended up
    /// with Meliodas's counter, which makes the Sins mean nothing.
    ///
    /// So the signature powers now belong exclusively to the people they belong to, and this file
    /// is the pool everyone else draws from: fifteen abilities, three per magic class, that nobody
    /// famous has and that read as what an ordinary practitioner of that class would actually learn.
    ///
    /// A Reforzador hardens his own body. An Encantador blesses the people beside him. A Hechicero
    /// throws things. A Sanador mends. A Especial does something nobody can predict — but still not
    /// Infinity, because Infinity is Merlin's.
    public static class ClassAbilities
    {
        // --- Reforzador: la magia vuelta hacia dentro --------------------------
        public const string IronSkin = "sds_ability_iron_skin";
        public const string HeavyBlow = "sds_ability_heavy_blow";
        public const string Berserk = "sds_ability_berserk";

        // --- Encantador: la magia vuelta hacia los suyos -----------------------
        public const string BlessWeapon = "sds_ability_bless_weapon";
        public const string Ward = "sds_ability_ward";
        public const string BattleHymn = "sds_ability_battle_hymn";

        // --- Hechicero: golpea de lejos ----------------------------------------
        public const string Spark = "sds_ability_spark";
        public const string FrostLance = "sds_ability_frost_lance";
        public const string Meteor = "sds_ability_meteor";

        // --- Sanador: cierra heridas -------------------------------------------
        public const string Mend = "sds_ability_mend";
        public const string Cleanse = "sds_ability_cleanse";
        public const string Vigor = "sds_ability_vigor";

        // --- Especial: una magia que nadie mas tiene ---------------------------
        public const string Mimic = "sds_ability_mimic";
        public const string Displace = "sds_ability_displace";
        public const string Unravel = "sds_ability_unravel";

        /// Las quince, para que otros sistemas puedan excluirlas. La herencia las usa: la magia de
        /// clase NO se hereda — se aprende con una clase, no se nace con ella.
        public static readonly string[] All =
        {
            IronSkin, HeavyBlow, Berserk, BlessWeapon, Ward, BattleHymn,
            Spark, FrostLance, Meteor, Mend, Cleanse, Vigor, Mimic, Displace, Unravel,
        };

        private const string Group = TraitGroups.ClassMagic;

        public static void Init()
        {
            A(IronSkin, "Piel de Hierro",
                "Endurece el cuerpo hasta que las hojas resbalan. Magia de Reforzador.",
                str: 40f, spi: 20f, mag: 0f, armor: 12f);
            A(HeavyBlow, "Golpe Pesado",
                "Cada golpe carga peso que el brazo no tiene. Magia de Reforzador.",
                str: 90f, spi: 10f, mag: 0f, damage: 12f, knockback: 3f);
            A(Berserk, "Frenesi",
                "Cuanto peor esta, mas fuerte pega. Magia de Reforzador.",
                str: 150f, spi: 40f, mag: 0f, damage: 8f);

            A(BlessWeapon, "Bendecir Arma",
                "Deja el filo de los suyos cantando. Magia de Encantador.",
                str: 10f, spi: 60f, mag: 50f);
            A(Ward, "Guarda",
                "Levanta un resguardo alrededor de los que tiene cerca. Magia de Encantador.",
                str: 0f, spi: 90f, mag: 70f, armor: 6f);
            A(BattleHymn, "Himno de Batalla",
                "Un canto que endurece a una linea entera. Magia de Encantador.",
                str: 20f, spi: 140f, mag: 120f);

            A(Spark, "Chispa",
                "El primer hechizo que aprende cualquiera. Magia de Hechicero.",
                str: 0f, spi: 20f, mag: 60f);
            A(FrostLance, "Lanza de Escarcha",
                "Atraviesa y deja al enemigo lento y torpe. Magia de Hechicero.",
                str: 0f, spi: 50f, mag: 130f);
            A(Meteor, "Meteoro",
                "Trae algo abajo desde muy arriba. Magia de Hechicero.",
                str: 0f, spi: 80f, mag: 220f);

            A(Mend, "Remendar",
                "Cierra la herida del que peor esta. Magia de Sanador.",
                str: 0f, spi: 60f, mag: 40f);
            A(Cleanse, "Purificar",
                "Saca el veneno y la podredumbre de la carne. Magia de Sanador.",
                str: 0f, spi: 110f, mag: 90f);
            A(Vigor, "Vigor",
                "Devuelve el aliento a todos los que le rodean a la vez. Magia de Sanador.",
                str: 0f, spi: 180f, mag: 150f);

            A(Mimic, "Imitar",
                "Copia una parte de la fuerza de quien tiene delante. Magia Especial.",
                str: 50f, spi: 70f, mag: 80f);
            A(Displace, "Desplazar",
                "Aparta lo que le estorba sin tocarlo. Magia Especial.",
                str: 0f, spi: 100f, mag: 140f);
            A(Unravel, "Deshacer",
                "Suelta lo que mantiene entero a un cuerpo. Magia Especial.",
                str: 0f, spi: 130f, mag: 240f);

            SDSTick.Register(Tick);
        }

        private static void A(string id, string nameEs, string infoEs,
                              float str, float spi, float mag,
                              float damage = 0f, float armor = 0f, float knockback = 0f)
        {
            if (AssetManager.traits.dict.ContainsKey(id)) return;

            ActorTrait t = SDSRegistry.Trait(id, Group, "ui/icons/" + id);
            t.type = TraitType.Positive;
            PowerLevel.Grant(t, str, spi, mag);

            if (damage != 0f) t.base_stats["damage"] = damage;
            if (armor != 0f) t.base_stats["armor"] = armor;
            if (knockback != 0f) t.base_stats["knockback"] = knockback;

            SDSRegistry.AddTrait(t);
            SDSLocale.Trait(id, nameEs, infoEs);
        }

        // ---------------------------------------------------------------- behaviour

        /// Cheap gate. These are common abilities on a big population, so the tick opens by asking
        /// one question the vast majority answer "no" to.
        private static void Tick(Actor a, float dt)
        {
            if (a == null || !a.isAlive() || a.data == null) return;

            // EL ORDEN DE ESTAS GUARDAS ES EL RENDIMIENTO DEL MOD.
            //
            // Debajo hay una docena de hasTrait, y cada uno es una busqueda por cadena. La mayoria
            // de la poblacion no esta peleando en un instante dado, asi que preguntar por el combate
            // ANTES que por los traits saca a casi todo el mundo tras dos lecturas baratas. Al reves
            // — que es como estaba — cada aldeano del mundo pagaba doce busquedas por barrido.
            bool fighting = a.has_attack_target;

            // El unico que trabaja fuera de combate; se comprueba con el tier, no con un trait.
            if (!fighting)
            {
                if (SDSData.GetInt(a, "sds_magic_tier", 0) > 0
                    && SDSData.GetBool(a, "sds_magic_rolled")
                    && !Curses.Incapacitated(a)
                    && a.hasTrait(Mend))
                {
                    TickMend(a);
                }
                return;
            }

            if (!SDSData.GetBool(a, "sds_magic_rolled")) return;

            // Sin ningun peldano subido no puede tener ninguna de estas habilidades.
            if (SDSData.GetInt(a, "sds_magic_tier", 0) <= 0) return;
            if (Curses.Incapacitated(a)) return;

            if (a.hasTrait(Berserk)) TickBerserk(a);

            if (a.hasTrait(HeavyBlow)) TickHeavyBlow(a);
            if (a.hasTrait(Spark)) TickBolt(a, Spark, 8f, 0.05f, 10f, "sds_fx_enchant");
            if (a.hasTrait(FrostLance)) TickFrost(a);
            if (a.hasTrait(Meteor)) TickMeteor(a);
            if (a.hasTrait(BlessWeapon)) TickBless(a, BlessWeapon, 8f, 10f);
            if (a.hasTrait(Ward)) TickBless(a, Ward, 10f, 14f);
            if (a.hasTrait(BattleHymn)) TickBless(a, BattleHymn, 13f, 20f);
            if (a.hasTrait(Cleanse)) TickMend(a);
            if (a.hasTrait(Vigor)) TickVigor(a);
            if (a.hasTrait(Mimic)) TickMimic(a);
            if (a.hasTrait(Displace)) TickDisplace(a);
            if (a.hasTrait(Unravel)) TickUnravel(a);
        }

        private static float CD(float s)
        {
            return SDSConfig.AbilityCooldowns ? s : 0.2f;
        }

        private static Actor Enemy(Actor a, float radius)
        {
            List<Actor> near = SDSUnit.Around(a, radius);
            for (int i = 0; i < near.Count; i++)
            {
                Actor o = near[i];
                if (o != null && o.isAlive() && o.kingdom != a.kingdom) return o;
            }
            return null;
        }

        // --- Reforzador ---------------------------------------------------------

        /// The worse it gets, the harder they hit. A passive, so it just keeps a status topped up
        /// while they are hurt and in a fight.
        private static void TickBerserk(Actor a)
        {
            if (!a.has_attack_target) return;

            float max = a.getMaxHealth();
            if (max <= 0f || a.data.health / max > 0.5f) return;
            if (a.hasStatus("sds_status_reinforced")) return;

            SDSStatus.Inflict(a, "sds_status_reinforced", 6f);
        }

        private static void TickHeavyBlow(Actor a)
        {
            if (!SDSData.TryUse(a, "heavy_blow", CD(5f))) return;

            Actor target = Enemy(a, 3f);
            if (target == null) return;

            try { target.getHit(10f + PowerLevel.Strength(a) * 0.04f, true, AttackType.Other, a, true); }
            catch { return; }

            SDSFx.At(target, "sds_fx_creation", 0.35f);
        }

        // --- Encantador ---------------------------------------------------------

        /// Blesses nearby allies. One routine for all three tiers; they differ in reach and duration.
        private static void TickBless(Actor a, string key, float radius, float seconds)
        {
            if (!SDSData.TryUse(a, key, CD(9f))) return;

            List<Actor> near = SDSUnit.Around(a, radius);
            int blessed = 0;

            for (int i = 0; i < near.Count && blessed < 6; i++)
            {
                Actor o = near[i];
                if (!SDSUnit.IsAlly(a, o)) continue;
                if (o.hasStatus("sds_status_enchanted")) continue;

                SDSStatus.Inflict(o, "sds_status_enchanted", seconds);
                blessed++;
            }

            if (blessed > 0) SDSFx.At(a, "sds_fx_enchant", 0.5f);
        }

        // --- Hechicero ----------------------------------------------------------

        private static void TickBolt(Actor a, string key, float cd, float scale, float flat, string fx)
        {
            if (!SDSData.TryUse(a, key, CD(cd))) return;

            Actor target = Enemy(a, 12f);
            if (target == null) return;

            SDSFx.Projectile(a, target, Projectiles.Magic);
            try { target.getHit(flat + PowerLevel.Magic(a) * scale, true, AttackType.Other, a, true); }
            catch { return; }

            SDSFx.At(target, fx, 0.35f);
        }

        /// Hits, and leaves them slow. The slow is a status rather than a stat write so it wears off
        /// on its own — there is no verified way to remove one.
        private static void TickFrost(Actor a)
        {
            if (!SDSData.TryUse(a, FrostLance, CD(7f))) return;

            Actor target = Enemy(a, 13f);
            if (target == null) return;

            SDSFx.Projectile(a, target, Projectiles.Magic);
            try { target.getHit(14f + PowerLevel.Magic(a) * 0.06f, true, AttackType.Other, a, true); }
            catch { return; }

            SDSStatus.Inflict(target, Curses.Paralyzed, 3f);
            SDSFx.At(target, "sds_fx_ocean", 0.4f);
        }

        private static void TickMeteor(Actor a)
        {
            if (!SDSData.TryUse(a, Meteor, CD(14f))) return;

            Actor target = Enemy(a, 15f);
            if (target == null) return;

            float power = 20f + PowerLevel.Magic(a) * 0.08f;
            List<Actor> near = SDSUnit.Around(target, 5f);

            try { target.getHit(power, true, AttackType.Fire, a, true); }
            catch { return; }

            for (int i = 0; i < near.Count; i++)
            {
                Actor o = near[i];
                if (o == null || !o.isAlive() || o.kingdom == a.kingdom) continue;
                try { o.getHit(power * 0.5f, true, AttackType.Fire, a, true); }
                catch { }
            }

            SDSFx.At(target, "sds_fx_creation", 0.7f);
            SDSFx.Wave(target, 3f, 2f);
        }

        // --- Sanador ------------------------------------------------------------

        private static void TickMend(Actor a)
        {
            if (!SDSData.TryUse(a, Mend, CD(4f))) return;

            Actor worst = null;
            float worstRatio = 1f;

            List<Actor> near = SDSUnit.Around(a, 11f);
            for (int i = 0; i < near.Count; i++)
            {
                Actor o = near[i];
                if (!SDSUnit.IsAlly(a, o)) continue;

                float max = o.getMaxHealth();
                if (max <= 0f) continue;

                float ratio = o.data.health / max;
                if (ratio >= 1f || ratio >= worstRatio) continue;

                worstRatio = ratio;
                worst = o;
            }

            if (worst == null) return;

            try { worst.restoreHealth(Mathf.Max(1, Mathf.RoundToInt(8f + PowerLevel.Magic(a) * 0.05f))); }
            catch { return; }

            SDSFx.At(worst, "sds_fx_heal", 0.35f);
        }

        private static void TickVigor(Actor a)
        {
            if (!SDSData.TryUse(a, Vigor, CD(10f))) return;

            int amount = Mathf.Max(1, Mathf.RoundToInt(10f + PowerLevel.Magic(a) * 0.05f));
            List<Actor> near = SDSUnit.Around(a, 12f);
            bool used = false;

            for (int i = 0; i < near.Count; i++)
            {
                Actor o = near[i];
                if (!SDSUnit.IsAlly(a, o)) continue;
                if (o.data.health >= o.getMaxHealth()) continue;

                try { o.restoreHealth(amount); used = true; }
                catch { }
            }

            if (used) SDSFx.At(a, "sds_fx_heal", 0.6f);
        }

        // --- Especial -----------------------------------------------------------

        /// Copies a slice of the strength of whoever is in front of them. Nothing is taken from the
        /// target — this is imitation, not Snatch, and Snatch stays Ban's.
        private static void TickMimic(Actor a)
        {
            if (!SDSData.TryUse(a, Mimic, CD(12f))) return;

            Actor target = Enemy(a, 8f);
            if (target == null) return;

            float theirs = PowerLevel.Strength(target);
            if (theirs <= PowerLevel.Strength(a)) return;

            SDSStatus.Inflict(a, "sds_status_reinforced", 10f);
            SDSFx.At(a, "sds_fx_infinity", 0.4f);
        }

        /// Shoves everything hostile away. No damage — it is displacement, and it is what saves a
        /// caster who has been surrounded.
        private static void TickDisplace(Actor a)
        {
            if (!SDSData.TryUse(a, Displace, CD(11f))) return;

            List<Actor> near = SDSUnit.Around(a, 5f);
            bool used = false;

            for (int i = 0; i < near.Count; i++)
            {
                Actor o = near[i];
                if (o == null || !o.isAlive() || o.kingdom == a.kingdom) continue;
                try { o.getHit(1f, true, AttackType.Other, a, true); used = true; }
                catch { }
            }

            if (used)
            {
                SDSFx.Wave(a, 3.5f, 2.5f);
                SDSFx.At(a, "sds_fx_tornado", 0.5f);
            }
        }

        /// One target, heavy magic damage. The Especial's finisher.
        private static void TickUnravel(Actor a)
        {
            if (!SDSData.TryUse(a, Unravel, CD(13f))) return;

            Actor target = Enemy(a, 11f);
            if (target == null) return;

            try { target.getHit(26f + PowerLevel.Magic(a) * 0.09f, true, AttackType.Other, a, true); }
            catch { return; }

            SDSFx.At(target, "sds_fx_soul", 0.55f);
        }
    }
}
