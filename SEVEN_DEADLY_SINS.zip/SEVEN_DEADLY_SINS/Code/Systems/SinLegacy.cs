using System.Collections.Generic;
using UnityEngine;

namespace SevenDeadlySins
{
    /// EL LEGADO DE LOS PECADOS.
    ///
    /// Igual que Tristan (hijo de Meliodas y Elizabeth) tiene su magia propia y su forma propia, aqui
    /// CADA cruce de dos Pecados Capitales da un hijo con NOMBRE, HABILIDAD y TRANSFORMACION propios.
    /// Son 21 combinaciones (los pares de los siete Pecados), y valen tanto si el hijo sale hibrido
    /// (razas distintas) como puro (misma raza).
    ///
    /// COMO LO PIDIO EL USUARIO:
    ///   - La habilidad NO es un trait permanente: es un STATUS que dura 25 s y se relanza cada 30 s.
    ///   - Cada hijo tiene UNA sola habilidad PROPIA, basada en los poderes de sus dos padres pero sin
    ///     mezclar dos efectos: es un impulso de poder unico (su herencia despertando) con un golpe de
    ///     firma, no la suma de las dos magias de los padres.
    ///   - Un hijo de dos Pecados NO hereda las formas de sus padres: solo tiene la SUYA (Offspring lo
    ///     gatea con SinLegacy.IsPair). Y su transformacion tampoco reparte las habilidades de los
    ///     padres: su poder es el suyo.
    ///
    /// Todo son estados y comportamiento — NADA de actores ni texturas — asi que es de los seguros.
    public static class SinLegacy
    {
        // El elemento de cada Pecado. Da SABOR al golpe de firma del hijo (uno solo, no dos mezclados).
        private static readonly Dictionary<string, string> _element = new Dictionary<string, string>
        {
            { SevenSins.Wrath,    "dark"   },
            { SevenSins.Greed,    "steal"  },
            { SevenSins.Envy,     "earth"  },
            { SevenSins.Lust,     "mind"   },
            { SevenSins.Sloth,    "spirit" },
            { SevenSins.Gluttony, "arcane" },
            { SevenSins.Pride,    "sun"    },
        };

        private static readonly Dictionary<string, string> _code = new Dictionary<string, string>
        {
            { SevenSins.Wrath, "wr" }, { SevenSins.Greed, "gr" }, { SevenSins.Envy, "en" },
            { SevenSins.Lust, "lu" }, { SevenSins.Sloth, "sl" }, { SevenSins.Gluttony, "gl" },
            { SevenSins.Pride, "pr" },
        };

        // Que HACE cada una de las 21 habilidades. Sale en el panel y define su efecto (ver CastAbility).
        private static readonly Dictionary<string, string> _desc = new Dictionary<string, string>
        {
            { "gr_wr", "envuelve al enemigo en llama negra que le drena la vida para curarse — contra y hurto en uno" },
            { "en_wr", "sacude la tierra: onda de roca y fuego negro que quema a todos los enemigos alrededor" },
            { "lu_wr", "golpe de sombra en la mente: quema y deja al enemigo paralizado" },
            { "sl_wr", "invoca lanzas de espiritu envueltas en llama negra y cura a los aliados cercanos" },
            { "gl_wr", "estallido arcano y oscuro que petrifica al enemigo y lo deja ardiendo" },
            { "pr_wr", "una hoja de sol negro: fuego devastador sobre un solo objetivo" },
            { "en_gr", "golpea con roca y roba la vida del enemigo para curarse" },
            { "gr_lu", "paraliza al enemigo y le drena la vida mientras no puede moverse" },
            { "gr_sl", "drena la vida de todos los enemigos cercanos a la vez y se cura con ella" },
            { "gl_gr", "roba vida y petrifica al enemigo con magia" },
            { "gr_pr", "hurto ardiente: fuego que dana y devuelve vida a quien lo lanza" },
            { "en_lu", "levanta la tierra en un area y atrapa (paraliza) a los enemigos" },
            { "en_sl", "cura a los aliados y golpea con tierra a los enemigos de alrededor" },
            { "en_gl", "conjura roca pesada en area que petrifica a quien alcanza" },
            { "en_pr", "hace erupcionar roca al rojo vivo: fuego en area" },
            { "lu_sl", "duerme (paraliza) a los enemigos de un area y cura a los aliados" },
            { "gl_lu", "destroza la mente: paraliza, petrifica y dana con arcano" },
            { "lu_pr", "luz cegadora: fuego que dana y paraliza por el deslumbre" },
            { "gl_sl", "crecimiento sin fin: cura a los aliados y dana con arcano en area" },
            { "pr_sl", "un bosque bajo el sol: cura a los aliados y quema a los enemigos en area" },
            { "gl_pr", "rayo de saber solar: fuego arcano que petrifica" },
        };

        private sealed class Legacy
        {
            public string a, b;          // los dos Pecados padres
            public string key;           // clave limpia del par
            public string child;         // nombre del hijo
            public string abilityTrait;  // id del TRAIT permanente (la habilidad como marca, "como antes")
            public string ability;       // id del STATUS de 25s que ESA habilidad da
            public string abilityName, abilityInfo;
            public string abilityIcon;   // icono del status activo
            public string form;          // id del STATUS de transformacion
            public string formName, formInfo;
        }

        private static readonly Dictionary<string, Legacy> _table = new Dictionary<string, Legacy>();

        // Claves de ficha del hijo.
        private const string KeyPair = "sds_legacy_pair";    // identidad: que par es (no trait)
        private const string KeyForm = "sds_legacy_form";
        private const string KeyStage = "sds_legacy_stage";
        private const int FormKills = 20;                    // la transformacion se GANA

        private const float AbilityDuration = 25f;           // el status de habilidad dura 25 s...
        private const float AbilityCooldown = 30f;           // ...y se relanza cada 30 s

        private static int _diag;   // diagnostico temporal

        public static void Init()
        {
            //          Pecado A          Pecado B          hijo        habilidad            transformacion
            L(SevenSins.Wrath,   SevenSins.Greed,   "Kel",    "Contragolpe Voraz",  "Sombra Insaciable");
            L(SevenSins.Wrath,   SevenSins.Envy,    "Dorn",   "Furia Telurica",     "Coloso de la Ira");
            L(SevenSins.Wrath,   SevenSins.Lust,    "Vesa",   "Ira Mental",         "Espejismo Oscuro");
            L(SevenSins.Wrath,   SevenSins.Sloth,   "Aldric", "Contra Espiritual",  "Guardian del Ocaso");
            L(SevenSins.Wrath,   SevenSins.Gluttony,"Nero",   "Contra Infinita",    "Eclipse Eterno");
            L(SevenSins.Wrath,   SevenSins.Pride,   "Solon",  "Contra Solar",       "Ocaso Ardiente");
            L(SevenSins.Greed,   SevenSins.Envy,    "Terra",  "Hurto Petreo",       "Titan Ladron");
            L(SevenSins.Greed,   SevenSins.Lust,    "Lys",    "Robo de Almas",      "Fantasma Inmortal");
            L(SevenSins.Greed,   SevenSins.Sloth,   "Fenn",   "Cosecha del Bosque", "Guardian Inmortal");
            L(SevenSins.Greed,   SevenSins.Gluttony,"Vex",    "Codicia Infinita",   "Avaricia Absoluta");
            L(SevenSins.Greed,   SevenSins.Pride,   "Rox",    "Hurto Solar",        "Bandido del Mediodia");
            L(SevenSins.Envy,    SevenSins.Lust,    "Mira",   "Creacion Mental",    "Muneca de Piedra");
            L(SevenSins.Envy,    SevenSins.Sloth,   "Bryn",   "Jardin Viviente",    "Reina de la Tierra");
            L(SevenSins.Envy,    SevenSins.Gluttony,"Cora",   "Creacion Infinita",  "Arquitecta Eterna");
            L(SevenSins.Envy,    SevenSins.Pride,   "Gaia",   "Montana Solar",      "Coloso del Sol");
            L(SevenSins.Lust,    SevenSins.Sloth,   "Sable",  "Sueno del Bosque",   "Ilusion Silvana");
            L(SevenSins.Lust,    SevenSins.Gluttony,"Zeph",   "Mente Infinita",     "Titiritero Eterno");
            L(SevenSins.Lust,    SevenSins.Pride,   "Lux",    "Espejismo Solar",    "Sol Falso");
            L(SevenSins.Sloth,   SevenSins.Gluttony,"Wynn",   "Bosque Infinito",    "Rey Eterno");
            L(SevenSins.Sloth,   SevenSins.Pride,   "Elio",   "Bosque Solar",       "Rey del Mediodia");
            L(SevenSins.Gluttony,SevenSins.Pride,   "Sage",   "Saber Solar",        "Mago del Sol");

            SDSTick.Register(Tick);
        }

        private static void L(string a, string b, string child, string abilityName, string formName)
        {
            Legacy g = new Legacy();
            g.a = a; g.b = b; g.child = child;
            g.key = Key(a, b);
            g.abilityName = abilityName;
            g.formName = formName;

            g.abilityTrait = "sds_ability_legacy_" + g.key;          // TRAIT permanente (marca)
            g.ability = "sds_status_legacy_ab_" + g.key;             // STATUS de 25s que da
            g.abilityIcon = "ui/icons/sds_status_legacy_ab_" + g.key;
            g.form = "sds_status_legacy_" + g.key;

            string d;
            g.abilityInfo = _desc.TryGetValue(g.key, out d)
                ? ("Habilidad de " + child + ": " + d + ". Dura 25s, se relanza cada 30s.")
                : ("El poder propio de " + child + ".");
            g.formInfo = "La forma verdadera de " + child + ": " + formName + ", el legado de sus dos "
                       + "padres hecho una sola cosa.";

            _table[g.key] = g;

            RegisterAbilityTrait(g);
            RegisterAbilityStatus(g);
            RegisterForm(g);

            SDSLocale.Trait(g.abilityTrait, g.abilityName, g.abilityInfo);
            SDSLocale.Status(g.ability, g.abilityName, g.abilityInfo);
            SDSLocale.Status(g.form, g.formName, g.formInfo);

            // La letra gris del trait: como se consigue y que hace.
            string dd;
            string what = _desc.TryGetValue(g.key, out dd) ? dd : "el poder de sus dos padres";
            SDSLocale.TraitLore(g.abilityTrait,
                "Nace SOLO del cruce de dos Pecados Capitales concretos. Su poder, " + what
                + ", se desata como estado 25s cada 30s, y su transformacion (" + g.formName
                + ") se gana con 20 bajas.");
        }

        private static string Key(string a, string b)
        {
            string ca = _code[a], cb = _code[b];
            return string.CompareOrdinal(ca, cb) <= 0 ? ca + "_" + cb : cb + "_" + ca;
        }

        // ---------------------------------------------------------------- registro

        /// La habilidad como TRAIT permanente ("como antes"): la MARCA visible del hijo en su panel,
        /// que lo identifica siempre. Lleva un poco de poder de base; el grueso lo da su STATUS activo.
        private static void RegisterAbilityTrait(Legacy g)
        {
            if (AssetManager.traits.dict.ContainsKey(g.abilityTrait)) return;

            ActorTrait t = SDSRegistry.Trait(g.abilityTrait, TraitGroups.SinPowers, "ui/icons/" + g.abilityTrait);
            t.type = TraitType.Positive;
            PowerLevel.Grant(t, 500f, 500f, 500f);
            t.base_stats["damage"] = 20f;
            SDSRegistry.AddTrait(t);
        }

        /// Lo que ESA habilidad DA: un STATUS temporal (25 s). Mientras esta activo, el hijo se
        /// envuelve en su poder propio — un empujon de Nivel de Poder y de combate, su herencia
        /// despertando, no la magia de nadie mas.
        private static void RegisterAbilityStatus(Legacy g)
        {
            if (AssetManager.status.dict.ContainsKey(g.ability)) return;

            StatusAsset s = SDSRegistry.Status(g.ability, g.abilityIcon, AbilityDuration);
            PowerLevel.Grant(s, 4000f, 4000f, 4000f);   // el poder de SU habilidad, mientras dura
            s.base_stats["damage"] = 40f;
            s.base_stats["armor"] = 20f;
            s.base_stats["critical_chance"] = 0.15f;
            s.removed_on_damage = false;
            SDSRegistry.AddStatus(s);
        }

        private static void RegisterForm(Legacy g)
        {
            if (AssetManager.status.dict.ContainsKey(g.form)) return;

            StatusAsset s = SDSRegistry.Status(g.form, "ui/icons/sds_status_legacy_" + g.key, 9999f);
            PowerLevel.Grant(s, 9000f, 9000f, 9000f);
            s.base_stats["health"] = 900f;
            s.base_stats["damage"] = 60f;
            s.base_stats["armor"] = 30f;
            s.removed_on_damage = false;
            SDSRegistry.AddStatus(s);
        }

        // ---------------------------------------------------------------- aplicar al nacer

        /// True si esta pareja son dos Pecados distintos (su hijo es un hijo-legado). Offspring lo usa
        /// para NO darle a ese hijo las formas de sus padres: su unica transformacion es la SUYA.
        public static bool IsPair(Actor p1, Actor p2)
        {
            if (p1 == null || p2 == null) return false;
            string sa = SDSUnit.SinOf(p1), sb = SDSUnit.SinOf(p2);
            if (sa == null || sb == null || sa == sb) return false;
            return _table.ContainsKey(Key(sa, sb));
        }

        /// Convierte al bebe en su hijo-legado: nombre + identidad (por DATO, no por trait) + la forma
        /// pendiente. La habilidad NO se concede como trait: se aplicara como status en el Tick.
        public static bool TryApply(Actor baby, Actor p1, Actor p2)
        {
            if (baby == null || p1 == null || p2 == null) return false;

            string sa = SDSUnit.SinOf(p1), sb = SDSUnit.SinOf(p2);
            if (sa == null || sb == null || sa == sb) return false;

            Legacy g;
            if (!_table.TryGetValue(Key(sa, sb), out g)) return false;

            try
            {
                baby.setName(g.child);
                SDSData.SetBool(baby, SDSData.Named, true);
                SDSTraits.Give(baby, g.abilityTrait);         // la habilidad como TRAIT permanente
                SDSData.SetString(baby, KeyPair, g.key);      // clave para el Tick (busqueda O(1))
                SDSData.SetString(baby, KeyForm, g.form);     // la forma se gana con kills (ver Tick)

                // (El hijo hereda el reino/ciudad de un padre en BirthPatch, comun a TODOS los hijos
                //  del mod. Sin eso sus curas no encontraban aliados — la causa raiz del bug.)
                SDSFx.At(baby, "sds_fx_sunshine", 0.7f);
                SDSLog.Chronicle(SDSLocale.T(
                    "Ha nacido " + g.child + ", hijo de dos Pecados Capitales.",
                    g.child + " is born, child of two Deadly Sins."));
            }
            catch { }
            return true;
        }

        // ---------------------------------------------------------------- comportamiento

        private static float CD(float s)
        {
            return SDSConfig.AbilityCooldowns ? s : 0.2f;
        }

        private static void Tick(Actor a, float dt)
        {
            if (a == null || !a.isAlive() || a.data == null) return;
            if (!SDSUnit.IsNamed(a)) return;

            // Identidad por DATO, no por trait.
            string key = SDSData.GetString(a, KeyPair, "");
            if (string.IsNullOrEmpty(key)) return;
            Legacy g;
            if (!_table.TryGetValue(key, out g)) return;

            // La transformacion propia, ganada con kills. Es SOLO suya: no reparte las habilidades de
            // sus padres (el usuario no quiere eso) — su poder ya es el de su forma y su habilidad.
            string form = SDSData.GetString(a, KeyForm, "");
            if (!string.IsNullOrEmpty(form) && SDSData.GetInt(a, KeyStage, 0) == 0)
            {
                int kills = 0;
                try { kills = a.data.kills; } catch { }
                if (kills >= FormKills && a.isAdult())
                {
                    if (SDSStatus.Inflict(a, form, 9999f))
                    {
                        SDSData.SetInt(a, KeyStage, 1);
                        SDSFx.At(a, "sds_fx_demon_king", 0.8f);
                        SDSFx.Wave(a, 3f, 2f);
                        SDSLog.Chronicle(SDSLocale.T(
                            a.getName() + " despierta su forma verdadera, " + g.formName + ".",
                            a.getName() + " awakens their true form, " + g.formName + "."));
                    }
                }
            }

            // LA HABILIDAD QUE DA EL TRAIT: su efecto se desata como STATUS de 25 s cada 30 s. Una
            // sola habilidad propia, basada en sus padres (no dos efectos mezclados): se envuelve en
            // su poder heredado y descarga UN golpe de firma con el sabor de su linaje.
            if (Curses.Incapacitated(a)) return;
            // Dispara cuando hay ALGO que hacer: un enemigo a tiro O un aliado herido cerca. Antes
            // exigia `has_attack_target` (atacar ACTIVAMENTE), y un hijo hibrido que se porta como
            // aldeano casi nunca ataca — por eso su habilidad (y su cura) no se disparaba nunca.
            if (NearestEnemy(a, 13f) == null && !HasWoundedAlly(a, 12f)) return;
            if (a.hasStatus(g.ability)) return;                        // ya activa: espera a que caduque
            if (!SDSData.TryUse(a, "legacy_cast", CD(AbilityCooldown))) return;

            if (!SDSStatus.Inflict(a, g.ability, AbilityDuration)) return;
            SDSFx.At(a, "sds_fx_legacy_" + g.key, 0.8f);   // su efecto visual PROPIO, unico por par

            // DIAGNOSTICO TEMPORAL: confirma en el Player.log que la habilidad SI se dispara (primeras
            // veces). Se quita cuando este confirmado.
            if (_diag < 12) { _diag++; SDSLog.Info("legado dispara: " + a.getName() + " [" + g.key + "]"); }

            // Y su efecto PROPIO y distinto — uno por par (ver CastAbility). Ademas del impulso de
            // poder del status, cada habilidad HACE algo suyo.
            CastAbility(a, g);
        }

        // Amigo/enemigo: la logica robusta vive en SDSUnit (una sola fuente de verdad, compartida con
        // las curas de clan de los hibridos de raza). Aqui solo se delega.
        private static bool IsAlly(Actor a, Actor o) { return SDSUnit.IsAlly(a, o); }
        private static bool IsEnemy(Actor a, Actor o) { return SDSUnit.IsEnemy(a, o); }

        private static Actor NearestEnemy(Actor a, float radius)
        {
            List<Actor> near = SDSUnit.Around(a, radius);
            for (int i = 0; i < near.Count; i++)
            {
                Actor o = near[i];
                if (IsEnemy(a, o)) return o;
            }
            return null;
        }

        private static bool HasWoundedAlly(Actor a, float radius)
        {
            List<Actor> near = SDSUnit.Around(a, radius);
            for (int i = 0; i < near.Count; i++)
            {
                Actor o = near[i];
                if (!IsAlly(a, o)) continue;
                if (o.data != null && o.data.health < o.getMaxHealth()) return true;
            }
            return false;
        }

        /// El efecto PROPIO y distinto de cada uno de los 21 hijos-legado. Uno cohesionado por par (no
        /// dos efectos de los padres pegados): es lo que HACE su habilidad, descrito en _desc.
        private static void CastAbility(Actor a, Legacy g)
        {
            try
            {
                Actor t = NearestEnemy(a, 13f);
                float m = PowerLevel.Magic(a);
                float s = PowerLevel.Strength(a);
                switch (g.key)
                {
                    case "gr_wr": // Kel: llama negra que drena
                        Drain(a, t, 16f + s * 0.05f); if (t != null) SDSStatus.Inflict(t, "sds_status_hellblaze", 8f); break;
                    case "en_wr": // Dorn: onda de tierra y fuego negro en area
                        AoE(a, 6f, 15f + s * 0.05f, AttackType.Fire, "sds_fx_creation", "sds_status_hellblaze", 6f); break;
                    case "lu_wr": // Vesa: golpe oscuro que paraliza
                        Hit(a, t, 14f + m * 0.05f, AttackType.Fire, "sds_fx_hellblaze");
                        if (t != null) { SDSStatus.Inflict(t, Curses.Paralyzed, 3f); SDSStatus.Inflict(t, "sds_status_hellblaze", 6f); } break;
                    case "sl_wr": // Aldric: lanza de espiritu en llama negra + cura aliados
                        if (t != null) { SDSFx.Projectile(a, t, Projectiles.Chastiefol); Hit(a, t, 14f + m * 0.05f, AttackType.Fire, null); SDSStatus.Inflict(t, "sds_status_hellblaze", 6f); }
                        HealAllies(a, 10f, 12f + m * 0.04f); break;
                    case "gl_wr": // Nero: estallido arcano oscuro que petrifica y quema
                        if (t != null) { SDSFx.Projectile(a, t, Projectiles.Hellblaze); Hit(a, t, 16f + m * 0.06f, AttackType.Fire, null); SDSStatus.Inflict(t, Curses.Petrified, 3f); SDSStatus.Inflict(t, "sds_status_hellblaze", 6f); } break;
                    case "pr_wr": // Solon: hoja de sol negro, fuego pesado a uno
                        Hit(a, t, 26f + m * 0.07f, AttackType.Fire, "sds_fx_sunshine"); break;
                    case "en_gr": // Terra: roca que roba vida
                        Drain(a, t, 18f + s * 0.06f); if (t != null) SDSFx.At(t, "sds_fx_creation", 0.5f); break;
                    case "gr_lu": // Lys: paraliza y drena
                        if (t != null) SDSStatus.Inflict(t, Curses.Paralyzed, 4f); Drain(a, t, 14f + s * 0.05f); break;
                    case "gr_sl": // Fenn: drena a todos alrededor y se cura
                        DrainAll(a, 8f, 10f + s * 0.03f); break;
                    case "gl_gr": // Vex: drena y petrifica
                        Drain(a, t, 15f + m * 0.05f); if (t != null) SDSStatus.Inflict(t, Curses.Petrified, 3f); break;
                    case "gr_pr": // Rox: hurto ardiente
                        if (t != null) { Hit(a, t, 18f + m * 0.05f, AttackType.Fire, "sds_fx_sunshine"); try { a.restoreHealth(Mathf.Max(1, Mathf.RoundToInt(12f + s * 0.03f))); } catch { } } break;
                    case "en_lu": // Mira: tierra que atrapa (paraliza) en area
                        AoE(a, 6f, 12f + m * 0.05f, AttackType.Other, "sds_fx_creation", Curses.Paralyzed, 3f); break;
                    case "en_sl": // Bryn: cura aliados + tierra en area
                        HealAllies(a, 11f, 14f + m * 0.05f); AoE(a, 6f, 12f + s * 0.04f, AttackType.Other, "sds_fx_creation", null, 0f); break;
                    case "en_gl": // Cora: roca pesada que petrifica en area
                        AoE(a, 6f, 16f + m * 0.05f, AttackType.Other, "sds_fx_creation", Curses.Petrified, 3f); break;
                    case "en_pr": // Gaia: roca al rojo, fuego en area
                        AoE(a, 6f, 18f + m * 0.06f, AttackType.Fire, "sds_fx_sunshine", null, 0f); break;
                    case "lu_sl": // Sable: duerme en area + cura aliados
                        AoE(a, 7f, 8f + m * 0.03f, AttackType.Other, "sds_fx_infinity", Curses.Paralyzed, 4f); HealAllies(a, 10f, 10f + m * 0.04f); break;
                    case "gl_lu": // Zeph: paraliza, petrifica y dana con arcano
                        if (t != null) { SDSFx.Projectile(a, t, Projectiles.Magic); Hit(a, t, 13f + m * 0.06f, AttackType.Other, null); SDSStatus.Inflict(t, Curses.Paralyzed, 3f); SDSStatus.Inflict(t, Curses.Petrified, 2f); } break;
                    case "lu_pr": // Lux: luz cegadora, fuego + paraliza
                        Hit(a, t, 16f + m * 0.05f, AttackType.Fire, "sds_fx_sunshine"); if (t != null) SDSStatus.Inflict(t, Curses.Paralyzed, 3f); break;
                    case "gl_sl": // Wynn: cura aliados + arcano en area
                        HealAllies(a, 11f, 14f + m * 0.05f); AoE(a, 6f, 12f + m * 0.05f, AttackType.Other, "sds_fx_infinity", null, 0f); break;
                    case "pr_sl": // Elio: cura aliados + fuego en area
                        HealAllies(a, 11f, 14f + m * 0.05f); AoE(a, 6f, 14f + m * 0.05f, AttackType.Fire, "sds_fx_sunshine", null, 0f); break;
                    case "gl_pr": // Sage: rayo arcano solar que petrifica
                        if (t != null) { SDSFx.Projectile(a, t, Projectiles.Magic); Hit(a, t, 20f + m * 0.06f, AttackType.Fire, "sds_fx_sunshine"); SDSStatus.Inflict(t, Curses.Petrified, 3f); } break;
                }
            }
            catch { }
        }

        // ---- primitivos de efecto, reutilizados por CastAbility ----

        private static void Hit(Actor a, Actor t, float dmg, AttackType type, string fx)
        {
            if (t == null || !t.isAlive()) return;
            try { t.getHit(dmg, true, type, a, true); } catch { return; }
            if (!string.IsNullOrEmpty(fx)) SDSFx.At(t, fx, 0.5f);
        }

        private static void AoE(Actor a, float radius, float dmg, AttackType type, string fx, string status, float statusTime)
        {
            List<Actor> near = SDSUnit.Around(a, radius);
            for (int i = 0; i < near.Count; i++)
            {
                Actor o = near[i];
                if (!IsEnemy(a, o)) continue;
                try { o.getHit(dmg, true, type, a, true); } catch { continue; }
                if (!string.IsNullOrEmpty(status)) SDSStatus.Inflict(o, status, statusTime);
            }
            if (!string.IsNullOrEmpty(fx)) SDSFx.At(a, fx, 0.6f);
        }

        private static void Drain(Actor a, Actor t, float dmg)
        {
            if (t == null || !t.isAlive()) return;
            try
            {
                t.getHit(dmg, true, AttackType.Other, a, true);
                a.restoreHealth(Mathf.Max(1, Mathf.RoundToInt(dmg * 0.7f)));
            }
            catch { }
            SDSFx.At(t, "sds_fx_snatch", 0.5f);
        }

        private static void DrainAll(Actor a, float radius, float dmg)
        {
            List<Actor> near = SDSUnit.Around(a, radius);
            float healed = 0f;
            for (int i = 0; i < near.Count; i++)
            {
                Actor o = near[i];
                if (!IsEnemy(a, o)) continue;
                try { o.getHit(dmg, true, AttackType.Other, a, true); healed += dmg * 0.5f; } catch { }
            }
            if (healed > 0f)
            {
                try { a.restoreHealth(Mathf.Max(1, Mathf.RoundToInt(healed))); } catch { }
                SDSFx.At(a, "sds_fx_snatch", 0.6f);
            }
        }

        private static void HealAllies(Actor a, float radius, float amount)
        {
            List<Actor> near = SDSUnit.Around(a, radius);
            bool used = false;
            int allies = 0, healed = 0;
            for (int i = 0; i < near.Count; i++)
            {
                Actor o = near[i];
                if (!IsAlly(a, o)) continue;
                allies++;
                if (o.data == null || o.data.health >= o.getMaxHealth()) continue;
                try { o.restoreHealth(Mathf.Max(1, Mathf.RoundToInt(amount))); used = true; healed++; } catch { }
            }
            if (used) SDSFx.At(a, "sds_fx_heal", 0.5f);

            // DIAGNOSTICO TEMPORAL: prueba en el Player.log que la cura YA encuentra aliados (antes del
            // arreglo salia siempre aliados=0). Se quita cuando este confirmado.
            if (_healDiag < 12)
            {
                _healDiag++;
                SDSLog.Info("legado cura: " + a.getName() + " aliados=" + allies + " curados=" + healed);
            }
        }

        private static int _healDiag;
    }
}
