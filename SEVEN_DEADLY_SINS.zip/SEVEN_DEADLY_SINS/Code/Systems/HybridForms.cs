using System.Collections.Generic;

namespace SevenDeadlySins
{
    /// Una transformacion PROPIA para cada tipo de hibrido, con su nombre y sus numeros.
    ///
    /// El usuario lo pidio exacto: la forma generica "Forma Hibrida" no vale — cada mezcla tiene que
    /// tener SU forma, con nombre segun las dos razas, y efectos mejorados segun el desglose de su
    /// hibridez. Un medio demonio media diosa no despierta lo mismo que un medio gigante medio hada.
    ///
    /// COMO SE ARMAN LOS EFECTOS. Cada raza aporta un DOMINIO — su bloque de poder: el demonio trae
    /// fuerza y regeneracion, la diosa espiritu y magia, el gigante vida y armadura, el hada
    /// agilidad, el vampiro pegada con robo, el humano equilibrio. La forma de un hibrido es la SUMA
    /// de los dos dominios: por eso "mejoradas segun el desglose" — literalmente se desglosan las dos
    /// sangres y se suman. Asi las quince formas salen distintas sin escribir quince a mano.
    public static class HybridForms
    {
        /// dominio de una raza: lo que aporta a una forma hibrida.
        private class Domain
        {
            public float str, spi, mag, health, damage, armor, speed, knockback;
        }

        private static readonly Dictionary<string, Domain> _domain = new Dictionary<string, Domain>
        {
            ["demon"]   = new Domain { str = 500, spi = 250, mag = 350, health = 350, damage = 45, armor = 15 },
            ["goddess"] = new Domain { str = 120, spi = 600, mag = 550, health = 250, damage = 20 },
            ["fairy"]   = new Domain { str = 180, spi = 450, mag = 450, health = 180, speed = 35 },
            ["giant"]   = new Domain { str = 750, spi = 120, mag = 60,  health = 650, damage = 55, armor = 35, knockback = 6 },
            ["vampire"] = new Domain { str = 450, spi = 180, mag = 180, health = 250, damage = 40 },
            ["human"]   = new Domain { str = 300, spi = 300, mag = 300, health = 250, damage = 25 },
        };

        /// nombre de la forma por par (clave ordenada "a|b"). Tematico a las dos razas.
        private static readonly Dictionary<string, (string es, string en)> _name =
            new Dictionary<string, (string, string)>
        {
            ["demon|human"]    = ("Demonio Encarnado", "Incarnate Demon"),
            ["goddess|human"]  = ("Angel Encarnado", "Incarnate Angel"),
            ["fairy|human"]    = ("Elfo Mayor", "Elder Fae"),
            ["giant|human"]    = ("Coloso", "Colossus"),
            ["human|vampire"]  = ("Senor de Sangre", "Blood Lord"),
            ["demon|goddess"]  = ("Crepusculo", "Twilight"),
            ["demon|fairy"]    = ("Sombra del Bosque", "Forest Shade"),
            ["demon|giant"]    = ("Titan Oscuro", "Dark Titan"),
            ["demon|vampire"]  = ("Devorador Nocturno", "Night Devourer"),
            ["fairy|goddess"]  = ("Luz del Bosque", "Forest Light"),
            ["giant|goddess"]  = ("Titan Sagrado", "Sacred Titan"),
            ["goddess|vampire"]= ("Caliz de Luz", "Chalice of Light"),
            ["fairy|giant"]    = ("Guardian Ancestral", "Ancestral Warden"),
            ["fairy|vampire"]  = ("Espectro del Bosque", "Forest Wraith"),
            ["giant|vampire"]  = ("Devorador Colosal", "Colossal Devourer"),
        };

        private static readonly string[] Order = { "human", "demon", "goddess", "fairy", "giant", "vampire" };

        /// clan hibrido (id del rasgo) -> id del estado de forma.
        private static readonly Dictionary<string, string> _formForHybridClan = new Dictionary<string, string>();

        /// La HABILIDAD que aporta cada raza a la forma de un hibrido. Son las de clan, que
        /// funcionan en cualquiera (Abilities.Tick no exige nombre). El humano no aporta ninguna:
        /// su fuerza es la versatilidad, no un poder concreto.
        private static readonly Dictionary<string, string> _ability = new Dictionary<string, string>
        {
            ["demon"]   = Abilities.Hellblaze,
            ["goddess"] = Abilities.Ark,
            ["fairy"]   = Abilities.Disaster,
            ["giant"]   = Abilities.Creation,
            ["vampire"] = Abilities.Invasion,
        };

        /// Las dos etapas EXTRA de transformacion (mas alla de la primera con nombre). Suben el
        /// poder a lo bestia; se ganan con muchas mas kills. Apilan sobre la forma con nombre.
        public const string Stage2 = "sds_status_hyb_stage2";
        public const string Stage3 = "sds_status_hyb_stage3";

        public static void Init()
        {
            for (int i = 0; i < Order.Length; i++)
                for (int j = i + 1; j < Order.Length; j++)
                    Register(Order[i], Order[j]);

            Stages();
        }

        private static void Stages()
        {
            if (!AssetManager.status.dict.ContainsKey(Stage2))
            {
                StatusAsset s = SDSRegistry.Status(Stage2, "ui/icons/sds_hybrid", 9999f);
                PowerLevel.Grant(s, 800f, 800f, 1000f);
                s.base_stats["health"] = 800f; s.base_stats["damage"] = 60f; s.base_stats["armor"] = 25f;
                s.removed_on_damage = false;
                SDSRegistry.AddStatus(s);
                SDSLocale.Status(Stage2, "Segunda Forma", "La segunda transformacion de un hibrido. Su poder se dobla.");
            }
            if (!AssetManager.status.dict.ContainsKey(Stage3))
            {
                StatusAsset s = SDSRegistry.Status(Stage3, "ui/icons/sds_hybrid", 9999f);
                PowerLevel.Grant(s, 1600f, 1600f, 2000f);
                s.base_stats["health"] = 1600f; s.base_stats["damage"] = 100f; s.base_stats["armor"] = 40f;
                s.removed_on_damage = false;
                SDSRegistry.AddStatus(s);
                SDSLocale.Status(Stage3, "Forma Verdadera", "La forma final de un hibrido. Todo lo que sus dos sangres pueden dar.");
            }
        }

        /// Despierta una etapa de la forma de un hibrido.
        ///   Etapa 1: su forma con NOMBRE + las HABILIDADES de sus dos razas.
        ///   Etapa 2 y 3: transformaciones mas fuertes que apilan encima.
        public static void Awaken(Actor a, string hybridClanId, int stage)
        {
            if (a == null || string.IsNullOrEmpty(hybridClanId)) return;

            if (stage == 1)
            {
                string formId = FormForHybridClan(hybridClanId);
                if (!string.IsNullOrEmpty(formId) && !a.hasStatus(formId))
                    SDSStatus.Inflict(a, formId, 9999f);

                // NADA de heredar las dos habilidades de clan: un hibrido tiene su UNICA habilidad
                // propia (HybridLegacy), concedida al nacer, que no es la suma de dos clanes sino su
                // poder distinto. Aqui solo se despierta su FORMA (el impulso de estadisticas).
            }
            else if (stage == 2 && !a.hasStatus(Stage2))
            {
                SDSStatus.Inflict(a, Stage2, 9999f);
            }
            else if (stage == 3 && !a.hasStatus(Stage3))
            {
                SDSStatus.Inflict(a, Stage3, 9999f);
            }

            // Efecto visual PROPIO de esta forma hibrida (uno por par de clanes, sin reutilizar).
            // El id del clan hibrido es "sds_clan_hybrid_<a>_<b>"; el FX es "sds_fx_hybrid_<a>_<b>".
            string fx = hybridClanId.Replace("sds_clan_hybrid_", "sds_fx_hybrid_");
            SDSFx.At(a, fx, 0.85f);
        }

        private static void GrantClanAbilities(Actor a, string hybridClanId)
        {
            // id = "sds_clan_hybrid_<a>_<b>" -> saca las dos claves.
            string suffix = hybridClanId.Replace("sds_clan_hybrid_", "");
            string[] parts = suffix.Split('_');
            if (parts.Length != 2) return;

            for (int i = 0; i < 2; i++)
            {
                string ab;
                if (_ability.TryGetValue(parts[i], out ab)) SDSTraits.Give(a, ab);
            }

            // Que sus habilidades CORRAN aunque no sea un personaje con nombre.
            SDSUnit.MarkAbilityUser(a);
        }

        private static string Key(string a, string b)
        {
            return string.CompareOrdinal(a, b) < 0 ? a + "|" + b : b + "|" + a;
        }

        private static void Register(string a, string b)
        {
            string key = Key(a, b);
            string formId = "sds_status_form_hyb_" + a + "_" + b;
            string hybridClan = "sds_clan_hybrid_" + a + "_" + b;   // mismo orden que HybridClans

            if (AssetManager.status.dict.ContainsKey(formId)) { _formForHybridClan[hybridClan] = formId; return; }

            Domain da = _domain[a];
            Domain db = _domain[b];

            StatusAsset s = SDSRegistry.Status(formId, "ui/icons/" + hybridClan, 9999f);

            // La SUMA de los dos dominios: aqui se desglosa la hibridez en numeros.
            PowerLevel.Grant(s, da.str + db.str, da.spi + db.spi, da.mag + db.mag);
            s.base_stats["health"] = da.health + db.health;
            if (da.damage + db.damage > 0f) s.base_stats["damage"] = da.damage + db.damage;
            if (da.armor + db.armor > 0f) s.base_stats["armor"] = da.armor + db.armor;
            if (da.speed + db.speed > 0f) s.base_stats["speed"] = da.speed + db.speed;
            if (da.knockback + db.knockback > 0f) s.base_stats["knockback"] = da.knockback + db.knockback;
            s.removed_on_damage = false;

            SDSRegistry.AddStatus(s);

            (string es, string en) nm;
            string nameEs = _name.TryGetValue(key, out nm) ? nm.es : "Forma Hibrida";
            string nameEn = _name.TryGetValue(key, out nm) ? nm.en : "Hybrid Form";
            SDSLocale.Status(formId, nameEs,
                "La forma despierta de un hibrido " + nameEs + ". Reune el poder de sus dos sangres.");
            SDSLocale.Add("status_title_" + formId, nameEs);
            SDSLocale.Add("status_description_" + formId, "La forma despierta de un hibrido. Reune el poder de sus dos sangres.");

            _formForHybridClan[hybridClan] = formId;
        }

        /// La forma que le toca a un hibrido segun su clan hibrido, o null.
        public static string FormForHybridClan(string hybridClanId)
        {
            if (string.IsNullOrEmpty(hybridClanId)) return null;
            string id;
            return _formForHybridClan.TryGetValue(hybridClanId, out id) ? id : null;
        }

        /// La forma que le toca a un par de clanes base (por si se calcula desde los clanes).
        public static string FormForClans(string clanA, string clanB)
        {
            string ka = KeyOf(clanA), kb = KeyOf(clanB);
            if (ka == null || kb == null || ka == kb) return null;
            return FormForHybridClan("sds_clan_hybrid_" + Ordered(ka, kb));
        }

        private static string Ordered(string a, string b)
        {
            // mismo orden que HybridClans: por posicion en Order (human, demon, goddess, ...)
            int ia = System.Array.IndexOf(Order, a), ib = System.Array.IndexOf(Order, b);
            return ia < ib ? a + "_" + b : b + "_" + a;
        }

        private static string KeyOf(string clanTrait)
        {
            if (clanTrait == Clans.Human) return "human";
            if (clanTrait == Clans.Demon) return "demon";
            if (clanTrait == Clans.Goddess) return "goddess";
            if (clanTrait == Clans.Fairy) return "fairy";
            if (clanTrait == Clans.Giant) return "giant";
            if (clanTrait == Clans.Vampire) return "vampire";
            return null;
        }
    }
}
