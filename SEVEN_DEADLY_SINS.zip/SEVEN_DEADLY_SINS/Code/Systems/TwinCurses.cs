using System.Collections.Generic;
using HarmonyLib;
using UnityEngine;

namespace SevenDeadlySins
{
    /// LAS MALDICIONES DE MELIODAS Y ELIZABETH — el corazon de toda la serie.
    ///
    /// El Rey Demonio maldijo a Meliodas con la INMORTALIDAD: no puede morir, y cada vez que cae
    /// vuelve habiendo perdido una emocion mas, con mas rabia, un paso mas cerca de convertirse en su
    /// vaso. La Diosa Suprema maldijo a Elizabeth con la REENCARNACION: muere y vuelve a nacer.
    ///
    /// Y el lazo que las une es la tragedia entera: cada vez que Meliodas VE morir a Elizabeth, su
    /// maldicion se hace mas honda. Ver morir a quien ama, una y otra vez, es lo que empuja a Meliodas
    /// hacia el demonio.
    ///
    /// EL ARREGLO (antes no se disparaba): se engancha la MUERTE de verdad con un prefijo de Harmony
    /// sobre `Actor.die`. Antes se miraba el "borde de la muerte" en el tick, pero una unidad muere de
    /// golpe (vida a 0) antes de que el tick la pille, asi que casi nunca ocurria. El prefijo es
    /// seguro: `die` no hace NADA antes de su cuerpo (lo primero es un guard), asi que devolver false
    /// cancela la muerte por completo; solo hay que devolverle la vida. `pDestroy` (borrar a la fuerza:
    /// el dedo divino, el Purgatorio, los clones) SIEMPRE pasa, para poder quitar a un inmortal cuando
    /// se quiere de verdad.
    public static class TwinCurses
    {
        private const string KeyRage = "sds_curse_rage";        // la rabia/emociones perdidas de Meliodas
        private const string KeyReborn = "sds_curse_reborn";    // cuantas veces ha renacido Elizabeth
        private const string KeyEmotions = "sds_curse_emotions"; // ya se manifestaron sus emociones?
        private const string StatusCurse = "sds_status_curse_wrath";

        /// Las siete emociones que el Rey Demonio le arranca, una por muerte. Al llegar a siete, el
        /// demonio despierta.
        private const int MaxRage = 7;

        public static void Init()
        {
            CurseStatus();
            Main.harmony.PatchAll(typeof(DeathPatch));
            SDSTick.Register(Tick);
        }

        private static void CurseStatus()
        {
            if (AssetManager.status.dict.ContainsKey(StatusCurse)) return;

            StatusAsset s = SDSRegistry.Status(StatusCurse, "ui/icons/" + StatusCurse, 9999f);
            PowerLevel.Grant(s, 2000f, 2000f, 3000f);   // la rabia lo hace mas fuerte, como en el manga
            s.base_stats["damage"] = 30f;
            s.removed_on_damage = false;
            SDSRegistry.AddStatus(s);
            SDSLocale.Status(StatusCurse, "Maldicion del Rey Demonio",
                "Cada muerte le arranca una emocion y le deja mas rabia: el camino hacia el demonio.");
        }

        // ------------------------------------------------ el enganche REAL a la muerte

        [HarmonyPatch(typeof(Actor), nameof(Actor.die))]
        internal static class DeathPatch
        {
            private static bool _busy;

            [HarmonyPrefix]
            public static bool Prefix(Actor __instance, bool pDestroy)
            {
                if (pDestroy || _busy) return true;         // borrado a la fuerza, o reentrada: pasa
                Actor a = __instance;
                if (a == null || a.data == null || !a.isAlive()) return true;
                try
                {
                    _busy = true;
                    if (a.hasTrait(SevenSins.Wrath)) { OnMeliodasDeath(a); return false; }
                    if (a.hasTrait(SevenDeadlySins.Traits.Reincarnation)) { OnElizabethDeath(a); return false; }
                    if (a.hasTrait(SevenDeadlySins.Traits.Immortal)) { OnImmortalDeath(a); return false; }
                }
                catch { }
                finally { _busy = false; }
                return true;
            }
        }

        private static void Restore(Actor a, float frac)
        {
            try { a.data.health = Mathf.Max(1, Mathf.RoundToInt(a.getMaxHealth() * frac)); }
            catch { }
        }

        // ------------------------------------------------ Meliodas: la inmortalidad rabiosa

        private static void OnMeliodasDeath(Actor a)
        {
            Restore(a, 0.5f);
            int rage = Mathf.Min(MaxRage, SDSData.GetInt(a, KeyRage, 0) + 1);
            SDSData.SetInt(a, KeyRage, rage);
            ApplyRage(a, rage);
            SDSFx.At(a, "sds_fx_demon_mark", 0.8f);
            SDSLog.Chronicle(SDSLocale.T(
                a.getName() + " no puede morir: vuelve con mas rabia (" + rage + "/" + MaxRage + ").",
                a.getName() + " cannot die: he returns with more rage (" + rage + "/" + MaxRage + ")."));
        }

        /// La rabia se hace poder: la maldicion visible, luego la Marca del Demonio, y al final —
        /// perdida la ultima emocion — el Modo Asalto, el Rey Demonio despertando en el.
        private static void ApplyRage(Actor a, int rage)
        {
            if (rage >= 1 && !a.hasStatus(StatusCurse)) SDSStatus.Inflict(a, StatusCurse, 9999f);
            if (rage >= 3) SDSStatus.Inflict(a, DemonMark.StatusMark, 9999f);
            if (rage >= MaxRage)
            {
                if (!a.hasStatus(DemonMark.StatusAssault))
                    SDSLog.Chronicle(SDSLocale.T(
                        a.getName() + " ha perdido la ultima emocion. El Rey Demonio despierta en el.",
                        a.getName() + " has lost his last emotion. The Demon King awakens within him."));
                SDSStatus.Inflict(a, DemonMark.StatusAssault, 9999f);
            }
        }

        // ------------------------------------------------ Elizabeth: la reencarnacion, y el lazo

        private static void OnElizabethDeath(Actor a)
        {
            Restore(a, 1f);
            int reborn = SDSData.GetInt(a, KeyReborn, 0) + 1;
            SDSData.SetInt(a, KeyReborn, reborn);
            SDSFx.At(a, "sds_fx_ark", 0.6f);
            SDSFx.At(a, "sds_fx_halo", 0.5f);
            SDSLog.Chronicle(SDSLocale.T(
                a.getName() + " ha muerto, y ha vuelto a nacer (reencarnacion " + reborn + ").",
                a.getName() + " has died, and been born again (reincarnation " + reborn + ")."));

            // EL LAZO TRAGICO. Si Meliodas esta cerca y la ve morir, su maldicion se agrava.
            Actor mel = NearestWrath(a, 24f);
            if (mel != null && mel.data != null)
            {
                int rage = Mathf.Min(MaxRage, SDSData.GetInt(mel, KeyRage, 0) + 1);
                SDSData.SetInt(mel, KeyRage, rage);
                ApplyRage(mel, rage);
                SDSFx.At(mel, "sds_fx_demon_mark", 0.7f);
                SDSLog.Chronicle(SDSLocale.T(
                    mel.getName() + " ha visto morir a " + a.getName()
                        + " otra vez. La maldicion se hace mas honda (" + rage + "/" + MaxRage + ").",
                    mel.getName() + " watched " + a.getName()
                        + " die again. The curse deepens (" + rage + "/" + MaxRage + ")."));
            }
        }

        // ------------------------------------------------ Ban y los dioses: inmortalidad simple

        private static void OnImmortalDeath(Actor a)
        {
            Restore(a, 0.5f);
            SDSFx.At(a, "sds_fx_heal", 0.4f);
            // Sin cronica en cada golpe: simplemente no mueren.
        }

        // ------------------------------------------------ mantenimiento

        private static void Tick(Actor a, float dt)
        {
            if (a == null || !a.isAlive() || a.data == null) return;

            // Mantener vivos los estados de rabia de Meliodas por si caducan.
            if (a.hasTrait(SevenSins.Wrath))
            {
                int rage = SDSData.GetInt(a, KeyRage, 0);
                if (rage > 0 && SDSData.TryUse(a, "curse_upkeep", 12f)) ApplyRage(a, rage);

                // LAS EMOCIONES PERDIDAS. Cuando el demonio despierta del todo (rabia 7), las
                // emociones que el Rey Demonio le arranco toman cuerpo a su alrededor, como en el
                // manga. Una sola vez por Meliodas. Se hace en el tick, no en el parche de muerte.
                if (rage >= MaxRage && !SDSData.GetBool(a, KeyEmotions))
                {
                    SDSData.SetBool(a, KeyEmotions, true);
                    ManifestLostEmotions(a);
                }
            }
        }

        /// Las Emociones Perdidas de Meliodas cobran cuerpo (Actors.LostEmotion, un actor que YA
        /// existe — spawnear uno registrado es seguro, es lo que hace Legends). Fragmentos de lo que
        /// era, peligrosos porque cada uno guarda un pedazo de su poder.
        private static void ManifestLostEmotions(Actor a)
        {
            try
            {
                WorldTile tile = a.current_tile;
                if (tile == null) return;
                for (int i = 0; i < 3; i++)
                {
                    Actor e = null;
                    try { e = World.world.units.spawnNewUnit(Actors.LostEmotion, tile, pSpawnSound: false, pMiracleSpawn: true, pAdultAge: true); }
                    catch { }
                    if (e != null) SDSFx.At(e, "sds_fx_soul", 0.6f);
                }
                SDSFx.At(a, "sds_fx_demon_king", 0.9f);
                SDSLog.Chronicle(SDSLocale.T(
                    "Las emociones que el Rey Demonio le arranco a " + a.getName() + " toman cuerpo.",
                    "The emotions the Demon King tore from " + a.getName() + " take form."));
            }
            catch { }
        }

        private static Actor NearestWrath(Actor a, float radius)
        {
            List<Actor> near = SDSUnit.Around(a, radius);
            for (int i = 0; i < near.Count; i++)
            {
                Actor o = near[i];
                if (o != null && o.isAlive() && o != a && o.hasTrait(SevenSins.Wrath)) return o;
            }
            return null;
        }
    }
}
