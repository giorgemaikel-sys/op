using HarmonyLib;
using UnityEngine;

namespace SevenDeadlySins
{
    /// Red de seguridad del renderizado de edificios.
    ///
    /// CADENA DEL FALLO: si la lista de sprites de un edificio esta vacia,
    /// Building.calculateMainSprite devuelve null, y calculateColoredSprite se lo pasa a
    /// DynamicSprites.getRecoloredBuilding, que llama GetHashCode() sobre ese null. Resultado: una
    /// NullReferenceException por edificio y POR FRAME. Novecientas por partida, y el juego pegado.
    ///
    /// Esta guarda no arregla el arte que falte: hace que un fotograma sin sprite no se dibuje en vez
    /// de lanzar. Un edificio invisible durante un frame se recalcula al siguiente; una excepcion por
    /// frame no se recupera nunca.
    ///
    /// Es defensa GENERAL a proposito — cubre tambien un despliegue incompleto o un edificio de otro
    /// mod. AncientWarfare tiene este mismo parche por la misma razon y su comentario cita el mismo
    /// numero de excepciones que yo media.
    [HarmonyPatch]
    public static class BuildingSpriteGuard
    {
        [HarmonyPrefix]
        [HarmonyPatch(typeof(Building), nameof(Building.calculateColoredSprite))]
        public static bool CalculateColoredSprite_Prefix(Building __instance, Sprite pMainSprite,
                                                         ref Sprite __result)
        {
            if (pMainSprite == null || __instance == null || __instance.asset == null
                || __instance.asset.atlas_asset == null)
            {
                __result = null;
                return false;      // salta el metodo original
            }
            return true;
        }

        /// La guarda de verdad, y la que hacia falta.
        ///
        /// El prefix de arriba protege el coloreado, pero la excepcion que llenaba el log salia
        /// DENTRO de calculateMainSprite, antes de que llegara a devolver nada. Un finalizer de
        /// Harmony corre despues del metodo original y puede TRAGARSE lo que haya lanzado: se
        /// devuelve null, el renderizador no dibuja ese edificio ese frame, y al siguiente lo
        /// reintenta con la textura ya cargada.
        ///
        /// Es una red, no una excusa: si un edificio no tiene arte hay que darselo. Lo que esto
        /// garantiza es que la falta de una textura cueste un fotograma en blanco y no una partida
        /// congelada a dos mil excepciones por minuto.
        [HarmonyFinalizer]
        [HarmonyPatch(typeof(Building), nameof(Building.calculateMainSprite))]
        public static System.Exception CalculateMainSprite_Finalizer(System.Exception __exception,
                                                                     ref Sprite __result)
        {
            if (__exception == null) return null;
            __result = null;
            return null;      // suprime la excepcion
        }
    }

    /// One architecture per clan, so every people of Britannia builds its own kingdoms.
    ///
    /// THE TIMING TRAP, which is the whole reason this file is long:
    /// ArchitectureLibrary.loadAutoBuildingsForAsset and BuildingLibrary.initBuildingsFromArchitectures
    /// both run during the game's own init, BEFORE any mod's OnModLoad. An architecture cloned here is
    /// therefore never processed by them, so both passes have to be replicated by hand — first
    /// re-keying the construction orders onto our building ids, then cloning a building for each order.
    ///
    /// Three things in here will crash the game every frame if they are dropped. They are marked
    /// individually below. All three are taken from AncientWarfare's Xia architecture, which is a
    /// working implementation of exactly this on this build of the game.
    ///
    /// BUILDING ART: none of our own. The buildings keep the human `main_path`, so a Fairy hall looks
    /// like a human hall. That is deliberate for now — a full set is roughly a hundred sprites per
    /// clan, and a missing one is not a blank wall but a null sprite the renderer dereferences every
    /// frame. What differs per clan is everything the architecture asset controls: material,
    /// flammability, acid resistance, and which biome the kingdom spreads.
    public static class Architecture
    {
        private const string From = "human";

        /// clan trait id -> architecture id.
        ///
        /// LA ARQUITECTURA SE LLAMA IGUAL QUE LA RAZA, y no es cosmetico.
        ///
        /// Cada edificio generado guarda `civ_kingdom = <id de arquitectura>` y
        /// `kingdom = "nomads_" + <id de arquitectura>`. Con ids propios tipo "sds_arch_goddess",
        /// esos campos apuntaban a los reinos "sds_arch_goddess" y "nomads_sds_arch_goddess", que no
        /// existen — los reinos que registra Kingdoms.cs se llaman "sds_goddess" y
        /// "nomads_sds_goddess". Los edificios quedaban colgando de un reino inexistente y por eso
        /// los pueblos no levantaban nada.
        ///
        /// Compartiendo el id, los tres nombres encajan solos.
        public static string Of(string clanTrait)
        {
            if (!OwnBuildings) return From;

            switch (clanTrait)
            {
                case Clans.Demon: return Actors.Demon;
                case Clans.Goddess: return Actors.Goddess;
                case Clans.Fairy: return Actors.Fairy;
                case Clans.Giant: return Actors.Giant;
                case Clans.Vampire: return Actors.Vampire;
                default: return From;
            }
        }

        /// ENCENDIDO. El arte nunca fue el problema.
        ///
        /// Perseguí durante días un sprite que no cargaba, y no había ningún sprite sin cargar. La
        /// excepción de verdad estaba tres llamadas más arriba y decía exactamente lo que pasaba:
        ///
        ///     KeyNotFoundException: The given key 'stone' was not present in the dictionary.
        ///     Building.setMaterial -> Building.checkMaterial -> Building.setState -> Building.setBuilding
        ///
        /// `BuildingAsset.material` no es "de qué está hecho". Es el nombre de un Material de Unity,
        /// y `setMaterial` lo mete como clave cruda en `LibraryMaterials.instance.dict`. Le estaba
        /// pasando "stone" y "wood", que no son claves de nada.
        ///
        /// Y lo que lo volvía indescifrable es DÓNDE revienta. `setBuilding` llama a `setState`
        /// —que es quien acaba en setMaterial— ANTES de llamar a `initAnimationData()`. Al lanzar,
        /// setBuilding se aborta a medias: el edificio queda colocado en el mundo pero con
        /// `animData` en null, porque la línea que lo asigna nunca llegó a ejecutarse. Entonces
        /// `calculateMainSprite` hace `animData.main` sobre null y lanza NullReference por frame.
        ///
        /// De ahí las tres oleadas de excepciones, todas hijas de la misma línea:
        ///   1. NullReference en calculateMainSprite      (animData es null)
        ///   2. NullReference en getShadowBuilding        (mi finalizer devolvía null, y la sombra
        ///                                                 se construye a partir de ese sprite)
        ///   3. NullReference en GroupSpriteObject.setSharedMat  (Building.material también quedó
        ///                                                 sin asignar, por el mismo abort)
        ///
        /// Los PNG de gen_world.py estaban bien desde el principio, en la ruta correcta y con el
        /// nombre correcto. `setTemplate` —que es quien llama a checkSpritesAreLoaded()— corre
        /// ANTES del throw, así que las texturas sí se cargaban. Se cargaban y no las miraba nadie.
        private const bool OwnBuildings = true;

        public static void Init()
        {
            // La guarda va SIEMPRE, incluso si no generamos arquitectura propia: protege tambien
            // contra edificios de otros mods a los que les falte una textura.
            try { Main.harmony.PatchAll(typeof(BuildingSpriteGuard)); }
            catch (System.Exception e) { SDSLog.Error("guarda de sprites de edificio: " + e.Message); }

            // LOS PUEBLOS CONSTRUYEN CON LA ARQUITECTURA HUMANA, y esto es una decision, no un olvido.
            //
            // Generar una arquitectura por raza funcionaba: en cuanto los ids encajaron, las ciudades
            // empezaron a levantar edificios propios. Y entonces el juego reventaba 6.000 veces por
            // partida en Building.calculateMainSprite, porque un edificio resuelve su sprite como
            // main_path + su id, y "house_sds_goddess_0" no tiene arte en ninguna carpeta.
            //
            // Las opciones eran dibujar diecinueve edificios por raza — con sus fotogramas de obra y
            // de ruina, casi cien sprites — o que construyan con arte que existe. Un pueblo que
            // levanta aldeas humanas es un mod que funciona; uno que levanta aldeas invisibles y
            // tumba el juego, no.
            //
            // Todo el codigo de generacion sigue aqui y probado. Cuando exista el arte, basta poner
            // OwnBuildings en true y colocar los PNG en buildings/civ_main/<id de raza>/.
            if (!OwnBuildings) return;

            if (AssetManager.architecture_library.get(From) == null)
            {
                SDSLog.Warn("no existe la arquitectura 'human'; las razas construiran como humanos.");
                return;
            }

            // OJO CON `material`: NO es "de que esta hecho el edificio". Es el NOMBRE DE UN MATERIAL
            // DE UNITY (un shader), y el juego lo usa como clave directa:
            //     Building.setMaterial -> LibraryMaterials.instance.dict[pMaterialID]
            // Las unicas claves que existen para edificios son "building" (la de por defecto),
            // "jelly", "tree" y "tree_celestial". Pasar "stone" o "wood" tira KeyNotFoundException
            // y aborta setBuilding a medias — ver el comentario de Build().
            //
            // Lo que de verdad distingue a cada clan es burnable/acid, que son campos aparte.

            // Demons: no arde — Purgatorio ya esta en llamas.
            Build(Actors.Demon, Mat, burnable: false, acid: false);

            // The Goddess Clan.
            Build(Actors.Goddess, Mat, burnable: false, acid: false);

            // Fairies build from the forest itself, and it burns.
            Build(Actors.Fairy, Mat, burnable: true, acid: true);

            // Giants carve their halls out of the mountain.
            Build(Actors.Giant, Mat, burnable: false, acid: false);

            // Vampires.
            Build(Actors.Vampire, Mat, burnable: false, acid: true);
        }

        /// El unico material de render valido para un edificio normal.
        ///
        /// `BuildingAsset.material` viaja hasta `LibraryMaterials.instance.dict[...]`, un diccionario
        /// de Materials de Unity cuyas claves salen de los assets en Resources/materials/. Vale
        /// "building", "jelly", "tree" y "tree_celestial"; nada mas. El vanilla usa "building" en
        /// todos los edificios civiles y "jelly" solo para los slime.
        private const string Mat = "building";

        private static void Build(string id, string material, bool burnable, bool acid)
        {
            try
            {
                if (AssetManager.architecture_library.get(id) != null) return;

                ArchitectureAsset arch = AssetManager.architecture_library.clone(id, From);
                if (arch == null) return;

                arch.generate_buildings = true;
                arch.generation_target = From;
                arch.material = material;
                arch.burnable_buildings = burnable;
                arch.acid_affected_buildings = acid;

                RekeyOrders(arch);

                // shared orders go into the same dictionary — this is what the game's own
                // initBuildingKeys does, and skipping it leaves those orders unresolvable.
                if (arch.shared_building_orders != null)
                {
                    foreach (var pair in arch.shared_building_orders)
                        arch.addBuildingOrderKey(pair.Item1, pair.Item2);
                }

                int made = GenerateBuildings(arch);
                SDSLog.Info("arquitectura '" + id + "': " + made + " edificios");
            }
            catch (System.Exception e)
            {
                SDSLog.Error("arquitectura '" + id + "': " + e.Message);
            }
        }

        /// Maps each styled order onto OUR building id, copying the game's own naming rules.
        ///
        /// Without this the cloned dictionary still points at the *_human buildings, so the clan
        /// would build human houses under a different label and nothing else would differ.
        private static void RekeyOrders(ArchitectureAsset arch)
        {
            if (arch.styled_building_orders == null) return;
            string id = arch.id;

            foreach (string order in arch.styled_building_orders)
            {
                string newId = null;
                switch (order)
                {
                    case "order_tent": newId = "tent_" + id; break;
                    case "order_house_0":
                    case "order_house_1":
                    case "order_house_2":
                    case "order_house_3":
                    case "order_house_4":
                    case "order_house_5":
                        newId = "house_" + id + "_" + order.Substring(order.Length - 1); break;
                    case "order_hall_0":
                    case "order_hall_1":
                    case "order_hall_2":
                        newId = "hall_" + id + "_" + order.Substring(order.Length - 1); break;
                    case "order_windmill_0":
                    case "order_windmill_1":
                        newId = "windmill_" + id + "_" + order.Substring(order.Length - 1); break;
                    case "order_docks_0": newId = "fishing_docks_" + id; break;
                    case "order_docks_1": newId = "docks_" + id; break;
                    case "order_watch_tower": newId = "watch_tower_" + id; break;
                    case "order_temple": newId = "temple_" + id; break;
                    case "order_library": newId = "library_" + id; break;
                    case "order_market": newId = "market_" + id; break;
                    case "order_barracks": newId = "barracks_" + id; break;
                }
                if (newId != null) arch.addBuildingOrderKey(order, newId);
            }
        }

        /// Clones a building per order from the human source. Replicates initBuildingsFromArchitectures.
        private static int GenerateBuildings(ArchitectureAsset arch)
        {
            if (arch.styled_building_orders == null) return 0;

            ArchitectureAsset source = AssetManager.architecture_library.get(arch.generation_target);
            if (source == null) return 0;

            int made = 0;

            string archId = arch.id;

            foreach (string order in arch.styled_building_orders)
            {
                if (!arch.building_ids_for_construction.ContainsKey(order)) continue;

                string newId = arch.building_ids_for_construction[order];
                BuildingAsset src = source.getBuilding(order);
                if (src == null) continue;

                BuildingAsset b = AssetManager.buildings.clone(newId, src.id);
                if (b == null) continue;
                made++;

                b.group = "civ_building";
                b.mini_civ_auto_load = true;
                b.civ_kingdom = archId;
                b.kingdom = "nomads_" + archId;
                b.has_sprite_construction = true;

                // DONDE ESTA EL ARTE. Sin esta linea el edificio hereda el main_path del humano y el
                // juego busca "buildings/civ_main/human/house_sds_fairy_0/", que no existe — y
                // Building.calculateMainSprite lanza NullReference en cada frame que intente
                // dibujarlo. El arte de cada raza vive en su propia carpeta.
                b.main_path = "buildings/civ_main/" + archId + "/";

                // Y `main_path` NO BASTA. BuildingAsset.loadBuildingSpriteList hace:
                //     var p = sprite_path;  if (string.IsNullOrEmpty(p)) p = main_path + id;
                // O sea: si `sprite_path` viene con algo, main_path se ignora entero. El vanilla se
                // lo pone a fishing_docks_human ("buildings/civ_general/fishing_dock"), asi que el
                // clon lo hereda y nuestro embarcadero saldria con el arte generico del juego,
                // ignorando el nuestro en silencio. Vaciarlo devuelve el control a main_path.
                b.sprite_path = string.Empty;

                // CRASH GUARD 1 — the upgrade chain still points at *_human after the clone. Left
                // alone, a Fairy house upgrades into a human building id that has no entry here.
                if (!string.IsNullOrEmpty(b.upgrade_to))
                    b.upgrade_to = b.upgrade_to.Replace("_" + From, "_" + archId);
                if (!string.IsNullOrEmpty(b.upgraded_from))
                    b.upgraded_from = b.upgraded_from.Replace("_" + From, "_" + archId);

                if (arch.spread_biome)
                {
                    b.spread_biome = true;
                    b.spread_biome_id = arch.spread_biome_id;
                }

                b.material = arch.material;
                b.shadow = arch.has_shadows;
                b.burnable = arch.burnable_buildings;
                b.affected_by_acid = arch.acid_affected_buildings;

                // CRASH GUARD 2 — the real one. The game binds atlas_asset for every building during
                // post_init, which has already happened by the time a mod runs. A building created
                // afterwards keeps atlas_asset null, and the renderer dereferences it EVERY FRAME:
                // calculateColoredSprite -> getRecoloredBuilding(null) -> null reference, forever.
                b.atlas_asset = AssetManager.dynamic_sprites_library.get(b.atlas_id)
                                ?? AssetManager.dynamic_sprites_library.get("buildings");

                switch (order)
                {
                    case "order_tent": b.fundament = new BuildingFundament(2, 2, 2, 0); break;
                    case "order_hall_0": b.fundament = new BuildingFundament(3, 3, 4, 0); break;
                    case "order_temple": b.fundament = new BuildingFundament(2, 2, 3, 0); break;
                    case "order_library": b.fundament = new BuildingFundament(2, 2, 2, 0); break;
                    case "order_watch_tower": b.fundament = new BuildingFundament(1, 1, 1, 0); break;
                    case "order_windmill_0":
                        b.fundament = new BuildingFundament(2, 2, 2, 0);
                        if (b.shadow) b.setShadow(0.4f, 0.38f, 0.47f);
                        break;
                    case "order_docks_0":
                        b.upgrade_to = "docks_" + archId;
                        b.can_be_upgraded = true;
                        break;
                    case "order_docks_1":
                        b.upgraded_from = "fishing_docks_" + archId;
                        b.upgrade_to = string.Empty;
                        b.can_be_upgraded = false;
                        b.has_sprites_main_disabled = false;
                        break;
                }

                // CRASH GUARD 3 — the vanilla docks clone leaves upgrade_to pointing at itself.
                // CityBehBuild.haveRequiredBuildings follows that chain and never terminates.
                if (b.upgrade_to == b.id)
                {
                    b.upgrade_to = string.Empty;
                    b.can_be_upgraded = false;
                }
            }

            return made;
        }
    }
}
