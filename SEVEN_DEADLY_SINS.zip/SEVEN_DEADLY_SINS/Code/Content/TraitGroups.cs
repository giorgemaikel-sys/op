namespace SevenDeadlySins
{
    /// One group per axis of identity, so the trait browser reads like a codex instead of a pile.
    ///
    ///   Clanes        the six bloodlines: Human, Demon, Goddess, Fairy, Giant, Vampire
    ///   Magia         the five kinds of magic; every caster has exactly one
    ///   Rangos        the Holy Knight ladder, Apprentice -> Grand Master
    ///   Pecados       the Seven Deadly Sins
    ///   Mandamientos  the Ten Commandments and their curses
    ///   Habilidades   the named techniques: Full Counter, Snatch, Sunshine, Hellblaze, Ark...
    public static class TraitGroups
    {
        public const string Clans = "sds_group_clans";
        public const string Sins = "sds_group_sins";
        public const string Commandments = "sds_group_commandments";
        public const string Magic = "sds_group_magic";
        public const string Ranks = "sds_group_ranks";
        // "Habilidades" era un cajon de sastre con casi cincuenta rasgos dentro: los poderes de los
        // Pecados, las gracias de las Diosas, la llama del Rey Demonio, las magias de clase de
        // cualquier aldeano y los linajes de sangre, todo revuelto. Separado por lo que CADA COSA ES.
        public const string Abilities = "sds_group_abilities";     // se conserva por compatibilidad
        public const string SinPowers = "sds_group_sin_powers";
        public const string Grace = "sds_group_grace";
        public const string Demonic = "sds_group_demonic";
        public const string ClassMagic = "sds_group_class";
        public const string KnightMagic = "sds_group_knight";
        public const string Arcane = "sds_group_arcane";
        public const string Bloodline = "sds_group_bloodline";

        public static readonly string[] All =
        {
            Clans, Magic, Ranks, Sins, Commandments,
            SinPowers, Grace, Demonic, Arcane, KnightMagic, ClassMagic, Bloodline,
        };

        /// Groups appear in the trait browser in the order they are registered, so this order IS the
        /// layout of the browser. It reads as a life in Britannia rather than as the order the
        /// systems happened to be written in:
        ///
        ///   WHAT YOU ARE BORN AS  — the clan, and the magic that runs in you
        ///   WHAT YOU EARN         — the Holy Knight rank you fight your way up to
        ///   WHAT YOU BECOME       — a Sin, or a Commandment
        ///   WHAT YOU CAN DO       — the techniques those titles come with
        public static void Init()
        {
            Add(Clans, "Clanes", "#4FA3D1");
            Add(Magic, "Tipos de Magia", "#3FBFA8");
            Add(Ranks, "Caballeros Sagrados", "#E8C34A");
            Add(Sins, "Los Siete Pecados Capitales", "#D94A3D");
            Add(Commandments, "Los Diez Mandamientos", "#7B3FA0");

            //   LO QUE PUEDES HACER — ordenado de lo mas raro a lo mas comun, que es como se lee
            //   una enciclopedia: primero los siete poderes que solo tiene una persona cada uno,
            //   al final las magias que puede aprender cualquier aldeano.
            Add(SinPowers, "Poderes de los Pecados", "#E07B2A");
            Add(Grace, "Gracias de las Diosas", "#F2D06B");
            Add(Demonic, "Poderes Demoniacos", "#8E2436");
            Add(Arcane, "Hechizos Arcanos", "#8E5BC4");
            Add(KnightMagic, "Magias de Caballero", "#5B8FD1");
            Add(ClassMagic, "Magias de Clase", "#4FB073");
            Add(Bloodline, "Linajes y Dones", "#B07A4F");
        }

        /// The game runs a group's `name` through the localisation table, so it must be a KEY, not the
        /// text itself. A group whose name is Spanish text mapped to itself shows that same Spanish to
        /// an English player forever; the key is `<group>_name` and both languages live in SDSLocale.
        private static void Add(string id, string es, string color)
        {
            string nameKey = id + "_name";
            SDSLocale.Add(nameKey, es);

            if (AssetManager.trait_groups.dict.ContainsKey(id)) return;

            ActorTraitGroupAsset group = new ActorTraitGroupAsset();
            group.id = id;
            group.name = nameKey;
            group.color = color;
            AssetManager.trait_groups.add(group);
        }
    }
}
