namespace SevenDeadlySins
{
    /// Every projectile the mod fires. Ids match what MagicTypes, Abilities and the Sacred Treasures
    /// expect, so renaming one here breaks them — they are referenced by string.
    public static class Projectiles
    {
        public const string Ark = "sds_proj_ark";
        public const string Magic = "sds_proj_magic";
        public const string Hellblaze = "sds_proj_hellblaze";
        public const string Chastiefol = "sds_proj_chastiefol";
        public const string Creation = "sds_proj_creation";
        public const string Herritt = "sds_proj_herritt";

        public static void Init()
        {
            // Ark: the Goddess Clan's light. Unblockable — it is not a thrown object, it is judgement.
            ProjectileAsset ark = New(Ark, "sds_proj_ark", 26f, 0.09f);
            ark.can_be_blocked = false;
            ark.draw_light_area = true;
            ark.draw_light_size = 0.25f;
            SDSRegistry.AddProjectile(ark);

            // The plain bolt any Incantation caster throws. Blockable: it is ordinary magic.
            ProjectileAsset magic = New(Magic, "sds_proj_magic", 24f, 0.075f);
            magic.can_be_blocked = true;
            SDSRegistry.AddProjectile(magic);

            // Hellblaze: black flame. Nothing stops it and it lights the ground it crosses.
            ProjectileAsset hell = New(Hellblaze, "sds_proj_hellblaze", 22f, 0.1f);
            hell.can_be_blocked = false;
            hell.draw_light_area = true;
            hell.draw_light_size = 0.3f;
            hell.end_effect = "sds_fx_hellblaze";
            SDSRegistry.AddProjectile(hell);

            // Chastiefol. A spirit spear thrown by the Fairy King, so it is heavy and it shakes.
            ProjectileAsset spear = New(Chastiefol, "sds_proj_chastiefol", 20f, 0.13f);
            spear.can_be_blocked = false;
            spear.hit_shake = true;
            SDSRegistry.AddProjectile(spear);

            // Creation: a thrown rock. Slow, blockable, and it hits like a rock.
            ProjectileAsset rock = New(Creation, "sds_proj_creation", 16f, 0.11f);
            rock.can_be_blocked = true;
            rock.hit_shake = true;
            SDSRegistry.AddProjectile(rock);

            // Herritt, Gowther's twin bow. Fast and light.
            ProjectileAsset arrow = New(Herritt, "sds_proj_herritt", 30f, 0.06f);
            arrow.can_be_blocked = true;
            SDSRegistry.AddProjectile(arrow);
        }

        /// The shared shape of every projectile here. Shadow and sounds are borrowed from the vanilla
        /// arrow so they always resolve, whatever the build.
        private static ProjectileAsset New(string id, string texture, float speed, float scale)
        {
            ProjectileAsset p = new ProjectileAsset();
            p.id = id;
            p.speed = speed;
            p.texture = texture;
            p.look_at_target = true;
            p.texture_shadow = "shadows/projectiles/shadow_arrow";
            p.scale_start = scale;
            p.scale_target = scale;
            p.sound_launch = "event:/SFX/WEAPONS/WeaponStartArrow";
            p.sound_impact = "event:/SFX/HIT/HitGeneric";
            p.can_be_collided = true;
            return p;
        }
    }
}
