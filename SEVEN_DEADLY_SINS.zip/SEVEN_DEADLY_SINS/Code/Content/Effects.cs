using System.Collections.Generic;

namespace SevenDeadlySins
{
    /// The mod's visual vocabulary. Every effect below is an animated sprite folder under
    /// GameResources/effects/&lt;id&gt;/, named after the effect id itself so the sprite generator and the
    /// code can never drift apart.
    ///
    /// Registration only writes an EffectAsset with a sprite PATH — no sprite is touched here. Loading
    /// the frames during OnModLoad would poison SpriteTextureLoader's cache with empty arrays for the
    /// whole session (DESIGN.md invariant 4); the game reads the path on the first real spawn.
    public static class Effects
    {
        // --- clan and shared techniques ------------------------------------------------------
        public const string Hellblaze = "sds_fx_hellblaze";     // the Demon Clan's black flame
        public const string Ark = "sds_fx_ark";                 // the Goddess Clan's light
        public const string Purge = "sds_fx_purge";             // Mael's white flame
        public const string DemonMark = "sds_fx_demon_mark";    // the mark crawling over the skin

        // --- the Seven Deadly Sins ------------------------------------------------------------
        public const string FullCounter = "sds_fx_full_counter"; // Meliodas reflects the blow
        public const string Snatch = "sds_fx_snatch";            // Ban takes what is not his
        public const string Creation = "sds_fx_creation";        // Diane reshapes the ground
        public const string Sunshine = "sds_fx_sunshine";        // Escanor's daylight
        public const string Chastiefol = "sds_fx_chastiefol";    // King's spirit spear landing
        public const string Herritt = "sds_fx_herritt";          // Gowther's twin bow

        // --- transformations -------------------------------------------------------------------
        public const string AssaultMode = "sds_fx_assault_mode"; // Meliodas unsealed
        public const string TheOne = "sds_fx_the_one";           // Escanor at noon
        public const string Infinity = "sds_fx_infinity";        // Merlin's endless spell
        public const string Indura = "sds_fx_indura";            // a demon that burned out

        // --- the Ten Commandments ---------------------------------------------------------------
        /// One shared flash for all ten punishments: the curse is announced by its own status icon,
        /// and ten near-identical purple bursts would cost ten sprite folders for nothing.
        public const string Curse = "sds_fx_curse";

        // --- auras persistentes de clan ---------------------------------------------------------
        /// Las alas de las hadas y el halo de las diosas. No son ataques: se repiten en bucle sobre
        /// la unidad para que se VEA de que clan es sin tener que abrir su ficha.
        public const string Wings = "sds_fx_wings";
        public const string Halo = "sds_fx_halo";

        public static readonly List<string> Ids = new List<string>();

        public static void Init()
        {
            Ids.Clear();

            Add(Hellblaze, 0.06f);      // slow, heavy black fire
            Add(Ark, 0.05f);
            Add(Purge, 0.05f);
            Add(DemonMark, 0.07f);      // the mark creeps rather than flickers

            Add(FullCounter, 0.035f);   // fastest of the set: it must read as an instant riposte
            Add(Snatch, 0.05f);
            Add(Creation, 0.06f);
            Add(Sunshine, 0.05f);
            Add(Chastiefol, 0.045f);
            Add(Herritt, 0.04f);

            Add(AssaultMode, 0.06f);
            Add(TheOne, 0.05f);
            Add(Infinity, 0.07f);
            Add(Indura, 0.08f);         // slowest: a lumbering beast

            Add(Curse, 0.055f);

            Add(Wings, 0.05f);
            Add(Halo, 0.05f);

            // FX PROPIOS de cada hibrido, sin reutilizar. Registrar solo escribe la RUTA
            // "effects/<id>/"; el sprite lo genera gen_sprites aparte. Las claves DEBEN coincidir:
            //   - Legado: SinLegacy usa "sds_fx_legacy_" + Key(codigos de 2 letras, ORDINAL-sorted).
            //   - Hibridos: HybridForms deriva "sds_fx_hybrid_<a>_<b>" del id del clan hibrido
            //     (claves de clan en el orden de HybridClans.Bases).
            string[] sinCodes = { "wr", "gr", "en", "lu", "sl", "gl", "pr" };
            for (int i = 0; i < sinCodes.Length; i++)
                for (int j = i + 1; j < sinCodes.Length; j++)
                {
                    string ca = sinCodes[i], cb = sinCodes[j];
                    string key = string.CompareOrdinal(ca, cb) <= 0 ? ca + "_" + cb : cb + "_" + ca;
                    Add("sds_fx_legacy_" + key, 0.05f);
                }

            string[] clanKeys = { "human", "demon", "goddess", "fairy", "giant", "vampire" };
            for (int i = 0; i < clanKeys.Length; i++)
                for (int j = i + 1; j < clanKeys.Length; j++)
                    Add("sds_fx_hybrid_" + clanKeys[i] + "_" + clanKeys[j], 0.06f);
        }

        /// The sprite folder is always "effects/&lt;id&gt;/". Deriving it from the id instead of passing it
        /// in is what guarantees an effect can never point at another effect's art.
        private static void Add(string id, float frameTime)
        {
            SDSRegistry.Effect(id, "effects/" + id + "/", frameTime);
            if (!Ids.Contains(id)) Ids.Add(id);
        }
    }
}
