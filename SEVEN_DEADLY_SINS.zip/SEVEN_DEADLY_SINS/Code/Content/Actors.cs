using HarmonyLib;
using UnityEngine;

namespace SevenDeadlySins
{
    /// THE FIX FOR THE 10.000 NullReferenceException FREEZE.
    ///
    /// World.world.kingdoms_wild is a RUNTIME manager, not an asset library. Its constructor
    /// (MapBox.Awake) walks AssetManager.kingdoms.list ONCE and builds one Kingdom instance per
    /// asset — and it is the only caller of newWildKingdom in the whole game. NeoModLoader runs
    /// OnModLoad long after that Awake, so every kingdom this mod registers exists as an ASSET but
    /// never as a live Kingdom.
    ///
    /// Result: MapBox.finalizeActor -> Actor.checkDefaultKingdom -> setDefaultKingdom does
    ///     setKingdom(World.world.kingdoms_wild.get(asset.kingdom_id_wild))
    /// which returns null for "nomads_sds_*", and setKingdom stores the null without complaint.
    /// From the next frame on, ActorManager.prepareForMetaChecks (actor.kingdom.wild) and
    /// ChunkObjectContainer.addActor (pActor.kingdom.id) throw once per unit per frame.
    ///
    /// setDefaultKingdom is the single choke point every spawn path goes through, and World.world
    /// is guaranteed to exist by then, so the missing Kingdom is built here on demand.
    [HarmonyPatch(typeof(Actor), nameof(Actor.setDefaultKingdom))]
    internal static class WildKingdomBackfill
    {
        [HarmonyPrefix]
        public static void Prefix(Actor __instance)
        {
            if (__instance == null || __instance.asset == null) return;

            string wildId = __instance.asset.kingdom_id_wild;
            if (string.IsNullOrEmpty(wildId)) return;

            WildKingdomsManager wild = World.world != null ? World.world.kingdoms_wild : null;
            if (wild == null || wild.get(wildId) != null) return;

            KingdomAsset asset = AssetManager.kingdoms.get(wildId);
            if (asset == null) return;

            // createWildKingdom() dereferences this. KingdomLibrary.post_init fills a shared grey in
            // for any null, but post_init ran before this mod existed, so nothing back-fills ours.
            if (asset.default_kingdom_color == null)
                asset.default_kingdom_color = ColorAsset.tryMakeNewColorAsset("#888888");

            wild.newWildKingdom(asset);
            SDSLog.Info("reino salvaje '" + wildId + "' no existia en kingdoms_wild; creado en caliente.");
        }
    }

    /// The peoples of Britannia, and the things that are not people.
    ///
    /// TWO KINDS OF ACTOR, and the split is deliberate:
    ///
    /// - A CLAN is a race. It is a recoloured human with its own architecture, so a Fairy village is
    ///   founded, built and inhabited by Fairies. Cloning "human" is what gets them villages, jobs,
    ///   families and ageing for free — and, just as importantly, keeps them selectable.
    ///
    /// - A NAMED CHARACTER is not a race. Meliodas is a human being who happens to carry the Wrath;
    ///   Ludociel is a Goddess who happens to be an Archangel. They spawn as plain humans and are
    ///   defined entirely by their traits, because inventing a one-off body for one person means
    ///   maintaining a whole actor asset to say something a trait already says.
    ///
    /// Creatures are the third case: an Indura is not a person and must not look like one.
    public static class Actors
    {
        // --- the five non-human peoples ----------------------------------------
        public const string Demon = "sds_demon";
        public const string Goddess = "sds_goddess";
        public const string Fairy = "sds_fairy";
        public const string Giant = "sds_giant";
        public const string Vampire = "sds_vampire";

        // --- creatures ----------------------------------------------------------
        public const string GrayDemon = "sds_gray_demon";
        public const string RedDemon = "sds_red_demon";
        public const string Indura = "sds_indura";
        public const string BlueDemon = "sds_blue_demon";
        public const string Albion = "sds_albion";

        // --- nativos del Purgatorio ---------------------------------------------
        public const string PurgatoryBeast = "sds_purgatory_beast";
        public const string LostEmotion = "sds_lost_emotion";

        /// The vanilla actor every named character spawns as.
        public const string Human = "human";

        /// The five peoples, in the order they appear in the tab.
        public static readonly string[] Peoples = { Goddess, Fairy, Giant, Demon, Vampire };

        /// The creatures.
        public static readonly string[] Beasts =
            { GrayDemon, RedDemon, BlueDemon, Indura, Albion, PurgatoryBeast, LostEmotion };

        /// actor id -> the clan its members are born into.
        private static readonly System.Collections.Generic.Dictionary<string, string> _clan =
            new System.Collections.Generic.Dictionary<string, string>();

        public static string ClanOfRace(string actorId)
        {
            if (string.IsNullOrEmpty(actorId)) return null;
            string c;
            return _clan.TryGetValue(actorId, out c) ? c : null;
        }

        public static void Init()
        {
            // Without this the races spawn with kingdom == null and the meta layer throws every
            // frame. See WildKingdomBackfill above.
            Main.harmony.PatchAll(typeof(WildKingdomBackfill));

            // Architecture MUST already exist: the actor stores a reference to it, and a race
            // registered first would keep a null one and fall back to building like a human.
            //
            // The colour is what separates one people from another on screen: it tints the human
            // body, which is how the game differentiates its own races.
            Person(Goddess, Clans.Goddess, 110f, "#F2E3B0");
            Person(Fairy, Clans.Fairy, 70f, "#3FA96B");
            Person(Giant, Clans.Giant, 320f, "#B5651D");
            Person(Demon, Clans.Demon, 140f, "#8E1F2B");
            Person(Vampire, Clans.Vampire, 105f, "#6B3A8A");

            // Los Siete Pecados Capitales, cada uno con su cuerpo y sus colores canonicos. No son un
            // pueblo — son siete personas — asi que van por Character, no por Person.
            Character(Meliodas, Clans.Human, 110f, "#2E8B57", "sds_item_lostvayne");   // rubio, chaqueta negra
            Character(Ban, Clans.Human, 110f, "#9BB8D0", "sds_item_courechouse");      // pelo claro, chaqueta roja
            Character(DianeChar, Clans.Giant, 130f, "#D06818", "sds_item_gideon");     // giganta, naranja
            Character(Gowther, Clans.Human, 110f, "#E888B8", "sds_item_herritt");      // pelo rosa, armadura gris
            Character(KingChar, Clans.Fairy, 95f, "#F0A890", "sds_item_chastiefol");   // hada, salmon, alas
            Character(Merlin, Clans.Human, 110f, "#5A3A6A", "sds_item_aldan");         // pelo negro largo
            Character(Escanor, Clans.Human, 110f, "#E07828", "sds_item_rhitta");       // naranja y oro del sol

            // La jerarquia del Clan de los Demonios, de menor a mayor: gris, rojo, azul.
            Beast(GrayDemon, 90f, 0.15f, 9f);
            Beast(RedDemon, 160f, 0.35f, 14f);
            Beast(BlueDemon, 260f, 0.5f, 20f);

            // Albion: los golems del Purgatorio. Enormes, lentisimos y durisimos.
            ActorAsset albion = Beast(Albion, 1400f, 2.2f, 42f);
            if (albion != null)
            {
                albion.base_stats["armor"] = 40f;
                albion.base_stats["knockback"] = 12f;
                albion.base_stats["speed"] = -12f;
            }

            ActorAsset indura = Beast(Indura, 900f, 1.6f, 34f);
            if (indura != null)
            {
                indura.base_stats["armor"] = 18f;
                indura.base_stats["knockback"] = 8f;
                indura.base_stats["speed"] = -4f;
            }

            // Las alimanas del Purgatorio. Meliodas y Ban vivieron sesenta anos cazandolas: son
            // debiles de una en una y no se acaban nunca, que es justo lo que las hace peligrosas.
            ActorAsset beast = Beast(PurgatoryBeast, 120f, 0.4f, 16f);
            if (beast != null)
            {
                beast.base_stats["speed"] = 14f;
                beast.base_stats["multiplier_lifespan"] = 6f;
            }

            // Las emociones que el Rey Demonio le arranco a Meliodas, con cuerpo propio. Cada una
            // guarda un pedazo de lo que era, y por eso pegan como algo muy por encima de su tamano.
            ActorAsset emotion = Beast(LostEmotion, 340f, 0.75f, 30f);
            if (emotion != null)
            {
                emotion.base_stats["speed"] = 8f;
                emotion.base_stats["armor"] = 10f;
                emotion.base_stats["multiplier_lifespan"] = 20f;
            }

            for (int i = 0; i < Peoples.Length; i++) SDSUnit.AllowRace(Peoples[i]);

            // Deja constancia de lo que las razas heredan de verdad, para no volver a suponerlo.
            // Si build order sale vacio, no construiran y esta linea lo dira antes que el jugador.
            try
            {
                ActorAsset g = AssetManager.actor_library.get(Goddess);
                ActorAsset h = AssetManager.actor_library.get(Human);
                if (g != null && h != null)
                {
                    SDSLog.Info("build order  humano='" + (h.build_order_template_id ?? "<null>")
                                + "'  raza='" + (g.build_order_template_id ?? "<null>")
                                + "'  civ='" + (g.kingdom_id_civilization ?? "<null>")
                                + "'  arq='" + (g.architecture_id ?? "<null>") + "'");
                }
            }
            catch { }
        }

        // ---------------------------------------------------------------- builders

        /// A people: lives in kingdoms, works, breeds, and builds in its own style.
        ///
        /// Each people has its OWN body art, bound in BindRaceTextures below.
        ///
        /// It has to be in the phenotype layout — male_1 / female_1 / warrior_1 / king / leader /
        /// child — and not the Main/walk_0..3 layout creatures use. Pointing a human clone at a
        /// creature folder is what produced units you could see but could not CLICK: the selection
        /// collider is built from the sprite the phenotype pipeline resolves, and it resolved
        /// nothing. Colour is still set on top, so a Fairy reads green at a glance.
        private static ActorAsset Person(string id, string clanTrait, float health, string colorHex)
        {
            ActorAsset a = SDSRegistry.CloneActor(id, Human);
            if (a == null) return null;

            a.id = id;
            a.name_locale = id;
            SDSLocale.Add(id, DisplayName(id));

            _clan[id] = clanTrait;

            // linkAssets runs before OnModLoad, so a clone registered here never gets the default
            // delegate and throws inside ActorMovement the first time the unit turns around.
            if (a.check_flip == null)
                a.check_flip = (BaseSimObject pObj, WorldTile pTile) => true;

            // --- what makes them a CIVILISATION -----------------------------------
            //
            // Without these they are people who wander and never build a thing. This is the actual
            // answer to "no pueden construir": a cloned actor keeps human's architecture but none of
            // the fields that tell the game it founds kingdoms of its own.
            // Each step is guarded SEPARATELY and reports by name. One shared try/catch meant a
            // throw in the first line silently skipped every line after it, and the symptom showed
            // up hundreds of frames later inside ActorManager.prepareForMetaChecks with no clue
            // which field was missing.
            Set(id, "kingdoms", delegate
            {
                a.kingdom_id_civilization = id;
                a.kingdom_id_wild = "nomads_" + id;
            });

            Set(id, "build order", delegate
            {
                // NO se toca build_order_template_id.
                //
                // Aqui habia `a.build_order_template_id = "build_order_advanced"`, un id que me
                // invente. No existe en el ensamblado del juego — solo existe el nombre del campo —
                // asi que estaba SUSTITUYENDO el valor valido que el clon hereda de "human" por uno
                // que no apunta a ninguna plantilla. Sin plantilla de construccion no se levanta
                // nada, y ese era el motivo de que los pueblos no construyeran.
                //
                // El clon de human ya trae el correcto. La leccion: heredar y no tocar es mas seguro
                // que copiar una constante de otro mod sin comprobar que existe.
                a.civ_base_cities = 1;
            });

            Set(id, "arquitectura", delegate
            {
                string archId = Architecture.Of(clanTrait);
                a.architecture_id = archId;
                a.architecture_asset = AssetManager.architecture_library.get(archId)
                                       ?? AssetManager.architecture_library.get(Human);
            });

            // Taxonomy. A sapiens race without it is missing the lineage that the family, culture
            // and meta systems all read from — and the meta pass does not check for null.
            Set(id, "taxonomia", delegate
            {
                a.cloneTaxonomyFromForSapiens(Human);
                a.name_taxonomic_genus = "homo";
                a.name_taxonomic_species = "sapiens";
            });

            // The name templates the meta layer uses to name families and settlements. Inherited
            // from the human clone, but restated so a missing one is visible here rather than as a
            // null three systems away.
            Set(id, "nombres", delegate
            {
                ActorAsset human = AssetManager.actor_library.get(Human);
                if (human != null && human.name_template_sets != null)
                    a.name_template_sets = human.name_template_sets;
            });

            // --- appearance --------------------------------------------------------
            Set(id, "color", delegate
            {
                a.color_hex = colorHex;
                a.color = Toolbox.makeColor(colorHex);
            });

            // Puesto en false a proposito. Ver el comentario de BindRaceTextures.
            if (OwnBodies) Set(id, "texturas", delegate { BindRaceTextures(a, id); });

            // NOMBRE PELADO, no ruta. El juego compone la carpeta el solo (ui/Icons/ + icon), asi
            // que pasarle "ui/icons/<id>" producia "ui/Icons/ui/icons/<id>" y devolvia null. Eso es
            // lo que reventaba QuantumSpriteLibrary.drawFamilySpeciesIcons — el icono de especie que
            // solo se dibuja AL ALEJAR LA CAMARA, y por eso el fallo parecia depender del zoom.
            a.icon = id;
            a.base_stats["health"] = health;

            // birth_rate must be explicit: BabyMaker casts it to int every tick to decide extra
            // children, and an unset value truncates to zero — the race dies out in one generation.
            a.base_stats["birth_rate"] = 4f;

            return a;
        }

        // --- personajes con cuerpo propio (los Pecados) ------------------------
        public const string Meliodas = "sds_meliodas";
        public const string Ban = "sds_ban";
        public const string DianeChar = "sds_diane";
        public const string Gowther = "sds_gowther";
        public const string KingChar = "sds_king";
        public const string Merlin = "sds_merlin";
        public const string Escanor = "sds_escanor";

        /// Un PERSONAJE con cuerpo propio, no un pueblo. Mismo cuerpo a medida que una raza (arte en
        /// actors/<id>/, atado con BindRaceTextures), pero sin fundar ciudades: un Pecado es UNA
        /// persona, no una civilizacion. Se le deja la taxonomia y el reino salvaje que el meta lee,
        /// porque sin ellos el juego revienta cada frame; solo se le quita el fundar reinos propios.
        private static ActorAsset Character(string id, string clanTrait, float health, string colorHex,
                                            string weapon = null)
        {
            ActorAsset a = SDSRegistry.CloneActor(id, Human);
            if (a == null) return null;

            a.id = id;
            a.name_locale = id;
            SDSLocale.Add(id, DisplayName(id));
            _clan[id] = clanTrait;

            if (a.check_flip == null)
                a.check_flip = (BaseSimObject pObj, WorldTile pTile) => true;

            // Reino salvaje y taxonomia: el meta los lee sin comprobar null. Se quedan. Lo que NO se
            // pone es kingdom_id_civilization/civ_base_cities: un Pecado no funda un reino propio.
            Set(id, "reino salvaje", delegate { a.kingdom_id_wild = "nomads_" + id; });
            Set(id, "taxonomia", delegate
            {
                a.cloneTaxonomyFromForSapiens(Human);
                a.name_taxonomic_genus = "homo";
                a.name_taxonomic_species = "sapiens";
            });
            Set(id, "nombres", delegate
            {
                ActorAsset human = AssetManager.actor_library.get(Human);
                if (human != null && human.name_template_sets != null)
                    a.name_template_sets = human.name_template_sets;
            });
            Set(id, "color", delegate
            {
                a.color_hex = colorHex;
                a.color = Toolbox.makeColor(colorHex);
            });
            if (OwnBodies) Set(id, "texturas", delegate { BindRaceTextures(a, id); });

            a.icon = id;
            a.base_stats["health"] = health;
            a.base_stats["birth_rate"] = 4f;

            // EL ARMA EN LA MANO. `default_attack` es el arma que el juego le pone a una unidad
            // desarmada, Y LA DIBUJA en la mano. Asi cada Pecado empuna su Tesoro Sagrado a la vista
            // (Lostvayne, Chastiefol, Rhitta...) en vez de ir con las manos vacias. Es un id de item;
            // se resuelve al renderizar, asi que da igual que el item se registre despues (Sac.Tes.).
            if (!string.IsNullOrEmpty(weapon)) a.default_attack = weapon;

            return a;
        }

        /// Encendido: el juego completo de piezas ya existe.
        ///
        /// Estuvo apagado porque un cuerpo de raza NO son cuatro fotogramas de caminado. El pipeline
        /// de fenotipos pide veintiuna piezas por piel — walk, swim, y las superposiciones _head e
        /// _item de cada fotograma, mas un sprites.json con sus pivotes — y las que faltaban le
        /// llegaban como null: trescientas excepciones en GroupSpriteObject.setSprite.
        ///
        /// Las cabezas y los items se generan como PNG de 1x1 transparentes, que es lo que hace el
        /// mod de referencia: el cuerpo ya dibuja la cabeza, pero el archivo tiene que EXISTIR.
        private const bool OwnBodies = true;

        /// Points a people at its own body art.
        ///
        /// THE THREE SKIN ARRAYS MUST BE THE SAME LENGTH. The game picks ONE random index and uses
        /// it to read skin_citizen_male, skin_citizen_female AND skin_warrior. Arrays of different
        /// lengths — or an empty one — walk straight off the end the first time a unit of this race
        /// is born. One entry each is the safest possible shape and is what the generator produces.
        ///
        /// The skin names are the vanilla ones (male_1 / female_1 / warrior_1) on purpose too: a
        /// subspecies composes its path as base + skin name, so a half-human child of this race
        /// would otherwise build a path into the human folder that does not exist.
        ///
        /// Head textures are INHERITED from the human asset rather than replaced. Our bodies already
        /// draw their own heads, and leaving those fields pointing at art that exists is safer than
        /// nulling them out and finding out at render time.
        private static void BindRaceTextures(ActorAsset a, string id)
        {
            string basePath = "actors/" + id + "/";

            a.has_advanced_textures = true;
            a.render_heads_for_babies = false;

            a.skin_citizen_male = new[] { "male_1" };
            a.skin_citizen_female = new[] { "female_1" };
            a.skin_warrior = new[] { "warrior_1" };

            ActorTextureSubAsset human = null;
            ActorAsset humanAsset = AssetManager.actor_library.get(Human);
            if (humanAsset != null) human = humanAsset.texture_asset;

            ActorTextureSubAsset tex = new ActorTextureSubAsset(basePath, true);
            a.texture_asset = tex;

            tex.texture_path_base = basePath;
            tex.texture_path_main = basePath + "male_1";
            tex.texture_path_base_male = basePath + "male_1";
            tex.texture_path_base_female = basePath + "female_1";
            tex.texture_path_warrior = basePath + "warrior_1";
            tex.texture_path_king = basePath + "king";
            tex.texture_path_leader = basePath + "leader";
            tex.texture_path_baby = basePath + "child";

            // Heads: keep whatever the humans use. Ours are drawn into the body already.
            if (human != null)
            {
                tex.texture_heads_male = human.texture_heads_male;
                tex.texture_heads_female = human.texture_heads_female;
                tex.texture_head_warrior = human.texture_head_warrior;
                tex.texture_head_king = human.texture_head_king;
                tex.has_old_heads = false;
            }

            tex.render_heads_for_children = false;

            if (a.shadow)
            {
                tex.shadow = true;
                tex.shadow_texture = a.shadow_texture;
                tex.shadow_texture_baby = a.shadow_texture_baby;
                try { tex.loadShadow(); }
                catch { }
            }
        }

        /// Runs one setup step and says which one failed if it does.
        private static void Set(string raceId, string what, System.Action step)
        {
            try { step(); }
            catch (System.Exception e)
            {
                SDSLog.Error("raza '" + raceId + "', paso '" + what + "': " + e.Message);
            }
        }

        /// A creature: hostile, does not build, does not join kingdoms.
        private static ActorAsset Beast(string id, float health, float scale, float damage)
        {
            ActorAsset a = Beast_(id, health);
            if (a == null) return null;
            a.base_stats["damage"] = damage;
            if (scale != 0f) a.base_stats["scale"] = scale;
            return a;
        }

        /// The shared setup for a CREATURE. Peoples do not come through here: they must keep the
        /// human phenotype pipeline untouched.
        private static ActorAsset Beast_(string id, float health)
        {
            ActorAsset a = SDSRegistry.CloneActor(id, "$mob$");
            if (a == null) return null;

            a.id = id;

            // name_locale is looked up as a KEY, so the id doubles as one.
            a.name_locale = id;
            SDSLocale.Add(id, DisplayName(id));

            a.use_phenotypes = false;
            a.has_advanced_textures = false;

            // El clon hereda de `$mob$` las rutas de sombra (`shadow_texture` y sus variantes de
            // huevo y cria), que se resuelven contra la carpeta del actor y no existen para las
            // mias: el juego avisaba "Shadow size is too small : (0.00, 0.00)" por cada criatura.
            // Apagarla quita veintiun avisos y NO cambia nada en pantalla, porque una sombra de
            // tamano cero no dibujaba nada de todos modos.
            //
            // OJO, para el que venga detras: probe esto creyendo que era la causa del
            // IndexOutOfRangeException de `PixelBag..ctor` en la precarga. NO LO ES — los avisos
            // desaparecen y la excepcion sigue igual. Van tres hipotesis caidas sobre ese error
            // (tamano de las superposiciones, fotogramas de nado que faltaban, y esta). Sigue
            // abierto, salta una vez al cargar y no impide jugar.
            a.shadow = false;

            // SIN FORMA DE CRIA. Esto es lo que tenia el juego a 2 FPS y lo que hacia que las
            // criaturas no se vieran, que parecian dos fallos distintos y era uno solo.
            //
            // `$mob$` hereda `has_baby_form = true` de `$basic_unit_colored$` y no lo revierte. Mis
            // bestias solo tienen carpeta `Main/`, asi que en cuanto una nacia cria el juego
            // resolvia su textura a `actors/<id>/child`, que no existe: el contenedor de animacion
            // salia vacio, `createAnim()` devolvia null y `calculateMainSprite()` lanzaba
            // NullReference CADA FRAME Y POR UNIDAD. Mas de treinta mil excepciones en un solo log.
            //
            // Y lo peor no era el rendimiento: una unidad que revienta ahi NO OBTIENE SPRITE Y NO SE
            // DIBUJA. Por eso el Purgatorio parecia vacio aunque hubiera criaturas dentro.
            a.has_baby_form = false;
            a.can_have_subspecies = false;

            // TODAS las bestias del mod van a la horda del Purgatorio, que es un reino con
            // `units_always_looking_for_enemies`. Sin esto se quedaban pastando: eran monstruos
            // decorativos. Son demonios y alimañas del Purgatorio — que sean hostiles es lo suyo
            // tambien fuera de alli. Ver Kingdoms.Horde.
            a.kingdom_id_wild = Kingdoms.PurgatoryHorde;

            // linkAssets runs before OnModLoad; a null check_flip throws inside the renderer.
            if (a.check_flip == null) a.check_flip = delegate { return true; };

            a.animation_walk = new string[] { "walk_0", "walk_1", "walk_2", "walk_3" };
            a.texture_asset = new ActorTextureSubAsset("actors/" + id + "/", a.has_advanced_textures);

            // El constructor de ActorTextureSubAsset rellena `texture_path_baby` SIEMPRE, sin
            // preguntar si hay forma de cria. Va aqui, despues de crearlo, no antes.
            a.texture_asset.texture_path_baby = null;

            a.texture_id = id;
            // NOMBRE PELADO, no ruta. El juego compone la carpeta el solo (ui/Icons/ + icon), asi
            // que pasarle "ui/icons/<id>" producia "ui/Icons/ui/icons/<id>" y devolvia null. Eso es
            // lo que reventaba QuantumSpriteLibrary.drawFamilySpeciesIcons — el icono de especie que
            // solo se dibuja AL ALEJAR LA CAMARA, y por eso el fallo parecia depender del zoom.
            a.icon = id;
            a.base_stats["health"] = health;

            // Resources.Load rather than SpriteTextureLoader: it does not touch the sprite-list cache
            // that OnModLoad poisons.
            try { a._cached_sprite = Resources.Load<Sprite>("GameResources/actors/" + id + "/Main/walk_0"); }
            catch { }

            return a;
        }

        private static string DisplayName(string id)
        {
            switch (id)
            {
                case Demon: return "Demonio";
                case Goddess: return "Diosa";
                case Fairy: return "Hada";
                case Giant: return "Gigante";
                case Vampire: return "Vampiro";
                case GrayDemon: return "Demonio Gris";
                case RedDemon: return "Demonio Rojo";
                case Indura: return "Indura";
                case PurgatoryBeast: return "Bestia del Purgatorio";
                case LostEmotion: return "Emocion Perdida";
                case BlueDemon: return "Demonio Azul";
                case Albion: return "Albion";
                default: return id;
            }
        }

        // ---------------------------------------------------------------- naming

        /// Un repertorio por pueblo. Los nombres duros son de los demonios; las diosas no se
        /// llaman "Engendro".
        private static readonly System.Collections.Generic.Dictionary<string, string[]> _names =
            new System.Collections.Generic.Dictionary<string, string[]>
        {
            { Goddess, new[] { "Aurelia", "Seraphine", "Liriel", "Casandra", "Elenor", "Miriam",
                               "Astrid", "Celeste", "Ysolde", "Rowena" } },
            { Fairy,   new[] { "Puora", "Gerheade", "Elaine", "Aster", "Linnea", "Briar",
                               "Sylvan", "Thistle", "Fenn", "Ivy" } },
            { Giant,   new[] { "Matrona", "Dolores", "Gustaf", "Brann", "Hedda", "Torvald",
                               "Ulla", "Magnus", "Freya", "Bergthor" } },
            { Demon,   new[] { "Malachar", "Vexis", "Nerak", "Zaroth", "Grimhild", "Kazrel",
                               "Morvek", "Sythra", "Dolgan", "Vharn" } },
            { Vampire, new[] { "Izraf", "Gelda", "Ren", "Orlok", "Mircea", "Vasska",
                               "Lucian", "Carmilla", "Draven", "Nadia" } },
        };

        private static readonly string[] BeastNames =
        {
            "Bestia del Purgatorio", "Engendro", "Aberracion", "Sombra Hambrienta",
        };

        /// Nombra a una unidad recien invocada segun SU PUEBLO.
        ///
        /// Antes esto ignoraba el assetId por completo y sacaba siempre de la lista de bestias, asi
        /// que una diosa invocada nacia llamada "Engendro" o "Aberracion". Los nombres duros son de
        /// los demonios; cada pueblo tiene el suyo.
        public static void NameUnit(Actor a, string assetId)
        {
            if (a == null || string.IsNullOrEmpty(assetId)) return;

            string[] pool;
            if (!_names.TryGetValue(assetId, out pool) || pool == null || pool.Length == 0)
            {
                // Solo las criaturas caen aqui. Una persona sin repertorio se queda con el nombre
                // que le haya puesto el juego, que siempre es mejor que llamarla Aberracion.
                if (System.Array.IndexOf(Beasts, assetId) < 0) return;
                pool = BeastNames;
            }

            try { a.setName(pool[Random.Range(0, pool.Length)]); }
            catch { }
        }
    }
}
