using UnityEngine;

namespace SevenDeadlySins
{
    /// Traits that belong to no exclusive family: blood, gifts and curses that can sit alongside a
    /// clan and a sin. Two of them are real mechanics rather than stat blocks — Ban's immortality
    /// and Elizabeth's reincarnation — and both are implemented here.
    public static class Traits
    {
        public const string Immortal = "sds_immortal";
        public const string Reincarnation = "sds_reincarnation";
        public const string DemonBlood = "sds_demon_blood";
        public const string GoddessBlood = "sds_goddess_blood";
        public const string FairyWings = "sds_fairy_wings";
        public const string GiantStrength = "sds_giant_strength";
        public const string VampireThirst = "sds_vampire_thirst";
        public const string Druid = "sds_druid";

        private const string Group = TraitGroups.Bloodline;

        public static void Init()
        {
            Immortal_();
            Reincarnation_();
            Blood(DemonBlood, "Sangre de Demonio",
                "La oscuridad corre por sus venas, sea cual sea la forma que vista.", 45f, 20f, 40f);
            Blood(GoddessBlood, "Sangre de Diosa",
                "La luz corre por sus venas, sea cual sea la forma que vista.", 30f, 45f, 50f);
            Blood(FairyWings, "Alas de Hada",
                "Alas del Bosque del Rey Hada.", 10f, 25f, 30f);
            Blood(GiantStrength, "Fuerza de Gigante",
                "Fuerza que se mide contra montanas.", 70f, 15f, 0f);
            Blood(VampireThirst, "Sed de Sangre",
                "Se alimenta de aquello que hiere.", 35f, 15f, 20f);
            Blood(Druid, "Druida",
                "Guardian de los viejos ritos de la Tierra de los Druidas.", 15f, 40f, 45f);

            SDSTick.Register(Tick);
        }

        // ---------------------------------------------------------------- registration

        private static ActorTrait New(string id, string nameEs, string infoEs)
        {
            ActorTrait t = SDSRegistry.Trait(id, Group, "ui/icons/" + id);
            t.type = TraitType.Positive;
            SDSRegistry.AddTrait(t);
            SDSLocale.Trait(id, nameEs, infoEs);
            return t;
        }

        private static void Blood(string id, string nameEs, string infoEs, float str, float spi, float mag)
        {
            ActorTrait t = SDSRegistry.Trait(id, Group, "ui/icons/" + id);
            t.type = TraitType.Positive;
            PowerLevel.Grant(t, str, spi, mag);
            SDSRegistry.AddTrait(t);
            SDSLocale.Trait(id, nameEs, infoEs);
        }

        private static void Immortal_()
        {
            ActorTrait t = New(Immortal, "Inmortal",
                "La Fuente de la Juventud le quito la muerte de encima. Las heridas ya no deciden nada.");
            PowerLevel.Grant(t, 60f, 90f, 20f);
            t.base_stats["health"] = 150f;
        }

        private static void Reincarnation_()
        {
            ActorTrait t = New(Reincarnation, "Reencarnacion",
                "Maldita a morir y volver a nacer, una y otra vez. Ya van ciento siete.");
            PowerLevel.Grant(t, 10f, 70f, 60f);
        }

        // ---------------------------------------------------------------- behaviour

        /// Both immortality mechanics are health FLOORS rather than death hooks.
        ///
        /// The honest reason: no death callback was verifiable against this build, and an unverified
        /// Harmony patch on a death path is the single easiest way to hard-crash a world. A floor is
        /// less elegant but it delivers the thing that matters — Ban does not die of wounds — without
        /// betting the save on a guessed signature.
        private static void Tick(Actor a, float dt)
        {
            if (a == null || !a.isAlive() || a.data == null) return;

            // Inmortal (Ban, el Rey Demonio, la Diosa Suprema...): suelo de vida, nunca muere.
            // La REENCARNACION de Elizabeth y la maldicion de Meliodas las lleva ahora TwinCurses,
            // con toda su tragedia; aqui solo queda la inmortalidad simple.
            if (a.hasTrait(Immortal)) TickImmortal(a);
        }

        /// Ban. Pulled back from the edge continuously and quietly: he does not "revive", he simply
        /// never finishes dying.
        private static void TickImmortal(Actor a)
        {
            float max = a.getMaxHealth();
            if (max <= 0f) return;

            float floor = max * 0.18f;
            if (a.data.health >= floor) return;

            try { a.restoreHealth(Mathf.Max(1, Mathf.RoundToInt(max * 0.10f))); }
            catch { }
        }

        /// Elizabeth. Unlike Ban this is a REBIRTH: she is allowed to fall all the way to the brink,
        /// and then comes back whole, with a long cooldown so it reads as an event and not as regen.
        private static void TickReincarnation(Actor a)
        {
            float max = a.getMaxHealth();
            if (max <= 0f) return;
            if (a.data.health >= max * 0.06f) return;
            if (!SDSData.TryUse(a, "reincarnation", 120f)) return;

            try { a.restoreHealth(Mathf.RoundToInt(max)); }
            catch { return; }

            SDSFx.At(a, "sds_fx_ark", 0.5f);
            SDSLog.Chronicle(SDSLocale.T(
                a.getName() + " ha muerto, y ha vuelto a nacer.",
                a.getName() + " has died, and been born again."));
        }
    }
}
