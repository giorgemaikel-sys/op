using System.Collections.Generic;
using UnityEngine;

namespace SevenDeadlySins
{
    /// Every StatusAsset the mod applies to a unit: the four transformations, the three signature
    /// buffs, the black flame, and the ten punishments of the Commandments.
    ///
    /// Two rules govern this file.
    ///
    /// 1. Stats are written through the INDEXER (`base_stats["armor"] = 30f`), never through
    ///    `base_stats.set(...)`. `BaseStats.set` is private even in the publicized assembly, so a
    ///    call to it does not compile here — the indexer is the public door, and it is what
    ///    PowerLevel.Grant uses too.
    /// 2. Auras are attached LATE. SDSRegistry.Aura calls SpriteTextureLoader.getSpriteList, and
    ///    doing that from OnModLoad poisons the sprite cache with empty arrays for the rest of the
    ///    session (DESIGN.md invariant 4). Init only registers the assets; AttachAuras runs on the
    ///    global tick, once, when a world is actually up.
    public static class Statuses
    {
        // --- transformations -------------------------------------------------------------------
        public const string DemonMark = "sds_status_demon_mark";
        public const string AssaultMode = "sds_status_assault_mode";
        public const string TheOne = "sds_status_the_one";
        public const string Indura = "sds_status_indura";

        // --- signature abilities ---------------------------------------------------------------
        public const string FullCounterReady = "sds_status_full_counter_ready";
        public const string Infinity = "sds_status_infinity";
        public const string ArkBlessing = "sds_status_ark_blessing";
        public const string Hellblaze = "sds_status_hellblaze";

        // --- the ten punishments ----------------------------------------------------------------
        public const string CursePiety = "sds_status_curse_piety";
        public const string CurseLove = "sds_status_curse_love";
        public const string CurseTruth = "sds_status_curse_truth";
        public const string CurseFaith = "sds_status_curse_faith";
        public const string CurseSelflessness = "sds_status_curse_selflessness";
        public const string CursePacifism = "sds_status_curse_pacifism";
        public const string CurseRepose = "sds_status_curse_repose";
        public const string CursePatience = "sds_status_curse_patience";
        public const string CurseReticence = "sds_status_curse_reticence";
        public const string CursePurity = "sds_status_curse_purity";

        public static readonly string[] AllCurses =
        {
            CursePiety, CurseLove, CurseTruth, CurseFaith, CurseSelflessness,
            CursePacifism, CurseRepose, CursePatience, CurseReticence, CursePurity,
        };

        /// Health snapshot for the black flame. Lives on Actor.data so it survives a save/load.
        private const string HellblazeHealthKey = "sds_hellblaze_hp";

        public static void Init()
        {
            Transformations();
            Abilities();
            Commandments();

            // The black flame is not a stat, it is a rule; see HellblazeTick.
            SDSTick.Register(HellblazeTick);

            // Auras cannot be built yet — see the class comment.
            SDSTick.RegisterGlobal(AttachAuras);
        }

        // ------------------------------------------------------------------ transformations

        private static void Transformations()
        {
            // The Demon Mark: a demon at low health lets the mark spread. Strong, but it is only the
            // doorway — Assault Mode below is what it grows into.
            StatusAsset mark = Base(DemonMark, 30f);
            PowerLevel.Grant(mark, 1200f, 600f, 400f);
            mark.base_stats["multiplier_damage"] = 0.50f;
            mark.base_stats["multiplier_speed"] = 0.25f;
            mark.base_stats["multiplier_health"] = 0.35f;
            mark.base_stats["armor"] = 20f;
            mark.can_be_cured = false;          // no village healer talks a demon down
            mark.allow_timer_reset = true;      // staying in the fight keeps the mark up
            Register(mark, "Marca del Demonio",
                "La marca demoniaca se extiende por su piel. Su poder crece mientras la sangre hierve.");

            // Assault Mode: Meliodas unsealed. Canon puts him at ~56.000 here against ~3.370 sealed,
            // so the grant is deliberately enormous — this is meant to end fights.
            StatusAsset assault = Base(AssaultMode, 25f);
            PowerLevel.Grant(assault, 20000f, 12000f, 8000f);
            assault.base_stats["multiplier_damage"] = 2.5f;
            assault.base_stats["multiplier_speed"] = 0.60f;
            assault.base_stats["multiplier_health"] = 1.5f;
            assault.base_stats["armor"] = 60f;
            assault.base_stats["knockback"] = 3f;
            assault.can_be_cured = false;
            // One demonic form at a time: the full release replaces the mark it grew out of, instead
            // of stacking both sets of stats on the same actor.
            assault.remove_status = new[] { DemonMark };
            Register(assault, "Modo Asalto",
                "El sello se rompe. Meliodas libera el poder que el Rey Demonio le dio, y nada a su alrededor sobrevive.");

            // The One: Escanor at high noon. Sunshine.cs decides WHEN; this is only how it feels.
            // scale is what physically grows the unit — Escanor towers over the battlefield at noon.
            StatusAsset one = Base(TheOne, 20f);
            PowerLevel.Grant(one, 90000f, 60000f, 50000f);
            one.base_stats["multiplier_damage"] = 5f;
            one.base_stats["multiplier_health"] = 2f;
            one.base_stats["armor"] = 120f;
            one.base_stats["knockback"] = 4f;
            one.base_stats["scale"] = 1.25f;
            one.can_be_cured = false;
            Register(one, "The One",
                "Es mediodia. Durante un minuto, Escanor es el ser mas poderoso que ha pisado este mundo.");

            // Indura: a demon that spent its magic to the last drop degenerates. Irreversible by
            // design, so the duration is effectively forever and nothing can cure it.
            StatusAsset indura = Base(Indura, 99999f);
            PowerLevel.Grant(indura, 8000f, 2000f, 0f);
            indura.base_stats["multiplier_damage"] = 2f;
            indura.base_stats["multiplier_health"] = 3f;
            indura.base_stats["multiplier_speed"] = -0.20f;   // huge, but slow
            indura.base_stats["armor"] = 80f;
            indura.base_stats["scale"] = 1.60f;
            indura.base_stats["mass_2"] = 60f;
            indura.can_be_cured = false;
            indura.allow_timer_reset = false;
            Register(indura, "Indura",
                "Agoto su poder magico y perdio la razon. Ya no es un demonio: es una bestia hostil a todo lo que respira.");
        }

        // ------------------------------------------------------------------ signature abilities

        private static void Abilities()
        {
            // Full Counter armed. FullCounter.cs reads this status to decide whether the next ranged
            // or magical hit gets thrown back; the stats here are the readiness itself.
            StatusAsset counter = Base(FullCounterReady, 6f);
            PowerLevel.Grant(counter, 200f, 400f, 0f);
            counter.base_stats["armor"] = 30f;
            counter.base_stats["accuracy"] = 0.25f;
            counter.allow_timer_reset = true;
            Register(counter, "Contraataque Total",
                "Lee el ataque antes de que llegue. El proximo golpe a distancia o magico volvera multiplicado.");

            // Infinity: Merlin's spells never end, so neither does this. Duration is nominal.
            StatusAsset infinity = Base(Infinity, 99999f);
            PowerLevel.Grant(infinity, 0f, 500f, 2500f);
            infinity.base_stats["multiplier_health"] = 0.5f;
            infinity.base_stats["armor"] = 40f;
            infinity.can_be_cured = false;
            infinity.allow_timer_reset = false;
            Register(infinity, "Infinito",
                "Todo hechizo que Merlin lanza dura para siempre. Ningun estado negativo la alcanza.");

            // The Ark blessing a Goddess leaves on an ally she healed.
            StatusAsset ark = Base(ArkBlessing, 15f);
            PowerLevel.Grant(ark, 0f, 300f, 300f);
            ark.base_stats["multiplier_health"] = 0.30f;
            ark.base_stats["multiplier_speed"] = 0.15f;
            ark.base_stats["armor"] = 25f;
            ark.can_be_cured = false;       // curing a blessing would be a bug, not a feature
            ark.allow_timer_reset = true;
            Register(ark, "Bendicion del Ark",
                "La luz del Clan de las Diosas le envuelve: mas resistente, mas rapido, y a salvo de la oscuridad.");

            // Hellblaze. The stats below are the burn; the part that MATTERS — wounds that refuse to
            // close — is HellblazeTick, because WorldBox has no regeneration stat to zero out.
            // can_be_cured = false is the other half: a healer cannot put the black flame out.
            StatusAsset hell = Base(Hellblaze, 20f);
            hell.base_stats["multiplier_health"] = -0.35f;
            hell.base_stats["multiplier_damage"] = -0.15f;
            hell.base_stats["multiplier_speed"] = -0.10f;
            hell.base_stats["armor"] = -30f;
            hell.can_be_cured = false;
            hell.allow_timer_reset = true;
            Register(hell, "Llama Negra",
                "Fuego demoniaco que no se apaga. Las heridas que abre no cicatrizan y ninguna magia curativa le alcanza.");
        }

        // ------------------------------------------------------------------ commandment curses

        /// Every punishment is a real mechanical sentence written in base_stats, not a line of text.
        /// TenCommandments.cs applies them; this file decides what breaking the rule costs.
        private static void Commandments()
        {
            // PIEDAD (Zeldris) — quien juzgue al portador pierde su fuerza.
            StatusAsset piety = Base(CursePiety, 18f);
            PowerLevel.Grant(piety, -800f, 0f, 0f);
            piety.base_stats["multiplier_damage"] = -0.60f;
            piety.base_stats["damage"] = -20f;
            Register(piety, "Castigo: Piedad",
                "Juzgo al portador del Mandamiento. Su fuerza le ha sido arrancada.");

            // AMOR (Estarossa) — quien sienta odio sin amor queda paralizado.
            StatusAsset love = Base(CurseLove, 15f);
            love.base_stats["multiplier_speed"] = -0.95f;
            love.base_stats["multiplier_attack_speed"] = -0.85f;
            love.base_stats["accuracy"] = -0.40f;
            Register(love, "Castigo: Amor",
                "Odio sin una gota de amor. Su cuerpo se niega a obedecerle.");

            // VERDAD (Galand) — quien mienta se convierte en piedra.
            StatusAsset truth = Base(CurseTruth, 20f);
            PowerLevel.Grant(truth, -1000f, -1000f, -1000f);
            truth.base_stats["multiplier_speed"] = -0.99f;
            truth.base_stats["multiplier_attack_speed"] = -0.95f;
            truth.base_stats["multiplier_damage"] = -0.90f;
            truth.base_stats["multiplier_health"] = -0.50f;
            truth.base_stats["armor"] = 60f;        // stone skin: hard, and completely useless to him
            truth.base_stats["mass_2"] = 80f;
            Register(truth, "Castigo: Verdad",
                "Mintio delante del Mandamiento. La piedra le sube por el cuerpo y ya casi no puede moverse.");

            // FE (Melascula) — quien dude pierde el alma.
            StatusAsset faith = Base(CurseFaith, 18f);
            PowerLevel.Grant(faith, 0f, -2000f, -1000f);
            faith.base_stats["multiplier_health"] = -0.40f;
            faith.base_stats["multiplier_damage"] = -0.35f;
            faith.base_stats["accuracy"] = -0.30f;
            Register(faith, "Castigo: Fe",
                "Dudo, y el Mandamiento se llevo su alma. Queda el cuerpo, vacio.");

            // ALTRUISMO (Fraudrin) — quien actue por egoismo pierde lo que ama.
            StatusAsset self = Base(CurseSelflessness, 16f);
            PowerLevel.Grant(self, 0f, -1200f, 0f);
            self.base_stats["multiplier_health"] = -0.50f;
            self.base_stats["multiplier_damage"] = -0.25f;
            self.base_stats["armor"] = -40f;
            Register(self, "Castigo: Altruismo",
                "Actuo pensando solo en si mismo. El Mandamiento le quito aquello por lo que peleaba.");

            // PACIFISMO (Grayroad) — quien mate queda reducido a ceniza. El mas duro de los diez.
            StatusAsset pacifism = Base(CursePacifism, 30f);
            PowerLevel.Grant(pacifism, -2000f, -1000f, -1000f);
            pacifism.base_stats["multiplier_health"] = -0.80f;
            pacifism.base_stats["multiplier_damage"] = -0.50f;
            pacifism.base_stats["multiplier_speed"] = -0.30f;
            pacifism.base_stats["armor"] = -60f;
            Register(pacifism, "Castigo: Pacifismo",
                "Mato en presencia del Mandamiento. Se esta deshaciendo en ceniza mientras camina.");

            // REPOSO (Gloxinia) — quien descanse pierde tiempo de vida.
            StatusAsset repose = Base(CurseRepose, 20f);
            repose.base_stats["multiplier_lifespan"] = -0.50f;
            repose.base_stats["multiplier_stamina"] = -0.50f;
            repose.base_stats["multiplier_health"] = -0.25f;
            Register(repose, "Castigo: Reposo",
                "Bajo la guardia y descanso. Los anos que le quedaban se le escapan entre los dedos.");

            // PACIENCIA (Drole) — quien huya con miedo pierde su poder.
            StatusAsset patience = Base(CursePatience, 18f);
            PowerLevel.Grant(patience, -1500f, -1000f, -500f);
            patience.base_stats["multiplier_damage"] = -0.50f;
            patience.base_stats["multiplier_speed"] = -0.40f;
            Register(patience, "Castigo: Paciencia",
                "Huyo con miedo en los ojos. El Mandamiento se quedo con el poder que no supo usar.");

            // SILENCIO (Monspeet) — quien hable del portador arde.
            StatusAsset reticence = Base(CurseReticence, 16f);
            reticence.base_stats["multiplier_health"] = -0.45f;
            reticence.base_stats["multiplier_attack_speed"] = -0.30f;
            reticence.base_stats["multiplier_speed"] = -0.20f;
            reticence.base_stats["armor"] = -35f;
            Register(reticence, "Castigo: Silencio",
                "Hablo del portador del Mandamiento. Arde desde dentro y no puede gritar.");

            // PUREZA (Derieri) — quien se corrompa se ahoga.
            StatusAsset purity = Base(CursePurity, 16f);
            purity.base_stats["multiplier_speed"] = -0.70f;
            purity.base_stats["multiplier_attack_speed"] = -0.60f;
            purity.base_stats["multiplier_health"] = -0.35f;
            purity.base_stats["multiplier_stamina"] = -0.80f;
            Register(purity, "Castigo: Pureza",
                "Se dejo corromper. El aire ya no le entra: se ahoga de pie.");
        }

        /// The punishment status for a commandment trait id, following the id contract in DESIGN.md
        /// (`sds_cmd_<name>` -> `sds_status_curse_<name>`). Derived rather than hand-mapped so a new
        /// commandment cannot silently end up without a curse. Returns null if nothing is registered
        /// under the derived id, which SDSSelfCheck reports rather than failing at runtime.
        public static string CurseFor(string commandmentTraitId)
        {
            const string prefix = "sds_cmd_";
            if (string.IsNullOrEmpty(commandmentTraitId)) return null;
            if (!commandmentTraitId.StartsWith(prefix)) return null;

            string id = "sds_status_curse_" + commandmentTraitId.Substring(prefix.Length);
            return AssetManager.status.dict.ContainsKey(id) ? id : null;
        }

        // ------------------------------------------------------------------ hellblaze enforcement

        /// Hellblaze is the one status whose whole point cannot be expressed as a stat: WorldBox has
        /// no regeneration stat to zero out, so "no cicatriza" has to be enforced.
        ///
        /// Each sweep we snapshot the carrier's health. If it went UP since the last visit — natural
        /// regeneration, a Goddess's Ark, a healer's spell, anything — we put it back. Damage is left
        /// alone, so the target still takes hits normally; it simply never gets any of it back while
        /// the black flame burns. Running on the sliced tick (about one visit per second) means the
        /// wound visibly reopens instead of the health bar freezing, which is the effect we want.
        private static void HellblazeTick(Actor a, float dt)
        {
            if (a == null || !a.isAlive() || a.data == null) return;

            bool burning;
            try
            {
                IReadOnlyDictionary<string, Status> statuses = a.getStatusesDict();
                burning = statuses != null && statuses.ContainsKey(Hellblaze);
            }
            catch { return; }

            if (!burning)
            {
                // Drop the snapshot so a later application starts from the health he has THEN, not
                // from a stale number left over from the last time he burned.
                if (SDSData.GetInt(a, HellblazeHealthKey, -1) >= 0)
                    SDSData.SetInt(a, HellblazeHealthKey, -1);
                return;
            }

            int health = a.getHealth();
            int last = SDSData.GetInt(a, HellblazeHealthKey, -1);

            if (last >= 0 && health > last)
            {
                try { a.setHealth(last, true); }
                catch { }
                health = last;
            }

            SDSData.SetInt(a, HellblazeHealthKey, health);
        }

        // ------------------------------------------------------------------ late aura attachment

        private static bool _aurasAttached;

        /// Runs once, on the global tick, as soon as a world exists. Everything it touches goes
        /// through SpriteTextureLoader, which is exactly why it cannot live in Init.
        private static void AttachAuras(float dt)
        {
            if (_aurasAttached) return;
            if (World.world == null) return;
            _aurasAttached = true;

            Aura(DemonMark, Effects.DemonMark, 0.55f);
            Aura(AssaultMode, Effects.AssaultMode, 0.80f);
            Aura(TheOne, Effects.TheOne, 1.00f);
            Aura(Indura, Effects.Indura, 1.20f);
            Aura(FullCounterReady, Effects.FullCounter, 0.50f);
            Aura(Infinity, Effects.Infinity, 0.60f);
            Aura(ArkBlessing, Effects.Ark, 0.60f);
            Aura(Hellblaze, Effects.Hellblaze, 0.60f);

            SDSLog.Info("auras de estado enlazadas");
        }

        private static void Aura(string statusId, string fxId, float scale)
        {
            try
            {
                StatusAsset s = AssetManager.status.get(statusId);
                if (s == null) return;
                SDSRegistry.Aura(s, fxId, scale);
            }
            catch (System.Exception e)
            {
                SDSLog.Error("aura de '" + statusId + "' fallo: " + e.Message);
            }
        }

        // ------------------------------------------------------------------ plumbing

        /// The icon path is derived from the id, so a status can never wear another status's icon and
        /// the sprite generator has exactly one rule to follow: ui/icons/&lt;status id&gt;.
        private static StatusAsset Base(string id, float duration)
        {
            StatusAsset s = SDSRegistry.Status(id, "ui/icons/" + id, duration);

            // A transformation or a curse that vanishes the instant its carrier is hit does nothing
            // at all — and the engine default is to strip a status on damage. These are meant to be
            // lived through, so they stay on for their full duration.
            s.removed_on_damage = false;
            return s;
        }

        private static void Register(StatusAsset s, string title, string description)
        {
            if (s == null) return;
            SDSRegistry.AddStatus(s);
            SDSLocale.Status(s.id, title, description);
        }
    }
}
