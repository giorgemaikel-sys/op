namespace SevenDeadlySins
{
    /// The "how do I get this?" line under a trait's stats.
    ///
    /// Runs late in the load, after every trait id in the mod exists, because it only registers text
    /// and there is no point guessing at ids that may not have been created yet.
    public static class TraitLore
    {
        public static void Init()
        {
            Clans();
            Sins();
            Commandments();
            Magic();
            Ranks();
            Abilities();
            Loose();
        }

        private static void L(string id, string howToGet)
        {
            SDSLocale.TraitLore(id, howToGet);
        }

        private static void Clans()
        {
            L(SevenDeadlySins.Clans.Human, "Se nace humano. Es lo mas comun de Britannia y lo unico que puede portar un Pecado.");
            L(SevenDeadlySins.Clans.Demon, "Se nace del Clan de los Demonios, o se recibe del Rey Demonio.");
            L(SevenDeadlySins.Clans.Goddess, "Se nace del Clan de las Diosas, bajo la Diosa Suprema.");
            L(SevenDeadlySins.Clans.Fairy, "Se nace en el Bosque del Rey Hada.");
            L(SevenDeadlySins.Clans.Giant, "Se nace en el Calabozo de los Gigantes.");
            L(SevenDeadlySins.Clans.Vampire, "Se nace vampiro, o se despierta de un sello muy antiguo.");
        }

        private static void Sins()
        {
            L(SevenSins.Wrath, "Solo un humano puede portar la Ira, y solo uno a la vez. El Dragon no se comparte.");
            L(SevenSins.Greed, "La Avaricia elige a quien nunca tiene bastante. Bebe de la Fuente de la Juventud.");
            L(SevenSins.Envy, "La Envidia va a quien mira hacia arriba desde muy abajo.");
            L(SevenSins.Lust, "La Lujuria busca a quien no entiende el corazon ajeno y quiere entenderlo.");
            L(SevenSins.Sloth, "La Pereza corona a quien pudo actuar y no lo hizo. El Rey Hada la lleva.");
            L(SevenSins.Gluttony, "La Gula devora conocimiento, no comida. Va al mago mas grande de Britannia.");
            L(SevenSins.Pride, "La Soberbia solo acepta a quien es de verdad el mas fuerte. Al mediodia se nota.");
        }

        private static void Commandments()
        {
            L(TenCommandments.Piety, "El Rey Demonio la entrega. Su portador juzga y no admite ser juzgado.");
            L(TenCommandments.Love, "Se otorga a quien puede odiar sin dejar de amar.");
            L(TenCommandments.Truth, "Va a quien no ha mentido nunca, y castiga a quien si.");
            L(TenCommandments.Faith, "Se concede a quien no ha dudado jamas.");
            L(TenCommandments.Selflessness, "Para quien no ha guardado nada para si.");
            L(TenCommandments.Pacifism, "La lleva quien no necesita matar con sus manos.");
            L(TenCommandments.Repose, "Se da a quien no descansa. Gloxinia la acepto siendo hada.");
            L(TenCommandments.Patience, "Para quien espera siglos sin moverse. Drole la porta como gigante.");
            L(TenCommandments.Reticence, "Va a quien calla. Hablar de el es lo que quema.");
            L(TenCommandments.Purity, "Se entrega a quien no se ha corrompido nunca.");
        }

        private static void Magic()
        {
            L(MagicTypes.Strengthener, "Nace con quien vuelca la magia hacia dentro.");
            L(MagicTypes.Enchanter, "Nace con quien vuelca la magia hacia lo que le rodea.");
            L(MagicTypes.Incantation, "Nace con quien aprende a golpear mas lejos de lo que alcanza su brazo.");
            L(MagicTypes.Healer, "Nace con quien cierra heridas en vez de abrirlas.");
            L(MagicTypes.Special, "No se aprende. O se tiene una magia que nadie mas tiene, o no. Es requisito para un Pecado.");
        }

        private static void Ranks()
        {
            L(HolyKnights.Apprentice, "Se jura el cargo de joven. Basta con sobrevivir a la primera batalla.");
            L(HolyKnights.HolyKnight, "Se asciende con los anos y con los enemigos caidos.");
            L(HolyKnights.GreatHolyKnight, "Se manda sobre los Caballeros Sagrados de un reino tras muchas guerras.");
            L(HolyKnights.GrandMaster, "El techo de lo que un mortal puede alcanzar con una espada.");
        }

        private static void Abilities()
        {
            L("sds_ability_full_counter", "Viene con la Ira. Devuelve magia y proyectiles multiplicados; contra un puno no sirve de nada.");
            L("sds_ability_snatch", "Viene con la Avaricia. Roba la fuerza de lo que toca y se la queda.");
            L("sds_ability_creation", "Viene con la Envidia. La tierra obedece.");
            L("sds_ability_invasion", "Viene con la Lujuria. Entra en una mente y reescribe lo que encuentra.");
            L("sds_ability_disaster", "Viene con la Pereza. Todo el poder del Rey Hada, espiritu y bosque.");
            L("sds_ability_infinity", "Viene con la Gula. Lo que ella lanza no caduca jamas.");
            L("sds_ability_sunshine", "Viene con la Soberbia. Sube con el sol y se apaga con el. A medianoche no es nadie.");
            L("sds_ability_hellblaze", "Llama negra del Rey Demonio. Las heridas que abre no cierran.");
            L("sds_ability_ark", "Luz del Clan de las Diosas. Cura a los suyos y abrasa demonios.");
            L("sds_ability_purge", "Llama blanca. Solo responde a quien sostiene el sol.");
        }

        private static void Loose()
        {
            L(SevenDeadlySins.Traits.Immortal, "Se bebe de la Fuente de la Juventud, y ya no hay marcha atras.");
            L(SevenDeadlySins.Traits.Reincarnation, "Es una maldicion, no un don. Morir y volver, ciento siete veces.");
            L(SevenDeadlySins.Traits.DemonBlood, "Se hereda del Clan de los Demonios aunque el cuerpo sea otro.");
            L(SevenDeadlySins.Traits.GoddessBlood, "Se hereda del Clan de las Diosas aunque el cuerpo sea otro.");
            L(SevenDeadlySins.Traits.FairyWings, "Se nace con ellas en el Bosque del Rey Hada.");
            L(SevenDeadlySins.Traits.GiantStrength, "Se hereda de la sangre de los gigantes.");
            L(SevenDeadlySins.Traits.VampireThirst, "Llega con el colmillo. No se elige.");
            L(SevenDeadlySins.Traits.Druid, "Se aprende en la Tierra de los Druidas, y cuesta anos.");
        }
    }
}
