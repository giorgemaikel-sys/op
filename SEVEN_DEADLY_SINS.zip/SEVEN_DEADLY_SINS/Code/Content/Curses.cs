using System.Collections.Generic;
using UnityEngine;

namespace SevenDeadlySins
{
    /// The dramatic half of the Ten Commandments.
    ///
    /// TenCommandments already brands a violator with sds_status_curse_<name>, but those are quiet
    /// stat penalties. In the series breaking a Commandment does something you can WATCH: Galand
    /// turns you to stone, Grayroad reduces you to ash, Melascula pulls your soul out. These are
    /// those punishments — a second, louder status on top of the plain curse, each with its own
    /// effect animation and its own mechanical bite.
    ///
    /// They are separate from the curse statuses on purpose: the curse is the law, this is the
    /// spectacle, and a player who turns curses off in the config should lose both without either
    /// system having to know about the other.
    public static class Curses
    {
        public const string Petrified = "sds_status_petrified";
        public const string Paralyzed = "sds_status_paralyzed";
        public const string Ash = "sds_status_ash";
        public const string SoulStolen = "sds_status_soul_stolen";
        public const string Drowning = "sds_status_drowning";

        /// commandment id -> (dramatic status, effect, seconds)
        private class Punishment
        {
            public readonly string status, fx;
            public readonly float seconds;
            public Punishment(string status, string fx, float seconds)
            {
                this.status = status; this.fx = fx; this.seconds = seconds;
            }
        }

        private static readonly Dictionary<string, Punishment> _byLaw =
            new Dictionary<string, Punishment>();

        public static void Init()
        {
            // --- the five spectacles ---------------------------------------------
            Status(Petrified, "Petrificado",
                "La piedra sube desde los pies. No se puede mover ni golpear.",
                speed: -400f, damage: -200f, armor: 60f);

            Status(Paralyzed, "Paralizado",
                "El cuerpo no responde. Odiar sin amar tiene precio.",
                speed: -300f, damage: -120f, armor: 0f);

            Status(Ash, "Ceniza",
                "Se deshace por dentro. Matar cerca de Grayroad cuesta el cuerpo entero.",
                speed: -60f, damage: -80f, armor: -40f, dps: 6f);

            Status(SoulStolen, "Alma Robada",
                "El alma se le escapa por la boca. La magia deja de responderle.",
                speed: -40f, damage: -60f, armor: -20f, dps: 3f, magic: -400f);

            Status(Drowning, "Ahogandose",
                "Se ahoga en tierra firme. La corrupcion se paga con aire.",
                speed: -120f, damage: -100f, armor: 0f, dps: 5f);

            // --- which law delivers which ----------------------------------------
            //
            // Only five of the ten get a spectacle. The other five punish in ways that have no good
            // visual (losing what you love, losing years of life), and inventing one for them would
            // be louder than the source material.
            Link(TenCommandments.Truth, Petrified, "sds_fx_petrify", 14f);
            Link(TenCommandments.Love, Paralyzed, "sds_fx_flash", 8f);
            Link(TenCommandments.Pacifism, Ash, "sds_fx_ash", 16f);
            Link(TenCommandments.Faith, SoulStolen, "sds_fx_soul", 12f);
            Link(TenCommandments.Purity, Drowning, "sds_fx_ocean", 10f);
        }

        /// `dps` is accepted and deliberately NOT written onto the asset.
        ///
        /// StatusAsset has no verifiable damage-over-time field on this build — `effect_damage`
        /// exists in the assembly but its semantics could not be confirmed, and a status that
        /// silently does the wrong thing every tick is worse than one that only debuffs. The
        /// continuous damage for a broken commandment already comes from TenCommandments' own
        /// `law.dps`, so nothing is lost; the parameter stays so the intent is documented at each
        /// call site.
        private static void Status(string id, string nameEs, string infoEs,
                                   float speed, float damage, float armor,
                                   float dps = 0f, float magic = 0f)
        {
            StatusAsset s = SDSRegistry.Status(id, "ui/icons/" + id, 10f);

            s.base_stats["speed"] = speed;
            s.base_stats["damage"] = damage;
            if (armor != 0f) s.base_stats["armor"] = armor;
            if (magic != 0f) s.base_stats[PowerLevel.StatMagic] = magic;

            // Not shaken off by a lucky hit: a Commandment's punishment lasts as long as it lasts.
            s.removed_on_damage = false;

            SDSRegistry.AddStatus(s);
            SDSStatus.MarkNegative(id);
            SDSLocale.Status(id, nameEs, infoEs);
        }

        private static void Link(string law, string status, string fx, float seconds)
        {
            _byLaw[law] = new Punishment(status, fx, seconds);
        }

        /// Delivers the spectacle for a law, if it has one. Called by TenCommandments right after the
        /// plain curse lands, so an Infinity holder who shrugged off the curse never sees this either.
        public static void Deliver(Actor subject, string law)
        {
            if (subject == null || !subject.isAlive() || string.IsNullOrEmpty(law)) return;

            Punishment p;
            if (!_byLaw.TryGetValue(law, out p)) return;

            // Already suffering it: renew quietly rather than replaying the animation every second.
            bool fresh = !subject.hasStatus(p.status);

            if (!SDSStatus.Inflict(subject, p.status, p.seconds)) return;

            if (fresh) SDSFx.At(subject, p.fx, 0.5f);
        }

        /// True when this unit is under a punishment that should stop it acting. Read by the
        /// abilities so a petrified caster does not keep casting.
        public static bool Incapacitated(Actor a)
        {
            if (a == null) return false;
            return a.hasStatus(Petrified) || a.hasStatus(Paralyzed);
        }
    }
}
