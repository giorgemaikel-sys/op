using System.Collections.Generic;
using UnityEngine;

namespace SevenDeadlySins
{
    /// A load-time audit. Runs once, needs no simulation, and reports the failure modes that are
    /// otherwise invisible until a player stumbles into them hours later:
    /// a trait with no name, a button with no icon, two traits wearing the same icon, an exclusion
    /// list that never took effect.
    ///
    /// It never throws and never blocks the load. It only tells the truth in the log.
    public static class SDSSelfCheck
    {
        public static void Run()
        {
            int problems = 0;

            problems += CheckTraitsRegistered();
            problems += CheckTraitLocales();
            problems += CheckDuplicateIcons();
            problems += CheckOpposites();
            problems += CheckStatuses();
            problems += CheckActors();
            problems += CheckPowerStats();

            if (problems == 0)
                Debug.Log(Main.Tag + " autocomprobacion: todo correcto ("
                          + SDSRegistry.TraitIds.Count + " traits, "
                          + SDSRegistry.StatusIds.Count + " estados, "
                          + SDSRegistry.ActorIds.Count + " actores, "
                          + SDSRegistry.PowerIds.Count + " poderes)");
            else
                Debug.LogWarning(Main.Tag + " autocomprobacion: " + problems + " problema(s) detectado(s)");
        }

        /// Every id we think we registered should actually be in the game's library.
        private static int CheckTraitsRegistered()
        {
            int bad = 0;
            foreach (string id in SDSRegistry.TraitIds)
            {
                if (AssetManager.traits.get(id) == null)
                {
                    Debug.LogError(Main.Tag + " trait declarado pero NO registrado: " + id);
                    bad++;
                }
            }
            return bad;
        }

        /// A trait with no name shows the raw id in the unit panel.
        private static int CheckTraitLocales()
        {
            int bad = 0;
            foreach (string id in SDSRegistry.TraitIds)
            {
                if (!Resolves("trait_" + id))
                {
                    Debug.LogWarning(Main.Tag + " trait sin nombre localizado: " + id);
                    bad++;
                }
                if (!Resolves("trait_" + id + "_info"))
                {
                    Debug.LogWarning(Main.Tag + " trait sin descripcion: " + id);
                    bad++;
                }
            }
            return bad;
        }

        /// Two traits sharing an icon is not fatal, but it means the player cannot tell them apart
        /// at a glance — which for a mod built on "which sin is this" is most of the point.
        private static int CheckDuplicateIcons()
        {
            Dictionary<string, string> seen = new Dictionary<string, string>();
            int bad = 0;

            foreach (KeyValuePair<string, string> pair in SDSRegistry.TraitIcons)
            {
                if (string.IsNullOrEmpty(pair.Value)) continue;

                string other;
                if (seen.TryGetValue(pair.Value, out other))
                {
                    Debug.LogWarning(Main.Tag + " icono compartido por '" + other + "' y '"
                                     + pair.Key + "': " + pair.Value);
                    bad++;
                }
                else seen[pair.Value] = pair.Key;
            }
            return bad;
        }

        /// The single most damaging silent failure in this mod: if ApplyOpposites did not take, a
        /// unit can hold all seven sins at once and every balance decision is meaningless.
        /// We verify the game actually built the hashsets, not just that we filled the lists.
        private static int CheckOpposites()
        {
            int bad = 0;
            string[][] families =
            {
                Clans.All, SevenSins.All, TenCommandments.All, MagicTypes.All, HolyKnights.All,
            };
            string[] names = { "clanes", "pecados", "mandamientos", "magia", "rangos" };

            for (int f = 0; f < families.Length; f++)
            {
                string[] family = families[f];
                if (family == null || family.Length < 2) continue;

                ActorTrait t = AssetManager.traits.get(family[0]);
                if (t == null) continue;

                bool ok = t.opposite_traits != null && t.opposite_traits.Count > 0;
                if (!ok)
                {
                    Debug.LogError(Main.Tag + " EXCLUSIVIDAD INERTE en " + names[f]
                                   + ": opposite_traits vacio en '" + family[0]
                                   + "'. ApplyOpposites no surtio efecto.");
                    bad++;
                }
            }
            return bad;
        }

        private static int CheckStatuses()
        {
            int bad = 0;
            foreach (string id in SDSRegistry.StatusIds)
            {
                if (AssetManager.status.get(id) == null)
                {
                    Debug.LogError(Main.Tag + " estado declarado pero NO registrado: " + id);
                    bad++;
                    continue;
                }
                if (!Resolves("status_title_" + id))
                {
                    Debug.LogWarning(Main.Tag + " estado sin titulo localizado: " + id);
                    bad++;
                }
            }
            return bad;
        }

        private static int CheckActors()
        {
            int bad = 0;
            foreach (string id in SDSRegistry.ActorIds)
            {
                if (AssetManager.actor_library.get(id) == null)
                {
                    Debug.LogError(Main.Tag + " actor declarado pero NO registrado: " + id);
                    bad++;
                }
            }
            return bad;
        }

        /// The three stats the whole mod is built on. If these are missing, every power level is 0.
        private static int CheckPowerStats()
        {
            int bad = 0;
            string[] stats = { PowerLevel.StatStrength, PowerLevel.StatSpirit, PowerLevel.StatMagic };

            foreach (string id in stats)
            {
                if (AssetManager.base_stats_library.get(id) == null)
                {
                    Debug.LogError(Main.Tag + " STAT BASE AUSENTE: " + id
                                   + ". Todo nivel de poder saldra a cero.");
                    bad++;
                }
            }
            return bad;
        }

        /// True when the key resolves to real text rather than the game handing the key back.
        private static bool Resolves(string key)
        {
            try
            {
                string v = LocalizedTextManager.getText(key, null, false);
                return !string.IsNullOrEmpty(v) && v != key;
            }
            catch { return false; }
        }
    }
}
