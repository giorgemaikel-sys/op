using System.Collections.Generic;

namespace SevenDeadlySins
{
    /// The single door for inflicting a NEGATIVE status.
    ///
    /// Why this exists instead of a cleanse routine: no status-REMOVAL signature was verifiable
    /// against this build (`clearStatus` exists in the assembly but its parameters could not be
    /// confirmed, and guessing wrong on a method that touches the status pool is not worth it). So
    /// immunity is enforced where the status is applied rather than by stripping it afterwards.
    ///
    /// That inversion turns out to be the better design anyway: Merlin's Infinity is supposed to mean
    /// "nothing sticks to her", and never applying it is a truer reading than applying it and then
    /// removing it a fraction of a second later.
    ///
    /// Anything that lapses on its own — Escanor's The One, an aura — should NOT go through here.
    /// Apply those directly with a short duration and re-apply them while the condition holds.
    public static class SDSStatus
    {
        /// Every affliction in the mod. Registered here so Infinity does not have to be taught about
        /// each new curse by hand.
        private static readonly HashSet<string> _negative = new HashSet<string>
        {
            "sds_status_hellblaze",
            "sds_status_curse_piety", "sds_status_curse_love", "sds_status_curse_truth",
            "sds_status_curse_faith", "sds_status_curse_selflessness", "sds_status_curse_pacifism",
            "sds_status_curse_repose", "sds_status_curse_patience", "sds_status_curse_reticence",
            "sds_status_curse_purity",
        };

        public static void MarkNegative(string statusId)
        {
            if (!string.IsNullOrEmpty(statusId)) _negative.Add(statusId);
        }

        public static bool IsNegative(string statusId)
        {
            return !string.IsNullOrEmpty(statusId) && _negative.Contains(statusId);
        }

        /// True when nothing bad can be made to stick to this unit.
        public static bool IsImmune(Actor a)
        {
            return a != null && a.hasTrait(Abilities.Infinity);
        }

        /// Inflicts a status. Returns false when it was refused — the caller can use that to skip the
        /// visual effect, so an immune target reads as "nothing happened" rather than as a hit.
        public static bool Inflict(Actor target, string statusId, float duration)
        {
            if (target == null || !target.isAlive() || string.IsNullOrEmpty(statusId)) return false;
            if (IsNegative(statusId) && IsImmune(target)) return false;

            try { target.addStatusEffect(statusId, duration); }
            catch { return false; }
            return true;
        }
    }
}
