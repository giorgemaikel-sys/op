using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace SevenDeadlySins
{
    /// The single door through which every system registers content.
    /// Systems never touch AssetManager directly, so every id is tracked and self-checked.
    public static class SDSRegistry
    {
        public static readonly List<string> TraitIds = new List<string>();
        public static readonly List<string> StatusIds = new List<string>();
        public static readonly List<string> EffectIds = new List<string>();
        public static readonly List<string> ProjectileIds = new List<string>();
        public static readonly List<string> ActorIds = new List<string>();
        public static readonly List<string> PowerIds = new List<string>();
        public static readonly List<string> KingdomIds = new List<string>();
        public static readonly List<string> ItemIds = new List<string>();

        /// Every trait's icon, by id. Most traits are registered through a helper (Clan, Sin,
        /// Commandment, Rank...) that passes the path in, so grepping the source finds only a
        /// fraction of them — this is the one place they ALL pass through. SDSSelfCheck reads it to
        /// report any icon worn by more than one trait.
        public static readonly Dictionary<string, string> TraitIcons = new Dictionary<string, string>();

        // ---------------------------------------------------------------- traits

        /// rate_birth is deliberately never set. The game's birth pool is species-blind, so a trait
        /// left in it gets rolled onto bears and dragons too. Systems hand traits out instead.
        public static ActorTrait Trait(string id, string group, string icon, int rateInherit = 0)
        {
            ActorTrait t = new ActorTrait();
            t.id = id;
            t.group_id = group;
            t.path_icon = icon;
            if (!string.IsNullOrEmpty(id)) TraitIcons[id] = icon;
            t.can_be_given = true;
            t.needs_to_be_explored = false;
            t.rate_inherit = rateInherit;
            t.rate_birth = 0;
            t.base_stats = new BaseStats();
            return t;
        }

        public static void AddTrait(ActorTrait t)
        {
            if (t == null) return;
            if (!TraitIds.Contains(t.id)) TraitIds.Add(t.id);
            if (AssetManager.traits.dict.ContainsKey(t.id)) return;
            AssetManager.traits.add(t);
        }

        /// Makes every id in the set mutually exclusive with the others.
        /// Used for the six clans, the seven sins, the ten commandments and the magic types:
        /// each of those is a "pick exactly one" axis.
        public static void Opposites(string[] ids)
        {
            foreach (string id in ids)
            {
                Opposite(id, ids.Where(x => x != id).ToArray());
            }
        }

        /// One-way declaration: adding `id` removes each of `others`.
        /// Used where exclusion is not symmetric — a Demon may hold the Demon Mark, but taking the
        /// Goddess clan strips it.
        public static void Opposite(string id, string[] others)
        {
            ActorTrait t = AssetManager.traits.get(id);
            if (t == null) return;
            t.opposite_list = new List<string>(others);
        }

        /// Actor.addTrait removes opposites by reading trait.opposite_traits, a HashSet the game
        /// builds from opposite_list inside fillOppositeHashsetsWithAssets — which runs while the
        /// library boots, long before a mod registers anything. Without this call our exclusion
        /// lists are inert, and a unit can hold all seven sins and all ten commandments at once.
        /// MUST run after the last trait is registered. See DESIGN.md invariant 1.
        public static void ApplyOpposites()
        {
            AssetManager.traits.fillOppositeHashsetsWithAssets();
        }

        // ---------------------------------------------------------------- statuses

        public static StatusAsset Status(string id, string icon, float duration)
        {
            StatusAsset s = new StatusAsset();
            s.id = id;
            s.path_icon = icon;
            s.duration = duration;
            s.base_stats = new BaseStats();
            s.locale_id = "status_title_" + id;
            s.locale_description = "status_description_" + id;
            return s;
        }

        /// Draws an animated aura on the actor, reusing an effect sprite folder under
        /// GameResources/effects/<fxFolder>/. Used by the Demon Mark, Sunshine and Indura.
        public static void Aura(StatusAsset s, string fxFolder, float scale)
        {
            s.animated = true;
            s.texture = fxFolder;
            s.sprite_list = SpriteTextureLoader.getSpriteList("effects/" + fxFolder, false);
            s.material = SDSFx.AuraMaterial;
            s.need_visual_render = true;
            s.removed_on_damage = false;
            s.is_animated_in_pause = false;
            s.can_be_flipped = true;
            s.scale = scale;
        }

        public static void AddStatus(StatusAsset s)
        {
            if (s == null) return;
            if (!StatusIds.Contains(s.id)) StatusIds.Add(s.id);
            if (AssetManager.status.dict.ContainsKey(s.id)) return;
            AssetManager.status.add(s);
        }

        // ---------------------------------------------------------------- effects

        public static void Effect(string id, string spritePath, float frameTime = 0.05f)
        {
            if (!EffectIds.Contains(id)) EffectIds.Add(id);
            if (AssetManager.effects_library.get(id) != null) return;

            EffectAsset asset = new EffectAsset();
            asset.id = id;
            asset.use_basic_prefab = true;
            asset.sorting_layer_id = "EffectsTop";
            asset.sprite_path = spritePath;
            asset.time_between_frames = frameTime;
            AssetManager.effects_library.add(asset);
        }

        // ---------------------------------------------------------------- projectiles

        public static void AddProjectile(ProjectileAsset p)
        {
            if (p == null) return;
            if (!ProjectileIds.Contains(p.id)) ProjectileIds.Add(p.id);
            if (AssetManager.projectiles.get(p.id) != null) return;
            AssetManager.projectiles.add(p);
        }

        // ---------------------------------------------------------------- actors

        /// Clones a vanilla actor template ("$mob$" for a hostile creature, "$unit$" for a citizen)
        /// and registers it under a new id. Returns null if the template is missing.
        public static ActorAsset CloneActor(string newId, string template = "$mob$")
        {
            if (!ActorIds.Contains(newId)) ActorIds.Add(newId);
            ActorAsset existing = AssetManager.actor_library.get(newId);
            if (existing != null) return existing;

            try
            {
                ActorAsset a = AssetManager.actor_library.clone(newId, template);

                // linkAssets runs before OnModLoad, so a null check_flip here throws a
                // NullReferenceException deep inside the renderer. See DESIGN.md.
                if (a != null && a.check_flip == null) a.check_flip = delegate { return true; };
                return a;
            }
            catch (System.Exception e)
            {
                Debug.LogError(Main.Tag + " no se pudo clonar el actor '" + newId + "': " + e.Message);
                return null;
            }
        }

        // ---------------------------------------------------------------- powers

        public static void AddPower(GodPower p)
        {
            if (p == null) return;
            if (!PowerIds.Contains(p.id)) PowerIds.Add(p.id);
            if (AssetManager.powers.get(p.id) != null) return;
            AssetManager.powers.add(p);
        }

        // ---------------------------------------------------------------- kingdoms

        public static void AddKingdom(KingdomAsset k)
        {
            if (k == null) return;
            if (!KingdomIds.Contains(k.id)) KingdomIds.Add(k.id);
            if (AssetManager.kingdoms.get(k.id) != null) return;
            AssetManager.kingdoms.add(k);
        }

        // ---------------------------------------------------------------- items

        /// Weapons are CLONED from a vanilla template with AssetManager.items.clone, which registers
        /// them as a side effect — there is no add() path that accepts an ItemAsset on this build.
        /// So this only records the id for the self-check; SacredTreasures does the cloning.
        public static void TrackItem(string id)
        {
            if (string.IsNullOrEmpty(id)) return;
            if (!ItemIds.Contains(id)) ItemIds.Add(id);
        }
    }
}
