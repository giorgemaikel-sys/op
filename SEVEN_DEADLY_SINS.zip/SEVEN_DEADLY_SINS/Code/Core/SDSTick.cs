using System;
using System.Collections.Generic;
using UnityEngine;

namespace SevenDeadlySins
{
    /// A round-robin sliced tick.
    ///
    /// Walking every unit in the world every frame and doing string-keyed hasTrait lookups on each
    /// one does not survive a large world. Here each actor is visited once per sweep, and a sweep is
    /// spread across many frames, so per-frame cost stays flat no matter how big the population gets.
    ///
    /// Handlers receive the seconds elapsed since that actor was LAST VISITED, not the frame delta,
    /// so a per-second drain stays correct regardless of how long a sweep takes.
    public class SDSTick : MonoBehaviour
    {
        private const string HostName = "SevenDeadlySins_Logic";
        private const float StepInterval = 0.05f;
        private const int SweepFrames = 20;

        /// (actor, seconds since that actor was last visited)
        private static readonly List<Action<Actor, float>> _perActor = new List<Action<Actor, float>>();

        /// (seconds since last call) — runs once per second, for world-level systems.
        private static readonly List<Action<float>> _perSecond = new List<Action<float>>();

        private int _cursor;
        private float _accumulator;
        private float _secondAccumulator;
        private float _sweepStartTime;
        private float _lastSweepDuration = 1f;

        public static void Register(Action<Actor, float> handler)
        {
            if (handler != null && !_perActor.Contains(handler)) _perActor.Add(handler);
        }

        public static void RegisterGlobal(Action<float> handler)
        {
            if (handler != null && !_perSecond.Contains(handler)) _perSecond.Add(handler);
        }

        public static void Install()
        {
            if (GameObject.Find(HostName) != null) return;
            GameObject host = new GameObject(HostName);
            UnityEngine.Object.DontDestroyOnLoad(host);
            host.AddComponent<SDSTick>();
        }

        private void Start()
        {
            _sweepStartTime = Time.time;
        }

        private void Update()
        {
            if (World.world == null || World.world.isPaused()) return;
            if (MapBox.instance == null || MapBox.instance.units == null) return;

            _secondAccumulator += Time.deltaTime;
            if (_secondAccumulator >= 1f)
            {
                RunGlobal(_secondAccumulator);
                _secondAccumulator = 0f;
            }

            _accumulator += Time.deltaTime;
            if (_accumulator < StepInterval) return;
            _accumulator = 0f;

            List<Actor> units = MapBox.instance.units.getSimpleList();
            if (units == null || units.Count == 0) return;

            // Visit a slice of the population; a full sweep completes every SweepFrames steps.
            int perStep = Mathf.Max(1, units.Count / SweepFrames);
            for (int i = 0; i < perStep; i++)
            {
                if (_cursor >= units.Count)
                {
                    _cursor = 0;
                    _lastSweepDuration = Mathf.Max(0.01f, Time.time - _sweepStartTime);
                    _sweepStartTime = Time.time;
                }

                Actor a = units[_cursor];
                _cursor++;

                if (a == null || !a.isAlive()) continue;

                for (int h = 0; h < _perActor.Count; h++)
                {
                    try { _perActor[h](a, _lastSweepDuration); }
                    catch (Exception e) { Debug.LogError(Main.Tag + " tick por actor: " + e); }
                }
            }
        }

        private void RunGlobal(float dt)
        {
            for (int h = 0; h < _perSecond.Count; h++)
            {
                try { _perSecond[h](dt); }
                catch (Exception e) { Debug.LogError(Main.Tag + " tick global: " + e); }
            }
        }
    }
}
