using System;
using System.Collections.Generic;
using UnityEngine;

namespace SevenDeadlySins
{
    /// The signature mechanic of Nanatsu no Taizai.
    ///
    ///     Nivel de Poder = Fuerza + Espiritu + Magia
    ///
    /// The three halves are real BaseStatAssets, so ANY trait, status or item raises them just by
    /// writing base_stats["sds_strength"] — the game recomputes the total for us and it shows in the
    /// vanilla stat panel. Nothing here keeps a parallel copy of a number the game already owns.
    ///
    /// On top of that sits a list of MULTIPLIERS contributed by transformations (Sunshine, the Demon
    /// Mark, Indura). They are registered rather than hard-coded so that two transformations active at
    /// once compose instead of overwriting each other.
    public static class PowerLevel
    {
        public const string StatStrength = "sds_strength";
        public const string StatSpirit = "sds_spirit";
        public const string StatMagic = "sds_magic";

        /// A named multiplier on top of the raw stat sum. Return 1f to contribute nothing.
        /// Registered at load time by the systems that own each transformation.
        private static readonly List<KeyValuePair<string, Func<Actor, float>>> _contributors =
            new List<KeyValuePair<string, Func<Actor, float>>>();

        public static void AddContributor(string name, Func<Actor, float> multiplier)
        {
            if (string.IsNullOrEmpty(name) || multiplier == null) return;
            for (int i = 0; i < _contributors.Count; i++)
                if (_contributors[i].Key == name) return;      // idempotent: Init may run twice
            _contributors.Add(new KeyValuePair<string, Func<Actor, float>>(name, multiplier));
        }

        public static void RegisterBaseStats()
        {
            Stat(StatStrength, "ui/icons/iconDamage", 901);
            Stat(StatSpirit, "ui/icons/iconHealth", 902);
            Stat(StatMagic, "ui/icons/iconMana", 903);
        }

        private static void Stat(string id, string icon, int sortRank)
        {
            if (AssetManager.base_stats_library.get(id) != null) return;

            BaseStatAsset s = new BaseStatAsset();
            s.id = id;
            s.icon = icon;
            s.normalize = false;
            s.sort_rank = sortRank;
            s.translation_key = id;
            AssetManager.base_stats_library.add(s);
        }

        // ---------------------------------------------------------------- reading

        public static float Strength(Actor a)
        {
            return a == null || a.stats == null ? 0f : Mathf.Max(0f, a.stats[StatStrength]);
        }

        public static float Spirit(Actor a)
        {
            return a == null || a.stats == null ? 0f : Mathf.Max(0f, a.stats[StatSpirit]);
        }

        public static float Magic(Actor a)
        {
            return a == null || a.stats == null ? 0f : Mathf.Max(0f, a.stats[StatMagic]);
        }

        /// The raw sum, before any transformation multiplies it.
        public static float Base(Actor a)
        {
            return Strength(a) + Spirit(a) + Magic(a);
        }

        /// El producto de todos los multiplicadores de transformacion de esta unidad.
        ///
        /// Lo llama PowerScaling una vez por recalculo de estadisticas, y el resultado se aplica
        /// DIRECTAMENTE sobre `sds_strength`, `sds_spirit` y `sds_magic`. Antes se aplicaba aqui,
        /// sobre el total, y el panel se contradecia: la Fuerza, el Espiritu y la Magia se quedaban
        /// igual mientras el Nivel de Poder se multiplicaba por cincuenta, asi que las tres partes
        /// no sumaban el todo. Ahora crecen las partes y el total sale solo.
        public static float Multiplier(Actor a)
        {
            if (a == null) return 1f;

            float m = 1f;
            for (int i = 0; i < _contributors.Count; i++)
            {
                try
                {
                    float c = _contributors[i].Value(a);
                    if (c > 0f && !float.IsNaN(c) && !float.IsInfinity(c)) m *= c;
                }
                catch (Exception e)
                {
                    Debug.LogError(Main.Tag + " contribuyente de nivel de poder '"
                                   + _contributors[i].Key + "': " + e.Message);
                }
            }
            return m;
        }

        /// THE public read. Everything that cares about how strong someone is calls this and nothing
        /// else, so a transformation only has to be taught to one place.
        ///
        /// Ya NO multiplica por los contribuyentes: eso lo hace PowerScaling sobre las estadisticas
        /// mismas. Volver a hacerlo aqui contaria el aumento dos veces.
        public static float Get(Actor a)
        {
            if (a == null || a.stats == null) return 0f;

            float total = Base(a);
            if (total <= 0f) return 0f;

            // Experience matters: a veteran of a hundred battles outclasses a fresh recruit with the
            // same blood. Kept sub-linear so it flavours the number instead of dominating it.
            total *= 1f + Mathf.Sqrt(Mathf.Max(0, a.data.kills)) * 0.05f;

            return Mathf.Max(0f, total);
        }

        /// Formatted the way the series writes it: thousands separated, no decimals.
        public static string Format(Actor a)
        {
            return Mathf.RoundToInt(Get(a)).ToString("N0");
        }

        /// Cached on the actor so the unit panel can draw without recomputing every frame.
        /// Refreshed by the sliced tick.
        public static void Cache(Actor a, float dt)
        {
            if (a == null || a.data == null) return;
            float pl = Get(a);
            if (pl <= 0f) return;
            SDSData.SetFloat(a, SDSData.PowerLevelCache, pl);
        }

        public static float Cached(Actor a)
        {
            float v = SDSData.GetFloat(a, SDSData.PowerLevelCache, -1f);
            return v >= 0f ? v : Get(a);
        }

        /// Convenience for the content files: hand a trait its three numbers in one line.
        public static void Grant(ActorTrait t, float strength, float spirit, float magic)
        {
            if (t == null) return;
            if (t.base_stats == null) t.base_stats = new BaseStats();
            if (strength != 0f) t.base_stats[StatStrength] = strength;
            if (spirit != 0f) t.base_stats[StatSpirit] = spirit;
            if (magic != 0f) t.base_stats[StatMagic] = magic;
        }

        /// Same, for a status.
        public static void Grant(StatusAsset s, float strength, float spirit, float magic)
        {
            if (s == null) return;
            if (s.base_stats == null) s.base_stats = new BaseStats();
            if (strength != 0f) s.base_stats[StatStrength] = strength;
            if (spirit != 0f) s.base_stats[StatSpirit] = spirit;
            if (magic != 0f) s.base_stats[StatMagic] = magic;
        }

        /// NO REGISTRA NADA EN EL TICK, y eso es el arreglo.
        ///
        /// Antes `Cache` corria sobre CADA actor en CADA barrido, y cada llamada recalculaba el
        /// nivel de poder recorriendo los seis contribuyentes (sunshine, marca del demonio, snatch,
        /// progresion, magia, rey demonio), cada uno con sus hasTrait/hasStatus. En un mundo grande
        /// eso son decenas de miles de busquedas por segundo para mantener al dia un numero que solo
        /// se mira cuando abres el panel de una unidad.
        ///
        /// Ahora el panel llama a Get() cuando dibuja, que es una vez por unidad seleccionada.
        public static void Init()
        {
        }
    }
}
