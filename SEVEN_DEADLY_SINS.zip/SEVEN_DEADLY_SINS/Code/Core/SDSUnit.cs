using System.Collections.Generic;
using UnityEngine;

namespace SevenDeadlySins
{
    /// Who is allowed to be what.
    ///
    /// No trait in this mod uses rate_birth: the game's birth pool is species-blind and would roll a
    /// Commandment onto a bear. Everything is handed out by systems, and the gates are here.
    public static class SDSUnit
    {
        /// Races that may carry a clan, a magic type, a sin or a commandment.
        /// Populated by Actors.Init once the custom races exist, plus vanilla "human".
        internal static readonly HashSet<string> SentientRaces = new HashSet<string> { "human" };

        public static void AllowRace(string actorAssetId)
        {
            if (!string.IsNullOrEmpty(actorAssetId)) SentientRaces.Add(actorAssetId);
        }

        /// Only these may carry clans, magic, sins, commandments and ranks.
        public static bool IsSentient(Actor a)
        {
            if (a == null || !a.isAlive() || a.asset == null) return false;
            return SentientRaces.Contains(a.asset.id);
        }

        /// One of the named characters of the story. The cheap gate every character system opens
        /// with — see SDSData.Named for why it exists.
        public static bool IsNamed(Actor a)
        {
            return a != null && a.data != null && SDSData.GetBool(a, SDSData.Named);
        }

        /// Marca de que esta unidad USA habilidades de firma aunque no sea una leyenda con nombre:
        /// un hijo que hereda una, un hibrido al que se le conceden. Sin esto, sus habilidades tenian
        /// el rasgo pero el comportamiento no corria (gateado en IsNamed) — por eso "no funcionaban".
        public const string AbilityUserKey = "sds_ability_user";

        public static void MarkAbilityUser(Actor a)
        {
            if (a != null && a.data != null) SDSData.SetBool(a, AbilityUserKey, true);
        }

        /// True para cualquiera que deba EJECUTAR una habilidad de firma: las leyendas con nombre y
        /// los que la heredaron/recibieron. Es la puerta correcta de los ticks de habilidad, en vez
        /// de solo IsNamed.
        public static bool RunsAbilities(Actor a)
        {
            return a != null && a.data != null
                && (SDSData.GetBool(a, SDSData.Named) || SDSData.GetBool(a, AbilityUserKey));
        }

        // ---------------------------------------------------------------- clan queries

        /// The clan trait this unit carries, or null. The six clans are mutually exclusive, so there
        /// is at most one.
        public static string ClanOf(Actor a)
        {
            if (a == null) return null;
            for (int i = 0; i < Clans.All.Length; i++)
                if (a.hasTrait(Clans.All[i])) return Clans.All[i];
            return null;
        }

        /// True si es un HIBRIDO (cruce de dos razas). Un hibrido ya NO lleva clan base: su identidad
        /// es su mezcla, no un clan — como pidio el usuario y como es en el canon (Tristan no es "un
        /// demonio", es medio demonio medio diosa).
        public static bool IsHybrid(Actor a)
        {
            return a != null && a.hasTrait(Offspring.TraitHybrid);
        }

        /// La raza REPRESENTATIVA de una unidad, para decidir cruces y herencia. Para un puro es su
        /// clan base; para un HIBRIDO (que ya no lleva clan base) se deduce de su SANGRE, para que
        /// pueda seguir cruzandose y engendrar hijos con su herencia — incluida la 3a generacion
        /// (los Caballeros del Grial).
        public static string RaceKeyOf(Actor a)
        {
            if (a == null) return null;
            string c = ClanOf(a);
            if (c == Clans.Human) return "human";
            if (c == Clans.Demon) return "demon";
            if (c == Clans.Goddess) return "goddess";
            if (c == Clans.Fairy) return "fairy";
            if (c == Clans.Giant) return "giant";
            if (c == Clans.Vampire) return "vampire";
            // Hibrido sin clan base: por sangre (prioridad tematica demonio > diosa > hada > gigante > vampiro).
            if (a.hasTrait(Traits.DemonBlood)) return "demon";
            if (a.hasTrait(Traits.GoddessBlood)) return "goddess";
            if (a.hasTrait(Traits.FairyWings)) return "fairy";
            if (a.hasTrait(Traits.GiantStrength)) return "giant";
            if (a.hasTrait(Traits.VampireThirst)) return "vampire";
            return null;
        }

        public static bool IsDemon(Actor a) { return a != null && a.hasTrait(Clans.Demon); }
        public static bool IsGoddess(Actor a) { return a != null && a.hasTrait(Clans.Goddess); }
        public static bool IsFairy(Actor a) { return a != null && a.hasTrait(Clans.Fairy); }
        public static bool IsGiant(Actor a) { return a != null && a.hasTrait(Clans.Giant); }
        public static bool IsVampire(Actor a) { return a != null && a.hasTrait(Clans.Vampire); }
        public static bool IsHuman(Actor a) { return a != null && a.hasTrait(Clans.Human); }

        // ---------------------------------------------------------------- role queries

        /// The sin trait this unit bears, or null.
        public static string SinOf(Actor a)
        {
            if (a == null) return null;
            for (int i = 0; i < SevenSins.All.Length; i++)
                if (a.hasTrait(SevenSins.All[i])) return SevenSins.All[i];
            return null;
        }

        /// The commandment this unit holds, or null.
        public static string CommandmentOf(Actor a)
        {
            if (a == null) return null;
            for (int i = 0; i < TenCommandments.All.Length; i++)
                if (a.hasTrait(TenCommandments.All[i])) return TenCommandments.All[i];
            return null;
        }

        public static bool IsSin(Actor a) { return SinOf(a) != null; }
        public static bool IsCommandment(Actor a) { return CommandmentOf(a) != null; }

        /// Demons and Goddesses are at war by blood, not by kingdom. Several systems key off this.
        public static bool AreEnemyClans(Actor x, Actor y)
        {
            if (x == null || y == null) return false;
            return (IsDemon(x) && IsGoddess(y)) || (IsGoddess(x) && IsDemon(y));
        }

        // ---------------------------------------------------------------- allegiance

        /// AMIGO robusto — la puerta que arregla las curas de los hibridos.
        ///
        /// EL BUG: un hijo del mod (legado o hibrido de raza) casi siempre cae en un reino SALVAJE
        /// distinto al de sus padres y aliados; y si lo INVOCAS a mano (dos sueltos, uno hembra y otro
        /// macho, como hace el usuario), puede no tener reino ninguno. Con la comprobacion vieja
        /// "o.kingdom == a.kingdom" sus curas no encontraban a NADIE y fallaban en silencio — "la
        /// llama que cura no curaba". Aqui se reconoce al aliado por VARIAS vias, no solo el reino:
        ///   1) mismo reino (aliado seguro),
        ///   2) familia/sangre — isRelatedTo — que es justo lo que salva el caso "invocados a mano":
        ///      el bebe SIEMPRE es pariente de sus padres,
        ///   3) misma ciudad,
        ///   4) por ultimo, una unidad del mod con nombre a la que el juego NO trata como enemiga
        ///      (excluyendo al clan-enemigo por sangre, para que una diosa no "cure" a un demonio).
        public static bool IsAlly(Actor a, Actor o)
        {
            if (a == null || o == null || o == a || !o.isAlive()) return false;
            if (a.kingdom != null && o.kingdom == a.kingdom) return true;    // mismo reino
            try { if (a.isRelatedTo(o)) return true; } catch { }             // sangre/familia (cubre "invocados a mano")
            try { if (a.city != null && o.city == a.city) return true; } catch { }  // misma ciudad
            // NADA de fallback "no-enemigo + tiene-habilidades": trataba como ALIADO a cualquier otro
            // usuario de habilidades de otro reino con el que no hubiera guerra declarada. Como ahora
            // TODOS los hibridos/legados son usuarios de habilidades, dos enemigos se veian como
            // aliados: no se atacaban, se curaban entre si, y la habilidad ni se disparaba (sin
            // enemigo a la vista). Era la causa de "afectan al bando equivocado" y "no hacen nada".
            return false;
        }

        /// ENEMIGO: el foe REAL del juego; en su defecto, cualquiera de otro reino que no sea aliado.
        /// (Las habilidades OFENSIVAS ya funcionaban con "o.kingdom != a.kingdom"; esto es el reverso
        /// exacto de IsAlly para los sitios que quieran un unico criterio coherente.)
        public static bool IsEnemy(Actor a, Actor o)
        {
            if (a == null || o == null || o == a || !o.isAlive()) return false;
            try { if (a.areFoes(o)) return true; } catch { }
            return !IsAlly(a, o) && o.kingdom != a.kingdom;
        }

        // ---------------------------------------------------------------- proximity

        /// Living units within `radius` tiles of the actor. Used by the commandment curses and by
        /// every area ability. Never returns null.
        public static List<Actor> Around(Actor a, float radius, bool includeSelf = false)
        {
            List<Actor> found = new List<Actor>();
            if (a == null || a.current_tile == null) return found;

            try
            {
                // Chunk count scales with radius: too few chunks and units at the edge of a large
                // radius are simply never seen, which is how a commandment curse silently stops
                // punishing anyone standing more than a chunk away.
                int chunks = Mathf.Clamp(Mathf.CeilToInt(radius / 2f), 1, 10);
                foreach (Actor other in Finder.getUnitsFromChunk(a.current_tile, chunks, radius, false))
                {
                    if (other == null || !other.isAlive()) continue;
                    if (!includeSelf && other == a) continue;
                    found.Add(other);
                }
            }
            catch { }
            return found;
        }

        /// The living unit standing on (or immediately next to) a tile. Used by click actions.
        public static Actor At(WorldTile tile)
        {
            if (tile == null) return null;
            try
            {
                foreach (Actor a in Finder.getUnitsFromChunk(tile, 1, 1.5f, false))
                    if (a != null && a.isAlive()) return a;
            }
            catch { }
            return null;
        }
    }
}
