using System;
using UnityEngine;

namespace SevenDeadlySins
{
    /// Safe wrappers around EffectsLibrary. VFX must never be able to throw into a combat callback:
    /// a missing sprite should cost you a puff of smoke, not the ability that spawned it.
    ///
    /// Every member name here was checked against a mod that compiles on this build. The game uses
    /// snake_case for Actor.current_tile and spawnAtTile (not spawnAt) — guessing either one is a
    /// compile error that takes the whole mod down with it.
    public static class SDSFx
    {
        private static Material _auraMaterial;

        /// The lit material every animated status aura in WorldBox uses.
        public static Material AuraMaterial
        {
            get
            {
                if (_auraMaterial == null)
                {
                    try
                    {
                        _auraMaterial = LibraryMaterials.instance.dict["mat_world_object_lit"];
                    }
                    catch (Exception e)
                    {
                        Debug.LogError(Main.Tag + " no se pudo obtener mat_world_object_lit: " + e.Message);
                    }
                }
                return _auraMaterial;
            }
        }

        /// Plays a registered EffectAsset on an actor.
        public static void At(Actor a, string effectId, float scale = 0.3f)
        {
            if (string.IsNullOrEmpty(effectId)) return;
            try
            {
                if (a == null || !a.isAlive() || a.current_tile == null) return;
                EffectsLibrary.spawnAtTile(effectId, a.current_tile, scale);
            }
            catch { }
        }

        /// Plays a registered EffectAsset on a tile.
        public static void At(WorldTile tile, string effectId, float scale = 0.3f)
        {
            if (string.IsNullOrEmpty(effectId) || tile == null) return;
            try { EffectsLibrary.spawnAtTile(effectId, tile, scale); }
            catch { }
        }

        /// Effect-first spelling of At(tile, id). Both orders exist because both read naturally at
        /// the call site ("play this effect, there") and a wrong argument order is a compile error
        /// rather than a silent no-op.
        public static void Play(string effectId, WorldTile tile, float scale = 0.3f)
        {
            At(tile, effectId, scale);
        }

        public static void Play(string effectId, Actor a, float scale = 0.3f)
        {
            At(a, effectId, scale);
        }

        /// A shockwave centred on an actor. Used by Assault Mode, Indura and Creation.
        public static void Wave(Actor a, float radius = 1.5f, float power = 1f)
        {
            try
            {
                if (a == null || !a.isAlive() || a.current_tile == null) return;
                EffectsLibrary.spawnExplosionWave(a.current_tile.posV3, radius, power);
            }
            catch { }
        }

        /// Fires a registered projectile from caster to target.
        public static void Projectile(Actor caster, Actor target, string projectileId)
        {
            if (string.IsNullOrEmpty(projectileId)) return;
            try
            {
                if (caster == null || target == null) return;
                if (caster.current_tile == null || target.current_tile == null) return;
                World.world.projectiles.spawn(caster, target, projectileId,
                    caster.current_tile.posV3, target.current_tile.posV3);
            }
            catch { }
        }
    }
}
