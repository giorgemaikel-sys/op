using UnityEngine;

namespace SevenDeadlySins
{
    /// Time of day, derived from world time.
    ///
    /// WorldBox has no day/night clock a mod can read on this build, so we derive one deterministically
    /// from World.world.getCurWorldTime() — the same clock SDSData timestamps against. Deriving it
    /// rather than counting our own ticks means it survives save/load and pause without drifting, and
    /// two systems reading it in the same frame always agree.
    ///
    /// Two things depend on this and they are the reason it exists: Escanor's Sunshine, which must
    /// peak at noon and collapse at midnight, and the Vampire Clan, which must weaken in daylight.
    public static class DayCycle
    {
        /// One in-world day. Short enough that a player watching Escanor sees him rise and fall
        /// without waiting, long enough that noon feels like an event.
        public const float SecondsPerDay = 480f;

        /// Hour of the world day, in [0, 24). 0 and 24 are midnight, 12 is noon.
        public static float Hour()
        {
            double t = 0.0;
            try { if (World.world != null) t = World.world.getCurWorldTime(); }
            catch { }

            double frac = (t % SecondsPerDay) / SecondsPerDay;
            if (frac < 0.0) frac += 1.0;          // guard against a negative clock
            return (float)(frac * 24.0);
        }

        /// How high the sun sits: 0 at midnight, 1 at exactly noon, smooth in between.
        ///
        /// A cosine rather than a triangle wave on purpose — it makes dawn and dusk change fast while
        /// midday plateaus, which is what makes "noon Escanor" read as a window rather than a spike.
        public static float SunHeight()
        {
            float h = Hour();
            // cos(0) = 1 at midnight -> 0; cos(PI) = -1 at noon -> 1. Verified at both ends and at
            // the equinox hours (6 and 18 both give 0.5).
            return Mathf.Clamp01((1f - Mathf.Cos(h / 24f * 2f * Mathf.PI)) * 0.5f);
        }

        public static bool IsDay { get { float h = Hour(); return h >= 6f && h < 18f; } }
        public static bool IsNight { get { return !IsDay; } }

        /// The narrow window in which Escanor becomes The One.
        public static bool IsNoon { get { float h = Hour(); return h >= 11.5f && h <= 12.5f; } }

        /// Deep night, when a vampire is strongest and the Lion's Sin is a harmless man.
        public static bool IsDeepNight { get { float h = Hour(); return h >= 23f || h < 3f; } }

        /// A human-readable clock for the UI and the guide.
        public static string Clock()
        {
            float h = Hour();
            int hh = Mathf.FloorToInt(h);
            int mm = Mathf.FloorToInt((h - hh) * 60f);
            return hh.ToString("00") + ":" + mm.ToString("00");
        }
    }
}
