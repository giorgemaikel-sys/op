using UnityEngine;

namespace SevenDeadlySins
{
    /// On-screen feedback and console logging, both guarded so a UI failure can never abort a system.
    ///
    /// Tips are THROTTLED on purpose. A world of a thousand units produces dozens of these a second
    /// and WorldTip only shows one at a time, so an unthrottled tip looks frozen on screen while it
    /// is really being replaced sixty times a second.
    public static class SDSLog
    {
        private const float MinSecondsBetweenTips = 1.5f;
        private const float RepeatBlockSeconds = 8f;

        private static float _lastTipAt = -999f;
        private static string _lastMessage = "";
        private static float _lastMessageAt = -999f;

        public static void Info(string message)
        {
            Debug.Log(Main.Tag + " " + message);
        }

        public static void Warn(string message)
        {
            Debug.LogWarning(Main.Tag + " " + message);
        }

        public static void Error(string message)
        {
            Debug.LogError(Main.Tag + " " + message);
        }

        /// A transient tip in the corner of the screen. Used when the mod has to refuse something the
        /// player did, so the click does not just silently fail.
        public static void Tip(string message, float duration = 2.5f)
        {
            if (string.IsNullOrEmpty(message)) return;

            float now = Time.realtimeSinceStartup;
            if (now - _lastTipAt < MinSecondsBetweenTips) return;
            if (message == _lastMessage && now - _lastMessageAt < RepeatBlockSeconds) return;

            _lastTipAt = now;
            _lastMessage = message;
            _lastMessageAt = now;

            try { WorldTip.instance.show(message, false, "top", duration); }
            catch { }
        }

        /// An event that deserves to be part of Britannia's history: a sin awakening, a commandment
        /// falling, the first time someone reaches The One.
        ///
        /// Deliberately routed through the same throttled tip plus the console rather than the game's
        /// own world-log: no world-log API was verifiable against this build, and a chronicle entry is
        /// not worth risking a load failure over. Swap the body if a real API turns up.
        public static void Chronicle(string message)
        {
            if (string.IsNullOrEmpty(message)) return;
            Debug.Log(Main.Tag + " [cronica] " + message);
            Tip(message, 4f);
        }
    }
}
