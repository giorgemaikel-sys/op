using UnityEngine;

namespace SevenDeadlySins
{
    /// The one way traits are handed out.
    ///
    /// Actor.addTrait(id) defaults pRemoveOpposites to FALSE, so calling it directly leaves a unit
    /// holding two clans or three sins at once. Everything goes through Give.
    public static class SDSTraits
    {
        public static void Give(Actor a, string traitId)
        {
            if (a == null || string.IsNullOrEmpty(traitId)) return;
            if (a.hasTrait(traitId)) return;

            try
            {
                // The `true` is the whole point of this wrapper: it makes the exclusion lists
                // declared in SDSRegistry.Opposites actually strip the previous clan / sin / rank.
                a.addTrait(traitId, true);
            }
            catch (System.Exception e)
            {
                Debug.LogError(Main.Tag + " no se pudo dar el trait '" + traitId + "': " + e.Message);
            }
        }

        public static void Remove(Actor a, string traitId)
        {
            if (a == null || string.IsNullOrEmpty(traitId)) return;
            if (!a.hasTrait(traitId)) return;
            try { a.removeTrait(traitId); }
            catch { }
        }

        /// Gives exactly one of a set and strips the rest. Belt-and-braces for axes where a stray
        /// duplicate would be especially visible (the ten commandments).
        public static void GiveExclusive(Actor a, string traitId, string[] family)
        {
            if (a == null || string.IsNullOrEmpty(traitId)) return;
            for (int i = 0; i < family.Length; i++)
                if (family[i] != traitId) Remove(a, family[i]);
            Give(a, traitId);
        }
    }
}
