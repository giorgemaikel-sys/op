using HarmonyLib;
using UnityEngine;

namespace SevenDeadlySins
{
    /// Hace que el Nivel de Poder SIRVA PARA ALGO.
    ///
    /// Hasta ahora era un rotulo. `sds_strength`, `sds_spirit` y `sds_magic` son estadisticas mias,
    /// y el combate de WorldBox no las mira: pega con `damage`, aguanta con `health` y `armor`. O
    /// sea que Meliodas podia tener un Nivel de Poder de treinta mil y pegar como un aldeano, y el
    /// Purgatorio podia multiplicarte por cincuenta sin que cambiara nada en una pelea. Todo el
    /// sistema de transformaciones de este mod — Sunshine, la Marca del Demonio, Indura, el
    /// entrenamiento del Purgatorio — inflaba un numero decorativo.
    ///
    /// Aqui se cierra ese hueco: despues de que el juego recalcule las estadisticas de una unidad,
    /// se multiplican las de verdad segun su Nivel de Poder.
    ///
    /// POR QUE LA CURVA ES RAIZ CUADRADA. Lineal no vale. Un Rey Demonio con treinta y cuatro mil
    /// de Nivel de Poder pegaria treinta y cuatro mil veces mas que un humano y cada golpe seria un
    /// borrado instantaneo del mapa; ademas los numeros se irian a rangos donde el juego empieza a
    /// hacer cosas raras. Con raiz cuadrada la diferencia se NOTA muchisimo y sigue siendo una
    /// pelea: un Pecado arrasa a un caballero, pero un Rey Demonio no borra a un Pecado de un toque.
    internal static class PowerScaling
    {
        /// El Nivel de Poder de referencia: por debajo de esto no se multiplica nada.
        ///
        /// Un humano normal del juego no tiene ninguna estadistica mia, asi que su Nivel de Poder es
        /// cero y sale con factor 1. Esto solo toca a quien lleva algo del mod encima.
        private const float Baseline = 100f;

        /// Tope del multiplicador de combate. Sin el, el entrenamiento del Purgatorio (x50 sobre un
        /// Nivel de Poder ya alto) daria factores desbocados.
        ///
        /// Fijado en 150 a proposito, para que la ESCALERA CANONICA se note tambien en combate y no
        /// solo en el panel. Con raiz cuadrada sobre la base 100 los tramos quedan asi: un Pecado
        /// (~3.400) pega x6,8; un Mandamiento (26-60 mil) x17-25; The One de Escanor y los Demonios
        /// Originales (~170-210 mil) x42-47; la Diosa Suprema y el Rey Demonio (un millon) x101; el
        /// Caos (dos millones) x142 — el techo. Asi el Caos aplasta al Rey Demonio, el Rey Demonio a
        /// un Mandamiento y un Mandamiento a un Pecado, cada escalon claro pero cada pelea aun pelea.
        private const float MaxFactor = 150f;

        public static void Init()
        {
            Main.harmony.PatchAll(typeof(StatsPatch));
        }


        /// El multiplicador de combate que le corresponde a esta unidad.
        public static float FactorOf(Actor a)
        {
            float pl = PowerLevel.Get(a);
            if (pl <= Baseline) return 1f;

            float f = 1f + Mathf.Sqrt(pl / Baseline);
            return Mathf.Min(MaxFactor, f);
        }

        [HarmonyPatch(typeof(Actor), nameof(Actor.updateStats))]
        internal static class StatsPatch
        {
            /// EL PREFIJO NO ES OPCIONAL, Y ESTE ES EL MOTIVO.
            ///
            /// `updateStats` empieza con `if (!isStatsDirty()) return;` — o sea que la mayoria de
            /// las llamadas no recalculan nada. Pero un postfix de Harmony corre IGUAL aunque el
            /// metodo original se haya salido por esa puerta.
            ///
            /// Sin esta guarda, cada una de esas llamadas volvia a multiplicar unas estadisticas ya
            /// multiplicadas. La vida maxima crecia sin freno hasta desbordar el `(int)` de
            /// `getMaxHealth()`, y con una vida maxima corrupta el juego ya no puede rellenar la
            /// barra: `setHealth` hace `Clamp(valor, 1, getMaxHealth())` contra un numero sin
            /// sentido. Sintoma: "a los personajes que suben de poder no puedo curarlos del todo".
            ///
            /// Se apunta en el prefijo si tocaba recalcular, y solo entonces se escala.
            /// Devuelve la vida que tenia ANTES del recalculo, o -1 si no tocaba recalcular.
            ///
            /// Las dos cosas en el mismo dato porque las dos se necesitan y son del mismo momento:
            /// si hubo recalculo, y con cuanta vida se entro. El -1 distingue "no habia que hacer
            /// nada" de "tenia cero de vida".
            [HarmonyPrefix]
            public static void Prefix(Actor __instance, out int __state)
            {
                __state = -1;
                try
                {
                    if (__instance != null && __instance.data != null && __instance.isStatsDirty())
                        __state = __instance.data.health;
                }
                catch { }
            }

            /// Postfix: el juego ya ha sumado asset, rasgos, estados y equipo. Lo unico que queda es
            /// escalar el resultado. Va DESPUES a proposito — hacerlo antes lo pisaria todo.
            [HarmonyPostfix]
            public static void Postfix(Actor __instance, int __state)
            {
                if (__state < 0) return;

                Actor a = __instance;
                if (a == null || a.stats == null || a.data == null) return;

                try
                {
                    // EL PODER HEREDADO DE UN HIBRIDO, primero de todo.
                    //
                    // Un hijo de dos razas guarda en su ficha el 50% del poder de cada padre (ver
                    // Offspring). Se suma aqui, antes que nada, para que forme parte de su Nivel de
                    // Poder base y todo lo demas — transformaciones y factor de combate — lo escale
                    // igual que el resto. Va sobre las stats, no sobre el total, por lo mismo que el
                    // resto: para que el panel cuadre consigo mismo.
                    float hs = SDSData.GetFloat(a, Offspring.KeyHybStr, 0f);
                    if (hs > 0f)
                    {
                        a.stats[PowerLevel.StatStrength] += hs;
                        a.stats[PowerLevel.StatSpirit] += SDSData.GetFloat(a, Offspring.KeyHybSpi, 0f);
                        a.stats[PowerLevel.StatMagic] += SDSData.GetFloat(a, Offspring.KeyHybMag, 0f);
                    }

                    // PRIMERO las tres partes del Nivel de Poder.
                    //
                    // Las transformaciones (Purgatorio, Sunshine, Marca del Demonio, Indura) se
                    // aplican AQUI, sobre las estadisticas, y no sobre el total al leerlo. Antes se
                    // hacia al reves y el panel se contradecia solo: Fuerza 100, Espiritu 50, Magia
                    // 30... y Nivel de Poder 9.000. Ahora crecen las tres y el total es su suma.
                    //
                    // `stats.clear()` corre al principio de updateStats, asi que esto no se acumula
                    // entre llamadas: cada recalculo parte de cero.
                    float mult = PowerLevel.Multiplier(a);
                    if (mult > 1.001f)
                    {
                        a.stats[PowerLevel.StatStrength] *= mult;
                        a.stats[PowerLevel.StatSpirit] *= mult;
                        a.stats[PowerLevel.StatMagic] *= mult;
                    }

                    // Y AHORA el combate, leyendo el Nivel de Poder ya multiplicado.
                    float f = FactorOf(a);
                    if (f <= 1.001f) return;

                    // Dano y vida al completo: es lo que decide una pelea.
                    a.stats["damage"] *= f;
                    a.stats["health"] *= f;

                    // Techo duro. `getMaxHealth()` devuelve `(int)stats["health"]`, asi que un valor
                    // demasiado grande desborda el entero y deja la vida maxima en un numero sin
                    // sentido — y entonces la barra ya no se puede rellenar. Diez millones sobra
                    // para cualquier cosa de la serie y esta muy lejos del limite del int.
                    a.stats["health"] = Mathf.Min(a.stats["health"], 10000000f);
                    a.stats["damage"] = Mathf.Min(a.stats["damage"], 1000000f);

                    // DEVOLVERLE LA VIDA QUE TRAIA. Sin esto la barra no se puede llenar.
                    //
                    // El juego reconstruye las estadisticas SIN escalar y recorta la vida contra ese
                    // tope base; mi escalado llega despues, cuando el recorte ya ocurrio. Medido en
                    // el juego: un Cath Palug con tope 29.217 se quedaba clavado en 1.839, que es
                    // exactamente su tope sin escalar. Curabas, y al siguiente recalculo caia ahi.
                    //
                    // Se restaura el valor EXACTO que tenia antes del recalculo, no una proporcion:
                    // la proporcion contra el tope base curaria gratis a los heridos en cada
                    // recalculo, que es peor que el fallo que arregla. Solo se sube, nunca se baja,
                    // y siempre con el tope escalado como techo.
                    int prior = Mathf.Min(__state, Mathf.RoundToInt(a.stats["health"]));
                    if (prior > a.data.health) a.data.health = prior;


                    // La armadura escala a la raiz: la armadura resta dano plano en este juego, asi
                    // que multiplicarla igual que el resto hace a la unidad literalmente inmune en
                    // vez de fuerte.
                    a.stats["armor"] *= Mathf.Sqrt(f);

                    // La velocidad, apenas. Una unidad demasiado rapida se sale de su propio
                    // pathfinding y se queda vibrando contra las paredes.
                    a.stats["speed"] *= Mathf.Min(2.5f, 1f + (f - 1f) * 0.08f);
                }
                catch { }
            }
        }
    }
}
