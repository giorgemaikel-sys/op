using System.Collections.Generic;
using UnityEngine;

namespace SevenDeadlySins
{
    /// Bilingual text. Spanish is written inline at every call site; English lives in
    /// SDSLocaleEN.Map, keyed identically.
    public static class SDSLocale
    {
        private static bool _english;
        private static bool _detected;

        /// True when the game is running in English. The guide window reads this to pick its language.
        public static bool English { get { Detect(); return _english; } }

        /// Picks Spanish or English for an on-screen tip. Tips are composed strings (with actor names
        /// spliced in), not fixed keys, so they cannot go through the key table — this is how they get
        /// translated. Build the whole Spanish and the whole English string and pass both.
        public static string T(string es, string en)
        {
            return English ? en : es;
        }

        /// Every (key -> Spanish) the mod registers, so the full set can be dumped and translated.
        internal static readonly Dictionary<string, string> Spanish = new Dictionary<string, string>();

        /// Reads the game's language, and KEEPS TRYING until it gets a real answer.
        ///
        /// The first call happens while the mod is still loading — before the game has set its
        /// language — so the read comes back empty. Latching on that would cache "not English" for the
        /// whole session and show an English player every tip in Spanish. We only latch once we have
        /// actually read a language id.
        private static void Detect()
        {
            if (_detected) return;

            string lang = null;
            try
            {
                if (LocalizedTextManager.current_language != null)
                    lang = LocalizedTextManager.current_language.id;
                if (string.IsNullOrEmpty(lang) && LocalizedTextManager.instance != null)
                    lang = LocalizedTextManager.instance.language;
            }
            catch { }

            // Nothing to read yet: stay undecided (Spanish for now) and ask again next time.
            if (string.IsNullOrEmpty(lang)) return;

            _detected = true;
            lang = lang.ToLowerInvariant();
            _english = lang.Contains("english") || lang == "en";

            Debug.Log(Main.Tag + " idioma detectado: " + (_english ? "english" : "spanish/otro") + " (" + lang + ")");
        }

        public static void Add(string key, string spanish)
        {
            if (string.IsNullOrEmpty(key)) return;
            Detect();

            if (!Spanish.ContainsKey(key)) Spanish[key] = spanish;

            string value = spanish;
            if (_english)
            {
                string en;
                if (SDSLocaleEN.Map.TryGetValue(key, out en) && !string.IsNullOrEmpty(en)) value = en;
            }

            // LocalizedTextManager.add writes into the ACTIVE language's table, which is what makes
            // the text actually show. The old Localization.AddOrSet shim is deliberately NOT used as
            // a fallback: it does not resolve against this build's assemblies, and it never injected
            // into the English table anyway.
            try { LocalizedTextManager.add(key, value, true, "SevenDeadlySins", false); }
            catch { }
        }

        /// A key we own, cheap to test, used to detect that the game has thrown our text away.
        private const string Sentinel = "trait_sds_sin_wrath";

        private static int _reapplyCount;
        private static float _checkTimer;

        /// Writes the whole table again, in the language the game actually ended up in.
        ///
        /// Keys are registered while the mod loads, which can happen BEFORE the game has settled its
        /// language. Everything registered in that window went in as Spanish — and because
        /// LocalizedTextManager.add writes into the ACTIVE table, that Spanish overwrote the correct
        /// English the game had just read from Locales/en.json. Once a world is running the language
        /// is decided for good, so we re-register every key with the right side of each pair.
        public static void Reapply()
        {
            Detect();
            if (!_detected) return;      // still too early: try again on the next tick

            _reapplyCount++;

            int n = 0;
            foreach (KeyValuePair<string, string> pair in Spanish)
            {
                string value = pair.Value;
                if (_english)
                {
                    string en;
                    if (SDSLocaleEN.Map.TryGetValue(pair.Key, out en) && !string.IsNullOrEmpty(en)) value = en;
                }

                try { LocalizedTextManager.add(pair.Key, value, true, "SevenDeadlySins", false); n++; }
                catch { }
            }

            Debug.Log(Main.Tag + " locales reaplicados (#" + _reapplyCount + ") en "
                      + (_english ? "english" : "spanish/otro") + ": " + n + " claves"
                      + "; sentinela -> " + (Resolves(Sentinel) ? "ok" : "SIN RESOLVER"));
        }

        /// SELF-HEALING. Reapply used to latch after one successful pass, which was wrong: the game
        /// reloads its language table at several points (entering a world, changing the setting), and
        /// each reload drops every key a mod injected. Latching meant the mod's text came back exactly
        /// once and any later reload left the UI showing raw ids like `trait_sds_ability_invasion`
        /// for the rest of the session.
        ///
        /// So instead of trusting one pass, this checks a sentinel key once a second and rewrites the
        /// whole table whenever it stops resolving. The check is a single dictionary lookup; the
        /// rewrite only happens when something actually broke.
        public static void TickReapply(float dt)
        {
            if (_reapplyCount == 0)
            {
                Reapply();
                return;
            }

            _checkTimer += dt;
            if (_checkTimer < 1f) return;
            _checkTimer = 0f;

            if (!Resolves(Sentinel)) Reapply();
        }

        /// True when the key gives back real text rather than the key itself.
        private static bool Resolves(string key)
        {
            try
            {
                string v = LocalizedTextManager.getText(key, null, false);
                return !string.IsNullOrEmpty(v) && v != key;
            }
            catch { return false; }
        }

        // ---------------------------------------------------------------- typed helpers

        /// The two keys the game reads for every trait: its name and its description.
        public static void Trait(string id, string name, string info)
        {
            Add("trait_" + id, name);
            Add("trait_" + id + "_info", info);
        }

        /// The "how do I get this?" line under a trait's stats.
        public static void TraitLore(string id, string howToGet)
        {
            Add("trait_" + id + "_lore", howToGet);
        }

        public static void Status(string id, string title, string description)
        {
            Add("status_title_" + id, title);
            Add("status_description_" + id, description);
        }

        public static void Power(string id, string name, string description)
        {
            Add(id, name);
            Add(id + "_description", description);
        }

        public static void Kingdom(string id, string name)
        {
            Add("kingdom_" + id, name);
        }

        /// Registers a literal string as its own key.
        ///
        /// Several places in the game take what looks like display text and then look it up as a
        /// localisation key anyway — tab fallbacks, TipButton captions. Left unregistered they log
        /// "missing text: Legends" and render blank.
        ///
        /// Using the Spanish sentence AS the key has a second, better property: if the table is
        /// wiped (which happens when the game loads its language file after the mod has built its
        /// UI), the raw key the game falls back to printing is already the correct Spanish text
        /// instead of an identifier like Button_Tab_SevenDeadlySinsLegends. English still works,
        /// because SDSLocaleEN can map that same Spanish key to its translation.
        public static void Self(string text)
        {
            if (string.IsNullOrEmpty(text)) return;
            Add(text, text);
        }

        // ---------------------------------------------------------------- diagnostics

        /// A load-time sanity check (no simulation needed): does a sample key actually resolve to
        /// text, or does the game still hand back the raw key?
        public static void VerifyResolves()
        {
            try
            {
                string[] samples =
                {
                    "trait_sds_sin_wrath", "trait_sds_clan_demon",
                    "trait_sds_cmd_piety", PowerLevel.StatStrength,
                };
                foreach (string k in samples)
                {
                    string v = LocalizedTextManager.getText(k, null, false);
                    Debug.Log(Main.Tag + " locale check: " + k + " -> \"" + v + "\""
                              + (v == k ? "  [SIN RESOLVER]" : "  [ok]"));
                }
            }
            catch (System.Exception e) { Debug.LogError(Main.Tag + " locale check fallo: " + e.Message); }
        }

        /// TEMPORAL: vuelca todas las claves ES a un fichero para completar la traduccion inglesa.
        public static void DumpForTranslation()
        {
            try
            {
                System.Text.StringBuilder sb = new System.Text.StringBuilder();
                foreach (KeyValuePair<string, string> pair in Spanish)
                    sb.Append(pair.Key).Append('\t').Append(pair.Value.Replace("\n", " ")).Append('\n');
                System.IO.File.WriteAllText(
                    System.IO.Path.Combine(Application.persistentDataPath, "sds_locale_dump.txt"),
                    sb.ToString());
                Debug.Log(Main.Tag + " volcado de idioma: " + Spanish.Count + " claves");
            }
            catch (System.Exception e) { Debug.LogError(Main.Tag + " volcado fallo: " + e.Message); }
        }

        /// Base keys the stat panel and the config screen read.
        public static void RegisterBaseKeys()
        {
            Add("sds_config_gameplay", "Seven Deadly Sins");

            Add(PowerLevel.StatStrength, "Fuerza");
            Add(PowerLevel.StatSpirit, "Espiritu");
            Add(PowerLevel.StatMagic, "Magia");
            Add("sds_power_level", "Nivel de Poder");
        }
    }
}
