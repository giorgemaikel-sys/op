namespace SevenDeadlySins
{
    /// Every piece of per-actor state lives in Actor.data, which the game serialises with the save.
    /// Static dictionaries would silently reset on load, so nothing persistent goes in one.
    public static class SDSData
    {
        public const string StolenStrength = "sds_stolen_str";   // Snatch: what Ban has taken
        public const string DemonMarkTime = "sds_mark_time";     // when the mark last triggered
        public const string CommandmentBond = "sds_cmd_bond";    // which commandment judges this unit
        public const string PowerLevelCache = "sds_pl_cache";    // last computed level, for the UI
        public const string ClanAssigned = "sds_clan_assigned";  // guards one-time clan assignment
        public const string SinAssigned = "sds_sin_assigned";
        public const string KillsAtLastRank = "sds_kills_rank";  // Holy Knight promotion bookkeeping
        public const string InduraTimer = "sds_indura_timer";

        /// Marks one of the named characters — a Sin, an Archangel, the Demon King.
        ///
        /// THIS IS THE MOD'S PERFORMANCE GATE. Everyone is a plain vanilla human now, so "is this
        /// one of ours" can no longer be answered by looking at the actor asset. The systems that
        /// drive the named characters (TreasureArts, Progression, DemonKing, Archangels) open by
        /// reading this flag: one lookup in data the actor already carries, instead of the seven
        /// string-keyed hasTrait calls that SDSUnit.SinOf costs.
        public const string Named = "sds_named";

        /// Cooldowns are one key per ability: "sds_cd_<abilityId>" -> world time when it may fire again.
        public static string CooldownKey(string abilityId)
        {
            return "sds_cd_" + abilityId;
        }

        /// True if the ability is off cooldown. Does not consume it.
        public static bool Ready(Actor a, string abilityId)
        {
            return WorldSeconds() >= GetLong(a, CooldownKey(abilityId), long.MinValue);
        }

        /// Puts the ability on cooldown for `seconds` of world time.
        public static void Arm(Actor a, string abilityId, float seconds)
        {
            SetLong(a, CooldownKey(abilityId), WorldSeconds() + (long)seconds);
        }

        /// Ready + Arm in one call. Returns false and changes nothing when still cooling down.
        public static bool TryUse(Actor a, string abilityId, float cooldownSeconds)
        {
            if (a == null || a.data == null) return false;
            if (!Ready(a, abilityId)) return false;
            Arm(a, abilityId, cooldownSeconds);
            return true;
        }

        public static float GetFloat(Actor a, string key, float fallback = 0f)
        {
            if (a == null || a.data == null) return fallback;
            float v;
            a.data.get(key, out v, fallback);
            return v;
        }

        public static void SetFloat(Actor a, string key, float value)
        {
            if (a == null || a.data == null) return;
            a.data.set(key, value);
        }

        /// World time is a double and grows without bound; a float would lose whole seconds after a
        /// few hours of simulation, so time-stamps are stored as long seconds.
        public static long GetLong(Actor a, string key, long fallback = 0L)
        {
            if (a == null || a.data == null) return fallback;
            long v;
            a.data.get(key, out v, fallback);
            return v;
        }

        public static void SetLong(Actor a, string key, long value)
        {
            if (a == null || a.data == null) return;
            a.data.set(key, value);
        }

        public static long WorldSeconds()
        {
            if (World.world == null) return 0L;
            return (long)World.world.getCurWorldTime();
        }

        public static int GetInt(Actor a, string key, int fallback = 0)
        {
            if (a == null || a.data == null) return fallback;
            int v;
            a.data.get(key, out v, fallback);
            return v;
        }

        public static void SetInt(Actor a, string key, int value)
        {
            if (a == null || a.data == null) return;
            a.data.set(key, value);
        }

        public static bool GetBool(Actor a, string key, bool fallback = false)
        {
            if (a == null || a.data == null) return fallback;
            bool v;
            a.data.get(key, out v, fallback);
            return v;
        }

        public static void SetBool(Actor a, string key, bool value)
        {
            if (a == null || a.data == null) return;
            a.data.set(key, value);
        }

        public static string GetString(Actor a, string key, string fallback = "")
        {
            if (a == null || a.data == null) return fallback;
            string v;
            a.data.get(key, out v, fallback);
            return v;
        }

        public static void SetString(Actor a, string key, string value)
        {
            if (a == null || a.data == null) return;
            a.data.set(key, value);
        }
    }
}
