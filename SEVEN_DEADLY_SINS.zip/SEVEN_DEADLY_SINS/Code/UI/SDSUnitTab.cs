using System.Collections.Generic;
using System.Text;
using HarmonyLib;
using UnityEngine;
using UnityEngine.UI;

namespace SevenDeadlySins
{
    /// A "Pecados" tab in the unit window: the whole character on one page.
    ///
    /// This is the ONLY place the Power Level is shown. It used to be painted as a floating label over
    /// the window, which fought with the game's own layout and put a number on screen for every unit
    /// whether you cared or not. A real tab is opt-in — you look when you want to look.
    ///
    /// The tab is CLONED from one of the window's own tabs, which is the only way a mod can add one:
    /// the button, its container and its content list are all private. Everything is guarded, so if a
    /// game update moves any of it the tab simply does not appear and nothing else breaks.
    public static class SDSUnitTab
    {
        private static WindowMetaTab _tab;
        private static SDSSinsPanel _panel;
        private static UnitWindow _window;

        public static void Init()
        {
            try { Main.harmony.PatchAll(typeof(SDSUnitTabPatch)); }
            catch (System.Exception e)
            {
                Debug.LogError(Main.Tag + " no se pudo parchear la ventana de unidad: " + e.Message);
            }
        }

        internal static void Show(UnitWindow window, Actor actor)
        {
            try
            {
                Build(window);
                if (_tab == null || _panel == null) return;
                SetVisible(true);
                _panel.Refresh(actor);
            }
            catch { }
        }

        internal static void Hide(UnitWindow window)
        {
            try { SetVisible(false); }
            catch { }
        }

        private static void SetVisible(bool visible)
        {
            if (_tab == null) return;
            _tab.gameObject.SetActive(visible);
            _tab.toggleActive(visible);
        }

        private static void Build(UnitWindow window)
        {
            if (_tab != null && _panel != null && _window == window) return;

            WindowMetaTab template = TemplateTab(window);
            WindowMetaTabButtonsContainer tabs = TabsOf(window);
            if (template == null || tabs == null) return;

            Transform stats = window.transform.FindRecursive("content_stats");
            if (stats == null || stats.parent == null) return;

            _window = window;

            Font font = window.name_input != null && window.name_input.textField != null
                ? window.name_input.textField.font
                : Resources.GetBuiltinResource<Font>("Arial.ttf");

            _tab = CloneTab(template, tabs, "button_sds_tab", SDSLocale.T("Pecados", "Sins"), "#C0392B");
            if (_tab == null) return;

            _panel = SDSSinsPanel.Create(stats.parent, font);
            tabs.addTabContent(_tab, _panel.transform);
        }

        private static WindowMetaTab CloneTab(WindowMetaTab template, WindowMetaTabButtonsContainer tabs,
            string objectName, string label, string colorHex)
        {
            GameObject clone = Object.Instantiate(template.gameObject, template.transform.parent);
            clone.name = objectName;
            clone.transform.SetSiblingIndex(template.transform.GetSiblingIndex() + 1);

            WindowMetaTab tab = clone.GetComponent<WindowMetaTab>();
            if (tab == null) { Object.Destroy(clone); return null; }

            tab.tab_action = new WindowMetaTabEvent();
            tab.tab_action.AddListener(delegate (WindowMetaTab t) { tabs.showTab(t); });
            tab.tab_elements.Clear();
            tab.container = tabs;

            TipButton tip = clone.GetComponent<TipButton>();
            if (tip != null)
            {
                // Both of these are looked up as localisation KEYS, not printed as-is. Registering
                // them against themselves is what stops "missing text: Nivel de poder, clan, ..."
                // and an empty tooltip.
                string title = SDSLocale.T("Ficha de Britannia", "Britannia Sheet");
                string desc = SDSLocale.T(
                    "Nivel de poder, clan, pecado o mandamiento, magia, rango y tesoro de esta unidad.",
                    "Power level, clan, sin or commandment, magic, rank and treasure of this unit.");
                SDSLocale.Self(title);
                SDSLocale.Self(desc);

                tip.textOnClick = title;
                tip.textOnClickDescription = desc;
            }

            Tint(clone.transform, Hex(colorHex));
            Label(clone.transform, label, Hex("#1A0A08"));
            Register(tabs, tab);
            return tab;
        }

        private static void Label(Transform root, string text, Color color)
        {
            if (root.Find("SDSTabLabel") != null) return;
            GameObject go = new GameObject("SDSTabLabel", typeof(RectTransform));
            go.transform.SetParent(root, false);

            Text t = go.AddComponent<Text>();
            t.text = text;
            t.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            t.fontSize = 8;
            t.fontStyle = FontStyle.Bold;
            t.color = color;
            t.alignment = TextAnchor.MiddleCenter;
            t.horizontalOverflow = HorizontalWrapMode.Overflow;
            t.verticalOverflow = VerticalWrapMode.Overflow;
            t.raycastTarget = false;

            RectTransform rt = go.GetComponent<RectTransform>();
            rt.anchorMin = Vector2.zero;
            rt.anchorMax = Vector2.one;
            rt.offsetMin = Vector2.zero;
            rt.offsetMax = Vector2.zero;
        }

        private static void Tint(Transform root, Color c)
        {
            Image[] images = root.GetComponentsInChildren<Image>(true);
            for (int i = 0; i < images.Length; i++)
                if (images[i] != null) images[i].color = c;
        }

        internal static Color Hex(string hex)
        {
            Color c;
            return ColorUtility.TryParseHtmlString(hex, out c) ? c : Color.white;
        }

        // ---------------------------------------------------------------- private game internals

        private static WindowMetaTab TemplateTab(UnitWindow window)
        {
            System.Reflection.FieldInfo f = AccessTools.Field(typeof(UnitWindow), "_button_mind_tab");
            return f != null ? f.GetValue(window) as WindowMetaTab : null;
        }

        private static WindowMetaTabButtonsContainer TabsOf(UnitWindow window)
        {
            System.Reflection.FieldInfo f = AccessTools.Field(typeof(TabbedWindow), "scroll_window");
            ScrollWindow sw = f != null ? f.GetValue(window) as ScrollWindow : null;
            return sw != null ? sw.tabs : null;
        }

        private static void Register(WindowMetaTabButtonsContainer tabs, WindowMetaTab tab)
        {
            System.Reflection.FieldInfo f = AccessTools.Field(typeof(WindowMetaTabButtonsContainer), "_tabs");
            List<WindowMetaTab> list = f != null ? f.GetValue(tabs) as List<WindowMetaTab> : null;
            if (list != null && !list.Contains(tab)) list.Add(tab);
        }
    }

    /// The page itself.
    public sealed class SDSSinsPanel : MonoBehaviour
    {
        private Font _font;
        private Text _title;
        private Text _power;
        private Text _body;
        private RectTransform _rect;

        public static SDSSinsPanel Create(Transform parent, Font font)
        {
            GameObject root = new GameObject("SDSSinsPanel", typeof(RectTransform), typeof(Image),
                typeof(VerticalLayoutGroup), typeof(ContentSizeFitter), typeof(LayoutElement));
            root.transform.SetParent(parent, false);
            root.GetComponent<Image>().color = SDSUnitTab.Hex("#16101A");

            VerticalLayoutGroup v = root.GetComponent<VerticalLayoutGroup>();
            v.padding = new RectOffset(14, 14, 12, 14);
            v.spacing = 8f;
            v.childForceExpandHeight = false;
            v.childForceExpandWidth = true;
            v.childControlHeight = true;
            v.childControlWidth = true;

            ContentSizeFitter f = root.GetComponent<ContentSizeFitter>();
            f.verticalFit = ContentSizeFitter.FitMode.PreferredSize;
            f.horizontalFit = ContentSizeFitter.FitMode.Unconstrained;   // width comes from the parent

            root.GetComponent<LayoutElement>().minHeight = 340f;

            SDSSinsPanel p = root.AddComponent<SDSSinsPanel>();
            p._font = font;
            p._rect = root.GetComponent<RectTransform>();
            p.Build();
            return p;
        }

        private void Build()
        {
            _title = NewText("Title", 16, FontStyle.Bold, SDSUnitTab.Hex("#FFB765"), TextAnchor.MiddleLeft);

            // The headline number. Deliberately the largest thing on the page — in this series the
            // power level IS the character sheet.
            _power = NewText("Power", 22, FontStyle.Bold, SDSUnitTab.Hex("#FFD75E"), TextAnchor.MiddleLeft);

            _body = NewText("Body", 11, FontStyle.Normal, SDSUnitTab.Hex("#E4DCE8"), TextAnchor.UpperLeft);
            _body.lineSpacing = 1.45f;
        }

        /// The panel does NOT get a width for free: its parent has no layout driving it, so a fresh
        /// RectTransform sits at its default ~100px and every row wraps after a couple of words. The
        /// width has to be taken from the parent on every refresh, because the window is only measured
        /// once it is actually shown.
        private void FitWidthToParent()
        {
            if (_rect == null) return;
            RectTransform parent = _rect.parent as RectTransform;
            if (parent == null || parent.rect.width <= 0f) return;
            _rect.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal,
                Mathf.Max(240f, parent.rect.width - 8f));
        }

        private Text NewText(string name, int size, FontStyle style, Color color, TextAnchor anchor)
        {
            GameObject go = new GameObject(name, typeof(RectTransform));
            go.transform.SetParent(transform, false);
            Text t = go.AddComponent<Text>();
            t.font = _font;
            t.fontSize = size;
            t.fontStyle = style;
            t.color = color;
            t.alignment = anchor;
            t.horizontalOverflow = HorizontalWrapMode.Wrap;
            t.verticalOverflow = VerticalWrapMode.Overflow;
            go.AddComponent<ContentSizeFitter>().verticalFit = ContentSizeFitter.FitMode.PreferredSize;
            return t;
        }

        public void Refresh(Actor a)
        {
            if (a == null || !a.isAlive())
            {
                gameObject.SetActive(false);
                return;
            }
            gameObject.SetActive(true);
            FitWidthToParent();

            bool en = SDSLocale.English;
            _title.text = a.getName();
            _power.text = (en ? "Power Level  " : "Nivel de Poder  ") + PowerLevel.Format(a);

            StringBuilder sb = new StringBuilder();
            try { Compose(sb, a, en); }
            catch { }
            _body.text = sb.ToString();
        }

        private static void Row(StringBuilder sb, string label, string value)
        {
            if (string.IsNullOrEmpty(value)) return;
            sb.Append("<color=#9A90A4>").Append(label).Append(":</color> ").Append(value).Append('\n');
        }

        private static void Gap(StringBuilder sb) { sb.Append('\n'); }

        private static string Text(string key)
        {
            try
            {
                string v = LocalizedTextManager.getText(key, null, false);
                if (!string.IsNullOrEmpty(v) && v != key) return v;
            }
            catch { }
            return null;
        }

        private void Compose(StringBuilder sb, Actor a, bool en)
        {
            // --- the three halves of the number above ---
            Row(sb, en ? "Strength" : "Fuerza", Mathf.RoundToInt(PowerLevel.Strength(a)).ToString("N0"));
            Row(sb, en ? "Spirit" : "Espiritu", Mathf.RoundToInt(PowerLevel.Spirit(a)).ToString("N0"));
            Row(sb, en ? "Magic" : "Magia", Mathf.RoundToInt(PowerLevel.Magic(a)).ToString("N0"));

            // El entrenamiento del Purgatorio se veia SOLO como un numero mas alto arriba, sin
            // decir de donde salia. Aqui se dice: es permanente, se lo llevan a Britannia, y es la
            // razon de entrar. Solo aparece si han estado dentro, para no ensuciar el panel.
            float years = Purgatory.YearsOf(a);
            if (years >= 1f)
            {
                Row(sb, en ? "Purgatory" : "Purgatorio",
                    "x" + Purgatory.MultiplierForYears(years).ToString("0.0")
                    + "  (" + Mathf.FloorToInt(years) + (en ? " years)" : " anos)"));
            }

            if (!SDSUnit.IsSentient(a))
            {
                Gap(sb);
                sb.Append(en ? "Not a people of Britannia." : "No es un pueblo de Britannia.");
                return;
            }

            Gap(sb);

            // --- who they are ---
            string clan = SDSUnit.ClanOf(a);
            Row(sb, en ? "Clan" : "Clan", clan == null ? (en ? "none" : "ninguno") : Text("trait_" + clan));

            string sin = SDSUnit.SinOf(a);
            if (sin != null)
            {
                Row(sb, en ? "Sin" : "Pecado", Text("trait_" + sin));
                Row(sb, en ? "Beast" : "Bestia", SevenSins.BeastOf(sin));

                // The ladder: which form they have unlocked and what the next one costs.
                string form = Progression.CurrentForm(a);
                Row(sb, en ? "Form" : "Forma",
                    form ?? (en ? "latent" : "latente"));

                int toNext = Progression.ToNext(a);
                if (toNext > 0)
                    Row(sb, en ? "Next form in" : "Siguiente forma en",
                        toNext + (en ? " kills" : " muertes"));
            }

            string cmd = SDSUnit.CommandmentOf(a);
            if (cmd != null) Row(sb, en ? "Commandment" : "Mandamiento", Text("trait_" + cmd));

            string magic = MagicTypes.TypeOf(a);
            if (magic != null)
            {
                Row(sb, en ? "Magic type" : "Tipo de magia", Text("trait_" + magic));

                // The magic ladder, which anyone can climb — no Holy Knight commission required.
                string next = MagicProgression.NextAbility(a);
                if (next != null)
                {
                    int toNext = MagicProgression.ToNext(a);
                    Row(sb, en ? "Learning" : "Aprendera",
                        Text("trait_" + next) + (toNext > 0
                            ? "  (" + toNext + (en ? " kills)" : " muertes)")
                            : ""));
                }
                else
                {
                    Row(sb, en ? "Magic" : "Magia",
                        en ? "nothing left to learn" : "no le queda nada por aprender");
                }
            }

            string rank = HolyKnights.RankOf(a);
            if (rank != null) Row(sb, en ? "Rank" : "Rango", Text("trait_" + rank));

            string treasure = SacredTreasures.Held(a);
            if (!string.IsNullOrEmpty(treasure)) Row(sb, en ? "Treasure" : "Tesoro", Text(treasure));

            // --- what makes them dangerous right now ---
            List<string> notes = new List<string>();

            if (a.hasTrait(Sunshine.Ability))
            {
                // Escanor's whole character is a function of the clock, so the clock goes on his sheet.
                string when = DayCycle.IsNoon
                    ? (en ? "THE ONE" : "THE ONE")
                    : (en ? "sun at " : "sol al ") + Mathf.RoundToInt(DayCycle.SunHeight() * 100f) + "%";
                notes.Add((en ? "Sunshine (" : "Sunshine (") + when + ", " + DayCycle.Clock() + ")");
            }

            float stolen = Snatch.Stolen(a);
            if (stolen > 0f)
                notes.Add((en ? "Snatched " : "Robado ") + Mathf.RoundToInt(stolen).ToString("N0"));

            if (a.hasStatus("sds_status_assault_mode")) notes.Add(en ? "ASSAULT MODE" : "ASSAULT MODE");
            else if (a.hasStatus("sds_status_demon_mark")) notes.Add(en ? "Demon Mark" : "Marca del Demonio");

            if (a.hasTrait(Abilities.Infinity)) notes.Add(en ? "Infinity: immune" : "Infinity: inmune");
            if (a.hasTrait(SevenDeadlySins.Traits.Immortal)) notes.Add(en ? "Immortal" : "Inmortal");

            string bond = SDSData.GetString(a, SDSData.CommandmentBond, "");
            if (!string.IsNullOrEmpty(bond))
            {
                string law = Text("trait_" + bond);
                if (law != null) notes.Add((en ? "Judged by " : "Juzgado por ") + law);
            }

            if (notes.Count > 0)
            {
                Gap(sb);
                Row(sb, en ? "State" : "Estado", string.Join("  -  ", notes.ToArray()));
            }
        }
    }

    /// The window rebuilds its content every time it shows a unit, so this is where the tab is
    /// (re)attached and filled.
    [HarmonyPatch(typeof(UnitWindow), "showInfo")]
    internal static class SDSUnitTabPatch
    {
        private static void Postfix(UnitWindow __instance)
        {
            try
            {
                Actor a = SelectedUnit.unit;
                if (a == null || !a.isAlive()) { SDSUnitTab.Hide(__instance); return; }
                SDSUnitTab.Show(__instance, a);
            }
            catch { }
        }
    }
}
