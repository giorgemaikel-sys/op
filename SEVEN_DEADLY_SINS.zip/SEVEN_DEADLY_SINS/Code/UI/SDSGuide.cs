using System.Collections.Generic;
using UnityEngine;

namespace SevenDeadlySins
{
    /// The in-game explanation of how any of this works.
    ///
    /// Delivered as a paged sequence of tips rather than a custom window: SDSLog.Tip is throttled and
    /// verified to work on this build, whereas a bespoke scrollable window would be a lot of
    /// unverified UI surface for something the player reads once. Each click of the guide button
    /// advances a page, so the whole thing is readable without a scrollbar.
    public static class SDSGuide
    {
        private static readonly List<string> _pagesEs = new List<string>();
        private static readonly List<string> _pagesEn = new List<string>();
        private static int _page;

        public static void Init()
        {
            P("NIVEL DE PODER: Fuerza + Espiritu + Magia, la clase de combate de la serie. Aldeano ~20; Pecado Capital ~3.000-4.700; Mandamiento 27.000-61.000; Meliodas en Modo Asalto 142.000; Arcangeles ~180.000; Rey Demonio y Diosa Suprema un millon; el Caos, dos.",
              "POWER LEVEL: Strength + Spirit + Magic, the series' combat class. Villager ~20; Deadly Sin ~3,000-4,700; Commandment 27,000-61,000; Assault Mode Meliodas 142,000; Archangels ~180,000; Demon King and Supreme Deity a million; Chaos, two.");

            P("LOS SEIS CLANES: Humano, Demonio, Diosa, Hada, Gigante y Vampiro. Cada unidad tiene exactamente uno. Demonios y Diosas se hacen dano solo con verse.",
              "THE SIX CLANS: Human, Demon, Goddess, Fairy, Giant and Vampire. Every unit has exactly one. Demons and Goddesses hurt each other on sight.");

            P("LOS SIETE PECADOS: solo los humanos pueden portarlos, y solo uno cada uno. Cada pecado trae su habilidad y su Tesoro Sagrado.",
              "THE SEVEN DEADLY SINS: only humans may bear them, one each. Every Sin brings its ability and its Sacred Treasure.");

            P("ESCANOR: su poder sube y baja con el sol. A medianoche es mas debil que un aldeano. A mediodia se convierte en The One y no hay nada que lo pare.",
              "ESCANOR: his power rises and falls with the sun. At midnight he is weaker than a villager. At noon he becomes The One and nothing stops him.");

            P("FULL COUNTER: Meliodas devuelve magia y proyectiles multiplicados. Contra un ataque cuerpo a cuerpo no hace absolutamente nada, igual que en el manga.",
              "FULL COUNTER: Meliodas returns magic and projectiles multiplied. Against a melee blow it does nothing at all, exactly as in the manga.");

            P("SNATCH: Ban roba fuerza de forma permanente a quien golpea, y se la queda para siempre. Se guarda en la partida.",
              "SNATCH: Ban permanently steals strength from whatever he hits, and keeps it forever. It persists in the save.");

            P("LOS DIEZ MANDAMIENTOS: cada portador impone una ley. Quien la viole cerca de el recibe su maldicion. Gloxinia es un hada y Drole un gigante, no demonios.",
              "THE TEN COMMANDMENTS: each bearer imposes a law. Whoever breaks it near them takes the curse. Gloxinia is a Fairy and Drole a Giant, not demons.");

            P("INFINITY: a Merlin no se le pega nada. Ninguna maldicion ni llama negra hace efecto sobre ella.",
              "INFINITY: nothing sticks to Merlin. No curse and no black flame takes hold on her.");

            P("MARCA DEL DEMONIO: aparece sola cuando un demonio pelea al borde de la muerte. Solo quien porta la Ira alcanza el Assault Mode.",
              "DEMON MARK: surfaces on its own when a demon fights at death's door. Only the bearer of Wrath reaches Assault Mode.");

            P("INDURA: un demonio que se agota en combates perdidos degenera en una bestia. Es irreversible: el demonio muere y la Indura ocupa su lugar.",
              "INDURA: a demon that burns out in losing fights degenerates into a beast. It is irreversible — the demon dies and the Indura takes its place.");

            for (int i = 0; i < _pagesEs.Count; i++)
                SDSLocale.Add("sds_guide_" + i, _pagesEs[i]);
        }

        private static void P(string es, string en)
        {
            _pagesEs.Add(es);
            _pagesEn.Add(en);
        }

        /// Shows the next page. Wraps around at the end.
        public static void Show()
        {
            if (_pagesEs.Count == 0) return;

            List<string> pages = SDSLocale.English ? _pagesEn : _pagesEs;
            if (_page >= pages.Count) _page = 0;

            string header = "(" + (_page + 1) + "/" + pages.Count + ") ";
            SDSLog.Tip(header + pages[_page], 8f);

            Debug.Log(Main.Tag + " guia " + header + pages[_page]);
            _page++;
        }
    }
}
