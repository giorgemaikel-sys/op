using System;
using System.Collections.Generic;
using NCMS.Utils;
using NeoModLoader.General.UI.Tab;
using UnityEngine;

namespace SevenDeadlySins
{
    /// The mod's power tabs.
    ///
    /// Systems do not build UI. They call AddSpawnPower / AddCustomPower during their own Init,
    /// and this lays the buttons out in sections once the tabs exist.
    public static class SDSTab
    {
        private class TabDef
        {
            public readonly string id, es, descEs, icon, fallback;
            public TabDef(string id, string es, string descEs, string icon, string fallback)
            {
                this.id = id; this.es = es; this.descEs = descEs; this.icon = icon; this.fallback = fallback;
            }
        }

        /// THREE tabs, and every button on them spawns something.
        ///
        /// There used to be five tabs full of click-to-grant buttons — a button per clan, per sin,
        /// per commandment, per magic type, per rank — plus one to switch the era by hand. They are
        /// gone. Handing a peasant the Commandment of Truth from a toolbar is not what this mod is
        /// about, and the eras belong in the game's own age wheel, where they now live and arrive on
        /// their own. What is left is the thing a player actually wants from a mod tab: put a
        /// character in the world and watch.
        private static readonly TabDef[] TabDefs =
        {
            new TabDef("SevenDeadlySins", "Los Siete Pecados",
                "Invocar a los Siete Pecados Capitales",
                "ui/icons/sds_meliodas", "Seven Deadly Sins"),

            new TabDef("SevenDeadlySinsClans", "Pueblos de Britannia",
                "Invocar a la gente de los cinco clanes y a las bestias",
                "ui/icons/sds_clan_goddess", "Clans of Britannia"),

            new TabDef("SevenDeadlySinsLegends", "Leyendas",
                "Arcangeles, el Purgatorio y los demas nombres de la historia",
                "ui/icons/sds_demon_king", "Legends"),
        };

        private const int TabSins = 0, TabClans = 1, TabLegends = 2;

        private class Entry
        {
            public string powerId, iconPath, title, description;
            public int category, seq, tab;
        }

        private static readonly List<Entry> _queued = new List<Entry>();
        private static PowersTab[] _tabs;

        // ---------------------------------------------------------------- registration

        public static void AddSpawnPower(string powerId, string actorAssetId, string iconPath,
                                         string title, string description, int tab, int category)
        {
            GodPower p = new GodPower();
            p.id = powerId;
            p.name = powerId;
            p.actor_asset_id = actorAssetId;
            p.show_spawn_effect = true;
            p.actor_spawn_height = 3f;
            p.sound_event = "spawn";
            p.multiple_spawn_tip = true;
            p.click_action = new PowerActionWithID(SpawnClick);
            SDSRegistry.AddPower(p);
            Queue(powerId, iconPath, title, description, tab, category);
        }

        public static void AddCustomPower(string powerId, Func<WorldTile, bool> action, string iconPath,
                                          string title, string description, int tab, int category)
        {
            GodPower p = new GodPower();
            p.id = powerId;
            p.name = powerId;
            p.click_action = new PowerActionWithID((tile, id) => action(tile));
            SDSRegistry.AddPower(p);
            Queue(powerId, iconPath, title, description, tab, category);
        }

        private static void Queue(string powerId, string iconPath, string title, string description,
                                  int tab, int category)
        {
            SDSLocale.Power(powerId, title, description);

            Entry e = new Entry();
            e.powerId = powerId;
            e.iconPath = iconPath;
            e.title = title;
            e.description = description;
            e.tab = tab;
            e.category = category;
            e.seq = _queued.Count;
            _queued.Add(e);
        }

        // ---------------------------------------------------------------- click actions

        private static bool SpawnClick(WorldTile tile, string powerId)
        {
            if (tile == null || string.IsNullOrEmpty(powerId)) return false;

            GodPower power = AssetManager.powers.get(powerId);
            if (power == null || string.IsNullOrEmpty(power.actor_asset_id)) return false;
            if (AssetManager.actor_library.get(power.actor_asset_id) == null) return false;

            Actor spawned = World.world.units.spawnNewUnit(power.actor_asset_id, tile,
                pSpawnSound: true, pMiracleSpawn: true, pSpawnHeight: 3f);
            Actors.NameUnit(spawned, power.actor_asset_id);
            return true;
        }

        // ---------------------------------------------------------------- build

        public static void Init()
        {
            BuildPowerList();

            _tabs = new PowersTab[TabDefs.Length];

            Sprite fallbackIcon = null;
            try { fallbackIcon = SpriteTextureLoader.getSprite("ui/icons/iconDamage"); }
            catch { }

            for (int i = 0; i < TabDefs.Length; i++)
            {
                TabDef d = TabDefs[i];

                // The tab's NAME, DESCRIPTION and FALLBACK are all looked up as localisation KEYS.
                //
                // We deliberately pass the Spanish TEXT as the key rather than an identifier like
                // Button_Tab_SevenDeadlySinsLegends. The game loads its own language file AFTER the
                // mod builds its tabs, which wipes everything we registered; the caption has already
                // been drawn by then, so it kept the unresolved key forever — which is why the tabs
                // showed up nameless. With the text itself as the key, the worst case prints the
                // right words anyway.
                string nameKey = d.es;
                string descKey = d.descEs;
                SDSLocale.Self(nameKey);
                SDSLocale.Self(descKey);
                SDSLocale.Self(d.fallback);

                // Kept registered too, so anything that does look for the conventional key finds it.
                SDSLocale.Add("Button_Tab_" + d.id, d.es);
                SDSLocale.Add("Button_Tab_" + d.id + " Description", d.descEs);

                Sprite icon = null;
                try { icon = SpriteTextureLoader.getSprite(d.icon); }
                catch { }
                if (icon == null) icon = fallbackIcon;

                try { _tabs[i] = TabManager.CreateTab(d.id, nameKey, descKey, icon, d.fallback); }
                catch (Exception e) { Debug.LogError(Main.Tag + " pestana '" + d.id + "': " + e.Message); }
            }

            _queued.Sort((x, y) =>
            {
                int c = x.category.CompareTo(y.category);
                return c != 0 ? c : x.seq.CompareTo(y.seq);
            });

            int made = 0;
            for (int i = 0; i < _tabs.Length; i++)
            {
                if (_tabs[i] == null) continue;
                made += LayOut(_tabs[i], i);
            }

            Debug.Log(Main.Tag + " botones colocados: " + made);
        }

        /// Every button the mod offers. All of them put a person or a creature in the world.
        ///
        /// The clan buttons spawn a plain vanilla human and hand it the clan trait — the same thing
        /// the mod does everywhere else. There is no Demon actor to spawn any more, because a Demon
        /// is a human with the Demon Clan trait.
        private static void BuildPowerList()
        {
            // --- tab 1: the Seven, in the order the series names them ---------------
            string[] sins = { "meliodas", "ban", "diane", "gowther", "king", "merlin", "escanor" };
            for (int i = 0; i < sins.Length; i++)
                LegendButton("sds_legend_" + sins[i], TabSins, 0);

            // --- tab 2: the five peoples, then the things that are not people -------
            for (int i = 0; i < Actors.Peoples.Length; i++)
            {
                string race = Actors.Peoples[i];
                AddSpawnPower("sds_power_spawn_" + race, race, "ui/icons/" + race,
                    Localised(race, race), "", TabClans, 0);
            }

            // Actors.Beasts en vez de una copia a mano: al anadir el Demonio Azul y Albion,
            // una lista duplicada aqui los habria dejado sin boton sin que nadie se enterara.
            string[] beasts = Actors.Beasts;
            for (int i = 0; i < beasts.Length; i++)
                AddSpawnPower("sds_power_spawn_" + beasts[i], beasts[i], "ui/icons/" + beasts[i],
                    Localised(beasts[i], beasts[i]), "", TabClans, 1);

            AddCustomPower("sds_power_purgatory", DemonKing.OpenRift,
                "ui/icons/sds_power_purgatory",
                "Abrir el Purgatorio",
                "Rasga el mundo y deja salir lo que el Rey Demonio guarda dentro.",
                TabClans, 2);

            // El Purgatorio de verdad: otro mapa entero, no una grieta.
            AddCustomPower("sds_power_purgatory_enter", Purgatory.Enter,
                "ui/icons/sds_power_purgatory_enter",
                "Entrar al Purgatorio",
                "Guarda Britannia y cruza al reino de los demonios. Alli todo el mundo es mas fuerte.",
                TabClans, 2);

            AddCustomPower("sds_power_purgatory_exit", Purgatory.Exit,
                "ui/icons/sds_power_purgatory_exit",
                "Salir del Purgatorio",
                "Vuelve a Britannia. El Purgatorio queda tal y como lo dejas.",
                TabClans, 2);

            AddCustomPower("sds_power_purgatory_send", Purgatory.SendUnit,
                "ui/icons/sds_power_purgatory_send",
                "Enviar al Purgatorio",
                "Manda a esta unidad al otro reino. Aparecera alli la proxima vez que entres.",
                TabClans, 2);

            AddCustomPower("sds_power_purgatory_extract", Purgatory.ExtractUnit,
                "ui/icons/sds_power_purgatory_extract",
                "Sacar del Purgatorio",
                "Marca a esta unidad para llevartela a Britannia, con el poder que gano dentro.",
                TabClans, 2);

            // --- tab 3: Heaven, Purgatory, and the rest -----------------------------
            string[] heaven = { "ludociel", "mael", "sariel", "tarmiel", "elizabeth", "supreme_deity", "nerobasta" };
            for (int i = 0; i < heaven.Length; i++)
                LegendButton("sds_legend_" + heaven[i], TabLegends, 0);

            string[] purgatory = { "demon_king", "chandler", "cusack", "original_demon", "chaos_king", "cath_palug" };
            for (int i = 0; i < purgatory.Length; i++)
                LegendButton("sds_legend_" + purgatory[i], TabLegends, 1);

            string[] commandments =
            {
                "zeldris", "estarossa", "galand", "melascula", "fraudrin",
                "grayroad", "monspeet", "derieri", "gloxinia", "drole",
            };
            for (int i = 0; i < commandments.Length; i++)
                LegendButton("sds_legend_" + commandments[i], TabLegends, 2);

            string[] liones =
            {
                // La corte y los Grandes Maestros
                "zaratras", "dreyfus", "hendrickson", "bartra", "margaret", "veronica",
                // Caballeros Sagrados con nombre
                "gilthunder", "howzer", "griamore", "guila", "jericho",
                "gustaf", "twigo", "alioni", "cain", "vivian",
                // Las Pleyades del Cielo Azul
                "denzel", "deathpierce", "waillo", "deldry", "dogedo", "arden",
                // Rugido del Alba
                "slader", "weinheidt", "simon", "jillian",
                // Los Colmillos Raros
                "golgius", "friesia", "ruin", "jude",
            };
            for (int i = 0; i < liones.Length; i++)
                LegendButton("sds_legend_" + liones[i], TabLegends, 3);

            string[] peoples =
            {
                "elaine", "helbram", "gerheade", "puck",       // Bosque del Rey Hada
                "matrona", "dolores", "dubs",                   // Calabozo de los Gigantes
                "izraf", "gelda", "ren", "ganne", "mod", "orlondi", // Edimburgo
            };
            for (int i = 0; i < peoples.Length; i++)
                LegendButton("sds_legend_" + peoples[i], TabLegends, 4);

            // Arthur, Hawk, y los CUATRO JINETES DEL APOCALIPSIS con su mundo (la secuela)
            string[] rest =
            {
                "arthur", "hawk",
                "percival", "lancelot", "tristan", "gawain",    // los Cuatro Jinetes
                "donny", "nasiens", "anne", "cernunnos",         // companeros de Percival
                "ironside", "pellegarde", "varghese",            // Caballeros del Caos de Camelot
                "mortlach", "talisker", "fiddich", "ardbeg",
                "chion", "jade", "isolde",                       // nueva generacion de Liones
            };
            for (int i = 0; i < rest.Length; i++)
                LegendButton("sds_legend_" + rest[i], TabLegends, 5);

            AddCustomPower("sds_power_guide", tile => { SDSGuide.Show(); return true; },
                "ui/icons/sds_magic_special",
                "Guia de Britannia", "Como funciona todo esto", TabLegends, 6);

            // El boton del Discord. Abre la invitacion en el navegador — no manda a nadie a ningun
            // sitio sin que el jugador lo pulse, y la URL es la que dio el autor del mod.
            // Va en la pestana de los SIETE PECADOS (TabSins), en su propia fila debajo de los siete.
            AddCustomPower("sds_power_discord", tile =>
                {
                    try { Application.OpenURL("https://discord.gg/gv4mmtAGz"); }
                    catch { }
                    return true;
                },
                "ui/icons/sds_discord",
                "Servidor de Discord", "Unete a la comunidad del mod en Discord.", TabSins, 1);
        }

        /// A button that spawns a named character, fully dressed.
        private static void LegendButton(string legendId, int tab, int category)
        {
            Legends.Legend l = Legends.Get(legendId);
            if (l == null) return;

            _placed.Add(legendId);
            string id = legendId;
            AddCustomPower("sds_power_" + legendId,
                tile => Legends.Spawn(id, tile) != null,
                IconForLegend(l), l.name, "", tab, category);
        }

        /// Legend ids already given a button, so the catch-all pass does not duplicate them.
        private static readonly HashSet<string> _placed = new HashSet<string>();

        /// A spawn button for the legend that lives in this body.
        ///
        /// Routed through Legends.Spawn rather than the plain actor spawn so the character arrives
        /// DRESSED — clan, sin, abilities and treasure — instead of as an empty body wearing the
        /// right face.
        private static void SpawnLegendFor(string actorId, int tab, int category)
        {
            Legends.Legend found = null;
            for (int i = 0; i < Legends.Table.Count; i++)
            {
                if (Legends.Table[i].race != actorId) continue;
                found = Legends.Table[i];
                break;
            }

            if (found == null)
            {
                // No named character for this body: fall back to a plain spawn.
                AddSpawnPower("sds_power_spawn_" + actorId, actorId, "ui/icons/" + actorId,
                    Localised(actorId, actorId), "", tab, category);
                return;
            }

            _placed.Add(found.id);
            string legendId = found.id;
            AddCustomPower("sds_power_" + legendId,
                tile => Legends.Spawn(legendId, tile) != null,
                "ui/icons/" + actorId, found.name, "", tab, category);
        }

        /// A legend's button icon: its sin, its commandment, or its clan.
        private static string IconForLegend(Legends.Legend l)
        {
            if (!string.IsNullOrEmpty(l.sin)) return "ui/icons/" + l.sin;
            if (!string.IsNullOrEmpty(l.commandment)) return "ui/icons/" + l.commandment;
            return "ui/icons/" + l.clan;
        }

        // ---------------------------------------------------------------- layout

        private static int LayOut(PowersTab tab, int tabIndex)
        {
            const int perRow = 10;
            const float step = 36f;
            float y = 18f;
            int made = 0, lastCategory = -1, col = 0;

            for (int i = 0; i < _queued.Count; i++)
            {
                Entry e = _queued[i];
                if (e.tab != tabIndex) continue;

                Sprite icon = null;
                try { icon = SpriteTextureLoader.getSprite(e.iconPath); }
                catch { }
                if (icon == null)
                {
                    Debug.LogWarning(Main.Tag + " sin icono para '" + e.powerId + "' (" + e.iconPath + ")");
                    continue;
                }

                if (e.category != lastCategory)
                {
                    if (lastCategory != -1) y -= step + 6f;
                    else y -= 2f;
                    lastCategory = e.category;
                    col = 0;
                    Header(tab.transform, CategoryName(tabIndex, e.category), new Vector2(18f, y));
                    y -= 20f;
                }
                else if (col >= perRow)
                {
                    col = 0;
                    y -= step;
                }

                try
                {
                    PowerButtons.CreateButton(e.powerId, icon,
                        Localised(e.powerId, e.title),
                        Localised(e.powerId + "_description", e.description),
                        new Vector2(18f + step * col, y), ButtonType.GodPower, tab.transform, null);
                    col++;
                    made++;
                }
                catch { }
            }
            return made;
        }

        private static string CategoryName(int tab, int category)
        {
            if (tab == TabSins)
                return SDSLocale.T("Los Siete Pecados Capitales", "The Seven Deadly Sins");

            if (tab == TabClans)
            {
                if (category == 0) return SDSLocale.T("Los Pueblos", "The Peoples");
                if (category == 1) return SDSLocale.T("Bestias", "Beasts");
                return SDSLocale.T("El Purgatorio", "Purgatory");
            }

            if (category == 0) return SDSLocale.T("Los Cuatro Arcangeles", "The Four Archangels");
            if (category == 1) return SDSLocale.T("El Purgatorio", "Purgatory");
            if (category == 2) return SDSLocale.T("Los Diez Mandamientos", "The Ten Commandments");
            if (category == 3) return SDSLocale.T("Caballeros Sagrados de Liones", "Holy Knights of Liones");
            if (category == 4) return SDSLocale.T("Hadas, Gigantes y Vampiros", "Fairies, Giants and Vampires");
            if (category == 5) return SDSLocale.T("Otros Nombres", "Other Names");
            return SDSLocale.T("Informacion", "Information");
        }

        private static void Header(Transform parent, string text, Vector2 pos)
        {
            if (string.IsNullOrEmpty(text) || parent == null) return;
            try
            {
                GameObject go = new GameObject("SDSGroup_" + text);
                go.transform.SetParent(parent, false);

                UnityEngine.UI.Text t = go.AddComponent<UnityEngine.UI.Text>();
                t.text = text;
                t.font = TabFont();
                t.fontSize = 11;
                t.fontStyle = FontStyle.Bold;
                t.color = new Color(1f, 0.84f, 0.4f);
                t.alignment = TextAnchor.MiddleLeft;
                t.horizontalOverflow = HorizontalWrapMode.Overflow;
                t.verticalOverflow = VerticalWrapMode.Overflow;
                t.raycastTarget = false;

                RectTransform rt = go.GetComponent<RectTransform>();
                rt.anchoredPosition = pos;
                rt.sizeDelta = new Vector2(340f, 16f);
                rt.localScale = Vector3.one;
            }
            catch { }
        }

        private static Font _font;
        private static Font TabFont()
        {
            if (_font != null) return _font;
            try
            {
                UnityEngine.UI.Text[] texts = UnityEngine.Object.FindObjectsOfType<UnityEngine.UI.Text>();
                for (int i = 0; i < texts.Length; i++)
                    if (texts[i] != null && texts[i].font != null) { _font = texts[i].font; return _font; }
            }
            catch { }
            try { _font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf"); }
            catch { }
            return _font;
        }

        private static string Localised(string key, string fallback)
        {
            try
            {
                string v = LocalizedTextManager.getText(key, null, false);
                if (!string.IsNullOrEmpty(v) && v != key) return v;
            }
            catch { }
            return fallback;
        }
    }
}
