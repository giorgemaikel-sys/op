using System;
using HarmonyLib;
using NeoModLoader.api;
using UnityEngine;

namespace SevenDeadlySins
{
    public class Main : BasicMod<Main>
    {
        public const string HarmonyId = "com.giorg.sevendeadlysins";
        public const string Tag = "[SevenDeadlySins]";

        internal static Harmony harmony;

        protected override void OnModLoad()
        {
            harmony = new Harmony(HarmonyId);

            // Order matters. Stats and groups first; then assets, because traits reference status,
            // effect and projectile ids; then systems, which reference those traits.
            Step("config", SDSConfig.Init);
            Step("localizacion base", SDSLocale.RegisterBaseKeys);
            Step("stats de nivel de poder", PowerLevel.RegisterBaseStats);

            Step("grupos de traits", TraitGroups.Init);
            Step("efectos", Effects.Init);
            Step("estados", Statuses.Init);
            Step("proyectiles", Projectiles.Init);
            Step("traits", Traits.Init);
            // ORDEN CRITICO: reinos -> arquitectura -> actores.
            //
            // Cada raza guarda por id su reino salvaje y su reino civilizado, y su arquitectura por
            // referencia. Registrar la raza antes que cualquiera de los dos deja esas referencias
            // colgando, y una referencia de reino colgando revienta ActorManager.prepareForMetaChecks
            // en CADA frame de simulacion — que es lo que impedia seleccionar a las unidades.
            Step("reinos", Kingdoms.Init);
            Step("arquitectura", Architecture.Init);
            Step("actores", Actors.Init);

            // --- identity systems -------------------------------------------------
            Step("clanes", Clans.Init);
            Step("tipos de magia", MagicTypes.Init);
            Step("siete pecados", SevenSins.Init);
            Step("progresion de pecados", Progression.Init);
            Step("habilidades de clase", ClassAbilities.Init);
            Step("progresion de magia", MagicProgression.Init);
            Step("diez mandamientos", TenCommandments.Init);
            Step("maldiciones", Curses.Init);
            Step("cuatro arcangeles", Archangels.Init);
            Step("rey demonio", DemonKing.Init);
            Step("formas de los pecados", SinForms.Init);
            Step("legado de los pecados", SinLegacy.Init);
            Step("caballeros de liones", Liones.Init);
            Step("magia racial", RaceMagic.Init);
            Step("clanes hibridos", HybridClans.Init);
            Step("formas hibridas", HybridForms.Init);
            Step("legado hibrido", HybridLegacy.Init);
            Step("medio pecado", HalfSinLegacy.Init);
            Step("caballeros del grial", GrailKnights.Init);
            Step("descendencia", Offspring.Init);
            Step("hechizos de merlin", Merlin.Init);
            Step("artes de los tesoros", TreasureArts.Init);
            Step("poderes de caballero", KnightPowers.Init);
            Step("caballeros sagrados", HolyKnights.Init);
            Step("tesoros sagrados", SacredTreasures.Init);

            // --- abilities --------------------------------------------------------
            Step("full counter", FullCounter.Init);
            Step("snatch", Snatch.Init);
            Step("sunshine", Sunshine.Init);
            Step("habilidades restantes", Abilities.Init);

            // --- transformations --------------------------------------------------
            Step("marca del demonio", DemonMark.Init);
            Step("maldiciones", TwinCurses.Init);
            Step("indura", Indura.Init);

            // --- world ------------------------------------------------------------
            Step("guerra santa", HolyWar.Init);
            Step("mecanicas de combate", Combat.Init);
            Step("caos", Chaos.Init);
            Step("cuatro jinetes", FourKnights.Init);
            Step("magia de leyendas", LegendMagic.Init);
            Step("reyes de raza", RacialKings.Init);
            Step("leyendas", Legends.Init);
            Step("eras", Eras.Init);
            Step("purgatorio", Purgatory.Init);
            Step("tiempo del purgatorio", PurgatoryTime.Init);

            // --- ui ---------------------------------------------------------------
            Step("nivel de poder", PowerLevel.Init);

            // DESPUES de todos los contribuyentes: este parche convierte el Nivel de Poder en dano
            // y vida de verdad, asi que necesita que todos esten ya registrados.
            Step("escalado de combate", PowerScaling.Init);
            Step("panel de unidad", SDSUnitTab.Init);
            Step("guia", SDSGuide.Init);
            Step("pestanas", SDSTab.Init);

            // Must run after the last trait is registered: it is what makes every opposite_list we
            // declared actually take effect. Without it a unit can hold all seven sins at once.
            Step("exclusividad", SDSRegistry.ApplyOpposites);

            // Legendary spawns get their kit now that every trait exists.
            Step("kits legendarios", Legends.ApplyKits);

            // The "how do I get this?" line under every trait. Runs late: by now every id exists.
            Step("lore de traits", TraitLore.Init);

            Step("tick loop", SDSTick.Install);

            // The language is not reliably known while the mod loads, so re-apply the text table
            // once a world is actually running. See SDSLocale.Reapply.
            Step("reaplicar idioma", delegate { SDSTick.RegisterGlobal(SDSLocale.TickReapply); });
            Step("verificar locale", SDSLocale.VerifyResolves);
            Step("autocomprobacion", SDSSelfCheck.Run);

            Debug.Log(Tag + " cargado.");
        }

        /// Each subsystem is isolated: a failure in one cannot abort the rest of the load.
        private static void Step(string name, Action action)
        {
            try
            {
                action();
                Debug.Log(Tag + " ok: " + name);
            }
            catch (Exception e)
            {
                Debug.LogError(Tag + " FALLO en '" + name + "': " + e);
            }
        }
    }
}
