"""
Generador de sprites para el mod Seven Deadly Sins de WorldBox.

Reglas verificadas contra el codigo del juego (no cambiar a la ligera):
  * Lienzo 16x16 RGBA, alfa binario (0 o 255). Nada de semitransparencias.
  * La carpeta se llama 'Main' obligatoriamente: ActorTextureSubAsset compone
    texture_path_main = ruta + "main", y si no existe cae a "male_1".
  * Ciclo de caminado por altura: walk_0 y walk_3 con los pies en la fila 15,
    walk_1 levantado 2 px, walk_2 levantado 1 px.
  * Los fotogramas deben ser contiguos: si falta uno, la animacion se corta.

A 16x16 y renderizado pequeno en pantalla la cara no se ve. Lo que identifica a
un personaje son los BLOQUES DE COLOR: pelo, prenda y un acento. Por eso este
generador no dibuja ojos salvo en demonios (rojos, como senal de peligro).

Los iconos son 16x16 tambien, pero con reglas distintas: se leen en un boton de
32 px, asi que priorizan una SILUETA reconocible sobre el detalle.

Uso:  python tools/gen_sprites.py
"""

from PIL import Image
import os

# --- rutas -----------------------------------------------------------------
HERE = os.path.dirname(os.path.abspath(__file__))
MOD = os.path.dirname(HERE)
RES = os.path.join(MOD, "GameResources")
ACTORS = os.path.join(RES, "actors")
ICONS = os.path.join(RES, "ui", "icons")
WEAPONS_UI = os.path.join(RES, "ui", "weapons")
WEAPONS = os.path.join(RES, "weapons")
EFFECTS = os.path.join(RES, "effects")
PROJECTILES = os.path.join(RES, "projectiles")

S = 16          # lado del lienzo
FEET = 15       # fila donde se apoyan los pies
NONE = (0, 0, 0, 0)

# --- geometria del cuerpo --------------------------------------------------
# 11 px de alto: cabeza 4 + torso 4 + piernas 3, centrado en las columnas 6-9.
HEAD_T, HEAD_B = 5, 8
TORSO_T, TORSO_B = 9, 12
LEG_T, LEG_B = 13, 15
BODY_L, BODY_R = 6, 9
ARM_L, ARM_R = 5, 10


class Canvas:
    """Lienzo 16x16 con alfa binario. Ignora escrituras fuera de rango."""

    def __init__(self):
        self.px = {}

    def put(self, x, y, c):
        if c is None or c[3] == 0:
            return
        if 0 <= x < S and 0 <= y < S:
            self.px[(x, y)] = (c[0], c[1], c[2], 255)

    def rect(self, x0, y0, x1, y1, c):
        for y in range(y0, y1 + 1):
            for x in range(x0, x1 + 1):
                self.put(x, y, c)

    def image(self):
        im = Image.new("RGBA", (S, S), NONE)
        for (x, y), c in self.px.items():
            im.putpixel((x, y), c)
        return im


def shade(c, f):
    """Aclara (f>1) u oscurece (f<1) un color, para dar volumen."""
    return (
        max(0, min(255, int(c[0] * f))),
        max(0, min(255, int(c[1] * f))),
        max(0, min(255, int(c[2] * f))),
        255,
    )


def hexc(h):
    h = h.lstrip("#")
    return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), 255)


def save(im, folder, name):
    os.makedirs(folder, exist_ok=True)
    im.save(os.path.join(folder, name + ".png"))


# ---------------------------------------------------------------------------
# CUERPOS
# ---------------------------------------------------------------------------

def draw_body(cv, sp, dy, pose):
    """
    Dibuja la figura desplazada dy pixeles hacia arriba.
    pose 0 = neutra, 1 = pierna izq adelante, 2 = pierna der adelante,
    pose 3 = neutra con brazos invertidos.
    """
    skin = sp["skin"]
    hair = sp["hair"]
    coat = sp["coat"]
    inner = sp["inner"]
    coat_d = shade(coat, 0.72)

    def row(r):
        return r - dy

    # --- piernas ------------------------------------------------------------
    # Estrechas y separadas, con hueco en medio: a tamano de juego una pierna
    # por columna con dos de hueco es lo que hace legible la silueta humana.
    #
    # La ZANCADA es lo que hace que se lea como andar y no como deslizarse. Con
    # un solo pixel de diferencia entre fotogramas la animacion desaparecia a
    # tamano de juego, asi que la pierna adelantada se separa lateralmente
    # ademas de levantarse: el hueco entre piernas cambia de forma visiblemente
    # de un fotograma al siguiente, y eso si se percibe en movimiento.
    if pose == 1:
        # pierna izquierda adelante: se abre y se acorta
        cv.rect(BODY_L - 1, row(LEG_T), BODY_L - 1, row(LEG_B) - 1, inner)
        cv.rect(BODY_R, row(LEG_T), BODY_R, row(LEG_B), inner)
    elif pose == 2:
        # pierna derecha adelante
        cv.rect(BODY_L, row(LEG_T), BODY_L, row(LEG_B), inner)
        cv.rect(BODY_R + 1, row(LEG_T), BODY_R + 1, row(LEG_B) - 1, inner)
    else:
        # fotograma de paso: ambas piernas juntas y rectas
        cv.rect(BODY_L, row(LEG_T), BODY_L, row(LEG_B), inner)
        cv.rect(BODY_R, row(LEG_T), BODY_R, row(LEG_B), inner)

    # --- torso --------------------------------------------------------------
    cv.rect(BODY_L, row(TORSO_T), BODY_R, row(TORSO_B), coat)
    # sombra lateral: da volumen sin gastar pixeles
    cv.rect(BODY_R, row(TORSO_T), BODY_R, row(TORSO_B), coat_d)

    # --- brazos -------------------------------------------------------------
    swing = 1 if pose in (1, 3) else 0
    cv.rect(ARM_L, row(TORSO_T) + swing, ARM_L, row(TORSO_B) - 1 + swing, coat_d)
    cv.rect(ARM_R, row(TORSO_T) - swing, ARM_R, row(TORSO_B) - 1 - swing, coat_d)

    # --- cabeza -------------------------------------------------------------
    cv.rect(BODY_L, row(HEAD_T), BODY_R, row(HEAD_B), skin)
    # pelo: cubre la fila superior y baja por los lados
    cv.rect(BODY_L, row(HEAD_T), BODY_R, row(HEAD_T) + 1, hair)
    cv.put(BODY_L - 1, row(HEAD_T) + 1, hair)
    cv.put(BODY_R + 1, row(HEAD_T) + 1, hair)

    # --- acento -------------------------------------------------------------
    # Un solo pixel de color propio a la altura del pecho. Es lo que distingue a
    # dos personajes que comparten paleta de pelo y prenda.
    if sp.get("accent"):
        cv.put(BODY_L + 1, row(TORSO_T) + 1, sp["accent"])

    # --- ojos: SOLO demonios ------------------------------------------------
    if sp.get("demon_eyes"):
        cv.put(BODY_L + 1, row(HEAD_T) + 2, (220, 30, 30, 255))
        cv.put(BODY_R - 1, row(HEAD_T) + 2, (220, 30, 30, 255))


WALK_LIFT = [0, 2, 1, 0]     # walk_0..walk_3: altura de cada fotograma
WALK_POSE = [0, 1, 2, 3]


def gen_actor(actor_id, spec):
    folder = os.path.join(ACTORS, actor_id, "Main")
    for i in range(4):
        cv = Canvas()
        draw_body(cv, spec, WALK_LIFT[i], WALK_POSE[i])
        save(cv.image(), folder, "walk_%d" % i)
    return 4


# ---------------------------------------------------------------------------
# ICONOS
# ---------------------------------------------------------------------------

def icon_disc(main, ring=None, mark=None):
    """Disco relleno con borde. La forma base de casi todos los iconos."""
    cv = Canvas()
    ring = ring or shade(main, 0.6)
    rows = [(2, 5, 10), (3, 4, 11), (4, 3, 12), (5, 3, 12), (6, 2, 13),
            (7, 2, 13), (8, 2, 13), (9, 2, 13), (10, 3, 12), (11, 3, 12),
            (12, 4, 11), (13, 5, 10)]
    for y, x0, x1 in rows:
        cv.rect(x0, y, x1, y, main)
    # borde
    for y, x0, x1 in rows:
        cv.put(x0, y, ring)
        cv.put(x1, y, ring)
    cv.rect(5, 2, 10, 2, ring)
    cv.rect(5, 13, 10, 13, ring)
    # brillo arriba a la izquierda
    cv.rect(5, 4, 6, 5, shade(main, 1.35))
    if mark:
        for (x, y) in mark:
            cv.put(x, y, shade(main, 0.35))
    return cv.image()


def icon_shield(main):
    """Escudo: para clanes y rangos."""
    cv = Canvas()
    edge = shade(main, 0.55)
    cv.rect(3, 2, 12, 9, main)
    for i, y in enumerate(range(10, 14)):
        cv.rect(4 + i, y, 11 - i, y, main)
    # borde
    cv.rect(3, 2, 12, 2, edge)
    cv.rect(3, 2, 3, 9, edge)
    cv.rect(12, 2, 12, 9, edge)
    for i, y in enumerate(range(10, 14)):
        cv.put(4 + i, y, edge)
        cv.put(11 - i, y, edge)
    cv.rect(5, 4, 6, 6, shade(main, 1.3))
    return cv.image()


def icon_diamond(main):
    """Rombo: para los mandamientos. Se lee distinto del disco de un vistazo."""
    cv = Canvas()
    edge = shade(main, 0.5)
    for i in range(7):
        cv.rect(7 - i, 2 + i, 8 + i, 2 + i, main)
    for i in range(6):
        cv.rect(1 + i, 9 + i, 14 - i, 9 + i, main)
    for i in range(7):
        cv.put(7 - i, 2 + i, edge)
        cv.put(8 + i, 2 + i, edge)
    for i in range(6):
        cv.put(1 + i, 9 + i, edge)
        cv.put(14 - i, 9 + i, edge)
    cv.rect(6, 5, 7, 6, shade(main, 1.35))
    return cv.image()


def icon_star(main):
    """Estrella de cuatro puntas: pecados y habilidades."""
    cv = Canvas()
    edge = shade(main, 0.5)
    cv.rect(7, 1, 8, 14, main)
    cv.rect(1, 7, 14, 8, main)
    cv.rect(6, 4, 9, 11, main)
    cv.rect(4, 6, 11, 9, main)
    cv.rect(5, 5, 10, 10, main)
    cv.put(7, 1, edge); cv.put(8, 1, edge)
    cv.put(7, 14, edge); cv.put(8, 14, edge)
    cv.put(1, 7, edge); cv.put(1, 8, edge)
    cv.put(14, 7, edge); cv.put(14, 8, edge)
    cv.rect(6, 6, 7, 7, shade(main, 1.4))
    return cv.image()


# ---------------------------------------------------------------------------
# EFECTOS Y PROYECTILES
# ---------------------------------------------------------------------------

def gen_effect(fx_id, color, frames=4):
    """Un destello que se abre y se apaga. 4 fotogramas contiguos."""
    folder = os.path.join(EFFECTS, fx_id)
    for f in range(frames):
        cv = Canvas()
        r = 2 + f * 2
        c = shade(color, 1.0 + 0.12 * f)
        for y in range(8 - r, 8 + r + 1):
            dy = abs(y - 8)
            half = max(0, r - dy)
            if half:
                cv.rect(8 - half, y, 7 + half, y, c)
        # nucleo brillante que se encoge mientras el anillo crece
        if f < 2:
            cv.rect(6, 6, 9, 9, shade(color, 1.5))
        save(cv.image(), folder, "%d" % f)
    return frames


def gen_projectile(name, color):
    cv = Canvas()
    edge = shade(color, 0.55)
    cv.rect(4, 7, 11, 8, color)
    cv.rect(11, 6, 13, 9, color)
    cv.put(13, 7, edge); cv.put(13, 8, edge)
    cv.rect(4, 7, 5, 8, shade(color, 1.4))
    save(cv.image(), PROJECTILES, name)
    return 1


def gen_weapon(name, blade, grip):
    """Icono de arma para el panel de equipo, y su sprite en mano."""
    cv = Canvas()
    edge = shade(blade, 0.55)
    cv.rect(7, 1, 8, 10, blade)
    cv.put(7, 1, edge); cv.put(8, 1, edge)
    cv.rect(7, 2, 7, 10, shade(blade, 1.3))
    cv.rect(5, 11, 10, 11, shade(grip, 0.8))   # guarda
    cv.rect(7, 12, 8, 14, grip)                # empunadura
    im = cv.image()
    save(im, WEAPONS_UI, name)
    save(im, WEAPONS, name)
    return 2


# ---------------------------------------------------------------------------
# CATALOGO
# ---------------------------------------------------------------------------

# Paletas de personaje. skin / hair / coat / inner / accent.
RACES = {
    "sds_demon": dict(skin=hexc("#6B4A6B"), hair=hexc("#1A1220"), coat=hexc("#3B1F2B"),
                      inner=hexc("#241019"), accent=hexc("#C0392B"), demon_eyes=True),
    "sds_goddess": dict(skin=hexc("#F2D9C0"), hair=hexc("#F4E4B0"), coat=hexc("#EFEFE4"),
                        inner=hexc("#D8D2C0"), accent=hexc("#F4D03F")),
    "sds_fairy": dict(skin=hexc("#F0DCC4"), hair=hexc("#E8A0C0"), coat=hexc("#2E7D4F"),
                      inner=hexc("#1E5537"), accent=hexc("#9BE8A0")),
    "sds_giant": dict(skin=hexc("#D9A88A"), hair=hexc("#6B3F1F"), coat=hexc("#B5651D"),
                      inner=hexc("#7A4212"), accent=hexc("#E8C07A")),
    "sds_vampire": dict(skin=hexc("#CFC3D6"), hair=hexc("#14101A"), coat=hexc("#4A1020"),
                        inner=hexc("#2A0A12"), accent=hexc("#D64550"), demon_eyes=True),
    "sds_gray_demon": dict(skin=hexc("#8A8A8A"), hair=hexc("#4A4A4A"), coat=hexc("#5A5A5A"),
                           inner=hexc("#3A3A3A"), accent=hexc("#C0392B"), demon_eyes=True),
    "sds_red_demon": dict(skin=hexc("#B04030"), hair=hexc("#3A1010"), coat=hexc("#7A1F1F"),
                          inner=hexc("#4A1010"), accent=hexc("#FFAA33"), demon_eyes=True),
    "sds_indura": dict(skin=hexc("#3A2038"), hair=hexc("#0F0812"), coat=hexc("#22102A"),
                       inner=hexc("#140818"), accent=hexc("#FF3355"), demon_eyes=True),
}

CLAN_COLORS = {
    "sds_clan_human": "#C8A27A",
    "sds_clan_demon": "#7A1F2B",
    "sds_clan_goddess": "#F4D03F",
    "sds_clan_fairy": "#27AE60",
    "sds_clan_giant": "#935116",
    "sds_clan_vampire": "#5B2C6F",
}

# Los siete pecados, con el color de su bestia.
SIN_COLORS = {
    "sds_sin_wrath": "#2E8B57",      # Meliodas, dragon
    "sds_sin_greed": "#C0392B",      # Ban, zorro
    "sds_sin_envy": "#E67E22",       # Diane, serpiente
    "sds_sin_lust": "#D98CB3",       # Gowther, cabra
    "sds_sin_sloth": "#7D6608",      # King, oso gris
    "sds_sin_gluttony": "#5B2C6F",   # Merlin, jabali
    "sds_sin_pride": "#E67E22",      # Escanor, leon
}

CMD_COLORS = {
    "sds_cmd_piety": "#8E44AD",
    "sds_cmd_love": "#E91E63",
    "sds_cmd_truth": "#16A085",
    "sds_cmd_faith": "#2980B9",
    "sds_cmd_selflessness": "#27AE60",
    "sds_cmd_pacifism": "#7F8C8D",
    "sds_cmd_repose": "#48C9B0",
    "sds_cmd_patience": "#935116",
    "sds_cmd_reticence": "#34495E",
    "sds_cmd_purity": "#5DADE2",
}

MAGIC_COLORS = {
    "sds_magic_strengthener": "#C0392B",
    "sds_magic_enchanter": "#8E44AD",
    "sds_magic_incantation": "#2980B9",
    "sds_magic_healer": "#27AE60",
    "sds_magic_special": "#F4D03F",
}

RANK_COLORS = {
    "sds_rank_apprentice": "#95A5A6",
    "sds_rank_holy_knight": "#BDC3C7",
    "sds_rank_great_holy_knight": "#F1C40F",
    "sds_rank_grand_master": "#E67E22",
}

ABILITY_COLORS = {
    "sds_ability_full_counter": "#2E8B57",
    "sds_ability_snatch": "#C0392B",
    "sds_ability_creation": "#935116",
    "sds_ability_invasion": "#D98CB3",
    "sds_ability_disaster": "#27AE60",
    "sds_ability_infinity": "#5B2C6F",
    "sds_ability_sunshine": "#F39C12",
    "sds_ability_hellblaze": "#1C1C1C",
    "sds_ability_ark": "#F4D03F",
    "sds_ability_purge": "#FDFEFE",
}

LOOSE_COLORS = {
    "sds_immortal": "#C0392B",
    "sds_reincarnation": "#F4D03F",
    "sds_demon_blood": "#7A1F2B",
    "sds_goddess_blood": "#F7DC6F",
    "sds_fairy_wings": "#27AE60",
    "sds_giant_strength": "#935116",
    "sds_vampire_thirst": "#5B2C6F",
    "sds_druid": "#16A085",
}

STATUS_ICON_COLORS = {
    "sds_status_reinforced": "#C0392B",
    "sds_status_enchanted": "#8E44AD",
    "sds_status_special_magic": "#F4D03F",
}

EFFECT_COLORS = {
    "sds_fx_ark": "#F7DC6F",
    "sds_fx_purge": "#FDFEFE",
    "sds_fx_hellblaze": "#2C1A2E",
    "sds_fx_sunshine": "#F39C12",
    "sds_fx_the_one": "#FFE07A",
    "sds_fx_demon_mark": "#7A1F2B",
    "sds_fx_assault_mode": "#C0392B",
    "sds_fx_full_counter": "#2E8B57",
    "sds_fx_snatch": "#C0392B",
    "sds_fx_creation": "#935116",
    "sds_fx_indura": "#4A1050",
    "sds_fx_infinity": "#5B2C6F",
    "sds_fx_chastiefol": "#27AE60",
    "sds_fx_herritt": "#D98CB3",
    "sds_fx_curse": "#6C3483",
    "sds_fx_enchant": "#8E44AD",
    "sds_fx_heal": "#2ECC71",
}

PROJECTILE_COLORS = {
    "sds_proj_ark": "#F7DC6F",
    "sds_proj_magic": "#5DADE2",
    "sds_proj_hellblaze": "#3A1F3E",
    "sds_proj_chastiefol": "#27AE60",
    "sds_proj_creation": "#935116",
    "sds_proj_herritt": "#D98CB3",
}

TREASURES = {
    "sds_item_lostvayne": ("#AAB7C4", "#2C3E50"),
    "sds_item_courechouse": ("#D5D8DC", "#7B241C"),
    "sds_item_chastiefol": ("#7DCEA0", "#1E5537"),
    "sds_item_gideon": ("#B7950B", "#6E2C00"),
    "sds_item_herritt": ("#E8C0D4", "#5B2C6F"),
    "sds_item_aldan": ("#BB8FCE", "#4A235A"),
    "sds_item_rhitta": ("#F5B041", "#7E5109"),
}


def main():
    n = 0

    # --- actores ------------------------------------------------------------
    for actor_id, spec in RACES.items():
        n += gen_actor(actor_id, spec)
        # el icono del actor reutiliza el color de su prenda
        save(icon_disc(spec["coat"]), ICONS, actor_id)
        n += 1

    # --- iconos por familia, cada una con su forma --------------------------
    for tid, hexcol in CLAN_COLORS.items():
        save(icon_shield(hexc(hexcol)), ICONS, tid); n += 1
    for tid, hexcol in RANK_COLORS.items():
        save(icon_shield(hexc(hexcol)), ICONS, tid); n += 1
    for tid, hexcol in SIN_COLORS.items():
        save(icon_star(hexc(hexcol)), ICONS, tid); n += 1
    for tid, hexcol in ABILITY_COLORS.items():
        save(icon_star(hexc(hexcol)), ICONS, tid); n += 1
    for tid, hexcol in CMD_COLORS.items():
        save(icon_diamond(hexc(hexcol)), ICONS, tid); n += 1
    for tid, hexcol in MAGIC_COLORS.items():
        save(icon_disc(hexc(hexcol)), ICONS, tid); n += 1
    for tid, hexcol in LOOSE_COLORS.items():
        save(icon_disc(hexc(hexcol)), ICONS, tid); n += 1
    for tid, hexcol in STATUS_ICON_COLORS.items():
        save(icon_disc(hexc(hexcol)), ICONS, tid); n += 1

    # --- efectos ------------------------------------------------------------
    for fx, hexcol in EFFECT_COLORS.items():
        n += gen_effect(fx, hexc(hexcol))

    # --- proyectiles --------------------------------------------------------
    for pid, hexcol in PROJECTILE_COLORS.items():
        n += gen_projectile(pid, hexc(hexcol))

    # --- tesoros sagrados ---------------------------------------------------
    for wid, (blade, grip) in TREASURES.items():
        n += gen_weapon(wid, hexc(blade), hexc(grip))

    # --- icono del mod ------------------------------------------------------
    save(icon_star(hexc("#C0392B")), MOD, "icon")
    n += 1

    print("Generados %d archivos PNG en %s" % (n, RES))


if __name__ == "__main__":
    main()
