"""
Glifos de los iconos, dibujados como pixel art literal.

Cada glifo es una rejilla de 10x10 que se estampa centrada sobre la placa del
icono. Se escriben como texto a proposito: un glifo que no se puede LEER en el
codigo fuente no se puede corregir sin abrir un editor de imagenes, y a 16x16
la diferencia entre un buen icono y uno ilegible son dos o tres pixeles.

Leyenda:
    .  transparente
    X  color principal del glifo
    o  sombra del glifo (mismo tono, mas oscuro)
    +  brillo del glifo (mismo tono, mas claro)

La regla que gobierna todos: SILUETA ANTES QUE DETALLE. A tamano de boton se ve
la forma exterior y nada mas, asi que cada glifo tiene que ser reconocible como
mancha negra. Si dos glifos comparten silueta, uno de los dos esta mal.
"""

G = {}

# ---------------------------------------------------------------- clanes

G["clan_human"] = """
...XXXX...
..XXXXXX..
..XoXXoX..
..XXXXXX..
...XXXX...
..XXXXXX..
.XXXXXXXX.
XX.XXXX.XX
...XXXX...
..XX..XX..
"""

G["clan_demon"] = """
X........X
XX......XX
XXX....XXX
.XXXXXXXX.
.XoXXXXoX.
.XXXXXXXX.
..XXXXXX..
..X.XX.X..
...XXXX...
..XX..XX..
"""

G["clan_goddess"] = """
...++++...
..+....+..
...XXXX...
..XXXXXX..
.XXXXXXXX.
XXXXXXXXXX
XX.XXXX.XX
X..XXXX..X
...XXXX...
..XX..XX..
"""

G["clan_fairy"] = """
.XX....XX.
XXXX..XXXX
XXXXXXXXXX
.XXXXXXXX.
..XXXXXX..
...XXXX...
...XXXX...
..XXXXXX..
.XX....XX.
X........X
"""

G["clan_giant"] = """
..XXXXXX..
.XXXXXXXX.
XXXXXXXXXX
XXoXXXXoXX
XXXXXXXXXX
.XXXXXXXX.
.XXXXXXXX.
XXXXXXXXXX
XX.XXXX.XX
XX......XX
"""

G["clan_vampire"] = """
.XXXXXXXX.
XXXXXXXXXX
XXoXXXXoXX
XXXXXXXXXX
.XXXXXXXX.
..XXXXXX..
...XXXX...
..X.XX.X..
..X....X..
..X....X..
"""

# ---------------------------------------------------------------- pecados (la bestia de cada uno)

G["sin_wrath"] = """      # dragon: cresta y fauces
....XXXX..
...XXXXXX.
..XXXoXXXX
.XXXXXXXXX
XXXXXXXX..
.XXXXXX...
..XXXXXXX.
...XXXX...
..XX...XX.
.XX......X
"""

G["sin_greed"] = """      # zorro: orejas puntiagudas
XX......XX
XXX....XXX
XXXXXXXXXX
XXoXXXXoXX
XXXXXXXXXX
.XXXXXXXX.
..XXXXXX..
...XXXX...
....XX....
..XXXXXX..
"""

G["sin_envy"] = """       # serpiente: cuerpo en S
...XXXXX..
..XXXXXXX.
..XXo.....
...XXXX...
.....XXXX.
....XXXXX.
..XXXXX...
.XXXX.....
XXXX......
XXX.......
"""

G["sin_lust"] = """       # cabra: cuernos curvos
X........X
XX......XX
.XX....XX.
..XXXXXX..
.XXXXXXXX.
.XXoXXoXX.
.XXXXXXXX.
..XXXXXX..
...XXXX...
....XX....
"""

G["sin_sloth"] = """      # oso: orejas redondas
XX......XX
XXXX..XXXX
.XXXXXXXX.
XXXXXXXXXX
XXoXXXXoXX
XXXXXXXXXX
XXXXXXXXXX
.XXXXXXXX.
..XXXXXX..
...XXXX...
"""

G["sin_gluttony"] = """   # jabali: colmillos hacia arriba
..XXXXXX..
.XXXXXXXX.
XXoXXXXoXX
XXXXXXXXXX
XXXXXXXXXX
X.XXXXXX.X
X..XXXX..X
XX.XXXX.XX
.X.XXXX.X.
..XXXXXX..
"""

G["sin_pride"] = """      # leon: melena
..XXXXXX..
.XXXXXXXX.
XXXXXXXXXX
XXXoXXoXXX
XXXXXXXXXX
XXXXXXXXXX
.XXXXXXXX.
X.XXXXXX.X
XX.XXXX.XX
X..XXXX..X
"""

# ---------------------------------------------------------------- mandamientos

G["cmd_piety"] = """      # cruz de juicio
....XX....
....XX....
....XX....
XXXXXXXXXX
XXXXXXXXXX
....XX....
....XX....
....XX....
....XX....
....XX....
"""

G["cmd_love"] = """       # corazon
.XX....XX.
XXXX..XXXX
XXXXXXXXXX
XXXXXXXXXX
XXXXXXXXXX
.XXXXXXXX.
..XXXXXX..
...XXXX...
....XX....
..........
"""

G["cmd_truth"] = """      # ojo abierto
..........
..XXXXXX..
.XXXXXXXX.
XXXX..XXXX
XXX.oo.XXX
XXXX..XXXX
.XXXXXXXX.
..XXXXXX..
..........
..........
"""

G["cmd_faith"] = """      # llama de fe
....XX....
...XXXX...
...XXXX...
..XXXXXX..
.XXXXXXXX.
XXXXXXXXXX
XXXXooXXXX
XXXXXXXXXX
.XXXXXXXX.
..XXXXXX..
"""

G["cmd_selflessness"] = """ # manos abiertas
X........X
XX......XX
XXX....XXX
XXXX..XXXX
.XXXXXXXX.
..XXXXXX..
...XXXX...
..XXXXXX..
.XXXXXXXX.
XXXXXXXXXX
"""

G["cmd_pacifism"] = """   # espada rota
....XX....
....XX....
....XX....
...XXXX...
..XX..XX..
.XX....XX.
....XX....
...XXXX...
....XX....
....XX....
"""

G["cmd_repose"] = """     # luna en reposo
...XXXXX..
..XXXXXXX.
.XXXX.....
.XXX......
.XXX......
.XXX......
.XXXX.....
..XXXXXXX.
...XXXXX..
..........
"""

G["cmd_patience"] = """   # reloj de arena
XXXXXXXXXX
XXXXXXXXXX
.XXXXXXXX.
..XXXXXX..
...XXXX...
...XXXX...
..XXXXXX..
.XXXXXXXX.
XXXXXXXXXX
XXXXXXXXXX
"""

G["cmd_reticence"] = """  # boca sellada
..........
XXXXXXXXXX
XXXXXXXXXX
..........
XXXXXXXXXX
XXXXXXXXXX
..........
..XXXXXX..
.XXXXXXXX.
..........
"""

G["cmd_purity"] = """     # gota
....XX....
....XX....
...XXXX...
...XXXX...
..XXXXXX..
.XXXXXXXX.
XXXXXXXXXX
XXXXooXXXX
.XXXXXXXX.
..XXXXXX..
"""

# ---------------------------------------------------------------- tipos de magia

G["magic_strengthener"] = """ # puno
..XXXXXX..
.XXXXXXXX.
XXXXXXXXXX
XXXXXXXXXX
XXoXXXXoXX
XXXXXXXXXX
XXXXXXXXXX
.XXXXXXXX.
..XXXXXX..
...XXXX...
"""

G["magic_enchanter"] = """   # anillos concentricos
..XXXXXX..
.X......X.
X..XXXX..X
X.X....X.X
X.X.XX.X.X
X.X.XX.X.X
X.X....X.X
X..XXXX..X
.X......X.
..XXXXXX..
"""

G["magic_incantation"] = """ # varita con destello
........XX
.......XX.
......XX..
.....XX...
....XX....
...XX.....
..XX......
.XX.X.....
XX.XXX....
....X.....
"""

G["magic_healer"] = """      # cruz de sanacion
...XXXX...
...XXXX...
...XXXX...
XXXXXXXXXX
XXXXXXXXXX
XXXXXXXXXX
...XXXX...
...XXXX...
...XXXX...
..........
"""

G["magic_special"] = """     # estrella unica
....XX....
....XX....
X...XX...X
XX..XX..XX
.XXXXXXXX.
..XXXXXX..
.XXXXXXXX.
XX..XX..XX
X...XX...X
....XX....
"""

# ---------------------------------------------------------------- rangos (galones ascendentes)

G["rank_apprentice"] = """
..........
..........
..........
..........
..........
..........
...XXXX...
..XXXXXX..
..XX..XX..
..........
"""

G["rank_holy_knight"] = """
..........
..........
..........
...XXXX...
..XXXXXX..
..XX..XX..
...XXXX...
..XXXXXX..
..XX..XX..
..........
"""

G["rank_great_holy_knight"] = """
..........
...XXXX...
..XXXXXX..
..XX..XX..
...XXXX...
..XXXXXX..
..XX..XX..
...XXXX...
..XXXXXX..
..XX..XX..
"""

G["rank_grand_master"] = """  # corona
X..X..X..X
XX.XX.XX.X
XXXXXXXXXX
XXXXXXXXXX
XXoXXXXoXX
XXXXXXXXXX
XXXXXXXXXX
XXXXXXXXXX
XXXXXXXXXX
..........
"""

# ---------------------------------------------------------------- habilidades

G["ability_full_counter"] = """ # espejo que devuelve
....XX....
...XXXX...
..XX..XX..
.XX....XX.
XX......XX
XX......XX
.XX....XX.
..XX..XX..
...XXXX...
....XX....
"""

G["ability_snatch"] = """     # mano que agarra
X..X..X...
X..X..X..X
XXXXXXX..X
XXXXXXXXXX
.XXXXXXXXX
..XXXXXXX.
...XXXXX..
...XXXX...
...XXXX...
...XXXX...
"""

G["ability_creation"] = """   # roca alzandose
..........
....XX....
...XXXX...
..XXXXXX..
.XXXXXXXX.
XXXXXXXXXX
XXXoooXXXX
XXXXXXXXXX
XXXXXXXXXX
XXXXXXXXXX
"""

G["ability_invasion"] = """   # mente con espiral
..XXXXXX..
.XXXXXXXX.
XX.XXXX.XX
X.XX..XX.X
X.X.XX.X.X
X.X.XX.X.X
X.XX...X.X
XX.XXXX.XX
.XXXXXXXX.
..XXXXXX..
"""

G["ability_disaster"] = """   # lanza espiritual
....XX....
...XXXX...
..XXXXXX..
...XXXX...
....XX....
....XX....
....XX....
...XXXX...
....XX....
....XX....
"""

G["ability_infinity"] = """   # simbolo de infinito
..........
.XXX..XXX.
XX.XXXX.XX
X...XX...X
X..X..X..X
X..X..X..X
X...XX...X
XX.XXXX.XX
.XXX..XXX.
..........
"""

G["ability_sunshine"] = """   # sol con rayos
X...XX...X
.X..XX..X.
..XXXXXX..
..XXXXXX..
XXXXXXXXXX
XXXXXXXXXX
..XXXXXX..
..XXXXXX..
.X..XX..X.
X...XX...X
"""

G["ability_hellblaze"] = """  # llama negra
....XX....
...XXXX...
...XXXX...
..XXXXXX..
..XX..XX..
.XX....XX.
.XX....XX.
XXX....XXX
XXXX..XXXX
.XXXXXXXX.
"""

G["ability_ark"] = """        # cruz de luz radiante
X...XX...X
.X..XX..X.
..XXXXXX..
XXXXXXXXXX
XXXXXXXXXX
..XXXXXX..
....XX....
....XX....
.X..XX..X.
X...XX...X
"""

G["ability_purge"] = """      # llama blanca ascendente
....XX....
...XXXX...
..XXXXXX..
..XXXXXX..
.XXXXXXXX.
.XXX..XXX.
XXX....XXX
XX......XX
XXX....XXX
.XXXXXXXX.
"""

# ---------------------------------------------------------------- rasgos sueltos

G["immortal"] = """          # corazon con marca
.XX....XX.
XXXX..XXXX
XXXXXXXXXX
XXX.XX.XXX
XXXXXXXXXX
.XXXXXXXX.
..XXXXXX..
...XXXX...
....XX....
..........
"""

G["reincarnation"] = """     # ciclo cerrado
..XXXXXX..
.XX....XX.
XX......XX
X........X
X........X
XX......XX
.XX....XX.
..XXXXXX..
...X..X...
..XXXXXX..
"""

G["demon_blood"] = """       # gota con cuernos
X........X
XX..XX..XX
...XXXX...
...XXXX...
..XXXXXX..
.XXXXXXXX.
XXXXXXXXXX
XXXXooXXXX
.XXXXXXXX.
..XXXXXX..
"""

G["goddess_blood"] = """     # gota con halo
..++++++..
.+......+.
...XXXX...
...XXXX...
..XXXXXX..
.XXXXXXXX.
XXXXXXXXXX
XXXXooXXXX
.XXXXXXXX.
..XXXXXX..
"""

G["fairy_wings"] = """       # par de alas
XX......XX
XXXX..XXXX
XXXXXXXXXX
XXXX..XXXX
XXX....XXX
XX......XX
XX......XX
.X......X.
.X......X.
..........
"""

G["giant_strength"] = """    # brazo flexionado
XXXX......
XXXXXX....
XX..XXX...
.....XXX..
......XXX.
.....XXXX.
...XXXXXX.
..XXXXXXX.
..XXXXXX..
..XXXXX...
"""

G["vampire_thirst"] = """    # colmillos
XXXXXXXXXX
XXXXXXXXXX
XXXXXXXXXX
.XX....XX.
.XX....XX.
..X....X..
..X....X..
...X..X...
...X..X...
....XX....
"""

G["druid"] = """             # hoja
.......XXX
.....XXXXX
...XXXXXXX
..XXXXXXX.
.XXXXXXX..
XXXXXXX...
XXXXXo....
XXXXo.....
XXo.......
X.........
"""

# ---------------------------------------------------------------- estados

G["status_reinforced"] = G["magic_strengthener"]
G["status_enchanted"] = G["magic_enchanter"]
G["status_special_magic"] = G["magic_special"]


def parse(name):
    """Devuelve el glifo como lista de filas de 10 caracteres, o None."""
    art = G.get(name)
    if not art:
        return None
    rows = [r for r in art.split("\n") if r.strip() and not r.strip().startswith("#")]
    # quita comentarios al final de la primera fila (van tras '#')
    cleaned = []
    for r in rows:
        r = r.split("#")[0].rstrip()
        if not r:
            continue
        cleaned.append((r + "." * 10)[:10])
    return cleaned[:10] if cleaned else None


# ---------------------------------------------------------------- armas (para el ICONO de boton)
#
# El sprite del arma en mano es una silueta detallada de 16x16; como icono de
# boton no se leia, porque a ese tamano una hoja de dos pixeles de ancho
# desaparece. Estos glifos son la version gruesa: se reconocen a 32 px.

G["weapon_sword"] = """
....XXXX..
....XXXX..
....XXXX..
....XXXX..
....XXXX..
....XXXX..
..XXXXXXXX
....XXXX..
....XXXX..
....XXXX..
"""

G["weapon_staff"] = """
....XXXX..
....XXXX..
..XXXXXXXX
....XXXX..
....XXXX..
..XXXXXXXX
....XXXX..
....XXXX..
..XXXXXXXX
....XXXX..
"""

G["weapon_spear"] = """
....XXXX..
...XXXXXX.
..XXXXXXXX
...XXXXXX.
....XXXX..
.....XX...
.....XX...
.....XX...
.....XX...
.....XX...
"""

G["weapon_hammer"] = """
.XXXXXXXX.
XXXXXXXXXX
XXoooooXXX
XXXXXXXXXX
XXoooooXXX
.XXXXXXXX.
.....XX...
.....XX...
.....XX...
.....XX...
"""

G["weapon_bow"] = """
..XXX..XXX
.XXXX..XXX
.XX.....XX
XX...XX..X
XX..XXXX.X
XX..XXXX.X
XX...XX..X
.XX.....XX
.XXXX..XXX
..XXX..XXX
"""

G["weapon_orb"] = """
...XXXX...
..XXXXXX..
.XX++++XX.
XX++++++XX
XX++++++XX
XX++++++XX
.XX++++XX.
..XXXXXX..
...XXXX...
.....XX...
"""

G["weapon_axe"] = """
XXXX..XXXX
XXXXX.XXXX
XXXXX.XXXX
XXoXX.XXoX
XXXXX.XXXX
XXXXX.XXXX
.XXXX.XXX.
..XX..XX..
.....XX...
.....XX...
"""


# ---------------------------------------------------------------- gracias de los Arcangeles

G["ability_flash"] = """      # rayo de Ludociel
......XXXX
.....XXXX.
....XXXX..
...XXXXXXX
..XXXXXXX.
.......XX.
......XX..
.....XX...
....XX....
...XX.....
"""

G["ability_tornado"] = """    # torbellino de Sariel
XXXXXXXXXX
.XXXXXXXX.
..XXXXXX..
XXXXXXXX..
.XXXXXX...
..XXXX....
.XXXXXX...
..XXXX....
...XX.....
..XXXX....
"""

G["ability_ocean"] = """      # oleaje de Tarmiel
..XX...XX.
.XXXX.XXXX
XX..XXX..X
..........
..XX...XX.
.XXXX.XXXX
XX..XXX..X
..........
..XX...XX.
.XXXX.XXXX
"""

G["ability_creation_king"] = """ # forma de Chastiefol
....XX....
...XXXX...
..XXXXXX..
.XXXXXXXX.
XXXXXXXXXX
.XXXXXXXX.
..XXXXXX..
...XXXX...
....XX....
....XX....
"""

# ---------------------------------------------------------------- estados nuevos

G["status_petrified"] = """   # piedra agrietada
.XXXXXXXX.
XXXXoXXXXX
XXXXoXXXXX
XXXoooXXXX
XXXXoXXXXX
XXXXoXXXXX
XXoXoXXoXX
XXoXXXXoXX
XXXXXXXXXX
.XXXXXXXX.
"""

G["status_paralyzed"] = """   # cadenas
XXX....XXX
X.X....X.X
XXX....XXX
.XXXXXXXX.
..XXXXXX..
..XXXXXX..
.XXXXXXXX.
XXX....XXX
X.X....X.X
XXX....XXX
"""

G["status_ash"] = """         # ceniza cayendo
..XXXXXX..
.XXXXXXXX.
..XXXXXX..
...XXXX...
....XX....
..X....X..
.X..XX..X.
X..X..X..X
.X......X.
X...XX...X
"""

G["status_soul_stolen"] = """ # alma que escapa
....XX....
...XXXX...
..XXXXXX..
..XXooXX..
..XXXXXX..
...XXXX...
....XX....
..X.XX.X..
.X..XX..X.
X...XX...X
"""

G["status_drowning"] = """    # ahogo
XXXXXXXXXX
.XXXXXXXX.
..XX..XX..
....XX....
...XXXX...
..XXXXXX..
..XXooXX..
..XXXXXX..
...XXXX...
....XX....
"""


# ---------------------------------------------------------------- habilidades de clase
#
# Quince habilidades que puede aprender cualquiera segun su magia. Ninguna es la
# emblematica de un personaje: eso sigue siendo exclusivo de los Siete Pecados,
# los Arcangeles y el Rey Demonio.

G["iron_skin"] = """      # escamas
.XX..XX..X
XXXXXXXX.X
.XX..XX..X
XXXXXXXX.X
.XX..XX..X
XXXXXXXX.X
.XX..XX..X
XXXXXXXX.X
.XX..XX..X
XXXXXXXX.X
"""

G["heavy_blow"] = """    # puno con impacto
X........X
.X..XX..X.
..XXXXXX..
.XXXXXXXX.
XXXXXXXXXX
XXXoooXXXX
XXXXXXXXXX
.XXXXXXXX.
..XXXXXX..
.X..XX..X.
"""

G["berserk"] = """       # colmillos y furia
X..X..X..X
XX.XX.XX.X
.XXXXXXXX.
XXXXXXXXXX
XX.XXXX.XX
XXXXXXXXXX
.XX.XX.XX.
..XXXXXX..
.X.X..X.X.
X..X..X..X
"""

G["bless_weapon"] = """  # espada con destello
....XX...X
....XX..X.
....XX....
....XX....
..XXXXXX..
....XX....
....XX....
X...XX....
.X..XX....
....XX....
"""

G["ward"] = """          # escudo redondo
..XXXXXX..
.XXXXXXXX.
XX......XX
X..XXXX..X
X.XXXXXX.X
X.XXXXXX.X
X..XXXX..X
XX......XX
.XXXXXXXX.
..XXXXXX..
"""

G["battle_hymn"] = """   # notas que suben
.......XXX
.......XXX
.......X..
....XXXX..
....XXXX..
....X.....
.XXXX.....
.XXXX.....
XXX.......
XXX.......
"""

G["spark"] = """         # chispa pequena
....X.....
X...X...X.
.X.XXX.X..
..XXXXX...
XXXXXXXXX.
..XXXXX...
.X.XXX.X..
X...X...X.
....X.....
..........
"""

G["frost_lance"] = """   # lanza de hielo
....XX....
...XXXX...
..XXXXXX..
...XXXX...
.X.XXXX.X.
X..XXXX..X
...XXXX...
....XX....
....XX....
....XX....
"""

G["meteor"] = """        # roca con estela
X.........
.XX.......
..XXX.....
....XXXX..
...XXXXXX.
..XXXXXXXX
..XXoooXXX
..XXXXXXXX
...XXXXXX.
....XXXX..
"""

G["mend"] = """          # cruz pequena con brillo
....XX....
....XX....
..XXXXXX..
..XXXXXX..
....XX....
....XX....
..........
X........X
.X......X.
..........
"""

G["cleanse"] = """       # gota que cae limpia
....XX....
...XXXX...
..XXXXXX..
.XXXXXXXX.
XXXXXXXXXX
XXXX..XXXX
.XXXXXXXX.
..XXXXXX..
....XX....
..X....X..
"""

G["vigor"] = """         # corazon con pulso
.XX....XX.
XXXXXXXXXX
XXXXXXXXXX
XX.XXXX.XX
X..XXXX..X
.XXXXXXXX.
..XXXXXX..
...XXXX...
....XX....
..........
"""

G["mimic"] = """         # dos siluetas iguales
XXX....XXX
XXX....XXX
.X......X.
XXX....XXX
XXX....XXX
XXX....XXX
.X......X.
XXX....XXX
X.X....X.X
X.X....X.X
"""

G["displace"] = """      # flechas hacia fuera
X..X..X..X
.X.X..X.X.
..XX..XX..
XXX....XXX
..........
..........
XXX....XXX
..XX..XX..
.X.X..X.X.
X..X..X..X
"""

G["unravel"] = """       # hilo que se deshace
XXXXXXXXXX
.XXXXXXXX.
..XXXXXX..
...XXXX...
....XX....
...X..X...
..X....X..
.X......X.
X........X
..........
"""
