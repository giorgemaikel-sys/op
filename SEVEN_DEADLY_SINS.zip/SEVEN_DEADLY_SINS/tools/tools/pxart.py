"""
Motor de pixel art del mod. Todo lo que dibuja sprites pasa por aqui.

Existe porque el generador anterior pintaba rectangulos de color plano: cada
sprite era su color base, su color base por 0.6 para la sombra y su color base
por 1.4 para el brillo. Eso es exactamente lo que separa el pixel art amateur
del profesional, y no es cuestion de gusto sino de tres cosas concretas:

1. RAMPAS CON DESVIACION DE TONO.  Multiplicar un color por 0.6 da el mismo
   color mas apagado, y una figura sombreada asi se ve sucia. Una sombra real
   se va hacia el AZUL y gana saturacion; una luz real se va hacia el AMARILLO
   y la pierde. Ramp() construye los siete niveles girando el tono ademas de
   mover el valor. Es el cambio que mas se nota de todos los que hay aqui.

2. LUZ VOLUMETRICA, NO SOMBRAS A MANO.  sculpt() calcula un campo de distancia
   al borde de la silueta, deriva una normal aproximada de su gradiente y
   aplica N·L. Cualquier forma — un escudo, un cuerno, una hoja de espada —
   sale redondeada sin que nadie decida a mano que pixel va mas oscuro. Es lo
   que permite mejorar los 280 sprites de golpe en vez de uno por uno.

3. CONTORNO.  Un sprite sin contorno oscuro desaparece sobre el terreno del
   juego. outline_inner oscurece el borde sin crecer (para placas que ya tocan
   el limite del lienzo) y outline_outer anade un pixel alrededor (para figuras
   con margen).

REGLA QUE NO SE PUEDE ROMPER: el juego exige alfa binario. Ningun pixel sale de
aqui con alfa distinto de 0 o 255. validate() lo comprueba y revienta si no.
"""

import colorsys
import math
import os

from PIL import Image

# --- constantes del formato -------------------------------------------------
S = 16
NONE = (0, 0, 0, 0)

# Siete niveles por rampa. El 3 es el color declarado; 0 es la sombra mas
# profunda y 6 el brillo mas alto. Siete y no cinco porque el sombreado
# volumetrico necesita margen a los dos lados para no saturarse en las curvas.
LEVELS = 7
BASE = 3
DARKEST = 0
BRIGHTEST = LEVELS - 1

# Hacia donde huyen los tonos. Azul-violeta para la sombra, ambar para la luz:
# es la desviacion que usa el pixel art clasico porque imita luz calida sobre
# ambiente frio, que es como se ve casi todo al aire libre.
COOL_HUE = 0.62
WARM_HUE = 0.11

# Luz global del mod, en coordenadas de pantalla (y crece hacia abajo).
# Arriba-izquierda, ligeramente frontal. TODO se ilumina desde aqui: en cuanto
# dos sprites tienen la luz en sitios distintos el conjunto se ve mal aunque
# cada uno por separado se vea bien.
LIGHT = (-0.55, -0.72, 0.62)


# ---------------------------------------------------------------------------
# COLOR
# ---------------------------------------------------------------------------

def hexc(h):
    """'#RRGGBB' -> (r, g, b, 255)."""
    h = h.lstrip("#")
    return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), 255)


def to_hex(c):
    return "#%02X%02X%02X" % (c[0], c[1], c[2])


def _hue_towards(h, target, amount):
    """Gira el tono hacia 'target' por el camino corto del circulo."""
    d = target - h
    if d > 0.5:
        d -= 1.0
    elif d < -0.5:
        d += 1.0
    return (h + d * amount) % 1.0


def luma(c):
    """Luminancia percibida 0..1. Sirve para decidir contrastes."""
    return (0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]) / 255.0


class Ramp:
    """Siete tonos derivados de un color, con desviacion de tono.

    Se indexa como una lista: ramp[0] es la sombra mas profunda, ramp[3] el
    color declarado, ramp[6] el brillo mas alto. Los indices fuera de rango se
    recortan en vez de fallar, porque el sombreado suma y resta niveles y no
    tiene sentido que un pixel muy iluminado tumbe la generacion entera.
    """

    __slots__ = ("cols", "base")

    _cache = {}

    def __init__(self, rgb):
        if isinstance(rgb, str):
            rgb = hexc(rgb)
        self.base = (rgb[0], rgb[1], rgb[2], 255)
        r, g, b = rgb[0] / 255.0, rgb[1] / 255.0, rgb[2] / 255.0
        h, s, v = colorsys.rgb_to_hsv(r, g, b)

        cols = []
        for i in range(LEVELS):
            t = (i - BASE) / float(BASE)          # -1 .. +1
            if t <= 0:
                k = -t
                nv = v * (1.0 - 0.62 * k)
                ns = s + (1.0 - s) * 0.30 * k     # la sombra satura
                nh = _hue_towards(h, COOL_HUE, 0.10 * k)
                # Los grises puros no tienen tono que girar, asi que se les
                # inyecta un poco de frio: un metal con sombra azulada se lee
                # como metal, y con sombra gris se lee como cartulina.
                if s < 0.08:
                    nh = COOL_HUE
                    ns = max(ns, 0.16 * k)
            else:
                nv = v + (1.0 - v) * 0.66 * t
                ns = s * (1.0 - 0.45 * t)
                nh = _hue_towards(h, WARM_HUE, 0.085 * t)
                if s < 0.08:
                    nh = WARM_HUE
                    ns = max(ns, 0.10 * t)

            nv = max(0.0, min(1.0, nv))
            ns = max(0.0, min(1.0, ns))
            rr, gg, bb = colorsys.hsv_to_rgb(nh, ns, nv)
            cols.append((int(rr * 255 + 0.5), int(gg * 255 + 0.5),
                         int(bb * 255 + 0.5), 255))
        self.cols = cols

    def __getitem__(self, i):
        return self.cols[max(0, min(LEVELS - 1, int(i)))]

    def __repr__(self):
        return "Ramp(%s)" % to_hex(self.base)


def ramp(c):
    """Rampa cacheada. Se llama miles de veces; construirla es caro."""
    if isinstance(c, Ramp):
        return c
    key = c if isinstance(c, str) else "%d,%d,%d" % (c[0], c[1], c[2])
    r = Ramp._cache.get(key)
    if r is None:
        r = Ramp(c)
        Ramp._cache[key] = r
    return r


def contrast_level(rmp, against, want=0.34, prefer=BASE):
    """Elige el nivel de 'rmp' que se separe lo suficiente de un color de fondo.

    Sirve para los glifos. El catalogo declara a mano el color de cada glifo y
    unos cuantos quedaban casi encima del color de su placa — blanco sobre
    #D8D8E8 en el caso peor — ilegibles a tamano de boton. En vez de repasar
    cien entradas del catalogo a ojo, aqui se busca un nivel que alcance la
    separacion de luminancia pedida.

    La busqueda respeta la POLARIDAD que pidio el catalogo. Un glifo claro sobre
    placa oscura se aclara mas si le falta contraste; nunca se oscurece. Da
    igual que oscurecerlo separase mas: un simbolo casi blanco bajado a gris
    medio sale apagado y sucio, que es peor que el problema que arregla.

    Y solo se invierte cuando en su propia direccion el contraste es DE VERDAD
    malo. Un glifo casi blanco sobre placa dorada se queda en 0.27 y no llega al
    umbral, pero se lee perfectamente; invertirlo por no llegar por tres
    centesimas daba una cruz oliva sobre oro, mucho peor que el original. Solo
    cuando ni el mejor nivel propio alcanza el 70% de lo pedido — que es el caso
    de blanco sobre placa casi blanca — compensa cambiar de lado.
    """
    lb = luma(against)
    up = luma(rmp[prefer]) >= lb
    forward = list(range(prefer, LEVELS)) if up else list(range(prefer, -1, -1))
    backward = list(range(prefer, -1, -1)) if up else list(range(prefer, LEVELS))

    for i in forward:
        if abs(luma(rmp[i]) - lb) >= want:
            return i
    best_own = max(forward, key=lambda k: abs(luma(rmp[k]) - lb))
    if abs(luma(rmp[best_own]) - lb) >= want * 0.7:
        return best_own
    for i in backward:
        if abs(luma(rmp[i]) - lb) >= want:
            return i
    return max(range(LEVELS), key=lambda k: abs(luma(rmp[k]) - lb))


# ---------------------------------------------------------------------------
# MATERIALES  (como responde cada superficie a la luz)
# ---------------------------------------------------------------------------
#
# Un mismo algoritmo de luz sobre todos los materiales produce sprites donde la
# piel brilla como el acero. Cada material declara cuanto se abre su rango,
# cuanto ambiente conserva y si tiene reflejo especular.
#
#   spread : cuantos niveles de rampa recorre entre la zona oscura y la clara
#   bias   : desplazamiento fijo (el metal parte mas claro, la tela mas mate)
#   spec   : umbral de N·L a partir del cual aparece el reflejo (None = ninguno)
#   depth  : a que profundidad del borde deja de aplicarse el especular
#   flat   : ignora la luz por completo (cosas que emiten en vez de recibir)

class Mat(object):
    __slots__ = ("name", "spread", "bias", "spec", "depth", "flat", "invert")

    def __init__(self, name, spread=2.0, bias=0.0, spec=None, depth=2,
                 flat=False, invert=False):
        self.name = name
        self.spread = spread
        self.bias = bias
        self.spec = spec
        self.depth = depth
        self.flat = flat
        self.invert = invert


CLOTH = Mat("cloth", spread=2.0, bias=-0.1)
SKIN = Mat("skin", spread=1.6, bias=0.1)
HAIR = Mat("hair", spread=2.2, bias=-0.15)
METAL = Mat("metal", spread=3.0, bias=0.1, spec=0.72, depth=2)
STONE = Mat("stone", spread=2.4, bias=-0.2)
GEM = Mat("gem", spread=2.6, bias=0.4, spec=0.6, depth=3, invert=True)
PLATE = Mat("plate", spread=2.4, bias=0.15)
EMIT = Mat("emit", flat=True)
LEATHER = Mat("leather", spread=1.8, bias=-0.3)


# ---------------------------------------------------------------------------
# LIENZO
# ---------------------------------------------------------------------------

class Canvas(object):
    """Lienzo de pixeles donde cada pixel guarda RAMPA + NIVEL + MATERIAL.

    Guardar el nivel en vez del color final es lo que hace posible el sombreado
    posterior: sculpt() no tiene que adivinar de que color venia un pixel, solo
    mueve su nivel dentro de su propia rampa. Un sprite pintado y luego
    iluminado conserva sus colores, solo cambia donde caen.
    """

    __slots__ = ("w", "h", "px")

    def __init__(self, w=S, h=S):
        self.w, self.h = w, h
        self.px = {}

    # --- escritura ---------------------------------------------------------

    def put(self, x, y, rmp, level=BASE, mat=CLOTH):
        if rmp is None:
            return
        x, y = int(round(x)), int(round(y))
        if 0 <= x < self.w and 0 <= y < self.h:
            self.px[(x, y)] = (ramp(rmp), level, mat)

    def erase(self, x, y):
        self.px.pop((int(round(x)), int(round(y))), None)

    def get(self, x, y):
        return self.px.get((int(x), int(y)))

    def filled(self, x, y):
        return (int(x), int(y)) in self.px

    # --- primitivas --------------------------------------------------------

    def rect(self, x0, y0, x1, y1, rmp, level=BASE, mat=CLOTH):
        if x1 < x0:
            x0, x1 = x1, x0
        if y1 < y0:
            y0, y1 = y1, y0
        for y in range(int(round(y0)), int(round(y1)) + 1):
            for x in range(int(round(x0)), int(round(x1)) + 1):
                self.put(x, y, rmp, level, mat)

    def line(self, x0, y0, x1, y1, rmp, level=BASE, mat=CLOTH):
        """Bresenham. Una linea recta de verdad, no una escalera de rectangulos."""
        x0, y0, x1, y1 = int(round(x0)), int(round(y0)), int(round(x1)), int(round(y1))
        dx, dy = abs(x1 - x0), -abs(y1 - y0)
        sx = 1 if x0 < x1 else -1
        sy = 1 if y0 < y1 else -1
        err = dx + dy
        while True:
            self.put(x0, y0, rmp, level, mat)
            if x0 == x1 and y0 == y1:
                break
            e2 = 2 * err
            if e2 >= dy:
                err += dy
                x0 += sx
            if e2 <= dx:
                err += dx
                y0 += sy

    def poly(self, pts, rmp, level=BASE, mat=CLOTH):
        """Poligono relleno por barrido de lineas (regla par-impar).

        Con esto las siluetas se describen por sus VERTICES en vez de por una
        lista de rectangulos escrita a mano, que es como se colaban los rombos
        que salian con forma de reloj de arena.
        """
        if len(pts) < 3:
            return
        ys = [p[1] for p in pts]
        y0, y1 = int(math.floor(min(ys))), int(math.ceil(max(ys)))
        for y in range(y0, y1 + 1):
            yc = y + 0.5
            xs = []
            for i in range(len(pts)):
                ax, ay = pts[i]
                bx, by = pts[(i + 1) % len(pts)]
                if (ay <= yc < by) or (by <= yc < ay):
                    xs.append(ax + (yc - ay) * (bx - ax) / float(by - ay))
            xs.sort()
            for i in range(0, len(xs) - 1, 2):
                a, b = xs[i], xs[i + 1]
                for x in range(int(math.floor(a)), int(math.ceil(b))):
                    if a <= x + 0.5 <= b:
                        self.put(x, y, rmp, level, mat)

    def ellipse(self, cx, cy, rx, ry, rmp, level=BASE, mat=CLOTH, fill=True,
                thickness=1.0):
        """Elipse por ecuacion, centrada en centros de pixel."""
        if rx <= 0 or ry <= 0:
            return
        for y in range(self.h):
            for x in range(self.w):
                dx = (x + 0.5 - cx) / float(rx)
                dy = (y + 0.5 - cy) / float(ry)
                d = dx * dx + dy * dy
                if fill:
                    if d <= 1.0:
                        self.put(x, y, rmp, level, mat)
                else:
                    inner = max(0.0, 1.0 - thickness / max(rx, ry)) ** 2
                    if inner <= d <= 1.0:
                        self.put(x, y, rmp, level, mat)

    def disc(self, cx, cy, r, rmp, level=BASE, mat=CLOTH):
        self.ellipse(cx, cy, r, r, rmp, level, mat)

    def ring(self, cx, cy, r, rmp, level=BASE, mat=CLOTH, thickness=1.0):
        self.ellipse(cx, cy, r, r, rmp, level, mat, fill=False,
                     thickness=thickness)

    def arc(self, cx, cy, r, a0, a1, rmp, level=BASE, mat=CLOTH, thickness=1.0):
        """Arco entre dos angulos. Paso fino para no dejar huecos."""
        steps = max(8, int(abs(a1 - a0) * r * 3))
        half = (thickness - 1.0) / 2.0
        for i in range(steps + 1):
            a = a0 + (a1 - a0) * i / float(steps)
            k = -half
            while k <= half + 1e-6:
                self.put(cx + math.cos(a) * (r + k), cy + math.sin(a) * (r + k),
                         rmp, level, mat)
                k += 1.0

    def bezier(self, p0, p1, p2, rmp, level=BASE, mat=CLOTH, steps=None):
        """Curva cuadratica. Los cuernos y las capas se describen asi."""
        steps = steps or 24
        px, py = p0
        for i in range(1, steps + 1):
            t = i / float(steps)
            u = 1 - t
            x = u * u * p0[0] + 2 * u * t * p1[0] + t * t * p2[0]
            y = u * u * p0[1] + 2 * u * t * p1[1] + t * t * p2[1]
            self.line(px, py, x, y, rmp, level, mat)
            px, py = x, y

    # --- operaciones de conjunto ------------------------------------------

    def keys(self):
        return set(self.px.keys())

    def mask_to(self, allowed):
        """Borra todo lo que caiga fuera del conjunto de coordenadas dado."""
        for k in list(self.px.keys()):
            if k not in allowed:
                del self.px[k]

    def shift(self, dx, dy):
        out = Canvas(self.w, self.h)
        for (x, y), v in self.px.items():
            nx, ny = x + dx, y + dy
            if 0 <= nx < self.w and 0 <= ny < self.h:
                out.px[(nx, ny)] = v
        return out

    def paste(self, other, dx=0, dy=0, under=False):
        """Compone otro lienzo encima (o debajo, para capas y alas)."""
        for (x, y), v in other.px.items():
            nx, ny = x + dx, y + dy
            if not (0 <= nx < self.w and 0 <= ny < self.h):
                continue
            if under and (nx, ny) in self.px:
                continue
            self.px[(nx, ny)] = v

    def copy(self):
        out = Canvas(self.w, self.h)
        out.px = dict(self.px)
        return out

    def bump(self, coords, delta):
        """Sube o baja el nivel de un conjunto de pixeles ya pintados."""
        for k in coords:
            v = self.px.get(k)
            if v:
                self.px[k] = (v[0], max(0, min(LEVELS - 1, v[1] + delta)), v[2])

    # --- salida ------------------------------------------------------------

    def image(self):
        im = Image.new("RGBA", (self.w, self.h), NONE)
        pix = im.load()
        for (x, y), (rmp, level, _mat) in self.px.items():
            pix[x, y] = rmp[level]
        return im


# ---------------------------------------------------------------------------
# CAMPO DE DISTANCIA Y NORMALES
# ---------------------------------------------------------------------------

def distance_field(cv):
    """Distancia de cada pixel lleno al vacio mas cercano (chamfer 3-4).

    El borde vale 1. Cuanto mas adentro, mas alto. De aqui sale todo el
    sombreado: la profundidad dice cuanto mira un pixel hacia el espectador y
    el gradiente dice hacia donde mira la superficie.
    """
    INF = 9999
    d = {}
    for k in cv.px:
        d[k] = INF

    def at(x, y):
        """Valor de una celda. El vacio y el exterior del lienzo valen 0: son
        el fondo desde el que se mide."""
        if not (0 <= x < cv.w and 0 <= y < cv.h):
            return 0
        return d.get((x, y), 0)

    # Chamfer 3-4 en dos pasadas: recto cuesta 3, diagonal 4, lo que aproxima
    # la distancia euclidea (4/3 ~ 1.33 frente a raiz de 2 ~ 1.41) con enteros.
    for y in range(cv.h):
        for x in range(cv.w):
            if (x, y) not in d:
                continue
            d[(x, y)] = min(d[(x, y)],
                            at(x - 1, y) + 3, at(x, y - 1) + 3,
                            at(x - 1, y - 1) + 4, at(x + 1, y - 1) + 4)
    for y in range(cv.h - 1, -1, -1):
        for x in range(cv.w - 1, -1, -1):
            if (x, y) not in d:
                continue
            d[(x, y)] = min(d[(x, y)],
                            at(x + 1, y) + 3, at(x, y + 1) + 3,
                            at(x + 1, y + 1) + 4, at(x - 1, y + 1) + 4)
    return dict((k, v / 3.0) for k, v in d.items())


def _normal(d, x, y, radius):
    """Normal aproximada: gradiente del campo hacia fuera + componente Z."""
    def sample(px, py):
        return d.get((px, py), 0.0)

    gx = sample(x + 1, y) - sample(x - 1, y)
    gy = sample(x, y + 1) - sample(x, y - 1)
    # El gradiente apunta hacia DENTRO; la superficie mira hacia fuera.
    nx, ny = -gx, -gy
    m = math.hypot(nx, ny)
    if m > 1e-6:
        nx, ny = nx / m, ny / m

    depth = min(1.0, sample(x, y) / float(radius))
    # Cerca del borde la superficie cae de lado; en el centro mira de frente.
    side = 1.0 - depth
    nz = depth
    nx, ny = nx * side, ny * side
    m = math.sqrt(nx * nx + ny * ny + nz * nz) or 1.0
    return nx / m, ny / m, nz / m


# ---------------------------------------------------------------------------
# SOMBREADORES
# ---------------------------------------------------------------------------

def sculpt(cv, light=LIGHT, radius=3.0, strength=1.0, only=None):
    """Da volumen a la silueta aplicando N·L sobre el nivel de cada pixel.

    Esta es la pieza central del motor. Sin ella cada forma habria que
    sombrearla a mano, y con ella un rectangulo pintado plano sale abombado,
    con la luz arriba a la izquierda y la sombra abajo a la derecha, respetando
    su propia rampa de color.

    'only' limita el efecto a un conjunto de coordenadas — util para iluminar
    la placa de un icono sin tocar el glifo que lleva encima.
    """
    if not cv.px:
        return
    d = distance_field(cv)
    lm = math.sqrt(sum(c * c for c in light)) or 1.0
    lx, ly, lz = (light[0] / lm, light[1] / lm, light[2] / lm)

    out = {}
    for (x, y), (rmp, level, mat) in cv.px.items():
        if mat.flat or (only is not None and (x, y) not in only):
            out[(x, y)] = (rmp, level, mat)
            continue
        nx, ny, nz = _normal(d, x, y, radius)
        lam = nx * lx + ny * ly + nz * lz

        # Reencuadre alrededor del plano frontal.
        #
        # Sin esto una superficie plana de cara al espectador da N·L = lz = 0.62
        # y sale a nivel base + 1.4, asi que el interior entero de cada sprite
        # se iba hacia el brillo y el color declarado en el catalogo no aparecia
        # en ninguna parte. Aqui el plano frontal vale exactamente 0 — el color
        # que pidio el catalogo — y solo las caras inclinadas se apartan de el.
        if lam >= lz:
            t = (lam - lz) / max(1e-6, 1.0 - lz)
        else:
            t = (lam - lz) / (lz + 0.55)
        t = max(-1.0, min(1.0, t))
        if mat.invert:
            t = -t * 0.85

        lv = level + int(round((t * mat.spread + mat.bias) * strength))
        if mat.spec is not None and t >= mat.spec and d[(x, y)] <= mat.depth:
            lv = max(lv, LEVELS - 1)
        out[(x, y)] = (rmp, max(0, min(LEVELS - 1, lv)), mat)
    cv.px = out


def boundary(cv, diagonal=True):
    """Coordenadas de la silueta que tocan el vacio (o el borde del lienzo)."""
    offs = ((1, 0), (-1, 0), (0, 1), (0, -1))
    if diagonal:
        offs = offs + ((1, 1), (1, -1), (-1, 1), (-1, -1))
    out = set()
    for (x, y) in cv.px:
        for ox, oy in offs:
            nx, ny = x + ox, y + oy
            if not (0 <= nx < cv.w and 0 <= ny < cv.h) or (nx, ny) not in cv.px:
                out.add((x, y))
                break
    return out


def outline_inner(cv, level=DARKEST, only=None, diagonal=True):
    """Oscurece el borde de la silueta SIN crecer.

    Para placas de icono, que ya llegan al limite del lienzo: un contorno por
    fuera se saldria y se veria cortado.
    """
    edge = []
    offs = ((1, 0), (-1, 0), (0, 1), (0, -1))
    if diagonal:
        offs = offs + ((1, 1), (1, -1), (-1, 1), (-1, -1))
    for (x, y) in cv.px:
        if only is not None and (x, y) not in only:
            continue
        for ox, oy in offs:
            nx, ny = x + ox, y + oy
            if not (0 <= nx < cv.w and 0 <= ny < cv.h) or (nx, ny) not in cv.px:
                edge.append((x, y))
                break
    for k in edge:
        rmp, _lv, mat = cv.px[k]
        cv.px[k] = (rmp, level, mat)


def outline_outer(cv, level=DARKEST, rmp=None, diagonal=True):
    """Anade un pixel de contorno alrededor de la silueta.

    El color sale de la rampa del pixel VECINO, no de un negro fijo: un
    contorno negro puro sobre un sprite claro se ve como un borde de recorte,
    y uno derivado del propio color se ve como sombra propia.
    """
    offs = ((1, 0), (-1, 0), (0, 1), (0, -1))
    if diagonal:
        offs = offs + ((1, 1), (1, -1), (-1, 1), (-1, -1))
    add = {}
    for (x, y), (r, _lv, mat) in cv.px.items():
        for ox, oy in offs:
            nx, ny = x + ox, y + oy
            if not (0 <= nx < cv.w and 0 <= ny < cv.h):
                continue
            if (nx, ny) in cv.px or (nx, ny) in add:
                continue
            add[(nx, ny)] = ((rmp or r), level, mat)
    cv.px.update(add)


def contact_shadow(cv, delta=-1):
    """Oscurece un pixel cuando el de arriba es de otro material.

    Da la sombra que proyecta la barbilla sobre el pecho, el casco sobre la
    cara o el cinturon sobre la pierna. Cuesta cuatro lineas y es la diferencia
    entre una figura con partes y una mancha de color.
    """
    hits = []
    for (x, y), (rmp, _lv, mat) in cv.px.items():
        up = cv.px.get((x, y - 1))
        if up and (up[0] is not rmp):
            hits.append((x, y))
    cv.bump(hits, delta)


def rim(cv, direction=(0.7, 0.6), delta=2, only=None):
    """Luz de recorte en el borde contrario a la luz principal.

    Separa la figura del fondo. En un juego donde los sprites se mueven sobre
    hierba, arena y lava, es lo que evita que un demonio oscuro se pierda sobre
    terreno oscuro.
    """
    m = math.hypot(direction[0], direction[1]) or 1.0
    dx, dy = direction[0] / m, direction[1] / m
    hits = []
    for (x, y) in cv.px:
        if only is not None and (x, y) not in only:
            continue
        nx, ny = x + int(round(dx)), y + int(round(dy))
        if not (0 <= nx < cv.w and 0 <= ny < cv.h) or (nx, ny) not in cv.px:
            hits.append((x, y))
    cv.bump(hits, delta)


BAYER4 = [
    [0, 8, 2, 10],
    [12, 4, 14, 6],
    [3, 11, 1, 9],
    [15, 7, 13, 5],
]


def dither(x, y, t):
    """Umbral ordenado 4x4. Devuelve True si el pixel cae en la parte alta.

    Con siete niveles de rampa y superficies grandes (los fondos de era) el
    salto entre dos niveles se ve como una banda. El tramado la rompe usando
    los dos niveles vecinos en un patron fijo — fijo y no aleatorio, porque el
    ruido a esta escala se ve como suciedad.
    """
    return (BAYER4[y & 3][x & 3] + 0.5) / 16.0 < t


def noise(x, y, seed=0):
    """Ruido determinista 0..1. Nada de random: el generador debe ser
    reproducible, si no cada ejecucion cambia sprites que nadie ha tocado."""
    n = (x * 374761393 + y * 668265263 + seed * 1274126177) & 0xFFFFFFFF
    n = (n ^ (n >> 13)) * 1274126177 & 0xFFFFFFFF
    return ((n ^ (n >> 16)) & 0xFFFF) / 65535.0


# ---------------------------------------------------------------------------
# CONTROL DE CALIDAD
# ---------------------------------------------------------------------------

class QAReport(object):
    def __init__(self):
        self.errors = []
        self.warnings = []
        self.checked = 0

    def error(self, what, msg):
        self.errors.append("%s: %s" % (what, msg))

    def warn(self, what, msg):
        self.warnings.append("%s: %s" % (what, msg))

    def summary(self):
        return "%d sprites revisados, %d errores, %d avisos" % (
            self.checked, len(self.errors), len(self.warnings))


def validate(im, name, report, size=None, min_fill=0.04, check_orphans=True):
    """Comprueba lo que el juego exige y lo que la vista exige.

    Del juego: tamano exacto y alfa binario. Un solo pixel a alfa 128 y el
    sprite se dibuja con halo gris sobre el terreno.

    De la vista: que el sprite no este vacio (un PNG transparente entero es un
    fallo silencioso que solo se descubre jugando) y que no tenga pixeles
    sueltos flotando sin vecinos, que a tamano de juego se ven como polvo.
    """
    report.checked += 1
    if size and im.size != size:
        report.error(name, "tamano %s, se esperaba %s" % (im.size, size))
        return

    px = im.load()
    w, h = im.size
    solid = []
    for y in range(h):
        for x in range(w):
            a = px[x, y][3]
            if a not in (0, 255):
                report.error(name, "alfa %d en (%d,%d) — el juego exige 0 o 255"
                             % (a, x, y))
                return
            if a == 255:
                solid.append((x, y))

    if len(solid) < max(2, int(w * h * min_fill)):
        report.warn(name, "casi vacio (%d pixeles)" % len(solid))
        return

    if check_orphans:
        ss = set(solid)
        orphans = 0
        for (x, y) in solid:
            near = sum(1 for ox in (-1, 0, 1) for oy in (-1, 0, 1)
                       if (ox or oy) and (x + ox, y + oy) in ss)
            if near == 0:
                orphans += 1
        if orphans > 2:
            report.warn(name, "%d pixeles sueltos sin vecinos" % orphans)


# ---------------------------------------------------------------------------
# SALIDA
# ---------------------------------------------------------------------------

def save(im, folder, name, report=None, size=None, **kw):
    os.makedirs(folder, exist_ok=True)
    if report is not None:
        validate(im, os.path.join(os.path.basename(folder), name), report,
                 size=size, **kw)
    im.save(os.path.join(folder, name + ".png"))


def contact_sheet(paths, cols, scale, out_path, bg=(38, 38, 46, 255), pad=3):
    """Hoja de contactos ampliada. Sin esto, revisar 280 sprites de 16x16 es
    imposible: hay que verlos grandes y juntos para detectar los que no
    encajan con el resto."""
    if not paths:
        return None
    n = len(paths)
    rows = (n + cols - 1) // cols
    im0 = Image.open(paths[0])
    cw, ch = im0.size[0] * scale + pad, im0.size[1] * scale + pad
    sheet = Image.new("RGBA", (cols * cw + pad, rows * ch + pad), bg)
    for i, p in enumerate(paths):
        s = Image.open(p).convert("RGBA")
        s = s.resize((s.size[0] * scale, s.size[1] * scale), Image.NEAREST)
        sheet.paste(s, ((i % cols) * cw + pad, (i // cols) * ch + pad), s)
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    sheet.save(out_path)
    return out_path
