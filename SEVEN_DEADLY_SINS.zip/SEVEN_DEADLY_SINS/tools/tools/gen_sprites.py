"""
Generador de sprites del mod Seven Deadly Sins de WorldBox.

Todo el dibujo pasa por pxart.py, que aporta rampas de color con desviacion de
tono, iluminacion volumetrica y contornos. Aqui vive lo que hay que dibujar; el
COMO se dibuja esta alli.

REGLAS DEL JUEGO, verificadas contra su codigo. No cambiar a la ligera:
  * Lienzo 16x16 RGBA con alfa binario (0 o 255). Nada de semitransparencias:
    un pixel a alfa intermedio sale con halo gris sobre el terreno.
  * La carpeta del actor se llama 'Main' obligatoriamente: ActorTextureSubAsset
    compone texture_path_main = ruta + "main", y si no existe cae a "male_1".
  * Ciclo de caminado por altura: walk_0 y walk_3 con los pies en la fila 15,
    walk_1 levantado 2 px, walk_2 levantado 1 px.
  * Los fotogramas deben ser contiguos: si falta uno, la animacion se corta.
  * Los proyectiles van en effects/projectiles/<id>/<id>_1.png — una CARPETA por
    proyectil. Un PNG suelto deja la lista de sprites vacia y el juego revienta
    en QuantumSpriteLibrary.drawProjectiles al primer disparo.
  * La carpeta de armas necesita sprites.json o SpriteTextureLoader devuelve una
    lista vacia y los siete tesoros usan el sprite de una espada de acero.

CUATRO DECISIONES DE DISENO, por si alguien se pregunta por que esta asi:

1. CADA ICONO LLEVA SU PROPIO GLIFO. La primera version pintaba una forma por
   familia (estrella = pecado) y cambiaba solo el color, asi que los siete
   pecados eran siete estrellas de colores y no se distinguian sin leer el
   tooltip. Ahora la forma dice la FAMILIA y el glifo dice CUAL: el pecado de la
   Ira lleva un dragon, el de la Soberbia un leon. Los glifos viven en
   glyphs.py escritos como texto para poder corregirlos leyendo el codigo.

2. LOS EFECTOS SON ANIMACIONES, NO CIRCULOS. La primera version daba a todos el
   mismo anillo que se expande, asi que Hellblaze y Ark se veian identicos. Cada
   efecto tiene su propio animador de 6 fotogramas, en tres tonos — halo, cuerpo
   y nucleo — porque una llama de un solo tono es una mancha de color.

3. LAS RAZAS SE DISTINGUEN POR SILUETA, NO POR PALETA. A tamano de juego el
   color se pierde antes que la forma, asi que los demonios tienen cuernos
   curvos, hombros anchos y brazos largos con garras, no una paleta mas roja.

4. EL CONTRASTE DEL GLIFO SE CALCULA, NO SE DECLARA. El catalogo pide un color
   de glifo a mano y varios quedaban casi encima del color de su placa. Ahora se
   comprueba la separacion de luminancia y se corrige sola la que no llega.

Uso:
    python tools/gen_sprites.py              genera todo
    python tools/gen_sprites.py --preview    genera y ademas deja hojas de
                                             contactos y GIF en tools/preview/
"""

import math
import os
import sys

from PIL import Image

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import glyphs
import pxart as px
from pxart import Canvas, ramp

# --- rutas -----------------------------------------------------------------
HERE = os.path.dirname(os.path.abspath(__file__))
MOD = os.path.dirname(HERE)
RES = os.path.join(MOD, "GameResources")
ACTORS = os.path.join(RES, "actors")
ICONS = os.path.join(RES, "ui", "icons")
WEAPONS_UI = os.path.join(RES, "ui", "weapons")
WEAPONS = os.path.join(RES, "weapons")
EFFECTS = os.path.join(RES, "effects")
PROJECTILES = os.path.join(RES, "effects", "projectiles")
OTHER = os.path.join(RES, "otherAssets")
PREVIEW = os.path.join(HERE, "preview")

S = 16
FEET = 15
FX_FRAMES = 6

REPORT = px.QAReport()

# Niveles de rampa que usan los efectos. Un efecto no recibe luz, la emite, asi
# que en vez de sombrearse se estratifica: halo tenue fuera, cuerpo en medio,
# nucleo encendido dentro. Es lo que hace que una llama parezca caliente.
L_GLOW = 1
L_BODY = 3
L_CORE = 6


def ease_out(t):
    """Arranca rapido y frena. Casi todo lo que estalla se mueve asi."""
    return 1.0 - (1.0 - t) ** 2


def ease_in(t):
    return t * t


# ---------------------------------------------------------------------------
# PLACAS DE ICONO  (la forma dice la familia)
# ---------------------------------------------------------------------------
#
# Siete siluetas, una por familia, y ninguna se parece a otra lo bastante como
# para confundirlas a tamano de boton. Se describen por vertices y las dibuja el
# rasterizador de poligonos: la version anterior las apilaba a base de
# rectangulos escritos a mano y de ahi salieron un rombo con forma de reloj de
# arena y una estrella que era un diamante achatado.

def plate_shield(cv, c):
    """Escudo: hombros rectos y base en punta. Para los clanes."""
    cv.poly([(2, 1), (14, 1), (14, 9.5), (8, 15.5), (2, 9.5)], c, px.BASE, px.PLATE)


def plate_crest(cv, c):
    """Blason: punta arriba, cuerpo ancho y base recta. Para los pecados.

    Esta familia costo tres intentos y merece la explicacion, porque el error se
    repite solo.

    El primero fue una estrella de cuatro puntas de verdad, con la cintura
    pellizcada. Se leia como estrella y era inservible: los iconos llevan el
    glifo enmascarado contra la placa, y una placa estrecha se comia al dragon,
    al zorro y al leon — precisamente la familia que mas necesita distinguirse.

    El segundo fue un octogono ancho MAS cuatro puas sueltas dibujadas pixel a
    pixel por fuera. Una pua de un pixel es, para el contorno, un borde entero,
    asi que las cuatro salian del tono mas oscuro y se leian como motas de
    suciedad alrededor del icono.

    El tercero fue un unico poligono de ocho vertices con los ejes mas largos
    que las diagonales. Ahi esta la trampa geometrica: en un lienzo de 16, un
    rombo tiene sus puntos medios a 5.66 del centro, asi que cualquier diagonal
    cercana a ese valor produce EXACTAMENTE un rombo — y el rombo ya es la placa
    de los mandamientos. Por debajo de 5.66 se lee como estrella pero se come el
    glifo; por encima se lee como disco, que ya es la placa de los estados.

    De ahi que esta no sea una estrella. Un blason de cinco lados es ancho en
    todo el area util, no choca con ninguna de las otras seis siluetas, y le
    sienta a los emblemas de los Siete Pecados mejor que una estrella.
    """
    cv.poly([(8, 0), (15.5, 5.5), (13.5, 15.5), (2.5, 15.5), (0.5, 5.5)],
            c, px.BASE, px.PLATE)


def plate_banner(cv, c):
    """Estandarte: rectangulo alto con la base en pico. Para los rangos.

    NO escudo: el escudo ya es de los clanes, y dos familias con la misma
    silueta es justo el problema que las placas existen para resolver.
    """
    cv.poly([(3, 0), (13, 0), (13, 12), (8, 15.5), (3, 12)], c, px.BASE, px.PLATE)


def plate_hex(cv, c):
    """Hexagono de tapa plana. Para las habilidades.

    Plano arriba y abajo a proposito: la placa de estrella tambien es un cuerpo
    ancho de esquinas cortadas, y sin la tapa recta las dos se confundirian.
    """
    cv.poly([(3, 0.5), (13, 0.5), (15.5, 8), (13, 15.5), (3, 15.5), (0.5, 8)],
            c, px.BASE, px.PLATE)


def plate_tag(cv, c):
    """Placa cuadrada de esquinas mordidas. Para los rasgos sueltos."""
    cv.poly([(3, 0.5), (13, 0.5), (15.5, 3), (15.5, 13), (13, 15.5),
             (3, 15.5), (0.5, 13), (0.5, 3)], c, px.BASE, px.PLATE)


def plate_diamond(cv, c):
    """Rombo. Para los mandamientos.

    La mitad de abajo es el ESPEJO de la de arriba. La primera version indexaba
    la mitad inferior al reves, asi que la fila 15 salia a lo ancho completo y la
    8 estrecha: el resultado era un reloj de arena, no un rombo.
    """
    cv.poly([(8, 0), (15.5, 8), (8, 15.5), (0.5, 8)], c, px.BASE, px.PLATE)


def plate_disc(cv, c):
    """Disco. La familia mas neutra: estados y magias."""
    cv.ellipse(8.0, 8.0, 7.2, 7.2, c, px.BASE, px.PLATE)


PLATES = {"shield": plate_shield, "crest": plate_crest, "diamond": plate_diamond,
          "disc": plate_disc, "banner": plate_banner, "hex": plate_hex,
          "tag": plate_tag}


def build_plate(plate, plate_hex):
    """Dibuja una placa, la abomba y le pone contorno.

    El contorno va al nivel mas oscuro de la propia rampa de la placa, no a
    negro puro: negro sobre una placa clara se ve como un recorte de tijera,
    mientras que el tono oscuro del mismo color se lee como sombra propia. Y va
    SIEMPRE, en todo el perimetro, porque un icono de interfaz no sabe sobre que
    fondo lo van a pintar.
    """
    cv = Canvas()
    PLATES[plate](cv, plate_hex)
    ring = px.boundary(cv)
    px.sculpt(cv, radius=4.2, only=cv.keys() - ring)
    for k in ring:
        r, _lv, m = cv.px[k]
        cv.px[k] = (r, px.DARKEST, m)
    return cv, ring


def stamp_glyph(cv, art, gramp, glevel, allowed):
    """Estampa un glifo de 10x10 enmascarado contra la silueta de la placa.

    El enmascarado no es cosmetico: sin el, un glifo sobre un escudo (que se
    estrecha en la base) o sobre un rombo (que se estrecha en las cuatro
    esquinas) derrama pixeles fuera de la silueta, y a tamano de boton eso se
    lee como icono roto.

    NO lleva sombra proyectada, y se probo. Un glifo de 10x10 ya ocupa casi toda
    la placa, asi que desplazar una copia oscura un pixel en diagonal duplica su
    masa: el dragon de la Ira y la cruz del Ark salian con una mancha pegada al
    lado y dejaban de leerse. El relieve de la placa — clara arriba a la
    izquierda, oscura abajo a la derecha — ya separa el simbolo del fondo, y
    entre las dos separaciones la que se ve mejor a tamano de boton es la que no
    anade tinta.
    """
    body = {}
    for y, row in enumerate(art):
        for x, ch in enumerate(row):
            if ch in "Xo+":
                body[(x + 3, y + 3)] = {"X": glevel, "o": glevel - 2,
                                        "+": glevel + 2}[ch]
    for (x, y), lv in body.items():
        if (x, y) in allowed:
            cv.put(x, y, gramp, lv, px.EMIT)


def gen_icon(icon_id, glyph_name, plate, plate_hex, glyph_hex, folder=None):
    cv, ring = build_plate(plate, plate_hex)
    pr = ramp(plate_hex)
    body = cv.keys() - ring

    art = glyphs.parse(glyph_name)
    if art:
        gr = ramp(glyph_hex)
        # El contraste se mide contra el color REAL de la placa ya iluminada
        # (nivel base + su sesgo), no contra el hexadecimal del catalogo.
        lv = px.contrast_level(gr, pr[px.BASE + 1], want=0.30)
        stamp_glyph(cv, art, gr, lv, body)

    px.save(cv.image(), folder or ICONS, icon_id, REPORT, size=(S, S))
    return 1


# ---------------------------------------------------------------------------
# EFECTOS  (cada uno con su propio movimiento)
# ---------------------------------------------------------------------------
#
# Todos los efectos usan material EMIT: no reciben luz, la emiten, asi que
# sculpt no los toca. El volumen se lo da la estratificacion en tres tonos.

def fx_flame(c, f, n, dark=False):
    """Lengua de fuego que sube y parpadea.

    En la variante oscura — Hellblaze, el fuego negro del Rey Demonio — los
    tonos se invierten: el nucleo es MAS OSCURO que el borde. Es lo unico que
    hace que una llama se lea como fuego que quema en negro y no como fuego
    normal pintado de morado.
    """
    cv = Canvas()
    core_lv = L_GLOW if dark else L_CORE
    edge_lv = L_BODY + 1 if dark else L_GLOW + 1
    t = f / float(n - 1)
    height = 7 + int(t * 5)
    lean = math.sin(f * 1.1) * 1.6

    for i in range(height):
        y = 15 - i
        p = i / float(height)
        w = (1.0 - p * 0.75) * 3.4 * (0.85 + 0.15 * math.sin(f * 2.0 + i))
        x = 8 + lean * p
        cv.rect(x - w, y, x + w - 1, y, c, edge_lv, px.EMIT)
        if w > 1.4:
            cv.rect(x - w + 1, y, x + w - 2, y, c, L_BODY, px.EMIT)
        if p < 0.55 and w > 2.0:
            cv.rect(x - w + 2, y, x + w - 3, y, c, core_lv, px.EMIT)

    # Pavesas: suben mas rapido que la llama y se apagan arriba.
    for k in range(3):
        p = ((f + k * 2) % n) / float(n)
        ey = int(9 - p * 8)
        ex = int(5 + k * 3 + math.sin(f + k) * 1.5)
        if ey >= 0:
            cv.put(ex, ey, c, L_BODY if p < 0.6 else L_GLOW, px.EMIT)
    return cv


def fx_sun(c, f, n):
    """Disco con corona y rayos que giran."""
    cv = Canvas()
    ang0 = (f / float(n)) * (math.pi / 4)
    reach = 6.5 + math.sin(f * 1.4) * 0.8
    for k in range(8):
        a = ang0 + k * (math.pi / 4)
        for r in range(3, int(reach)):
            lv = L_BODY if r < reach - 2 else L_GLOW
            cv.put(7.5 + math.cos(a) * r, 7.5 + math.sin(a) * r, c, lv, px.EMIT)
    cv.disc(8.0, 8.0, 3.4, c, L_BODY, px.EMIT)
    cv.disc(8.0, 8.0, 2.4, c, L_CORE - 1, px.EMIT)
    cv.disc(8.0, 8.0, 1.2, c, L_CORE, px.EMIT)
    return cv


def fx_burst(c, f, n):
    """Estallido: nucleo que se apaga, anillo que se abre y se afina."""
    cv = Canvas()
    t = f / float(n - 1)
    r = 1.5 + ease_out(t) * 6.5
    thick = 2.6 - t * 1.6
    cv.ring(8.0, 8.0, r, c, L_GLOW, px.EMIT, thickness=thick + 1.0)
    cv.ring(8.0, 8.0, r, c, L_BODY, px.EMIT, thickness=thick)
    if t < 0.6:
        cv.ring(8.0, 8.0, r, c, L_CORE, px.EMIT, thickness=max(1.0, thick - 1.0))
    k = 3.0 - f * 1.2
    if k > 0:
        cv.disc(8.0, 8.0, k, c, L_CORE, px.EMIT)
    return cv


def fx_slash(c, f, n):
    """Arco grueso que barre: el corte de Full Counter.

    Un arco de un pixel se pierde por completo sobre el terreno del juego — a
    tamano real eran cuatro puntos sueltos. Este tiene cuerpo y una estela que se
    apaga por detras, para que se lea como un tajo y no como ruido.
    """
    cv = Canvas()
    t = f / float(n - 1)
    head = -math.pi * 0.95 + ease_out(t) * math.pi * 1.15
    for k in range(16):
        a = head - k * 0.095
        if k < 3:
            lv, spread = L_CORE, (-1, 0, 1)
        elif k < 8:
            lv, spread = L_BODY, (-1, 0, 1)
        elif k < 12:
            lv, spread = L_BODY - 1, (0, 1)
        else:
            lv, spread = L_GLOW, (0,)
        for dr in spread:
            r = 6.2 + dr
            cv.put(7.5 + math.cos(a) * r, 7.5 + math.sin(a) * r, c, lv, px.EMIT)
    return cv


def fx_claw(c, f, n):
    """Tres zarpazos paralelos que se alargan y se afinan: Snatch."""
    cv = Canvas()
    t = f / float(n - 1)
    length = 4 + ease_out(t) * 9
    for k, off in enumerate((-4.5, 0.0, 4.5)):
        for i in range(int(length)):
            p = i / max(1.0, length - 1)
            x = 2.0 + i * 1.0 + (0 if k == 1 else 0.8)
            y = 2.0 + i * 1.0 + off
            lv = L_CORE if p > 0.75 else (L_BODY if p > 0.25 else L_GLOW)
            cv.put(x, y, c, lv, px.EMIT)
            # El zarpazo es ancho en el arranque y termina en punta.
            if p < 0.55:
                cv.put(x + 1, y, c, L_BODY if p > 0.25 else L_GLOW, px.EMIT)
    return cv


def fx_rocks(c, f, n):
    """Bloques que salen despedidos con polvo: Creation."""
    cv = Canvas()
    t = f / float(n - 1)
    # Suelo reventado, no una barra recta. Una linea continua de lado a lado se
    # lee como el borde de una plataforma; lo que tiene que leerse es tierra
    # levantada, asi que el perfil sube y baja con ruido determinista.
    for x in range(16):
        h = 14 + (1 if px.noise(x, 0, 7) > 0.55 else 0)
        cv.rect(x, h, x, 15, c, L_GLOW, px.EMIT)
        cv.put(x, h, c, L_BODY, px.EMIT)
    for k, (bx, spd, size) in enumerate(((2, 1.0, 3), (7, 1.35, 4), (12, 0.85, 3))):
        # Parabola: sube y empieza a caer, en vez de subir en linea recta.
        h = math.sin(min(1.0, t * spd) * math.pi * 0.85) * 11.0
        y = int(13 - h)
        cv.rect(bx - size // 2, y, bx - size // 2 + size - 1, y + size - 1,
                c, L_BODY, px.EMIT)
        cv.rect(bx - size // 2, y, bx - size // 2 + size - 2, y, c, L_CORE - 2, px.EMIT)
        cv.put(bx - size // 2 + size - 1, y + size - 1, c, L_GLOW, px.EMIT)
    for k in range(4):
        dx = int(1 + k * 4 + t * 2)
        cv.put(dx, int(13 - t * 3), c, L_GLOW, px.EMIT)
    return cv


def fx_spiral(c, f, n):
    """Espiral que gira hacia dentro: Infinity, Invasion y las almas.

    El brazo se traza GRUESO, con un segundo radio por dentro, y con el paso
    suficientemente fino para que no queden huecos entre muestras. Una espiral
    de un pixel muestreada a saltos no se lee como espiral sino como dos docenas
    de puntos sueltos dando vueltas — y en tres efectos distintos del mod, que
    son los que mas se repiten en pantalla.
    """
    cv = Canvas()
    turns = 2.15
    steps = 96
    phase = (f / float(n)) * math.pi * 2
    for i in range(steps):
        p = i / float(steps)
        a = phase + p * math.pi * 2 * turns
        r = 7.2 * (1 - p * 0.92)
        lv = L_CORE if p > 0.82 else (L_BODY if p > 0.32 else L_GLOW)
        cv.put(7.5 + math.cos(a) * r, 7.5 + math.sin(a) * r, c, lv, px.EMIT)
        if p > 0.15:
            cv.put(7.5 + math.cos(a) * (r - 1.0),
                   7.5 + math.sin(a) * (r - 1.0), c,
                   L_BODY if p > 0.55 else L_GLOW, px.EMIT)
    cv.rect(7, 7, 8, 8, c, L_CORE, px.EMIT)
    return cv


def fx_shock(c, f, n):
    """Onda de choque doble con grietas: las transformaciones."""
    cv = Canvas()
    t = f / float(n - 1)
    r = 2.0 + ease_out(t) * 6.0
    cv.ring(8.0, 8.0, r, c, L_GLOW, px.EMIT, thickness=3.0)
    cv.ring(8.0, 8.0, r, c, L_BODY, px.EMIT, thickness=1.8)
    if r > 4:
        cv.ring(8.0, 8.0, r - 3.0, c, L_GLOW, px.EMIT, thickness=1.4)
    for k in range(4):
        a = k * (math.pi / 2) + math.pi / 4
        for d in (0.0, 1.0):
            cv.put(7.5 + math.cos(a) * (r + d), 7.5 + math.sin(a) * (r + d),
                   c, L_CORE if d == 0 else L_GLOW, px.EMIT)
    return cv


def fx_spear(c, f, n):
    """Estocada vertical con estela: Chastiefol."""
    cv = Canvas()
    t = f / float(n - 1)
    tip = int(14 - ease_out(t) * 13)
    cv.rect(7, tip + 2, 8, 15, c, L_BODY, px.EMIT)
    cv.rect(7, tip + 2, 7, 15, c, L_GLOW, px.EMIT)
    # Punta en rombo, no un pixel plano.
    cv.put(7, tip, c, L_CORE, px.EMIT)
    cv.put(8, tip, c, L_CORE, px.EMIT)
    cv.rect(6, tip + 1, 9, tip + 1, c, L_CORE - 1, px.EMIT)
    if f >= n - 3:
        cv.rect(4, tip + 3, 11, tip + 3, c, L_GLOW, px.EMIT)
    return cv


def fx_motes(c, f, n):
    """Motas que suben y titilan: curacion y encantamiento."""
    cv = Canvas()
    seeds = ((2, 0.00), (5, 0.35), (8, 0.70), (11, 0.15), (13, 0.55), (6, 0.85))
    for x, off in seeds:
        p = ((f / float(n)) + off) % 1.0
        y = 14 - p * 12.5
        lv = L_CORE if p < 0.35 else (L_BODY if p < 0.7 else L_GLOW)
        cv.put(x, y, c, lv, px.EMIT)
        # Destello en cruz cuando la mota esta en su momento mas brillante.
        if p < 0.3:
            cv.put(x, y - 1, c, L_GLOW, px.EMIT)
            cv.put(x - 1, y, c, L_GLOW, px.EMIT)
            cv.put(x + 1, y, c, L_GLOW, px.EMIT)
    return cv


def fx_arrow(c, f, n):
    """Flechas gemelas que cruzan con estela: Herritt.

    Cuerpo de dos filas, no de una. Una flecha de un pixel de grosor sobre el
    terreno del juego es una raya que se confunde con el borde de una loseta.
    """
    cv = Canvas()
    t = ease_out(f / float(n - 1))
    for row, d in ((4, 1), (10, -1)):
        x = 1 + t * 13 if d > 0 else 14 - t * 13
        # punta
        cv.rect(x, row, x, row + 1, c, L_CORE, px.EMIT)
        cv.put(x - d, row - 1, c, L_BODY, px.EMIT)
        cv.put(x - d, row + 2, c, L_BODY, px.EMIT)
        # astil y estela, que se apaga hacia atras
        for k in range(1, 7):
            xx = x - d * k
            lv = L_BODY if k < 3 else L_GLOW
            cv.rect(xx, row, xx, row + 1, c, lv, px.EMIT)
    return cv


def fx_lightning(c, f, n):
    """Rayo quebrado que cae y golpea: la gracia de Ludociel."""
    cv = Canvas()
    t = f / float(n - 1)
    reach = int(2 + ease_out(t) * 14)
    # Zigzag fijo: si cambiara entre fotogramas el rayo "bailaria" en vez de
    # crecer, y a seis fotogramas eso se ve como parpadeo, no como descarga.
    zig = [8, 8, 7, 7, 6, 7, 8, 8, 9, 8, 7, 7, 6, 6, 7, 7]
    for y in range(min(reach, 16)):
        x = zig[y]
        cv.put(x, y, c, L_CORE, px.EMIT)
        cv.put(x - 1, y, c, L_BODY, px.EMIT)
        cv.put(x + 1, y, c, L_GLOW, px.EMIT)
    # Ramal que se abre a media caida.
    if reach > 8:
        for k in range(min(4, reach - 8)):
            cv.put(zig[8] + 2 + k, 8 + k, c, L_BODY if k < 2 else L_GLOW, px.EMIT)
    if f >= n - 2:
        cv.rect(4, 14, 11, 15, c, L_GLOW, px.EMIT)
        cv.rect(6, 14, 9, 14, c, L_BODY, px.EMIT)
    return cv


def fx_tornado(c, f, n):
    """Embudo que gira: la gracia de Sariel."""
    cv = Canvas()
    phase = (f / float(n)) * math.pi * 2
    for y in range(1, 16):
        p = (y - 1) / 14.0
        w = 1.2 + p * 5.2
        off = math.sin(phase + p * 5.2) * w * 0.5
        cx = 7.5 + off
        cv.rect(cx - w * 0.5, y, cx + w * 0.5, y, c, L_GLOW, px.EMIT)
        cv.put(cx - w * 0.5, y, c, L_BODY, px.EMIT)
        cv.put(cx + w * 0.5, y, c, L_CORE if (y + f) % 3 == 0 else L_BODY, px.EMIT)
    return cv


def fx_wave(c, f, n):
    """Oleaje que sube con espuma: la gracia de Tarmiel."""
    cv = Canvas()
    t = f / float(n - 1)
    base = 15 - ease_out(t) * 10
    for y in range(int(base), 16):
        for x in range(16):
            crest = math.sin((x + f * 1.5) * 0.8) * 1.2
            if y >= base + crest:
                lv = L_BODY if y > base + crest + 1.5 else L_CORE - 1
                cv.put(x, y, c, lv, px.EMIT)
    for x in range(16):
        crest = math.sin((x + f * 1.5) * 0.8) * 1.2
        cv.put(x, base + crest - 1, c, L_GLOW, px.EMIT)
    return cv


def fx_petrify(c, f, n):
    """La piedra trepa desde los pies: la maldicion de Galand."""
    cv = Canvas()
    t = f / float(n - 1)
    top = int(15 - t * 12)
    for y in range(top, 16):
        w = 3 + (15 - y) // 4
        cv.rect(7 - w + 1, y, 8 + w - 1, y, c, L_BODY, px.EMIT)
        cv.put(7 - w + 1, y, c, L_CORE - 2, px.EMIT)
        cv.put(8 + w - 1, y, c, L_GLOW, px.EMIT)
    cv.rect(4, top, 11, top, c, L_CORE - 1, px.EMIT)
    for y in range(top + 2, 16, 3):
        cv.put(6, y, c, L_GLOW, px.EMIT)
        cv.put(9, y, c, L_GLOW, px.EMIT)
    return cv


def fx_ash(c, f, n):
    """Se deshace en ceniza: la maldicion de Grayroad."""
    cv = Canvas()
    t = f / float(n - 1)
    top = int(3 + t * 10)
    for y in range(top, 14):
        for x in range(5, 11):
            # El borde de la desintegracion se come pixeles sueltos, no una
            # linea recta: una silueta que se acorta de golpe se ve como una
            # persiana bajando.
            if y < top + 2 and px.noise(x, y, f) < 0.45:
                continue
            cv.put(x, y, c, L_BODY if (x + y) % 3 else L_GLOW, px.EMIT)
    for k, x in enumerate((3, 6, 9, 12)):
        y = (t * 15 + k * 3.5) % 16
        cv.put(x, y, c, L_GLOW, px.EMIT)
        if k % 2 == 0:
            cv.put(x + 1, y + 1, c, L_GLOW, px.EMIT)
    return cv


FX_STYLES = {
    # Un efecto por Tesoro Sagrado, con el movimiento de lo que hace el arma:
    # la espada corta, el baston golpea en cadena, el martillo revienta el suelo,
    # el orbe pulsa y el hacha cae como el sol.
    "sds_fx_lostvayne": ("slash", "#DCE6F0"),
    "sds_fx_courechouse": ("claw", "#EDEFF2"),
    "sds_fx_gideon": ("rocks", "#F0D97A"),
    "sds_fx_aldan": ("spiral", "#E0C8F0"),
    "sds_fx_rhitta": ("sun", "#FFD98A"),

    "sds_fx_flash": ("lightning", "#AEE0FF"),
    "sds_fx_tornado": ("tornado", "#7DCEA0"),
    "sds_fx_ocean": ("wave", "#3498DB"),
    "sds_fx_petrify": ("petrify", "#95A5A6"),
    "sds_fx_ash": ("ash", "#7F8C8D"),
    "sds_fx_soul": ("spiral", "#5DADE2"),
    "sds_fx_demon_king": ("shock", "#4A1050"),
    "sds_fx_hellblaze":    ("flame_dark", "#7A2A8A"),
    "sds_fx_purge":        ("flame", "#FDFEFE"),
    "sds_fx_ark":          ("burst", "#F7DC6F"),
    "sds_fx_sunshine":     ("sun", "#F39C12"),
    "sds_fx_the_one":      ("sun", "#FFE07A"),
    "sds_fx_full_counter": ("slash", "#2ECC71"),
    "sds_fx_snatch":       ("claw", "#E74C3C"),
    "sds_fx_creation":     ("rocks", "#A5691D"),
    "sds_fx_infinity":     ("spiral", "#9B59B6"),
    "sds_fx_curse":        ("spiral", "#8E44AD"),
    "sds_fx_demon_mark":   ("shock", "#8E1F2B"),
    "sds_fx_assault_mode": ("shock", "#E74C3C"),
    "sds_fx_indura":       ("shock", "#6A1070"),
    "sds_fx_chastiefol":   ("spear", "#2ECC71"),
    "sds_fx_herritt":      ("arrow", "#E8A0C8"),
    "sds_fx_heal":         ("motes", "#2ECC71"),
    "sds_fx_enchant":      ("motes", "#AF7AC5"),
}

FX_FUNCS = {
    "flame": lambda c, f, n: fx_flame(c, f, n, False),
    "flame_dark": lambda c, f, n: fx_flame(c, f, n, True),
    "sun": fx_sun, "burst": fx_burst, "slash": fx_slash, "claw": fx_claw,
    "rocks": fx_rocks, "spiral": fx_spiral, "shock": fx_shock,
    "spear": fx_spear, "motes": fx_motes, "arrow": fx_arrow,
    "lightning": fx_lightning, "tornado": fx_tornado, "wave": fx_wave,
    "petrify": fx_petrify, "ash": fx_ash,
}


# Efectos hechos de particulas sueltas por definicion: motas que suben, pavesas
# que saltan, cascotes que vuelan, rayos de sol despegados del disco. El control
# de calidad avisa de pixeles sin vecinos porque en un sprite solido son ruido,
# pero aqui son justo lo que se quiere dibujar. Se exceptuan por estilo y no por
# archivo para que el aviso siga saltando en los veinte efectos que si deberian
# salir de una pieza — un informe con veintitres avisos inofensivos es un
# informe que nadie lee.
PARTICLE_STYLES = {"motes", "ash", "rocks", "sun", "flame", "flame_dark"}


def gen_effect(fx_id, style, hexcol):
    folder = os.path.join(EFFECTS, fx_id)
    fn = FX_FUNCS[style]
    r = ramp(hexcol)
    for f in range(FX_FRAMES):
        cv = fn(r, f, FX_FRAMES)
        px.save(cv.image(), folder, str(f), REPORT, size=(S, S), min_fill=0.01,
                check_orphans=style not in PARTICLE_STYLES)
    return FX_FRAMES


# ---------------------------------------------------------------------------
# ARMAS  (siete siluetas distintas)
# ---------------------------------------------------------------------------
#
# La silueta se escribe como texto porque es lo unico que se puede corregir
# leyendo el codigo, pero el color ya no: 'X' es hoja metalica, 'G' empunadura
# de cuero y '*' una gema. Lo que decide donde va la luz es sculpt, no la
# rejilla, asi que la misma silueta sale con filo brillante y lomo oscuro sin
# que nadie pinte pixel a pixel.

WEAPON_ART = {
    # Lostvayne: espada de hoja acanalada, guarda ancha y gema en el pomo
    "sds_item_lostvayne": """
.......XX.......
......XXXX......
......XxxX......
......XxxX......
......XxxX......
......XxxX......
......XxxX......
......XxxX......
......XxxX......
......XxxX......
....GGGGGGGG....
.......GG.......
.......GG.......
.......GG.......
......G**G......
.......GG.......
""",
    # Courechouse: baston de gema con dos abrazaderas.
    #
    # Antes eran cuatro secciones de metal alternando con cuatro de mango, todas
    # del mismo ancho y a intervalos iguales. Un cilindro a rayas regulares no
    # se lee como baston sino como termometro o escalera de mano; lo que dice
    # "baston" es una CABEZA distinta del resto y un mango largo y liso.
    "sds_item_courechouse": """
......XXXX......
.....XX**XX.....
.....XX**XX.....
......XXXX......
.......GG.......
.......GG.......
......GXXG......
.......GG.......
.......GG.......
.......GG.......
......GXXG......
.......GG.......
.......GG.......
.......GG.......
......GGGG......
................
""",
    # Chastiefol: lanza sagrada. Punta corta, astil largo.
    #
    # Costo dos intentos. El primero le puso una punta de seis columnas sobre un
    # astil de dos: en verde y con el degradado del metal encima se leia como la
    # copa de un arbol. El segundo le cambio el astil a madera marron para
    # separar punta de mango, y salio peor — verde ancho sobre tronco marron es
    # literalmente un arbol.
    #
    # Lo que distingue una lanza de una espada no es el color sino la PROPORCION:
    # la espada es hoja larga y mango corto, la lanza es punta corta y astil
    # largo. Con la punta en cinco filas de dieciseis ya no hay ambiguedad, y el
    # astil vuelve al verde oscuro del Arbol Sagrado, que es de donde sale.
    "sds_item_chastiefol": """
.......XX.......
......XXXX......
......XxxX......
......XxxX......
.....XXxxXX.....
.......GG.......
.......GG.......
......G**G......
.......GG.......
.......GG.......
.......GG.......
.......GG.......
.......GG.......
.......GG.......
......GGGG......
................
""",
    # Gideon: martillo de guerra, cabeza enorme
    "sds_item_gideon": """
................
...XXXXXXXXXX...
..XXXXXXXXXXXX..
..XXXXXXXXXXXX..
..XXXXxxxxXXXX..
..XXXXXXXXXXXX..
..XXXXXXXXXXXX..
...XXXXXXXXXX...
.......GG.......
.......GG.......
.......GG.......
.......GG.......
.......GG.......
.......GG.......
......GGGG......
................
""",
    # Herritt: arco de las hadas, de perfil.
    #
    # Antes eran DOS arcos enfrentados, simetricos respecto al eje vertical, y
    # el resultado se leia como una mariposa o un antifaz — cualquier cosa menos
    # un arco. Un arco solo, con la cuerda recta a un lado y las palas curvando
    # al otro, es inconfundible aunque ocupe la mitad de pixeles.
    "sds_item_herritt": """
......XXX.......
.....XX...X.....
....XX....X.....
....XX....X.....
....X.....X.....
....X.....X.....
....G.....X.....
....G.....X.....
....G.....X.....
....X.....X.....
....X.....X.....
....XX....X.....
....XX....X.....
.....XX...X.....
......XXX.......
................
""",
    # Aldan: orbe flotante engarzado
    "sds_item_aldan": """
................
.....XXXXXX.....
...XXXXXXXXXX...
..XXX******XXX..
..XX********XX..
.XXX********XXX.
.XXX********XXX.
.XXX********XXX.
..XX********XX..
..XXX******XXX..
...XXXXXXXXXX...
.....XXXXXX.....
.......GG.......
......GGGG......
.......GG.......
................
""",
    # Rhitta: hacha divina de doble hoja
    "sds_item_rhitta": """
...XXXX..XXXX...
..XXXXX..XXXXX..
.XXXXXX..XXXXXX.
XXXXXXX..XXXXXXX
XXXXXXX..XXXXXXX
XXXXXXX..XXXXXXX
.XXXXXX..XXXXXX.
..XXXXX..XXXXX..
...XXXX**XXXX...
.......GG.......
.......GG.......
.......GG.......
.......GG.......
.......GG.......
......GGGG......
................
""",
}


def gen_weapon(wid, blade_hex, grip_hex, glyph, plate_hex):
    """Dos imagenes distintas para el arma, y no es duplicar trabajo.

    El sprite EN MANO puede permitirse una silueta fina y detallada: se ve
    grande, en movimiento y sobre el terreno. El ICONO de boton no: a tamano de
    boton una hoja de dos pixeles de ancho sobre fondo transparente desaparece,
    que es por lo que las armas "no se veian bien" cuando ambos eran la misma
    imagen. El icono usa la misma placa+glifo que el resto de la interfaz.
    """
    blade = ramp(blade_hex)
    grip = ramp(grip_hex)
    gem = ramp(plate_hex)

    cv = Canvas()
    # Misma comprobacion de forma que los cuerpos: una fila a la que le falta un
    # punto desplaza media hoja una columna y sale un arma torcida que solo se
    # detecta ampliando el PNG.
    art = parse_body(WEAPON_ART[wid])
    for y, row in enumerate(art):
        for x, ch in enumerate(row):
            if ch == "X":
                cv.put(x, y, blade, px.BASE, px.METAL)
            elif ch == "x":
                # Acanaladura: el surco central de la hoja. Dos niveles por
                # debajo del filo, es lo que convierte una barra de metal en una
                # hoja con seccion.
                cv.put(x, y, blade, px.BASE - 2, px.METAL)
            elif ch == "G":
                cv.put(x, y, grip, px.BASE, px.LEATHER)
            elif ch == "*":
                cv.put(x, y, gem, px.BASE + 1, px.GEM)

    px.sculpt(cv, radius=2.4)
    px.contact_shadow(cv)
    px.outline_outer(cv, level=px.DARKEST)
    px.save(cv.image(), WEAPONS, wid, REPORT, size=(S, S))

    ic, ring = build_plate("tag", plate_hex)
    pr = ramp(plate_hex)
    gart = glyphs.parse(glyph)
    if gart:
        br = ramp(blade_hex)
        lv = px.contrast_level(br, pr[px.BASE + 1], want=0.30)
        stamp_glyph(ic, gart, br, lv, ic.keys() - ring)
    im = ic.image()
    px.save(im, WEAPONS_UI, wid, REPORT, size=(S, S))
    # Los tesoros tambien aparecen como boton de poder, que lee de ui/icons.
    px.save(im, ICONS, wid, REPORT, size=(S, S))
    return 3


# ---------------------------------------------------------------------------
# PROYECTILES
# ---------------------------------------------------------------------------

def gen_projectile(pid, hexcol, shape):
    """Cabeza solida con estela. Vuelan hacia la derecha por convencion del
    juego, asi que la estela va siempre a la izquierda."""
    cv = Canvas()
    c = ramp(hexcol)

    if shape == "bolt":
        cv.rect(9, 6, 12, 9, c, L_BODY, px.EMIT)
        cv.rect(10, 7, 13, 8, c, L_CORE, px.EMIT)
        cv.rect(4, 7, 8, 8, c, L_BODY, px.EMIT)
        cv.rect(1, 7, 3, 8, c, L_GLOW, px.EMIT)
    elif shape == "orb":
        cv.disc(10.0, 8.0, 4.0, c, L_GLOW, px.EMIT)
        cv.disc(10.0, 8.0, 3.0, c, L_BODY, px.EMIT)
        cv.disc(9.5, 7.5, 1.6, c, L_CORE, px.EMIT)
        cv.rect(2, 7, 5, 8, c, L_GLOW, px.EMIT)
    elif shape == "spear":
        cv.poly([(15, 7.5), (10, 5), (10, 10)], c, L_BODY, px.EMIT)
        cv.rect(11, 7, 13, 8, c, L_CORE, px.EMIT)
        cv.rect(3, 7, 10, 8, c, L_BODY, px.EMIT)
        cv.rect(0, 7, 2, 8, c, L_GLOW, px.EMIT)
    elif shape == "rock":
        cv.poly([(9, 3), (13, 6), (12.5, 11), (8, 13), (4.5, 10), (5, 5)],
                c, px.BASE, px.STONE)
        px.sculpt(cv, radius=2.6)
        px.outline_outer(cv, level=px.DARKEST)
    elif shape == "arrow":
        cv.poly([(15, 7.5), (11, 5.5), (11, 9.5)], c, L_BODY, px.EMIT)
        cv.rect(12, 7, 14, 8, c, L_CORE, px.EMIT)
        cv.rect(4, 7, 11, 8, c, L_BODY, px.EMIT)
        cv.rect(1, 7, 3, 8, c, L_GLOW, px.EMIT)

    px.save(cv.image(), os.path.join(PROJECTILES, pid), pid + "_1", REPORT,
            size=(S, S))
    return 1


# ---------------------------------------------------------------------------
# ACTORES  (la silueta identifica la raza)
# ---------------------------------------------------------------------------
#
# Los cuerpos se escriben como rejilla de texto, igual que las armas y los
# glifos, y no como huesos parametricos. Se intento al reves y salio mal: unos
# cuernos descritos como curva de Bezier con sus puntos de control se abrian
# hasta las esquinas del lienzo y el demonio parecia un insecto con antenas, el
# brazo se despegaba del torso en el fotograma levantado, y nada de eso se veia
# leyendo el codigo — habia que generar el PNG y mirarlo. Una rejilla de 16x16
# escrita a mano se corrige en el sitio donde esta el error.
#
# La regla del caminado la impone el juego: walk_0 y walk_3 con los pies en la
# fila 15, walk_1 levantado 2 px y walk_2 levantado 1 px. Como el levantamiento
# desplaza la rejilla entera hacia arriba, las dos primeras filas TIENEN que
# quedar libres: con los cuernos en la fila 0 el fotograma levantado los sacaria
# del lienzo y parpadearian al andar.
#
# Leyenda:
#   H  cuerno y garra (hueso, color 'horns')
#   S  piel de la cara (color 'skin')
#   E  ojo encendido — material EMIT, no se apaga en el lado en sombra
#   C  cuerpo (color 'coat')
#   A  brazo (color 'coat', un nivel mas oscuro para despegarlo del torso)
#   I  pierna (color 'inner')
#   .  vacio

# Dos medidas de esta rejilla estan puestas a proposito y conviene no tocarlas:
#
# LOS CUERNOS SE AFILAN. Empiezan con un pixel en la fila 2, dos en la 3 y
# nacen del craneo en la 4. Cuando eran bloques de dos por dos no se leian como
# cuernos sino como OREJAS de raton, y el demonio pasaba de temible a simpatico.
#
# LA CABEZA MIDE SEIS COLUMNAS Y LOS HOMBROS DIEZ. Cuando la cabeza media ocho
# el escalon con el torso era de una sola columna por lado, no habia cuello, y
# la masa entera de arriba se leia como UNA cabeza gigante — hasta el punto de
# que el adorno del pecho parecia una boca. Dos columnas de escalon a cada lado,
# mas la sombra de contacto bajo la mandibula, es lo que separa cabeza de cuerpo.

BRUTE_WALK = [
    # walk_0 — apoyo, piernas juntas
    """
................
................
..H..........H..
...H........H...
....HSSSSSSH....
.....SESSES.....
.....SSSSSS.....
......SSSS......
...CCCCCCCCCC...
..ACCCCCCCCCCA..
..ACCCCCCCCCCA..
..A.CCCCCCCC.A..
..A..IIIIII..A..
..H..II..II..H..
.....II..II.....
....III..III....
""",
    # walk_1 — zancada abierta; se dibuja con los pies en la fila 15 y el
    # levantamiento de 2 px lo aplica gen_actor al estampar
    """
................
................
..H..........H..
...H........H...
....HSSSSSSH....
.....SESSES.....
.....SSSSSS.....
......SSSS......
...CCCCCCCCCC...
...CCCCCCCCCCA..
..ACCCCCCCCCCA..
..A.CCCCCCCC.A..
..A..IIIIII..H..
..H.II....II....
....II....II....
...III....III...
""",
    # walk_2 — paso intermedio
    """
................
................
..H..........H..
...H........H...
....HSSSSSSH....
.....SESSES.....
.....SSSSSS.....
......SSSS......
...CCCCCCCCCC...
..ACCCCCCCCCC...
..ACCCCCCCCCCA..
..A.CCCCCCCC.A..
..H..IIIIII..A..
....II...II..H..
....II...II.....
...III...III....
""",
    # walk_3 — zancada contraria a walk_1
    """
................
................
..H..........H..
...H........H...
....HSSSSSSH....
.....SESSES.....
.....SSSSSS.....
......SSSS......
...CCCCCCCCCC...
..ACCCCCCCCCC...
..ACCCCCCCCCCA..
..A.CCCCCCCC.A..
..H..IIIIII..A..
....II....II.H..
....II....II....
...III....III...
""",
]

WALK_LIFT = [0, 2, 1, 0]

# Que rampa y que material usa cada letra de la rejilla.
BODY_LEGEND = {
    "H": ("horns", px.BASE, px.STONE),
    "S": ("skin", px.BASE, px.SKIN),
    "C": ("coat", px.BASE, px.CLOTH),
    "A": ("coat", px.BASE - 1, px.CLOTH),
    # Las piernas se oscurecen SIEMPRE respecto al color declarado. En paletas
    # claras el interior y la prenda quedaban a dos tonos de distancia y la
    # figura se leia como un bloque sin piernas; forzarlo aqui garantiza que la
    # silueta se reconozca en todas las paletas sin revisarlas una a una.
    "I": ("inner", px.BASE + 1, px.CLOTH),
}


def parse_body(art):
    """Texto -> lista de 16 filas de 16 caracteres, comprobando la forma.

    La comprobacion no es paranoia: una fila a la que le falta un punto
    desplaza medio cuerpo una columna y el resultado es un sprite torcido que
    solo se detecta mirando el PNG ampliado.
    """
    rows = [r for r in art.split("\n") if r.strip()]
    if len(rows) != S:
        raise ValueError("el cuerpo tiene %d filas, se esperaban %d" % (len(rows), S))
    for i, r in enumerate(rows):
        if len(r) != S:
            raise ValueError("la fila %d tiene %d columnas, se esperaban %d"
                             % (i, len(r), S))
    return rows


def draw_body(cv, sp, dy, pose):
    """Estampa la rejilla del cuerpo y le anade los rasgos propios de la raza.

    Se dibuja TODO plano y el sombreado va despues, de una vez, sobre la
    silueta entera. Si cada parte se sombreara por separado, los bordes entre
    cabeza, torso y piernas quedarian iluminados como si cada una fuera un
    objeto suelto flotando por su cuenta.
    """
    rows = parse_body(BRUTE_WALK[pose])

    for y, row in enumerate(rows):
        for x, ch in enumerate(row):
            if ch == ".":
                continue
            if ch == "E":
                # Ojo encendido: EMIT para que el sombreado no lo apague. Un ojo
                # que brilla tiene que brillar tambien en el lado en sombra de
                # la cara, o la mirada desaparece al girar la luz.
                cv.put(x, y - dy, ramp("#FF3B30"), px.BRIGHTEST, px.EMIT)
                continue
            key, level, mat = BODY_LEGEND[ch]
            col = sp.get(key) or sp["coat"]
            cv.put(x, y - dy, ramp(col), level, mat)

    # --- aletas dorsales: solo los monstruos mayores ----------------------
    #
    # Nacen PEGADAS al hombro, en diagonal. La primera version las sembraba a
    # una y dos columnas del cuerpo alternando el desplazamiento, y como no
    # tocaban nada quedaban como pixeles sueltos flotando alrededor de la
    # bestia: a tamano de juego, polvo.
    if sp.get("spines"):
        sc = ramp(sp["spines"])
        for d, bx in ((-1, 2), (1, 13)):
            cv.put(bx, 8 - dy, sc, px.BASE, px.STONE)
            cv.put(bx + d, 9 - dy, sc, px.BASE - 1, px.STONE)

    # AQUI NO VA UNA COLA, y se intento.
    #
    # Una curva de la cadera al suelo por detras de la pierna necesita, en un
    # lienzo de 16, mas resolucion de la que hay: la curva salia partida en un
    # pixel pegado a la cadera y un muñon de tres sueltos contra el borde
    # derecho, sin nada que los uniera. Y aunque saliera entera, un sprite
    # visto de frente no ensena la cola. Indura se distingue por su paleta y por
    # las aletas de los hombros, que si caben.


# Las seis carpetas de piel que espera un pueblo humanoide. Los nombres NO son
# opcionales: la subespecie compone la ruta como base + nombre de piel, y el
# juego indexa skin_citizen_male / skin_citizen_female / skin_warrior con el
# MISMO indice aleatorio. Si los tres arrays no existen y no miden lo mismo, la
# lectura se sale de rango al nacer una unidad.
HUMAN_SKINS = ["male_1", "female_1", "warrior_1", "king", "leader", "child"]


def gen_race_actor(actor_id, spec):
    """Cuerpo de PUEBLO, en el formato que espera el pipeline de fenotipos.

    Una criatura vive en una sola carpeta Main; un pueblo necesita una carpeta
    por tipo de piel, con los nombres exactos de HUMAN_SKINS. Apuntar un pueblo
    a una carpeta Main es lo que producia unidades visibles que no se podian
    seleccionar: el renderizador resolvia el sprite a nada, y la seleccion se
    construye a partir de ese sprite.

    Los seis tipos comparten el mismo dibujo. Distinguir al guerrero del civil
    seria mejor, pero el color ya lo da `color_hex` del actor y aqui lo que hace
    falta es que las seis carpetas EXISTAN: los tres arrays de piel se indexan
    con el mismo numero aleatorio y una carpeta que falte se sale de rango.
    """
    n = 0
    for skin in HUMAN_SKINS:
        folder = os.path.join(ACTORS, actor_id, skin)
        for i in range(4):
            cv = Canvas()
            draw_body(cv, spec, WALK_LIFT[i], i)
            px.save(cv.image(), folder, "walk_%d" % i, REPORT, size=(S, S))
            n += 1
    return n


def gen_actor(actor_id, spec):
    """Cuatro fotogramas de caminado, con la altura del paso comprobada.

    EL CONTORNO NO PUEDE BAJAR DE LA PLANTA DEL PIE, y esto costo encontrarlo.
    El juego anima el paso por ALTURA: walk_1 va 2 px mas alto que walk_0 y
    walk_2 va 1 px mas alto. Al anadir el contorno exterior, los pies de un
    fotograma levantado ganaban un pixel oscuro por debajo, mientras que los del
    fotograma apoyado lo perdian por salirse del lienzo. Resultado medido:
    saltos de 0, 1, 0 y 0 px en vez de 0, 2, 1 y 0 — el rebote casi entero
    comido, y walk_2 sin levantar nada.

    No se ve mirando el PNG: hay que medir la fila mas baja con alfa 255 de cada
    fotograma. Por eso se mide aqui y se compara con la regla, en vez de confiar
    en que el contorno "no molesta".
    """
    folder = os.path.join(ACTORS, actor_id, "Main")
    lows = []
    for i in range(4):
        cv = Canvas()
        draw_body(cv, spec, WALK_LIFT[i], i)
        bottom = max(y for (_x, y) in cv.keys())

        px.sculpt(cv, radius=2.6)
        px.contact_shadow(cv)
        solid = cv.keys()
        px.outline_outer(cv, level=px.DARKEST)
        for (x, y) in list(cv.keys()):
            if (x, y) not in solid and y > bottom:
                cv.erase(x, y)

        lows.append(max(y for (_x, y) in cv.keys()))
        px.save(cv.image(), folder, "walk_%d" % i, REPORT, size=(S, S))

    want = [FEET - lift for lift in WALK_LIFT]
    if lows != want:
        REPORT.error(actor_id, "el ciclo de paso apoya en las filas %s y el "
                               "juego espera %s" % (lows, want))
    return 4


RACES = {
    "sds_demon": dict(skin="#7A5480", hair="#1A1220", coat="#3B1F2B",
                      inner="#241019", accent="#C0392B",
                      horns="#E8DCC8", demon_eyes=True),
    "sds_goddess": dict(skin="#F2D9C0", hair="#F4E4B0", coat="#EFEFE4",
                        inner="#D8D2C0", accent="#F4D03F",
                        halo="#FFE98A"),
    "sds_fairy": dict(skin="#F0DCC4", hair="#E8A0C0", coat="#2E7D4F",
                      inner="#1E5537", accent="#9BE8A0",
                      wings="#BFF0D0"),
    # Los gigantes NO se dibujan mas anchos.
    #
    # Un cuerpo de ocho columnas dentro de un lienzo de dieciseis dejaba la
    # cabeza y las piernas fuera de proporcion y se leia como un monigote
    # hinchado, no como una persona grande. El tamano de un gigante es cosa de
    # base_stats["scale"] en el juego, que escala el sprite entero sin
    # deformarlo.
    "sds_giant": dict(skin="#D9A88A", hair="#6B3F1F", coat="#B5651D",
                      inner="#7A4212", accent="#E8C07A"),
    "sds_vampire": dict(skin="#CFC3D6", hair="#14101A", coat="#4A1020",
                        inner="#2A0A12", accent="#D64550",
                        cape="#2A0810", demon_eyes=True),

    # --- las tres bestias: unicas con cuerpo propio ------------------------
    "sds_gray_demon": dict(skin="#8A8A8A", hair="#4A4A4A", coat="#5A5A5A",
                           inner="#3A3A3A", accent="#C0392B",
                           horns="#C8C8C8", demon_eyes=True, brute=True),
    "sds_red_demon": dict(skin="#B04030", hair="#3A1010", coat="#7A1F1F",
                          inner="#4A1010", accent="#FFAA33",
                          horns="#F0D8B0", demon_eyes=True, brute=True),
    # Indura lleva la paleta ACLARADA respecto al canon. Con el morado casi
    # negro del original el cuerpo no se distinguia de su propio contorno y la
    # bestia era una mancha oscura con cuatro chispas encima.
    "sds_indura": dict(skin="#6B3C68", hair="#1E1024", coat="#402048",
                       inner="#2A1230", accent="#FF3355",
                       horns="#C4A8CC", demon_eyes=True, brute=True,
                       spines="#C4A8CC"),

    # --- los siete pecados capitales, uno por persona ----------------------
    #
    # Cada uno con la paleta del personaje, no la de su clan: a tamano de juego
    # el pelo y la prenda son lo unico que se lee, y son justo lo que distingue
    # a Meliodas de un humano cualquiera. El acento lleva el color de su bestia.
    "sds_meliodas": dict(skin="#F2D9C0", hair="#F2D16B", coat="#1B1B22",
                         inner="#0E0E14", accent="#2E8B57"),
    "sds_ban": dict(skin="#F0D8BC", hair="#E8E8E8", coat="#C0392B",
                    inner="#7B241C", accent="#E67E22"),
    "sds_diane": dict(skin="#EBC9A8", hair="#7A4A24", coat="#E67E22",
                      inner="#A85A12", accent="#F4D03F"),
    "sds_gowther": dict(skin="#F4DCD8", hair="#E8A8C4", coat="#2C2C3A",
                        inner="#1A1A24", accent="#D98CB3"),
    "sds_king": dict(skin="#F0DCC4", hair="#E87AA8", coat="#2E7D4F",
                     inner="#1E5537", accent="#7D6608",
                     wings="#BFF0D0"),
    "sds_merlin": dict(skin="#EFD8C0", hair="#14141F", coat="#5B2C6F",
                       inner="#331640", accent="#BB8FCE"),
    "sds_escanor": dict(skin="#F0CFA8", hair="#E67E22", coat="#F4E4C0",
                        inner="#C8A060", accent="#F39C12",
                        halo="#FFD75E"),

    # --- los Cuatro Arcangeles ---------------------------------------------
    # Todos con halo, y cada uno con el color de su gracia: relampago, sol,
    # torbellino y oceano. Es lo unico que los separa a simple vista, asi que el
    # acento y el pelo cargan con todo el peso.
    "sds_ludociel": dict(skin="#F4E0C8", hair="#F0F4F8", coat="#E8EEF4",
                         inner="#B8C4D4", accent="#5DADE2",
                         halo="#AEE0FF"),
    "sds_mael": dict(skin="#F2D9C0", hair="#F4E4B0", coat="#FBF0D8",
                     inner="#D4B878", accent="#F39C12",
                     halo="#FFD75E"),
    "sds_sariel": dict(skin="#F0DCC4", hair="#CFEFD8", coat="#E4F4E8",
                       inner="#9CC4A8", accent="#2ECC71",
                       halo="#BFF0D0"),
    "sds_tarmiel": dict(skin="#EFDCC8", hair="#BCE0F0", coat="#DCEEF8",
                        inner="#84A8C4", accent="#2980B9",
                        halo="#AEE0FF"),

    # --- el Purgatorio ------------------------------------------------------
    "sds_demon_king": dict(skin="#3A1C48", hair="#0A0610", coat="#1A0A24",
                           inner="#0E0414", accent="#C0392B",
                           horns="#F0E4D0", demon_eyes=True),
    "sds_chandler": dict(skin="#6B4878", hair="#241030", coat="#4A2058",
                         inner="#2A1034", accent="#BB8FCE",
                         horns="#E0D0E8", demon_eyes=True),
    "sds_cusack": dict(skin="#5A5A68", hair="#1A1A22", coat="#33333F",
                       inner="#1E1E28", accent="#95A5A6",
                       horns="#D8D8E0", demon_eyes=True),
}

# El pecado que porta cada actor con nombre. Lo usa el icono del actor y lo
# consume Actors.cs del lado C#.
SIN_ACTORS = {
    "sds_meliodas": "sin_wrath",
    "sds_ban": "sin_greed",
    "sds_diane": "sin_envy",
    "sds_gowther": "sin_lust",
    "sds_king": "sin_sloth",
    "sds_merlin": "sin_gluttony",
    "sds_escanor": "sin_pride",
}


# ---------------------------------------------------------------------------
# CATALOGO DE ICONOS: (id, glifo, placa, color de placa, color de glifo)
# ---------------------------------------------------------------------------

ICON_SPECS = []


def I(tid, glyph, plate, plate_hex, glyph_hex):
    ICON_SPECS.append((tid, glyph, plate, plate_hex, glyph_hex))


# clanes: escudo
I("sds_clan_human", "clan_human", "shield", "#C8A27A", "#4A3018")
I("sds_clan_demon", "clan_demon", "shield", "#7A1F2B", "#F0C0C0")
I("sds_clan_goddess", "clan_goddess", "shield", "#F4D03F", "#7A5A00")
I("sds_clan_fairy", "clan_fairy", "shield", "#27AE60", "#D8FFE0")
I("sds_clan_giant", "clan_giant", "shield", "#935116", "#F0D0A0")
I("sds_clan_vampire", "clan_vampire", "shield", "#5B2C6F", "#F0D0E0")

# pecados: estrella, con la bestia dentro
I("sds_sin_wrath", "sin_wrath", "crest", "#1E6B45", "#B8F0D0")
I("sds_sin_greed", "sin_greed", "crest", "#A03024", "#F8D0C0")
I("sds_sin_envy", "sin_envy", "crest", "#C4661A", "#FFE0B0")
I("sds_sin_lust", "sin_lust", "crest", "#B8709A", "#FFE0F0")
I("sds_sin_sloth", "sin_sloth", "crest", "#6B5808", "#F0E0A0")
I("sds_sin_gluttony", "sin_gluttony", "crest", "#4A2358", "#E0C0F0")
I("sds_sin_pride", "sin_pride", "crest", "#D07018", "#FFE8B0")

# mandamientos: rombo
I("sds_cmd_piety", "cmd_piety", "diamond", "#8E44AD", "#F0DCF8")
I("sds_cmd_love", "cmd_love", "diamond", "#C2185B", "#FFD8E8")
I("sds_cmd_truth", "cmd_truth", "diamond", "#16A085", "#D0FFF4")
I("sds_cmd_faith", "cmd_faith", "diamond", "#2471A3", "#D0E8FF")
I("sds_cmd_selflessness", "cmd_selflessness", "diamond", "#1E8449", "#D0FFE0")
I("sds_cmd_pacifism", "cmd_pacifism", "diamond", "#6C7A7D", "#EAF2F4")
I("sds_cmd_repose", "cmd_repose", "diamond", "#1ABC9C", "#D8FFF8")
I("sds_cmd_patience", "cmd_patience", "diamond", "#7E5109", "#F8E0B0")
I("sds_cmd_reticence", "cmd_reticence", "diamond", "#2C3E50", "#C8D8E8")
I("sds_cmd_purity", "cmd_purity", "diamond", "#3498DB", "#E0F4FF")

# magia: disco
I("sds_magic_strengthener", "magic_strengthener", "disc", "#C0392B", "#FFD8D0")
I("sds_magic_enchanter", "magic_enchanter", "disc", "#8E44AD", "#F0D8FF")
I("sds_magic_incantation", "magic_incantation", "disc", "#2980B9", "#D8ECFF")
I("sds_magic_healer", "magic_healer", "disc", "#27AE60", "#D8FFE4")
I("sds_magic_special", "magic_special", "disc", "#D4AC0D", "#FFF4C0")

# rangos: estandarte (NO escudo — el escudo ya es de los clanes, y dos familias
# con la misma silueta es exactamente el problema que las placas resuelven)
I("sds_rank_apprentice", "rank_apprentice", "banner", "#7F8C8D", "#ECF0F1")
I("sds_rank_holy_knight", "rank_holy_knight", "banner", "#95A5A6", "#FFFFFF")
I("sds_rank_great_holy_knight", "rank_great_holy_knight", "banner", "#D4AC0D", "#FFF8D0")
I("sds_rank_grand_master", "rank_grand_master", "banner", "#CA6F1E", "#FFE0A0")

# habilidades: hexagono
I("sds_ability_full_counter", "ability_full_counter", "hex", "#1E6B45", "#C0FFE0")
I("sds_ability_snatch", "ability_snatch", "hex", "#A03024", "#FFD0C0")
I("sds_ability_creation", "ability_creation", "hex", "#7E5109", "#F0D8A0")
I("sds_ability_invasion", "ability_invasion", "hex", "#B8709A", "#FFE4F4")
I("sds_ability_disaster", "ability_disaster", "hex", "#1E8449", "#D0FFE0")
I("sds_ability_infinity", "ability_infinity", "hex", "#4A2358", "#E8C8FF")
I("sds_ability_sunshine", "ability_sunshine", "hex", "#E67E22", "#FFF4C0")
I("sds_ability_hellblaze", "ability_hellblaze", "hex", "#241028", "#B060C8")
I("sds_ability_ark", "ability_ark", "hex", "#D4AC0D", "#FFFCE0")
I("sds_ability_purge", "ability_purge", "hex", "#D8D8E8", "#FFFFFF")

# rasgos sueltos: placa cuadrada
I("sds_immortal", "immortal", "tag", "#A03024", "#FFD8D0")
I("sds_reincarnation", "reincarnation", "tag", "#D4AC0D", "#FFF4C0")
I("sds_demon_blood", "demon_blood", "tag", "#7A1F2B", "#F0B0B0")
I("sds_goddess_blood", "goddess_blood", "tag", "#D4AC0D", "#FFFCE0")
I("sds_fairy_wings", "fairy_wings", "tag", "#27AE60", "#D8FFE8")
I("sds_giant_strength", "giant_strength", "tag", "#935116", "#F8D8A8")
I("sds_vampire_thirst", "vampire_thirst", "tag", "#5B2C6F", "#F8D8E8")
I("sds_druid", "druid", "tag", "#16A085", "#D0FFF0")

# habilidades de clase: hexagono, agrupadas por color de su magia para que se
# vea de un vistazo a que clase pertenece cada una
I("sds_ability_iron_skin", "iron_skin", "hex", "#8E3226", "#FFD8CC")
I("sds_ability_heavy_blow", "heavy_blow", "hex", "#A0392B", "#FFD0C0")
I("sds_ability_berserk", "berserk", "hex", "#7B1F14", "#FFC0B0")

I("sds_ability_bless_weapon", "bless_weapon", "hex", "#7D3C98", "#EFD8FA")
I("sds_ability_ward", "ward", "hex", "#6C3483", "#E8D0F5")
I("sds_ability_battle_hymn", "battle_hymn", "hex", "#5B2C6F", "#E0C4F0")

I("sds_ability_spark", "spark", "hex", "#2471A3", "#D4E9F8")
I("sds_ability_frost_lance", "frost_lance", "hex", "#1F6690", "#CCE6F6")
I("sds_ability_meteor", "meteor", "hex", "#1A5276", "#C4DEF2")

I("sds_ability_mend", "mend", "hex", "#1E8449", "#D0F5DE")
I("sds_ability_cleanse", "cleanse", "hex", "#17795E", "#CCF2E4")
I("sds_ability_vigor", "vigor", "hex", "#128C60", "#C8F5E0")

I("sds_ability_mimic", "mimic", "hex", "#B8860B", "#FFF0C0")
I("sds_ability_displace", "displace", "hex", "#A87A08", "#FFEBB0")
I("sds_ability_unravel", "unravel", "hex", "#96690A", "#FFE4A8")

# gracias de los Cuatro Arcangeles: hexagono, como el resto de habilidades
I("sds_ability_flash", "ability_flash", "hex", "#2874A6", "#D6EAF8")
I("sds_ability_tornado", "ability_tornado", "hex", "#1E8449", "#D4F5E0")
I("sds_ability_ocean", "ability_ocean", "hex", "#1A5276", "#CFE8F8")

# estados: disco (la familia mas neutra, no compite con ninguna otra)
I("sds_status_reinforced", "status_reinforced", "disc", "#C0392B", "#FFD8D0")
I("sds_status_enchanted", "status_enchanted", "disc", "#8E44AD", "#F0D8FF")
I("sds_status_special_magic", "status_special_magic", "disc", "#D4AC0D", "#FFF4C0")
# Las diez maldiciones de los Mandamientos: el simbolo de su ley sobre disco
# oscuro. Reutilizan el glifo del mandamiento a proposito — el jugador tiene que
# poder mirar el estado y saber QUE ley ha roto sin abrir nada.
I("sds_status_curse_piety", "cmd_piety", "disc", "#4A2458", "#E8D0F4")
I("sds_status_curse_love", "cmd_love", "disc", "#6E1636", "#F8D0E0")
I("sds_status_curse_truth", "cmd_truth", "disc", "#0E5448", "#C8F0E4")
I("sds_status_curse_faith", "cmd_faith", "disc", "#153B5A", "#CCE4F8")
I("sds_status_curse_selflessness", "cmd_selflessness", "disc", "#12482A", "#C8F0D8")
I("sds_status_curse_pacifism", "cmd_pacifism", "disc", "#3C4446", "#DCE4E6")
I("sds_status_curse_repose", "cmd_repose", "disc", "#106054", "#CCF4EC")
I("sds_status_curse_patience", "cmd_patience", "disc", "#4A3006", "#F0DCB0")
I("sds_status_curse_reticence", "cmd_reticence", "disc", "#1A242E", "#C0D0E0")
I("sds_status_curse_purity", "cmd_purity", "disc", "#1C5478", "#CCE8F8")

# Transformaciones y estados de habilidad.
I("sds_status_demon_mark", "clan_demon", "disc", "#5A1420", "#F0B0B0")
I("sds_status_assault_mode", "sin_wrath", "disc", "#8E1F1F", "#FFD0C0")
I("sds_status_the_one", "ability_sunshine", "disc", "#C87A0C", "#FFF4C0")
I("sds_status_hellblaze", "ability_hellblaze", "disc", "#1C0C22", "#B060C8")
I("sds_status_infinity", "ability_infinity", "disc", "#3A1848", "#E0C0F8")
I("sds_status_indura", "clan_demon", "banner", "#3A0C40", "#E8B0F0")
I("sds_status_ark_blessing", "ability_ark", "disc", "#B8930A", "#FFFCE0")
I("sds_status_full_counter_ready", "ability_full_counter", "disc", "#14503A", "#C0FFE0")

I("sds_status_petrified", "status_petrified", "disc", "#616A6B", "#D5DBDB")
I("sds_status_paralyzed", "status_paralyzed", "disc", "#7D3C98", "#E8D5F0")
I("sds_status_ash", "status_ash", "disc", "#5D6D7E", "#D5DBDB")
I("sds_status_soul_stolen", "status_soul_stolen", "disc", "#2874A6", "#D6EAF8")
I("sds_status_drowning", "status_drowning", "disc", "#1A5276", "#CFE8F8")


# id -> (color de hoja, color de empunadura, glifo del icono, color de placa)
TREASURES = {
    "sds_item_lostvayne": ("#DCE6F0", "#2C3E50", "weapon_sword", "#2C3E50"),
    "sds_item_courechouse": ("#EDEFF2", "#7B241C", "weapon_staff", "#7B241C"),
    "sds_item_chastiefol": ("#C8F0D8", "#1E5537", "weapon_spear", "#1E5537"),
    "sds_item_gideon": ("#F0D97A", "#6E2C00", "weapon_hammer", "#6E2C00"),
    "sds_item_herritt": ("#F8DCE8", "#5B2C6F", "weapon_bow", "#5B2C6F"),
    "sds_item_aldan": ("#E0C8F0", "#4A235A", "weapon_orb", "#4A235A"),
    "sds_item_rhitta": ("#FFD98A", "#7E5109", "weapon_axe", "#7E5109"),
}

PROJECTILES_SPEC = {
    "sds_proj_ark": ("#F7DC6F", "orb"),
    "sds_proj_magic": ("#5DADE2", "bolt"),
    "sds_proj_hellblaze": ("#8E44AD", "orb"),
    "sds_proj_chastiefol": ("#27AE60", "spear"),
    "sds_proj_creation": ("#935116", "rock"),
    "sds_proj_herritt": ("#D98CB3", "arrow"),
}


# Icono propio de cada actor: (glifo, forma de placa). Ninguna pareja se repite.
ACTOR_ICONS = {
    # los cinco pueblos: escudo, como sus clanes
    "sds_demon":       ("clan_demon", "shield"),
    "sds_goddess":     ("clan_goddess", "shield"),
    "sds_fairy":       ("clan_fairy", "shield"),
    "sds_giant":       ("clan_giant", "shield"),
    "sds_vampire":     ("clan_vampire", "shield"),

    # demonios menores y bestias: placas distintas para no chocar con el pueblo
    "sds_gray_demon":  ("magic_strengthener", "tag"),
    "sds_red_demon":   ("ability_hellblaze", "tag"),
    "sds_indura":      ("sin_wrath", "banner"),

    # los siete pecados: estrella con su bestia
    "sds_meliodas":    ("sin_wrath", "crest"),
    "sds_ban":         ("sin_greed", "crest"),
    "sds_diane":       ("sin_envy", "crest"),
    "sds_gowther":     ("sin_lust", "crest"),
    "sds_king":        ("sin_sloth", "crest"),
    "sds_merlin":      ("sin_gluttony", "crest"),
    "sds_escanor":     ("sin_pride", "crest"),

    # los cuatro arcangeles: rombo con su gracia
    "sds_ludociel":    ("ability_flash", "diamond"),
    "sds_mael":        ("ability_sunshine", "diamond"),
    "sds_sariel":      ("ability_tornado", "diamond"),
    "sds_tarmiel":     ("ability_ocean", "diamond"),

    # purgatorio: hexagono
    "sds_demon_king":  ("cmd_piety", "hex"),
    "sds_chandler":    ("cmd_reticence", "hex"),
    "sds_cusack":      ("cmd_patience", "hex"),
}

# Quien tiene cuerpo propio: los cinco pueblos y las tres criaturas.
#
# Los personajes con nombre NO estan aqui a proposito. Meliodas es un humano del
# juego con traits puestos; un cuerpo exclusivo para una sola persona es un actor
# mas que mantener para decir algo que un trait ya dice.
BODIED_ACTORS = [
    "sds_goddess", "sds_fairy", "sds_giant", "sds_demon", "sds_vampire",
    "sds_gray_demon", "sds_red_demon", "sds_indura",
]


# ---------------------------------------------------------------------------
# ERAS DEL MUNDO  (el sistema propio del juego, no una pestana aparte)
# ---------------------------------------------------------------------------
#
# El juego pide dos imagenes por era y con tamanos distintos a todo lo demas:
# un icono de 26x26 para la rueda de eras y un fondo de 110x110 para la ventana.
# Los tamanos estan tomados de un mod que ya registra una era y funciona.

ERAS = [
    # (id, glifo, placa, color placa, color glifo, fondo arriba, fondo abajo)
    ("sds_age_holy_war", "cmd_piety", "diamond", "#7A1F2B", "#F0C0C0", "#2A0810", "#7A1F2B"),
    ("sds_age_seven_sins", "sin_wrath", "crest", "#1E6B45", "#B8F0D0", "#0E2A1C", "#2E8B57"),
    ("sds_age_commandments", "cmd_truth", "diamond", "#4A2358", "#E0C0F0", "#140820", "#5B2C6F"),
]


def gen_era(age_id, glyph, plate, plate_hex, glyph_hex, top_hex, bottom_hex):
    cv, ring = build_plate(plate, plate_hex)
    pr = ramp(plate_hex)
    art = glyphs.parse(glyph)
    if art:
        gr = ramp(glyph_hex)
        lv = px.contrast_level(gr, pr[px.BASE + 1], want=0.30)
        stamp_glyph(cv, art, gr, lv, cv.keys() - ring)
    emblem16 = cv.image()

    # --- icono 26x26 ------------------------------------------------------
    #
    # Se dibuja a 16x16 y se escala x2 a 32x32 antes de recortar el centro a
    # 26x26. Escalar por un factor entero mantiene el pixel nitido; ir de 16 a 26
    # directamente lo emborronaria, que a este tamano se nota mucho.
    big = emblem16.resize((32, 32), Image.NEAREST)
    px.save(big.crop((3, 3, 29, 29)), OTHER, "iconAge_" + age_id, REPORT,
            size=(26, 26))

    # --- fondo 110x110 ----------------------------------------------------
    #
    # Aqui SI hay degradado continuo: el fondo no es un sprite del mundo sino
    # una lamina de interfaz, no pasa por el atlas de sprites y nadie le exige
    # alfa binario. Lleva tramado de Bayer porque un degradado de 110 filas
    # entre dos colores oscuros produce bandas visibles, y viñeteado para que el
    # emblema del centro no compita con las esquinas.
    top = px.hexc(top_hex)
    bot = px.hexc(bottom_hex)
    bg = Image.new("RGBA", (110, 110), (0, 0, 0, 255))
    pix = bg.load()
    for y in range(110):
        t = y / 109.0
        for x in range(110):
            # Viñeteado radial: mas oscuro cuanto mas lejos del centro.
            dx, dy = (x - 55) / 55.0, (y - 55) / 55.0
            vig = 1.0 - 0.45 * min(1.0, (dx * dx + dy * dy) ** 0.7)
            tt = t + (0.035 if px.dither(x, y, (t * 8) % 1.0) else 0.0)
            c = [int((top[i] + (bot[i] - top[i]) * min(1.0, tt)) * vig)
                 for i in range(3)]
            pix[x, y] = (c[0], c[1], c[2], 255)

    # Rayos que salen de detras del emblema: dan foco al centro sin tapar nada.
    for k in range(12):
        a = k * (math.pi / 6) + 0.26
        for r in range(26, 62):
            xx = int(55 + math.cos(a) * r)
            yy = int(55 + math.sin(a) * r)
            if 0 <= xx < 110 and 0 <= yy < 110 and px.dither(xx, yy, 0.55):
                o = pix[xx, yy]
                f = 1.0 + 0.30 * (1.0 - (r - 26) / 36.0)
                pix[xx, yy] = (min(255, int(o[0] * f)), min(255, int(o[1] * f)),
                               min(255, int(o[2] * f)), 255)

    emblem = emblem16.resize((64, 64), Image.NEAREST)
    bg.paste(emblem, (23, 23), emblem)
    px.save(bg, OTHER, age_id + "_background", REPORT, size=(110, 110))
    return 2


# ---------------------------------------------------------------------------
# VISTA PREVIA
# ---------------------------------------------------------------------------

def build_preview():
    """Hojas de contactos y GIF. Sin esto no hay forma humana de revisar 290
    imagenes de 16x16: hay que verlas grandes, juntas y en movimiento."""
    import glob
    os.makedirs(PREVIEW, exist_ok=True)

    px.contact_sheet(sorted(glob.glob(os.path.join(ICONS, "*.png"))), 12, 4,
                     os.path.join(PREVIEW, "icons.png"))

    fx_paths = []
    for d in sorted(glob.glob(os.path.join(EFFECTS, "sds_fx_*"))):
        for i in range(FX_FRAMES):
            p = os.path.join(d, "%d.png" % i)
            if os.path.exists(p):
                fx_paths.append(p)
    px.contact_sheet(fx_paths, FX_FRAMES, 4, os.path.join(PREVIEW, "effects.png"))

    body = []
    for d in sorted(glob.glob(os.path.join(ACTORS, "*", "Main"))):
        for i in range(4):
            p = os.path.join(d, "walk_%d.png" % i)
            if os.path.exists(p):
                body.append(p)
    body += sorted(glob.glob(os.path.join(WEAPONS, "*.png")))
    for d in sorted(glob.glob(os.path.join(PROJECTILES, "*"))):
        body += sorted(glob.glob(os.path.join(d, "*.png")))
    px.contact_sheet(body, 8, 6, os.path.join(PREVIEW, "actors_items.png"))

    # GIF del caminado, a velocidad de juego, para ver si la animacion cojea.
    for d in sorted(glob.glob(os.path.join(ACTORS, "*", "Main"))):
        frames = []
        for i in range(4):
            p = os.path.join(d, "walk_%d.png" % i)
            if os.path.exists(p):
                im = Image.open(p).convert("RGBA")
                bgim = Image.new("RGBA", im.size, (38, 38, 46, 255))
                bgim.paste(im, (0, 0), im)
                frames.append(bgim.resize((96, 96), Image.NEAREST))
        if len(frames) == 4:
            name = os.path.basename(os.path.dirname(d))
            frames[0].save(os.path.join(PREVIEW, "walk_%s.gif" % name),
                           save_all=True, append_images=frames[1:],
                           duration=140, loop=0)
    return PREVIEW


# ---------------------------------------------------------------------------

def main():
    n = 0

    for spec in ERAS:
        n += gen_era(*spec)

    # SOLO LAS BESTIAS TIENEN CUERPO PROPIO.
    #
    # Las personas del mod son humanos vanilla del juego y usan su arte, asi que
    # generar sprites de cuerpo para Demonio, Diosa, Meliodas y compania
    # producia sesenta PNG que no cargaba nadie.
    # Los PUEBLOS se dibujan en el formato de fenotipos (male_1/female_1/...);
    # las CRIATURAS en la carpeta Main. Mezclarlos fue lo que dejo a las razas
    # visibles pero imposibles de seleccionar.
    RACE_ACTORS = ("sds_goddess", "sds_fairy", "sds_giant", "sds_demon", "sds_vampire")
    for actor_id in BODIED_ACTORS:
        if actor_id in RACE_ACTORS:
            n += gen_race_actor(actor_id, RACES[actor_id])
        else:
            n += gen_actor(actor_id, RACES[actor_id])

    # EL ICONO, EN CAMBIO, LO NECESITAN LOS VEINTIDOS.
    #
    # Actors.cs asigna a.icon = "ui/icons/" + id a CADA actor que registra, y
    # SDSTab compone la misma ruta para el boton de invocacion. Durante un
    # tiempo este bucle estuvo dentro del de las bestias, asi que solo se
    # regeneraban tres de los veintidos y los otros diecinueve se quedaban en el
    # disco tal y como los dejo una version anterior del generador. No fallaba
    # nada — los archivos existian — pero eran de otra epoca grafica, y en la
    # rejilla de la interfaz se veian diecinueve iconos planos entre noventa con
    # relieve. Un fallo asi no lo caza el juego: hay que mirar la carpeta.
    missing = set(ACTOR_ICONS) - set(RACES)
    if missing:
        raise KeyError("actores con icono pero sin paleta: %s" % sorted(missing))
    for actor_id, (glyph, plate) in ACTOR_ICONS.items():
        spec = RACES[actor_id]
        n += gen_icon(actor_id, glyph, plate, spec["coat"], spec["accent"])

    for tid, glyph, plate, ph, gh in ICON_SPECS:
        n += gen_icon(tid, glyph, plate, ph, gh)

    for fx, (style, hexcol) in FX_STYLES.items():
        n += gen_effect(fx, style, hexcol)

    for pid, (hexcol, shape) in PROJECTILES_SPEC.items():
        n += gen_projectile(pid, hexcol, shape)

    for wid, (blade, grip, glyph, plate) in TREASURES.items():
        n += gen_weapon(wid, blade, grip, glyph, plate)

    # Metadatos de pivote de la carpeta de armas.
    #
    # SpriteTextureLoader no encuentra los sprites de una carpeta sin este
    # archivo: sin el, el cargador devolvia una lista vacia y los siete tesoros
    # acababan usando el sprite prestado de una espada de acero. El pivote en
    # (0.5, 0.1) es el que usa el mod de referencia — pone el punto de agarre en
    # la base del arma, que es por donde la sujeta la mano.
    os.makedirs(WEAPONS, exist_ok=True)
    with open(os.path.join(WEAPONS, "sprites.json"), "w", encoding="utf-8") as f:
        f.write('{\n  "Default": {\n'
                '    "PivotX": 0.5,\n'
                '    "PivotY": 0.1,\n'
                '    "Z": 2.0,\n'
                '    "Scale": 1.0\n'
                '  }\n}\n')

    print("%d imagenes generadas." % n)
    print(REPORT.summary())
    for e in REPORT.errors:
        print("  ERROR  %s" % e)
    for w in REPORT.warnings:
        print("  aviso  %s" % w)

    if "--preview" in sys.argv:
        print("vista previa en %s" % build_preview())

    return 1 if REPORT.errors else 0


if __name__ == "__main__":
    sys.exit(main())
