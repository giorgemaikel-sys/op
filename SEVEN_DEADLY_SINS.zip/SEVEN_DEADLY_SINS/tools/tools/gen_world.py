"""
Genera lo que le faltaba al mod para que las razas se vean y construyan:

  1. LOS CUERPOS DE RAZA, en el juego completo de archivos que espera el
     pipeline de fenotipos. No son cuatro fotogramas de caminado: son veintiuno
     por carpeta de piel, y las piezas que faltaban llegaban al juego como null
     — trescientas NullReferenceException en GroupSpriteObject.setSprite.

     Por carpeta de piel:
        walk_0..3.png          el cuerpo
        walk_0..3_head.png     1x1 TRANSPARENTE
        walk_0..3_item.png     1x1 TRANSPARENTE
        swim_0..3.png          el cuerpo, hundido
        swim_0..3_head.png     1x1 TRANSPARENTE
        sprites.json           pivotes de cabeza e item

     Lo de 1x1 no es un atajo: es lo que hace el mod de referencia. Cuando el
     sprite del cuerpo ya incluye la cabeza, la superposicion tiene que existir
     y no pintar nada. Un archivo ausente es null; un pixel transparente no.

  2. LOS EDIFICIOS, uno por orden de construccion y por raza.

     Por edificio:
        main_0.png                 en pie
        construction_0.png         en obra
        constructionShadow_0.png   su sombra
        ruin_0.png                 en ruinas
        mini_0.png                 punto del minimapa

     Los tamanos salen de medir los del mod de referencia, no de inventarlos:
     una casa mide 16x15, un salon 51x27, un cuartel 31x33, una torre 13x27.
     La obra siempre 20x16 salvo la torre, que va 12x11.

Uso:  python tools/gen_world.py
"""

from PIL import Image
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
MOD = os.path.dirname(HERE)
RES = os.path.join(MOD, "GameResources")

NONE = (0, 0, 0, 0)


def hexc(h):
    h = h.lstrip("#")
    return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), 255)


def shade(c, f):
    return (max(0, min(255, int(c[0] * f))),
            max(0, min(255, int(c[1] * f))),
            max(0, min(255, int(c[2] * f))), 255)


# Superposiciones vacias: 4x4 transparente.
#
# El mod de referencia usa 1x1 y funciona igual; probe 4x4 pensando que el
# IndexOutOfRangeException de PixelBag durante preloadPixelBagsUnits venia de un
# lienzo demasiado pequeno. NO ERA ESO: el error persiste identico con ambos
# tamanos. Queda en 4x4 porque es igual de invisible y no cuesta nada, pero que
# nadie lea aqui que esto arregla el PixelBag, porque no lo hace.
#
# Ese error sigue SIN DIAGNOSTICAR. Salta una sola vez en la precarga, no por
# frame, y no impide jugar. Siguiente pista a seguir: que sprite concreto le
# llega, porque la traza no lo dice.
def blank(w=4, h=4):
    return Image.new("RGBA", (w, h), NONE)


def save(im, folder, name):
    os.makedirs(folder, exist_ok=True)
    im.save(os.path.join(folder, name + ".png"))


# ---------------------------------------------------------------------------
# PALETAS
# ---------------------------------------------------------------------------

RACES = {
    "sds_goddess": dict(skin="#F2D9C0", hair="#F4E4B0", coat="#EFEFE4", inner="#C8C2B0",
                        accent="#F4D03F", halo="#FFE98A"),
    "sds_fairy":   dict(skin="#F0DCC4", hair="#E8A0C0", coat="#2E7D4F", inner="#1E5537",
                        accent="#9BE8A0", wings="#BFF0D0"),
    "sds_giant":   dict(skin="#D9A88A", hair="#6B3F1F", coat="#B5651D", inner="#7A4212",
                        accent="#E8C07A"),
    "sds_demon":   dict(skin="#7A5480", hair="#1A1220", coat="#3B1F2B", inner="#241019",
                        accent="#C0392B", horns="#E8DCC8", eyes=True),
    "sds_vampire": dict(skin="#CFC3D6", hair="#14101A", coat="#4A1020", inner="#2A0A12",
                        accent="#D64550", cape="#2A0810", eyes=True),
}

# Material de construccion por raza: muro, tejado, detalle.
BUILD_PALETTE = {
    "sds_goddess": ("#EDEAE0", "#C9A227", "#FFF6D0"),   # piedra blanca y oro
    "sds_fairy":   ("#8B6B43", "#2E7D4F", "#C8F0D0"),   # madera y follaje
    "sds_giant":   ("#9A9088", "#6E5340", "#C6BDB2"),   # piedra basta
    "sds_demon":   ("#4A3038", "#7A1F2B", "#C0392B"),   # piedra oscura
    "sds_vampire": ("#3A3040", "#4A1020", "#8E6C9E"),   # piedra morada
}

S = 16          # lienzo del cuerpo
FEET = 15
WALK_LIFT = [0, 2, 1, 0]


# ---------------------------------------------------------------------------
# CUERPOS
# ---------------------------------------------------------------------------

HEAD_T, HEAD_B = 4, 7
TORSO_T, TORSO_B = 8, 11
LEG_T, LEG_B = 12, 15
BODY_L, BODY_R = 5, 10
ARM_L, ARM_R = 4, 11


class Canvas:
    def __init__(self, w=S, h=S):
        self.w, self.h = w, h
        self.px = {}

    def put(self, x, y, c):
        if c is None or c[3] == 0:
            return
        x, y = int(x), int(y)
        if 0 <= x < self.w and 0 <= y < self.h:
            self.px[(x, y)] = (c[0], c[1], c[2], 255)

    def rect(self, x0, y0, x1, y1, c):
        for y in range(int(y0), int(y1) + 1):
            for x in range(int(x0), int(x1) + 1):
                self.put(x, y, c)

    def image(self):
        im = Image.new("RGBA", (self.w, self.h), NONE)
        for (x, y), c in self.px.items():
            im.putpixel((x, y), c)
        return im


def draw_body(cv, sp, dy, pose, swim=False):
    skin = hexc(sp["skin"])
    hair = hexc(sp["hair"])
    coat = hexc(sp["coat"])
    inner = shade(hexc(sp["inner"]), 0.72)
    coat_d = shade(coat, 0.72)

    L, R = BODY_L, BODY_R
    AL, AR = ARM_L, ARM_R

    def row(r):
        return r - dy

    if swim:
        # Nadando: el cuerpo va hundido hasta el pecho. Sin esto, una unidad en
        # el agua se ve de pie dentro de un charco.
        water = (90, 127, 184, 255)
        light = (143, 180, 224, 255)
        wl = row(TORSO_T) + 1
        cv.rect(L, row(HEAD_T), R, row(HEAD_B), skin)
        cv.rect(L, row(HEAD_T), R, row(HEAD_T) + 1, hair)
        cv.rect(L, row(TORSO_T), R, wl - 1, coat)
        cv.rect(L - 1, wl, R + 1, wl, light)
        cv.rect(L - 2, wl + 1, R + 2, wl + 1, water)
        return

    # piernas, con zancada lateral para que el paso se lea
    if pose == 1:
        cv.rect(L - 1, row(LEG_T), L - 1, row(LEG_B) - 1, inner)
        cv.rect(R, row(LEG_T), R, row(LEG_B), inner)
    elif pose == 2:
        cv.rect(L, row(LEG_T), L, row(LEG_B), inner)
        cv.rect(R + 1, row(LEG_T), R + 1, row(LEG_B) - 1, inner)
    else:
        cv.rect(L, row(LEG_T), L, row(LEG_B), inner)
        cv.rect(R, row(LEG_T), R, row(LEG_B), inner)

    if sp.get("cape"):
        cv.rect(L - 1, row(TORSO_T) - 1, R + 1, row(TORSO_B) + 1, hexc(sp["cape"]))

    cv.rect(L, row(TORSO_T), R, row(TORSO_B), coat)
    cv.rect(R, row(TORSO_T), R, row(TORSO_B), coat_d)

    swing = 1 if pose in (1, 3) else 0
    cv.rect(AL, row(TORSO_T) + swing, AL, row(TORSO_B) - 1 + swing, coat_d)
    cv.rect(AR, row(TORSO_T) - swing, AR, row(TORSO_B) - 1 - swing, coat_d)

    if sp.get("wings"):
        w = hexc(sp["wings"])
        flap = 1 if pose in (1, 2) else 0
        cv.rect(L - 3, row(TORSO_T) - 1 - flap, L - 2, row(TORSO_T) + 1, w)
        cv.rect(R + 2, row(TORSO_T) - 1 - flap, R + 3, row(TORSO_T) + 1, w)

    cv.rect(L, row(HEAD_T), R, row(HEAD_B), skin)
    cv.rect(L, row(HEAD_T), R, row(HEAD_T) + 1, hair)
    cv.put(L - 1, row(HEAD_T) + 1, hair)
    cv.put(R + 1, row(HEAD_T) + 1, hair)

    if sp.get("horns"):
        h = hexc(sp["horns"])
        for x in (L - 1, R + 1):
            cv.put(x, row(HEAD_T) - 1, h)
            cv.put(x, row(HEAD_T) - 2, h)

    if sp.get("halo"):
        hl = hexc(sp["halo"])
        cv.rect(L + 1, row(HEAD_T) - 2, R - 1, row(HEAD_T) - 2, hl)
        cv.put(L, row(HEAD_T) - 1, hl)
        cv.put(R, row(HEAD_T) - 1, hl)

    if sp.get("accent"):
        cv.put(L + 1, row(TORSO_T) + 1, hexc(sp["accent"]))

    if sp.get("eyes"):
        eye = (235, 45, 45, 255)
        cv.put(L + 1, row(HEAD_T) + 2, eye)
        cv.put(R - 1, row(HEAD_T) + 2, eye)


# Las seis pieles que el binding de C# referencia.
SKINS = ["male_1", "female_1", "warrior_1", "king", "leader", "child"]

# Pivotes de cabeza e item. Copiados del mod de referencia: el juego los lee de
# aqui para colocar la superposicion, y sin el archivo no sabe donde ponerla.
SKIN_JSON = {
    "Specific": [
        {"Path": "walk_0_head.png", "PivotX": 4, "PivotY": 6, "RectX": 0, "RectY": -2},
        {"Path": "walk_1_head.png", "PivotX": 4, "PivotY": 8, "RectX": 0, "RectY": 0},
        {"Path": "walk_2_head.png", "PivotX": 4, "PivotY": 8, "RectX": 0, "RectY": -1},
        {"Path": "walk_3_head.png", "PivotX": 4, "PivotY": 6, "RectX": 0, "RectY": -2},
        {"Path": "swim_0_head.png", "PivotX": 4, "PivotY": 6, "RectX": 0, "RectY": -4},
        {"Path": "swim_1_head.png", "PivotX": 4, "PivotY": 8, "RectX": 0, "RectY": -5},
        {"Path": "swim_2_head.png", "PivotX": 4, "PivotY": 8, "RectX": 0, "RectY": -4},
        {"Path": "swim_3_head.png", "PivotX": 4, "PivotY": 6, "RectX": 0, "RectY": -5},
        {"Path": "walk_0_item.png", "PivotX": 1, "PivotY": 4},
        {"Path": "walk_1_item.png", "PivotX": 1, "PivotY": 7},
        {"Path": "walk_2_item.png", "PivotX": 1, "PivotY": 6},
        {"Path": "walk_3_item.png", "PivotX": 1, "PivotY": 5},
    ]
}


def gen_race(race_id, spec):
    """Las seis carpetas de piel, con las veintiuna piezas cada una."""
    n = 0
    base = os.path.join(RES, "actors", race_id)

    for skin in SKINS:
        folder = os.path.join(base, skin)

        for i in range(4):
            cv = Canvas()
            draw_body(cv, spec, WALK_LIFT[i], i)
            save(cv.image(), folder, "walk_%d" % i)

            sw = Canvas()
            draw_body(sw, spec, 0, i, swim=True)
            save(sw.image(), folder, "swim_%d" % i)

            # Cabeza e item: 1x1 transparente. El cuerpo ya trae la cabeza, pero
            # el archivo TIENE que existir o el juego recibe null.
            save(blank(), folder, "walk_%d_head" % i)
            save(blank(), folder, "walk_%d_item" % i)
            save(blank(), folder, "swim_%d_head" % i)
            n += 5

        with open(os.path.join(folder, "sprites.json"), "w", encoding="utf-8") as f:
            json.dump(SKIN_JSON, f, indent=2)
        n += 1

    return n


# ---------------------------------------------------------------------------
# EDIFICIOS
# ---------------------------------------------------------------------------

# id de orden -> (ancho, alto) del sprite en pie. Medidos del mod de referencia.
BUILDING_SIZE = {
    "tent": (16, 14),
    "house": (16, 15),
    "hall": (51, 27),
    "windmill": (20, 26),
    "fishing_docks": (20, 14),
    "docks": (24, 16),
    "watch_tower": (13, 27),
    "temple": (24, 24),
    "library": (22, 20),
    "market": (24, 18),
    "barracks": (31, 33),
}


def draw_building(kind, w, h, wall, roof, trim):
    """Un edificio: cuerpo, tejado a dos aguas, puerta y ventanas.

    Deliberadamente sencillo. A tamano de juego un edificio se lee por su
    SILUETA y por el color del tejado; los detalles finos se pierden, y lo que
    de verdad importa aqui es que el archivo exista y tenga la forma correcta.
    """
    cv = Canvas(w, h)
    wall_d = shade(wall, 0.78)
    roof_d = shade(roof, 0.75)

    roof_h = max(3, h // 3)
    body_top = roof_h

    # cuerpo
    cv.rect(1, body_top, w - 2, h - 1, wall)
    cv.rect(w - 2, body_top, w - 2, h - 1, wall_d)     # sombra lateral
    cv.rect(1, h - 1, w - 2, h - 1, wall_d)            # base

    # tejado a dos aguas
    for y in range(roof_h):
        inset = int((roof_h - 1 - y) * (w / 2.0) / max(1, roof_h))
        cv.rect(inset, y, w - 1 - inset, y, roof if y > 0 else roof_d)
    cv.rect(0, roof_h - 1, w - 1, roof_h - 1, roof_d)

    if kind == "watch_tower":
        # torre: estrecha, con almenas
        cv.rect(0, 0, w - 1, 2, roof)
        for x in range(0, w, 3):
            cv.put(x, 0, NONE)
        return cv

    # puerta centrada
    dw = max(2, w // 8)
    dx = w // 2 - dw // 2
    cv.rect(dx, h - max(3, h // 4), dx + dw - 1, h - 1, trim)

    # ventanas
    step = max(4, w // 5)
    for x in range(2, w - 3, step):
        if abs(x - w // 2) < dw:
            continue
        cv.rect(x, body_top + 2, x + 1, body_top + 3, trim)

    if kind == "windmill":
        # aspas
        cv.rect(w // 2 - 1, 0, w // 2, roof_h, trim)
        cv.rect(0, roof_h // 2, w - 1, roof_h // 2, trim)

    return cv


def draw_ruin(kind, w, h, wall):
    """Lo que queda cuando se cae.

    El primer intento recorria las columnas dandole a cada una una altura
    ligeramente distinta, y el resultado eran barras verticales: se leia como
    una empalizada, no como un edificio derruido. Lo que hace que algo parezca
    ruina es que quede MASA BAJA y CONTINUA, con dos trozos de muro en pie y
    cascotes sueltos delante.
    """
    cv = Canvas(w, h)
    wall_d = shade(wall, 0.62)
    rubble = shade(wall, 0.45)

    # base continua de escombros
    base = h - max(2, h // 5)
    cv.rect(1, base, w - 2, h - 1, wall_d)
    cv.rect(2, h - 1, w - 3, h - 1, rubble)

    # dos jirones de muro todavia en pie, a distinta altura
    left_h = int(h * 0.45)
    right_h = int(h * 0.62)
    lw = max(2, w // 6)

    cv.rect(1, base - left_h, 1 + lw - 1, base - 1, wall)
    cv.rect(1, base - left_h, 1, base - 1, wall_d)          # borde
    cv.rect(w - 1 - lw, base - right_h, w - 2, base - 1, wall)
    cv.rect(w - 2, base - right_h, w - 2, base - 1, wall_d)

    # el borde superior roto de cada jiron
    for x in range(1, 1 + lw):
        if x % 2:
            cv.put(x, base - left_h, NONE)
    for x in range(w - 1 - lw, w - 1):
        if x % 2:
            cv.put(x, base - right_h, NONE)

    # cascotes sueltos delante
    for i, x in enumerate(range(2, w - 2, 3)):
        cv.put(x, base - 1 - (i % 2), rubble)

    return cv


def draw_construction(w, h, wall):
    """El andamio. Siempre del mismo tamano salvo en la torre."""
    cv = Canvas(w, h)
    wood = hexc("#9A6B3F")
    dark = shade(wood, 0.7)
    cv.rect(1, h - 2, w - 2, h - 1, dark)
    for x in range(1, w - 1, 4):
        cv.rect(x, h // 2, x, h - 2, wood)
    cv.rect(1, h // 2, w - 2, h // 2, wood)
    cv.rect(2, h - 5, w - 5, h - 5, dark)
    return cv


def gen_buildings(race_id, palette):
    wall, roof, trim = (hexc(c) for c in palette)
    root = os.path.join(RES, "buildings", "civ_main", race_id)
    n = 0

    # Los diecinueve ids que genera Architecture.cs, con su tipo de forma.
    ids = [("tent_" + race_id, "tent")]
    for i in range(6):
        ids.append(("house_%s_%d" % (race_id, i), "house"))
    for i in range(3):
        ids.append(("hall_%s_%d" % (race_id, i), "hall"))
    for i in range(2):
        ids.append(("windmill_%s_%d" % (race_id, i), "windmill"))
    ids.append(("fishing_docks_" + race_id, "fishing_docks"))
    ids.append(("docks_" + race_id, "docks"))
    ids.append(("watch_tower_" + race_id, "watch_tower"))
    ids.append(("temple_" + race_id, "temple"))
    ids.append(("library_" + race_id, "library"))
    ids.append(("market_" + race_id, "market"))
    ids.append(("barracks_" + race_id, "barracks"))

    # DOS UBICACIONES POR EDIFICIO, y no es redundancia.
    #
    # El mod de referencia deja cada edificio tanto en buildings/civ_main/<raza>/<id>/ como en
    # buildings/<id>/. Con solo la primera, el juego seguia sin encontrar el sprite y
    # Building.calculateMainSprite devolvia null a razon de novecientas excepciones por partida.
    # Copiar en ambas cuesta unos kilobytes y cubre las dos rutas que el cargador prueba.
    flat_root = os.path.join(RES, "buildings")

    for bid, kind in ids:
        w, h = BUILDING_SIZE[kind]

        main = draw_building(kind, w, h, wall, roof, trim).image()
        ruin = draw_ruin(kind, w, h, wall).image()

        cw, ch = (12, 11) if kind == "watch_tower" else (20, 16)
        constr = draw_construction(cw, ch, wall).image()

        shadow = Canvas(cw, ch)
        shadow.rect(1, ch - 3, cw - 2, ch - 1, (0, 0, 0, 255))
        shadow_im = shadow.image()

        mw = max(2, w // 3)
        mh = max(2, h // 3)
        mini = Canvas(mw, mh)
        mini.rect(0, 0, mw - 1, mh - 1, roof)
        mini_im = mini.image()

        for folder in (os.path.join(root, bid), os.path.join(flat_root, bid)):
            save(main, folder, "main_0")
            save(ruin, folder, "ruin_0")
            save(constr, folder, "construction_0")
            save(shadow_im, folder, "constructionShadow_0")
            save(mini_im, folder, "mini_0")
            n += 5

    return n


def copy_actor_icons():
    """Duplica el icono de cada actor en ui/Icons/ con el nombre pelado.

    El campo ActorAsset.icon NO admite ruta: el juego antepone la carpeta. El
    mod de referencia deja su icono en GameResources/ui/Icons/<nombre>.png y en
    el asset escribe solo <nombre>. Copiamos ahi los que ya genera el generador
    principal en ui/icons/ para no mantener dos dibujos del mismo icono.
    """
    src = os.path.join(RES, "ui", "icons")
    dst = os.path.join(RES, "ui", "Icons")
    if not os.path.isdir(src):
        return 0

    os.makedirs(dst, exist_ok=True)
    n = 0
    for name in list(RACES) + ["sds_gray_demon", "sds_red_demon", "sds_indura"]:
        f = os.path.join(src, name + ".png")
        if os.path.exists(f):
            Image.open(f).save(os.path.join(dst, name + ".png"))
            n += 1
    return n


# Paletas de las criaturas, solo para completarles los fotogramas que les faltan.
BEASTS = {
    "sds_gray_demon": dict(skin="#8A8A8A", hair="#4A4A4A", coat="#5A5A5A", inner="#3A3A3A",
                           accent="#C0392B", horns="#C8C8C8", eyes=True),
    "sds_red_demon":  dict(skin="#B04030", hair="#3A1010", coat="#7A1F1F", inner="#4A1010",
                           accent="#FFAA33", horns="#F0D8B0", eyes=True),
    "sds_indura":     dict(skin="#4A2848", hair="#0F0812", coat="#22102A", inner="#140818",
                           accent="#FF3355", horns="#D8C0E0", eyes=True),
}


def complete_beasts():
    """Las criaturas necesitan fotogramas de NADO, no solo de caminado.

    ActorAssetLibrary avisa "missing all animation_swim" y "texture_path_baby
    doesn't exist" para cada una, y acto seguido PixelBag revienta con
    IndexOutOfRange durante la precarga. Las criaturas viven en una sola carpeta
    Main, asi que los fotogramas de nado van ahi al lado de los de caminado.
    """
    n = 0
    for beast_id, spec in BEASTS.items():
        folder = os.path.join(RES, "actors", beast_id, "Main")
        if not os.path.isdir(folder):
            continue
        for i in range(4):
            cv = Canvas()
            draw_body(cv, spec, 0, i, swim=True)
            save(cv.image(), folder, "swim_%d" % i)
            n += 1
    return n


def main():
    total = 0
    total += copy_actor_icons()
    total += complete_beasts()

    for race_id, spec in RACES.items():
        total += gen_race(race_id, spec)
        total += gen_buildings(race_id, BUILD_PALETTE[race_id])

    print("Generados %d archivos en %s" % (total, RES))
    print("  cuerpos: %d razas x %d pieles x 21 piezas" % (len(RACES), len(SKINS)))
    print("  edificios: %d razas x 19 edificios x 5 piezas" % len(RACES))


if __name__ == "__main__":
    main()
