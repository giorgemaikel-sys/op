# Seven Deadly Sins — WorldBox Mod

*Read in English below / Versión en inglés más abajo*

---

## 🇪🇸 Español

**Los Siete Pecados Capitales llegan a WorldBox, con todo lo de la serie.**

Un mod que trae Britannia entera a tu caja de arena: los Siete Pecados, los Diez
Mandamientos, los Cuatro Arcángeles, los seis clanes, los Caballeros Sagrados de Liones,
el Rey Demonio, la Diosa Suprema — y el Caos, del final del manga.

### Lo que incluye
- **47 personajes con nombre**, cada uno con su habilidad y su Tesoro Sagrado. Meliodas y su
  Full Counter, Ban y su Snatch, Escanor que sube y baja con el sol, Merlin y sus hechizos,
  King y Chastiefol que cambia de forma, Lostvayne creando clones…
- **El Nivel de Poder de la serie** (Fuerza + Espíritu + Magia), y ahora **sí decide los
  combates**: un Pecado arrasa a un caballero, un Mandamiento arrasa a un Pecado.
- **Los seis clanes** como razas jugables, cada uno con su magia por clase: un gigante
  hechicero no lanza lo mismo que un demonio hechicero.
- **El Purgatorio como un mapa aparte**: entra, y un minuto fuera son 525.600 años dentro.
  Quien aguanta ahí sale convertido en un monstruo. Con botones para entrar, salir, mandar
  y sacar unidades.
- **Herencia de sangre**: los hijos heredan la sangre de sus padres. Meliodas y Elizabeth
  dan un hijo mitad demonio, mitad diosa — como Tristán en *Four Knights of the Apocalypse*.
  Opcional: cualquier raza puede cruzarse con otra.
- **Las tres eras** de la historia, en la rueda de eras del propio juego.
- **Español e inglés**, según el idioma del juego.

### Configurable
Casi todo se puede apagar desde los ajustes del mod: el ciclo de Escanor, las maldiciones,
las Induras, los enfriamientos, el cruce entre razas…

---

## 🇬🇧 English

**The Seven Deadly Sins come to WorldBox, with everything from the series.**

A mod that brings all of Britannia into your sandbox: the Seven Sins, the Ten Commandments,
the Four Archangels, the six clans, the Holy Knights of Liones, the Demon King, the Supreme
Deity — and Chaos, from the end of the manga.

### Features
- **47 named characters**, each with their ability and Sacred Treasure. Meliodas and his
  Full Counter, Ban and his Snatch, Escanor rising and falling with the sun, Merlin and her
  spells, King and shape-shifting Chastiefol, Lostvayne spawning clones…
- **The series' Power Level** (Strength + Spirit + Magic) — and now it **actually decides
  fights**: a Sin crushes a knight, a Commandment crushes a Sin.
- **The six clans** as playable races, each with per-class magic: a giant sorcerer does not
  cast what a demon sorcerer casts.
- **Purgatory as a separate map**: step in, and one minute outside is 525,600 years inside.
  Whoever endures there comes out a monster. With buttons to enter, leave, send, and pull
  units out.
- **Bloodline inheritance**: children inherit their parents' blood. Meliodas and Elizabeth
  give a child half-demon, half-goddess — like Tristan in *Four Knights of the Apocalypse*.
  Optional: any race can breed with any other.
- **The three ages** of the story, woven into the game's own age wheel.
- **English and Spanish**, following the game's language.

### Configurable
Almost everything can be switched off in the mod settings: Escanor's cycle, the curses, the
Induras, cooldowns, cross-race breeding…

---

**Discord:** https://discord.gg/gv4mmtAGz — hay un botón dentro del propio mod, en la
pestaña de Leyendas. / there's a button inside the mod itself, on the Legends tab.
